C(61,11,2) 的证明与复核材料

proof.md 为中文数学文稿，cover39.txt 为由 1 至 61 编号的显式构造。
lean/ 为带锁定依赖版本的 Lean 工程。Audit.lean 中列出接受公理审计的定理，
logs/serial-check-Audit.log 保留 Lean 的原始输出。各定理的数学范围见文末附录。

integer/verify_all.py 是标准库总入口。它将 Lean 的 215 张表与证书逐块比对，重建八张类型
互斥图、人对变量、轨道、每个被引用的矩阵行与上下界，再逐项检查整数分支、末端置换和
余块价格。程序还检查 39 块显式构造。仿射平面由 Lean 中的 Cover61.Catalog.s9_49_excluded
排除。文件路径相对于本包根目录。

    python -I -B -S integer/verify_all.py

也可只回放其中一项。

    python -I -B -S integer/verify_four.py
    python -I -B -S integer/verify_anchors.py
    python -I -B -S integer/verify_prices.py
    python -I -B -S integer/verify_moment_source.py
    python -I -B -S integer/verify_hard.py
    python -I -B -S integer/verify_inventories.py

人口与人对矩阵的组合来源还有 computational/round2/audit_base.py 与 audit_gram.py
组成的第二份实现。原完整路线的入口是 computational/verify.py。在独立评审环境中，该入口需要
Python 3.10 或更高、NumPy、SciPy 和支持 C++17 的 GCC 或 Clang。整数价格的搜索器
在复核时被禁用。logs/full-cover-serial.log 记录本次在 Windows 资源限制内重跑的全部
251 条路径，包括原人数枚举、余块价格、三个可行对照以及 39 块上界的点对检查。

343 万节点实例还有一份独立的分支证明，重建 121 个极大类型集合，按先后顺序核验
100 份整数价格和 21 棵树。除标准库实现外，以下入口还利用 NumPy 和 SciPy 的整数矩阵
从块数据分别重建类型和各行，交叉核对两种实现。

    python -B computational/round2/audit_hard_support.py
    logs/hard-full-audit.log

另外十个末端实例合计 197340 个新树节点。verify_tree.py 解释整数区间证明，
verify_photo_price.py 使用 Python 整数枚举每个定价见证允许的单块。其余块价格
有 142 个代表，photo-links.json.gz 提供 3351 个从原分配到代表的明确置换。
audit_exported_prices.py 核对全部 29 份二阶矩价格和 5 份带根价格的矩阵行、
变量界、原始整数权以及严格差额。

    python -B computational/round2/audit_exported_prices.py

Windows 本机的工作区通过 work/lean_task.py 和 work/resource_guard.py 运行。
上限为一项作业、一个逻辑核心、系统 CPU 的 4%、两个进程、总私有提交量 16 GiB，
并保留 16 GiB 可用物理内存和 8 GiB 提交余量。windows/resource_guard.py 为相同控制器。
在其他平台审读 Lean 工程时，依赖缓存准备好后运行 lake build，再运行 lake env lean Audit.lean。
解压包内的 Windows 串行入口为 python -B windows/serial_lean.py。它依次提交本工程的
模块，最后执行完整 lake build 和公理审计。它可识别标准 elan 安装目录，也可从
COVER61_LEAN_BIN 读取含 lake.exe 的真实工具链目录。
SHA256SUMS.txt 枚举包内其他文件的 SHA-256 摘要。
