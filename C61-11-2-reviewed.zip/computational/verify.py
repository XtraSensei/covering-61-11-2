"""Entry point of the verification archive. Run from an extracted writable copy."""
from pathlib import Path
import os
import shutil
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
r = base/'round2'


def main():
    if not __debug__:
        raise SystemExit('Run Python without -O. Assertions are part of the verifier.')
    sys.path.insert(0, str(r))
    os.environ['OPENBLAS_NUM_THREADS'] = '1'
    os.environ['OMP_NUM_THREADS'] = '1'
    import numpy
    import scipy
    import scipy.optimize
    def no_solver(*args, **kwargs):
        raise RuntimeError('The verifier must not call a linear optimizer.')
    scipy.optimize.linprog = no_solver
    compiler = os.environ.get('CXX') or shutil.which('g++') or shutil.which('clang++')
    if not compiler:
        raise SystemExit('Install a GCC or Clang C++17 compiler, or set CXX to its path.')
    print('Python', sys.version.split()[0], 'NumPy', numpy.__version__, 'SciPy', scipy.__version__,flush=True)
    print(subprocess.check_output([compiler,'--version'],text=True).splitlines()[0],flush=True)
    start=time.perf_counter()

    for path in [base/'prior'/'audit_nine.cpp',*(r/(s+'.cpp') for s in ('catalog','countsearch','audit_prices','cutfast'))]:
        out=path.with_suffix('.exe' if os.name=='nt' else '')
        subprocess.run([compiler,'-O3','-std=c++17',str(path),'-o',str(out)],check=True)
    assert (base/'nine_kernels.txt').read_text().splitlines()==(base/'prior'/'nine_kernels.txt').read_text().splitlines()
    subprocess.run([sys.executable,str(base/'prior'/'verify_38.py')],check=True)
    subprocess.run([str(base/'prior'/('audit_nine.exe' if os.name=='nt' else 'audit_nine')),
                    str(base/'nine_kernels.txt')],check=True)
    from proof_run import verify_catalog,verify_cases
    verify_catalog()
    from positive_control import verify as check_feasible_cover
    check_feasible_cover()
    verify_cases()
    from test_cut import run
    run()
    print(f'All checks passed. C(61,11,2) = 39. Elapsed {time.perf_counter()-start:.1f} seconds.',flush=True)


if __name__=='__main__':
    main()
