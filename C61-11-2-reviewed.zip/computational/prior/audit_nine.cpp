#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
using U=uint64_t;
using Code=array<int,12>;
int pts[84][3],tripleId[9][9][9],degree[9];
U bits[84],countLabel[13],countOrbit[13];
void visit(int start,U used,int n){
    if(n>=6&&*min_element(degree,degree+9)>=2)countLabel[n]++;
    for(int i=start;i<84;i++)if(!(used&bits[i])){
        for(int x:pts[i])degree[x]++;
        visit(i+1,used|bits[i],n+1);
        for(int x:pts[i])degree[x]--;
    }
}
int main(int argc,char**argv){
    int edge[9][9]={},e=0,t=0;
    for(int i=0;i<9;i++)for(int j=i+1;j<9;j++)edge[i][j]=e++;
    for(int i=0;i<9;i++)for(int j=i+1;j<9;j++)for(int k=j+1;k<9;k++){
        int a[3]={i,j,k};copy(a,a+3,pts[t]);bits[t]=(U(1)<<edge[i][j])|(U(1)<<edge[i][k])|(U(1)<<edge[j][k]);
        do{tripleId[a[0]][a[1]][a[2]]=t;}while(next_permutation(a,a+3));t++;
    }
    if(argc!=2)return 1;ifstream file(argv[1]);string line;set<Code> codes;
    while(getline(file,line)){
        stringstream ss(line);string x;vector<array<int,3>> rows;
        while(ss>>x)rows.push_back({x[0]-'1',x[1]-'1',x[2]-'1'});
        int n=rows.size(),p[9]={0,1,2,3,4,5,6,7,8},aut=0;Code canonical,origin;
        canonical.fill(1000);
        do{
            Code v;v.fill(100);
            for(int j=0;j<n;j++)v[j]=tripleId[p[rows[j][0]]][p[rows[j][1]]][p[rows[j][2]]];
            sort(v.begin(),v.begin()+n);
            if(!aut)origin=v;
            if(v==origin)aut++;
            canonical=min(canonical,v);
        }while(next_permutation(p,p+9));
        if(!codes.insert(canonical).second)return 2;
        countOrbit[n]+=362880/aut;
    }
    visit(0,0,0);
    for(int n=6;n<=12;n++){
        cout<<n<<" "<<countLabel[n]<<" "<<countOrbit[n]<<endl;
        if(countLabel[n]!=countOrbit[n])return 3;
    }
}
