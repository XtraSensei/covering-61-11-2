"""Exact local relaxation for a block with four regular points."""
from collections import Counter
from functools import lru_cache
from itertools import combinations,product
from localcut import profiles

def capacity(u,v):return min(u*v,4*u,4*v)
@lru_cache(maxsize=None)
def component(s,n,m):
    choices=[(u,v) for u in range(1,n+1) for v in range(1,m+1)]
    ans=[]
    def add(a,b,left,groups):
        ans.append(tuple(groups))
        if len(groups)>=(1,7,21,35)[s]:return
        for j in range(left,len(choices)):
            u,v=choices[j]
            if a>=u and b>=v:
                add(a-u,b-v,j,groups+[(s,u,v)])
    add(n,m,0,[])
    return ans
def required(n,R):
    for P in product(*(component(s,n[s],n[7-s]) for s in range(4))):
        G=sum(P,());eff=sum(capacity(u,v) for s,u,v in G)
        if eff<R:continue
        if any(eff-capacity(u,v)+max(capacity(u-1,v),capacity(u,v-1))>=R for s,u,v in G):continue
        rem=list(n)
        for s,u,v in G:rem[s]-=u;rem[7-s]-=v
        yield G,tuple(rem)

@lru_cache(maxsize=None)
def fill_rows(demands,rows):
    if not demands:return not rows
    if any(need>len(demands) for weight,need in rows):return False
    k,budget=demands[0];remain=demands[1:]
    bins=list(Counter(rows).items())
    def place(j,left,cost,nextrows):
        if left<0 or cost<0:return False
        if j==len(bins):
            return left==0 and fill_rows(remain,tuple(sorted(nextrows)))
        (w,need),mass=bins[j]
        for take in range(mass if need==len(demands) else 0,min(mass,left)+1):
            if take*w>cost:break
            temp=[(w,need)]*(mass-take)
            if need>1:temp.extend([(w,need-1)]*take)
            if place(j+1,left-take,cost-take*w,nextrows+temp):return True
        return False
    return place(0,k,budget,[])
def local_options(n,R,deg):
    patterns=0;survived=0
    for G,remaining in required(n,R):
        patterns+=1;budget=[10*(d+1) for d in deg];visits=[6+d for d in deg]
        rest=[i-1 for i,count in enumerate(remaining) if i for _ in range(count)]
        sumlow=[sum(rest[:k]) for k in range(len(rest)+1)]
        G=sorted(G,key=lambda g: (-capacity(g[1],g[2]),g))
        def assign(j):
            if j==len(G):
                if not all(0<=k<=len(rest) and sumlow[k]<=e for k,e in zip(visits,budget)):return False
                demands=tuple(sorted(zip(visits,budget),key=lambda t:(t[1]-sumlow[t[0]],t)))
                rows=tuple((s-1,s) for s,m in enumerate(remaining) if s for _ in range(m))
                return fill_rows(demands,rows)
            s,u,v=G[j]
            seen=set()
            for chosen in combinations(range(7),s):
                # Relabel points with the same residual demand and budget.
                state=tuple(sorted((visits[i],budget[i]) for i in chosen))
                if state in seen:continue
                seen.add(state)
                ch=set(chosen)
                for i in range(7):
                    visits[i]-=u if i in ch else v;budget[i]-=u*(s-1) if i in ch else v*(6-s)
                ok=min(visits)>=0 and min(budget)>=0 and assign(j+1)
                for i in range(7):
                    visits[i]+=u if i in ch else v;budget[i]+=u*(s-1) if i in ch else v*(6-s)
                if ok:return True
            return False
        if assign(0):survived+=1
    return patterns,survived
def check(R,deg):
    hists=patterns=survived=0
    for p in profiles(4,sum(deg)):
        hists+=1
        count,s=local_options(tuple(p.count(i) for i in range(8)),R,deg)
        patterns+=count;survived+=s
    return (R,tuple(deg),hists,patterns,survived)
if __name__=='__main__':
    from concurrent.futures import ProcessPoolExecutor
    rg=range(8,14)
    tasks=[(r,d) for r in rg for d in ([1,0,0,0,0,0,0],[2,0,0,0,0,0,0],[1,1,0,0,0,0,0])]
    with ProcessPoolExecutor(4) as pool:
        for f in [pool.submit(check,*s) for s in tasks]:print(f.result(),flush=True)
