C(61,11,2) 复核材料
2026-11-25

在本目录执行 python verify_38.py。需要 Python 3.10 或更高版本，仅用标准库。
程序逐对检查两份名单，重做局部枚举，检查 21 份座位容量证书和 2 份人对计数证书。
理论推导见配套 PDF。当前结论仍为 38 ≤ C(61,11,2) ≤ 39。

cover39.txt      39 张完整覆盖，每行一张，每行 11 个编号。
near38.txt       38 张实验名单，漏 16 对，不能用作覆盖证书。
nine_kernels.txt 9 位六次者的 50 个候选，每行一个，按行从 0 开始编号。
                行内 123 表示这三位六次者同框；双人、单人及空行可由三元组还原。
kernel_prices.json 和 pair_prices.json 保存用于排除其中 23 种的整数证书。
localcut.py 和 local_exact.py 实现第 6、8 页的局部枚举。
verify_twelve.py 和 twelve_kernels.txt 核验第 9 页的五个三角形分解代表及其完备性。

若要重新生成 50 个代表，在本目录执行 python enumerate_nine.py。
第二种方法独立核验重标等价和带标签的总数。若已安装 C++17 编译器，可执行
g++ -O3 -std=c++17 audit_nine.cpp -o audit_nine
然后在 Windows PowerShell 执行 .\audit_nine.exe nine_kernels.txt
在 Linux 或 macOS 执行 ./audit_nine nine_kernels.txt
每个三元组数所对应的两列计数都应相等。

39 张名单来源
Meliwat, covering-hunt, records/C61_11_2_b39.txt
https://github.com/Meliwat/covering-hunt/blob/master/records/C61_11_2_b39.txt
