"""Check the finite cases and both lists for C(61,11,2). Python 3.10+.

cover39.txt is the certificate published by Meliwat at
https://github.com/Meliwat/covering-hunt/blob/master/records/C61_11_2_b39.txt
near38.txt is an incomplete experimental layout, not a covering.
The mathematical arguments connecting the checks are in the accompanying PDF.
"""
from collections import Counter
from itertools import combinations, permutations, product
from math import comb
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
PERMUTATIONS = tuple(permutations(range(5)))

def verify_blocks(name, expected_count, expected_gaps):
    rows = [list(map(int, line.split()))
            for line in (ROOT / name).read_text().splitlines() if line.strip()]
    assert len(rows) == expected_count
    assert all(len(r) == len(set(r)) == 11 for r in rows)
    assert all(1 <= x <= 61 for r in rows for x in r)
    assert len({tuple(sorted(r)) for r in rows}) == expected_count
    covered = {p for r in rows for p in combinations(sorted(r), 2)}
    gaps = sorted(set(combinations(range(1, 62), 2)) - covered)
    assert len(gaps) == expected_gaps
    print(name, len(covered), 'covered pairs;', len(gaps), 'missing')
    if gaps:
        marked = {x for p in gaps for x in p}
        slots = sum(comb(len(set(r) & marked), 2) for r in rows)
        assert (len(marked), slots) == (10, 41)
        print('Endpoints:', sorted(marked), 'internal pair slots:', slots)

def cross(x):
    return x * (11 - x)

def largest_cross(rows, total, maximum):
    if not 0 <= total <= rows * maximum:
        return -1
    if rows == 0:
        return 0
    size, large = divmod(total, rows)
    return (rows - large) * cross(size) + large * cross(size + 1)

def check_five_regular():
    minimum = []
    for groups in range(2, 7):
        fixed = groups - 1
        for d in range(37):
            best = largest_cross(12-fixed, 36+d-6*fixed, 6)
            if best >= 0 and fixed*cross(6)+best >= 300:
                minimum.append(d)
                break
    assert minimum == [5, 6, 8, 10, 12]
    for a in range(21, 26):
        assert 5 * ((a-9)//6) * (a//5) < a*(a-19)
    print('Minimum extra appearances for g=2..6:', minimum)

def reduced_squares(rows=((0, 1, 2, 3, 4),)):
    if len(rows) == 5:
        yield rows
        return
    for p in PERMUTATIONS:
        if p[0] == len(rows) and all(a != b for r in rows for a,b in zip(p,r)):
            yield from reduced_squares((*rows,p))

def verify_latin():
    sizes, overlap = Counter(), Counter()
    for square in reduced_squares():
        trans = [sum(1 << (5*i+j) for i,j in enumerate(p))
                 for p in PERMUTATIONS if len({square[i][j] for i,j in enumerate(p)})==5]
        sizes[len(trans)] += 1
        if len(trans) == 15:
            classes = {frozenset(y for y in trans if y==x or not (x&y)) for x in trans}
            assert len(classes)==3 and all(len(c)==5 for c in classes)
            assert all(not (x&y) for c in classes for x,y in combinations(c,2))
            assert set.union(*(set(c) for c in classes)) == set(trans)
        for x,y in combinations(trans,2):
            if x & y:
                continue
            good = [z for z in trans if (x&z).bit_count()==(y&z).bit_count()==1]
            through = max(sum((z >> i) & 1 for z in good) for i in range(25))
            overlap[through] += 1
    assert sizes == {3:50, 15:6} and overlap == {2:180}
    print('Reduced Latin squares by transversal count:', dict(sizes))
    print('Disjoint pairs, by maximum admissible transversals through a cell:', dict(overlap))

def histograms(remaining, low=0, prefix=()):
    if not remaining:
        yield prefix
        return
    for s in range(low,8):
        yield from histograms(remaining-1,s,(*prefix,s))

def check_four_regular():
    best = {(d,case):-1 for d in (0,1) for case in ('large', 'balanced')}
    pure = set()
    for s in histograms(17):
        d = sum(s)-42
        if d not in (0,1):
            continue
        capacity = sum(map(cross,s))
        if sum(j>=4 for j in s)>=4 and max(s)>=5:
            best[d,'large'] = max(best[d,'large'],capacity)
        if s.count(3)>=4 and s.count(4)>=4 and max(s)<=4:
            best[d,'balanced'] = max(best[d,'balanced'],capacity)
        if d==0 and sum(j>=4 for j in s)>=2 and capacity>=350:
            pure.add(tuple(s.count(j) for j in range(8)))
    assert best[1,'large']==348 and best[1,'balanced']==346
    assert max(best[0,'large'],best[0,'balanced'])<350
    assert pure=={(0,0,11,4,2,0,0,0)}
    print('Four-regular capacity maxima:', best)

def check_local_assignments():
    from local_exact import check
    one = [1,0,0,0,0,0,0]
    two = [2,0,0,0,0,0,0]
    two_distinct = [1,1,0,0,0,0,0]
    assert check(5,one)[2:]==(31,44,0)
    assert check(7,two)[2:]==(86,223,0)
    assert check(7,two_distinct)[2:]==(86,223,0)
    assert check(6,two_distinct)[-1]>0
    assert check(8,[3,0,0,0,0,0,0])[-1]==0
    assert check(8,[2,1,0,0,0,0,0])[-1]==0
    print('Four-regular local enumerations passed, including a feasible control.')

def check_nine():
    source = ROOT / 'nine_kernels.txt'
    counts = Counter()
    for line in source.read_text().splitlines():
        triples = [tuple(map(int, t)) for t in line.split()]
        joined = [p for t in triples for p in combinations(t,2)]
        assert len(joined)==len(set(joined))
        deg = Counter(x for t in triples for x in t)
        assert set(deg)==set(range(1,10)) and min(deg.values())>=2
        counts[len(triples)]+=1
    assert counts=={6:2,7:11,8:20,9:11,10:4,11:1,12:1}
    print('Nine-person representatives by number of triples:', dict(sorted(counts.items())))

def kernel_rows(line):
    triples=[tuple(int(c)-1 for c in word) for word in line.split()]
    used={pair for triple in triples for pair in combinations(triple,2)}
    rows=triples+[p for p in combinations(range(9),2) if p not in used]
    for x in range(9):
        rows.extend([(x,)]*(6-sum(x in r for r in rows)))
    return rows+[()]*(38-len(rows))

def check_prices():
    catalogue=(ROOT/'nine_kernels.txt').read_text().splitlines()
    prices=json.loads((ROOT/'kernel_prices.json').read_text())
    assert len(prices)==21
    for ident, cert in prices.items():
        rows=kernel_rows(catalogue[int(ident)])
        q,*weight=cert
        assert len(weight)==len(rows)==38 and q>0 and min(weight)>=0
        assert sum((11-len(r))*w for r,w in zip(rows,weight))<52*q
        masks=[sum(1<<x for x in r) for r in rows]
        blanks=sorted(w for r,w in zip(rows,weight) if not r)
        # Each possible support partitions all nine labels, with empty rows padding it to seven.
        def visit(remaining,count,cost):
            if not remaining:
                if 0<=7-count<=len(blanks):
                    assert cost+sum(blanks[:7-count])>=q
                return
            if count==7:return
            bit=remaining & -remaining
            for mask,w in zip(masks,weight):
                if mask&bit and mask&remaining==mask:
                    visit(remaining^mask,count+1,cost+w)
        visit(511,0,0)
    print('Kernels excluded by integer capacity certificates:',len(prices))

def check_pair_prices():
    catalogue=(ROOT/'nine_kernels.txt').read_text().splitlines()
    certificates=json.loads((ROOT/'pair_prices.json').read_text())
    simple=json.loads((ROOT/'kernel_prices.json').read_text())
    assert {int(x) for x in certificates}.isdisjoint(int(x) for x in simple)
    for ident, coefficients in certificates.items():
        rows=kernel_rows(catalogue[int(ident)])
        labels=[sum(1<<z for z in r) for r in rows]
        classes=sorted(set(labels))
        width=[labels.count(z) for z in classes]
        cap=[11-z.bit_count() for z in classes]
        # Enumerate orbit types directly: each nonempty class may be used once.
        patterns=set()
        def visit(rem,selected):
            if not rem:
                blank=7-len(selected)
                if 0<=blank<=width[0]:
                    patterns.add(tuple([blank]+[int(k in selected) for k in range(1,len(classes))]))
                return
            if len(selected)==7:return
            bit=rem&-rem
            for k,mask in enumerate(classes[1:],1):
                if mask&bit and mask&rem==mask:visit(rem^mask,selected+(k,))
        visit(511,())
        T=sorted(patterns)
        assert len(T)==len(coefficients)
        X=[];S=[];Z=[]
        for a,(u,v,p,q) in zip(T,coefficients):
            assert len(p)==len(q)==len(classes)
            assert all(isinstance(c,int) for c in (u,v,*p,*q))
            X.append(-51*u-v-sum((n*c-s)*i+s*(c-1)*j for n,c,s,i,j in zip(width,cap,a,p,q)))
            S.append(v)
        for i,a in enumerate(T):
            u,v,p,q=coefficients[i]
            for j in range(i,len(T)):
                b=T[j];z,w,f,g=coefficients[j]
                base=u+z+sum(bk*pk+ak*fk for ak,bk,pk,fk in zip(a,b,p,f))
                intervals=[range(max(0,x+y-n),min(x,y)+1) for x,y,n in zip(a,b,width)]
                for o in product(*intervals):
                    common=sum(o)
                    if common:
                        Z.append(base+sum(s*(a1+b1) for s,a1,b1 in zip(o,q,g))+
                                 (v+w if common==7 else 0))
        assert 2*min(X)+2*min(0,min(S))+51*min(0,min(Z))>0
    print('Additional kernels excluded by pair consistency certificates:',len(certificates))

if __name__=='__main__':
    verify_blocks('cover39.txt',39,0)
    verify_blocks('near38.txt',38,16)
    check_five_regular()
    verify_latin()
    check_four_regular()
    check_local_assignments()
    check_nine()
    check_prices()
    check_pair_prices()
    from verify_twelve import verify
    verify()
    print('All checks passed.')
