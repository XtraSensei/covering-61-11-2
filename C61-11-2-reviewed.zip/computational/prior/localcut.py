from functools import lru_cache
from itertools import combinations_with_replacement
@lru_cache(maxsize=None)
def profiles(t,d):
    h=11-t
    rows=37-5*t
    S=6*h+d
    ans=[]
    def gen(prev,q,rem,w,current):
        if q==0:
            if rem==0 and w>=50*h:ans.append(tuple(current))
            return
        if rem<q*prev or rem>q*h:return
        near,left=divmod(rem,q)
        if w+(q-left)*near*(11-near)+left*(near+1)*(10-near)<50*h:return
        for j in range(prev,min(h,rem//q)+1):
            gen(j,q-1,rem-j,w+j*(11-j),current+[j])
    gen(0,rows,S,0,[])
    return ans

def capacity(n):
    reps=lambda i,j:min(4*n[i],4*n[j],n[i]*n[j])
    return sum(reps(i,7-i) for i in range(4))
def extra(n):
    return sum(j*(11-j)*c for j,c in enumerate(n))-350

def passmod(n):
    # Use the parity of the total weight assigned to each outsider.
    odd=sum((11-j)*n[j] for j in [1,3,5,7])
    return odd+extra(n)>=50
if __name__=='__main__':
 for d in range(5):
    ns=[tuple(p.count(s) for s in range(8)) for p in profiles(4,d)]
    ns=[n for n in ns if passmod(n)]
    print('d',d,'n',len(ns),'regular max',max(map(capacity,ns),default=None))
    if d<=2:
        print([(n,extra(n),capacity(n)) for n in ns if capacity(n)>=8])
