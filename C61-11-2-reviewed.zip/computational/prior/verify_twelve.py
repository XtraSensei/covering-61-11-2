"""The twelve-regular-point case in which all regular blocks have size at most three."""
from collections import Counter
from itertools import combinations,permutations
from pathlib import Path

def matching_shapes():
    def generate(points):
        if not points:
            yield ()
            return
        x,*rest=points
        for y in rest:
            if x//2==y//2: continue
            for p in generate([z for z in rest if z!=y]):
                yield ((x,y),*p)
    reps={};sizes=Counter()
    for p in generate(list(range(2,12))):
        match={x:y for a,b in p for x,y in ((a,b),(b,a))}
        remaining=set(range(2,12));cc=[]
        while remaining:
            component={remaining.pop()};queue=list(component)
            while queue:
                x=queue.pop()
                for y in (x^1,match[x]):
                    if y not in component:component.add(y);remaining.discard(y);queue.append(y)
            cc.append(len(component))
        key=tuple(sorted(cc));sizes[key]+=1;reps.setdefault(key,p)
    return sizes,reps

def verify():
    pts=range(12);pairs=[p for p in combinations(pts,2) if p[0]//2!=p[1]//2]
    edge={p:1<<i for i,p in enumerate(pairs)}
    triples=[t for t in combinations(pts,3) if all(p in edge for p in combinations(t,2))]
    masks={t:sum(edge[p] for p in combinations(t,2)) for t in triples}
    containing={v:[m for m in masks.values() if m&v] for v in edge.values()}
    sizes,reps=matching_shapes()
    def count(rem):
        if not rem:return 1
        bit=rem&-rem
        return sum(count(rem^m) for m in containing[bit] if rem&m==m)
    total=0
    for typ,m in reps.items():
        rem=(1<<60)-1
        for a,b in m:rem^=masks[0,a,b]
        total+=sizes[typ]*count(rem)
    assert total==115200
    source=Path(__file__).resolve().with_name('twelve_kernels.txt')
    reps=[[tuple(map(int,s.split(','))) for s in line.split()] for line in source.read_text().splitlines()]
    assert len(reps)==5
    canon=set();sumorbits=0
    permutations12=[]
    for p in permutations(range(6)):
        for signs in range(64):
            permutations12.append(tuple(2*p[i//2]+((i%2)^((signs>>(i//2))&1)) for i in pts))
    symbol={t:i for i,t in enumerate(triples)}
    for T in reps:
        assert len(T)==20 and len({p for t in T for p in combinations(t,2)})==60
        assert all(t in masks for t in T)
        base=tuple(sorted(symbol[t] for t in T));auto=0;low=base
        for p in permutations12:
            enc=tuple(sorted(symbol[tuple(sorted((p[a],p[b],p[c])))] for a,b,c in T))
            auto+=int(base==enc);low=min(low,enc)
        assert low not in canon;canon.add(low);sumorbits+=46080//auto
        blocks=[sum(1<<x for x in t) for t in T]+[3<<(2*i) for i in range(6)]
        def choices(rem,n):
            if not rem:return [n]
            bit=rem&-rem
            return [s for b in blocks if b&bit and rem&b==b for s in choices(rem^b,n+1)]
        lens=choices(4095,0)
        # Five copies of any such support exhaust more than all three extra appearances.
        assert min(lens)>=4 and 4*len(lens)<49
    assert sumorbits==total
    print('Twelve regulars without a four-person regular block: 5 orbits, 115200 labelled, all excluded.')
if __name__=='__main__':verify()
