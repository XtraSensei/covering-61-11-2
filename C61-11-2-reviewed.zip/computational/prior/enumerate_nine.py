"""Enumerate partial triple systems on nine points, up to relabelling."""
from collections import Counter,defaultdict
from itertools import combinations
from pathlib import Path
POINTS=range(9)
TRIPLES=list(combinations(POINTS,3))

def structure(triples):
    link=[[] for _ in POINTS]
    third=[[-1]*9 for _ in POINTS]
    for a,b,c in triples:
        for x,y,z in ((a,b,c),(b,a,c),(c,a,b)):
            link[x].append((y,z))
            third[x][y]=z;third[x][z]=y
    colors=[len(row) for row in link]
    while True:
        fingerprints=[(colors[i],tuple(sorted(tuple(sorted((colors[j],colors[k]))) for j,k in link[i]))) for i in POINTS]
        palette={v:j for j,v in enumerate(sorted(set(fingerprints)))}
        nxt=[palette[x] for x in fingerprints]
        if len(set(nxt))==len(set(colors)):break
        colors=nxt
    key=(tuple(sorted(fingerprints)),tuple(sorted(tuple(sorted(nxt[x] for x in t)) for t in triples)))
    return key,(tuple(triples),nxt,third)

def iso(left,right):
    _,a,A=left;_,b,B=right
    options=[[j for j in POINTS if b[j]==a[i]] for i in POINTS]
    order=sorted(POINTS,key=lambda i:len(options[i]))
    mapping={};used=set()
    def visit(step):
        if step==9:return True
        x=order[step]
        for y in options[x]:
            if y in used:continue
            for u,v in mapping.items():
                c=A[x][u];d=B[y][v]
                if (c<0)!=(d<0) or (c>=0 and (a[c]!=b[d] or (c in mapping and mapping[c]!=d))):break
            else:
                mapping[x]=y;used.add(y)
                if visit(step+1):return True
                del mapping[x];used.remove(y)
        return False
    return visit(0)

def main():
    layer=[structure([])[1]]
    result=Counter();root=Path(__file__).resolve().with_name('nine_kernels.txt')
    with root.open('w') as out:
        for n in range(13):
            by_key=defaultdict(list)
            for rep in layer:
                triples,colors,third=rep
                deg=[sum(t>=0 for t in row)//2 for row in third]
                if min(deg)>=2:
                    result[n]+=1
                    out.write(' '.join(''.join(str(x+1) for x in t) for t in triples)+'\n')
                if n==12:continue
                for a,b,c in TRIPLES:
                    if max(third[a][b],third[a][c],third[b][c])>=0:continue
                    key,child=structure((*triples,(a,b,c)))
                    bucket=by_key[key]
                    if not any(iso(child,other) for other in bucket):bucket.append(child)
            print(n,'all',len(layer),'allowed',result[n],flush=True)
            layer=[s for bucket in by_key.values() for s in bucket]
    print('sum',sum(result.values()))
if __name__=='__main__':main()
