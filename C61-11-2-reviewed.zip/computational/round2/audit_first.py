"""Verifies signed integer seat prices, including all prespecified-anchor orbits."""
import json
from collections import Counter,defaultdict
from family import ROOT,FREQUENCIES,catalog,setup,upper_bound,equations
from flagmath import flagdata,anchor_orbits,base

def check_screen():
    cases=json.loads((ROOT/'screen.json').read_text());c=catalog();record=Counter()
    assert len(cases)==sum(len(FREQUENCIES[a]) for a,rows in c.values())
    for key,(status,vec,n) in cases.items():
        name,i=key.split('.');a,rows=c[name];freq=FREQUENCIES[a][int(i)]
        p,u=setup(a,rows,freq);eq,rhs=equations(rows,freq,p)
        assert len(p)==n
        if status=='price':
            assert len(vec)==len(eq)
            payoff=[sum(vec[k] for k,s in enumerate(eq) if j in s) for j in range(n)]
            pool=defaultdict(list)
            for j,(q,r) in enumerate(p):pool[q].extend([max(0,payoff[j])]*u[j])
            total=sum(sum(sorted(x,reverse=True)[:upper_bound(a,q)]) for q,x in pool.items())
            assert sum(x*y for x,y in zip(rhs,vec))>total
        else:
            assert status=='integer' and len(vec)==n
            assert all(0<=v<=cap for v,cap in zip(vec,u))
            assert all(sum(vec[j] for j in s)==k for s,k in zip(eq,rhs))
            groups=Counter()
            for (q,r),v in zip(p,vec):groups[q]+=v
            assert all(v<=upper_bound(a,q) for q,v in groups.items())
        record[a,status]+=1
    return record

def verify_first(key):
    rows=base(key)[1];orbits,examples,where=anchor_orbits(key)
    assert set(examples)==set(orbits)==set(where.values())
    records=json.loads((ROOT/'firstflags'/(key+'.json')).read_text());blocked=set()
    for deny,i,proof in records:
        assert set(deny)<=blocked
        A=() if i==-1 else (examples[i],)
        colors,W,C,F,T,U,E=flagdata(key,A,tuple(deny))
        n=len(T)
        if 'empty' in proof:assert not n and sum(F)
        else:
            y=proof['y'];ranks=[r for r,v in enumerate(F,7) if v];rhs=[w*c for w,c in zip(W,C)]+[F[r-7] for r in ranks]
            assert len(y)==len(rhs)
            target=sum(x*v for x,v in zip(y,rhs))
            upper=0
            for s,u in zip(T,U):
                value=sum(x*v for x,v in zip(s,y))+y[len(W)+ranks.index(sum(s))]
                upper+=u*max(0,value)
            assert target==proof['need'] and upper==proof['maximum'] and target>upper
        if i>=0:blocked.add(i)
    return len(blocked)

if __name__=='__main__':
    print(sorted(check_screen().items()))
    files=sorted((ROOT/'firstflags').glob('*.json'))
    print('anchor files',len(files),'excluded orbits',sum(verify_first(f.stem) for f in files))
