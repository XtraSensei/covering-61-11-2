"""Price the mutually incompatible primary types as cliques."""
from neighborhood import Problem,ROOT,np,json
from itertools import combinations
from math import lcm
import sys
from concurrent.futures import ProcessPoolExecutor

def loadprevious(P):
    d=json.loads((ROOT/'neighborcerts'/(P.key+'.json')).read_text())
    P.blocked.update(d['blocked']);P.edges.update(map(tuple,d['edges']))

def maximal_cliques(n,edges,blocked):
    g=[0]*n
    for i,j in edges:g[i]|=1<<j;g[j]|=1<<i
    rest=((1<<n)-1)^sum(1<<i for i in blocked)
    def visit(current,P,X):
        if not P:
            if not X and len(current)>=2:yield current
            return
        pool=P|X;best=-1;v=0
        while pool:
            bit=pool&-pool;pool^=bit;i=bit.bit_length()-1;deg=(g[i]&P).bit_count()
            if deg>best:best=deg;v=i
        choices=P&~g[v]
        while choices:
            bit=choices&-choices;choices^=bit;i=bit.bit_length()-1
            yield from visit((*current,i),P&g[i],X&g[i])
            P^=bit;X|=bit
    return visit((),rest,0)

class CliqueProblem(Problem):
    def freeze(self):
        cliques=sorted((tuple(sorted(x)) for x in maximal_cliques(self.n,self.edges,self.blocked)),key=lambda x:(-len(x),x))
        # Prefer larger clique constraints and retain some incident to each type.
        if len(cliques)>380:
            seen=[0]*self.n;sel=[]
            for c in cliques:
                if min(seen[i] for i in c)>=12:continue
                sel.append(c)
                for i in c:seen[i]+=1
            cliques=sel[:380]
        self.gcl=np.zeros((len(cliques),self.n),dtype=np.int32);self.hcl=[]
        for j,c in enumerate(cliques):
            v=lcm(*(int(self.ub[i]) for i in c));self.hcl.append(v)
            for i in c:self.gcl[j,i]=v//self.ub[i]
        self.hcl=np.asarray(self.hcl,dtype=np.int32)
    def model(self,S):
        base=super().model(S)
        if isinstance(base,str):return base
        A,B,G,H,U=base
        shift=self.gcl[:,S].sum(axis=1) if len(S) else 0
        return A,B,np.vstack((G,self.gcl)),np.r_[H,self.hcl-shift],U

def run(key):
    P=CliqueProblem(key);loadprevious(P);history=[];closed=False
    for iteration in range(5):
        P.freeze();history.append([]);proof=history[-1]
        if c:=P.probe(()) :proof.append([[],c]);closed=True;break
        used=0
        for size in (1,2):
            done=set()
            for S in combinations(range(P.n),size):
                if S in done or set(S)&P.blocked or (size==2 and S in P.edges):continue
                done.update(P.orbit(S))
                if c:=P.probe(S):
                    proof.append([S,c]);P.apply(S);used+=1
        if not used:break
    d=ROOT/'cliquecerts';d.mkdir(exist_ok=True)
    (d/(key+'.json')).write_text(json.dumps(dict(history=history,closed=closed,blocked=sorted(P.blocked),edges=sorted(P.edges)),separators=(',',':')))
    print(key,len(P.blocked),len(P.edges),'closed' if closed else 'open',flush=True)

def verify(key):
    P=CliqueProblem(key);loadprevious(P)
    doc=json.loads((ROOT/'cliquecerts'/(key+'.json')).read_text())
    for step in doc['history']:
        P.freeze()
        for S,c in step:
            assert P.probe(tuple(S),c)==c
            if S:P.apply(tuple(S))
    assert sorted(P.blocked)==doc['blocked'] and [list(e) for e in sorted(P.edges)]==doc['edges']
    return doc['closed']

if __name__=='__main__':
    with ProcessPoolExecutor(2) as pool:list(pool.map(run,sys.argv[1:]))
