#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <vector>
using Mask=std::uint64_t;
struct Type{Mask p;int r,n,h,d;};
struct Term{int kind,i,j,v,s,rhs;long long weight;std::vector<int> subset;};
int main(int argc,char** argv){
 if(argc!=2)return 1;std::ifstream in(argv[1]);if(!in)return 2;
 int n,b,nt;long long expected,needed;
 in>>n>>b>>nt>>expected>>needed;std::vector<Type> t(n);
 int people=0,slots=0;for(auto& a:t){in>>a.p>>a.r>>a.n;a.h=a.r-__builtin_popcountll(a.p);people+=a.n;slots+=a.h*a.n;}
 if(slots!=11*b)return 3;
 std::vector<std::vector<int>> known(n,std::vector<int>(n));
 for(int i=0;i<n;i++){t[i].d=0;for(int j=0;j<n;j++){known[i][j]=bool(t[i].p&t[j].p);if(!known[i][j])t[i].d+=t[j].n;}}
 std::vector<Term> f;long long target=0;
 for(int k=0;k<nt;k++){
   Term e{};int m;in>>e.kind>>e.i>>e.j>>e.v>>e.s>>e.weight>>m;
   for(int z=0,j;z<m;z++){in>>j;e.subset.push_back(j);}
   if(e.kind!=0&&e.weight<0)return 4;
   if(e.kind==0)e.rhs=t[e.i].h*t[e.i].n;
   if(e.kind==1){if(known[e.i][e.j])return 5;e.rhs=t[e.i].n*t[e.j].n;}
   if(e.kind==2||e.kind==3){
     int W=0;std::vector<bool> seen(n,false);
     for(int j:e.subset){if(known[e.i][j]||seen[j])return 6;seen[j]=true;W+=t[j].n;}
     if(e.kind==2){if(t[e.i].h!=2||e.v<0||2*e.v>=W)return 7;}
     if(e.kind==3){if(e.v<=0||e.s<0)return 8;e.rhs=t[e.i].n*((W+t[e.i].h*e.s+e.v-1)/e.v);}
     e.j=W;
   }
   if(e.kind<0||e.kind>3)return 9;target+=e.weight*e.rhs;f.push_back(e);
 }
 if(!in||target!=needed)return 10;
 long long maximum=std::numeric_limits<long long>::min(),valid=0;
 std::vector<int> q(n),seen(n),suffix(n+1,0);for(int i=n-1;i>=0;i--)suffix[i]=suffix[i+1]+(t[i].h?t[i].n:0);
 auto visit=[&](auto& self,int i,int left)->void{
   if(left>suffix[i])return;
   if(!left){
     for(int j=0;j<n;j++)if(q[j]&&seen[j]-1>10*t[j].h-t[j].d)return;
     long long value=0;
     for(const auto& e:f){int v=q[e.i];
       if(e.kind==1)v*=q[e.j];
       if(e.kind>=2){int a=0;for(int j:e.subset)a+=q[j];
         if(e.kind==2)v*=int(a>=e.j-e.v)-int(a<=e.v);
         else v*=(a+e.s+e.v-1)/e.v;
       }
       value+=e.weight*v;
     }
     valid++;maximum=std::max(maximum,value);return;
   }
   if(i==n)return;
   int high=t[i].h?std::min(left,t[i].n):0;
   for(int j=0;j<i;j++)if(q[j]&&known[j][i])high=std::min(high,10*t[j].h-t[j].d+1-seen[j]);
   high=std::max(0,std::min(high,10*t[i].h-t[i].d+1-seen[i]));
   self(self,i+1,left);
   for(int a=1;a<=high;a++){
     q[i]=a;for(int j=0;j<n;j++)seen[j]+=known[j][i];self(self,i+1,left-a);
   }
   q[i]=0;for(int j=0;j<n;j++)seen[j]-=high*known[j][i];
 };
 visit(visit,0,11);
 if(!valid||maximum!=expected||b*maximum>=needed){std::cerr<<valid<<" "<<maximum<<" "<<expected<<" "<<needed<<"\n";return 11;}
 std::cout<<valid<<" "<<maximum<<" "<<needed<<" "<<needed-b*maximum<<"\n";
}
