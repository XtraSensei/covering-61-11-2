"""Identify isomorphic blank-photo completion instances by exact graph isomorphism."""
from collections import defaultdict
from pathlib import Path
import json
from family import ROOT
from forced import read_cases
from shapes import same

def graph(types):
    p=[x for x,r,w in types]; n=len(p)
    e=tuple(sum(1<<j for j,y in enumerate(p) if not x&y) for x in p)
    colors=[(r-x.bit_count(),w) for x,r,w in types]
    distinct=sorted(set(colors));c=[distinct.index(v) for v in colors]
    while True:
        sig=[(c[i],tuple(sorted(c[j] for j in range(n) if e[i]>>j&1))) for i in range(n)]
        sigs=sorted(set(sig));d=[sigs.index(v) for v in sig]
        if len(set(d))==len(set(c)):
            colored=[(base,col) for base,col in zip(colors,d)]
            return tuple(sorted(zip(colors,sig))),e,colored
        c=d

def representatives(cases):
    found=defaultdict(list);reps={}
    for i,t in enumerate(cases):
        key,e,c=graph(t)
        match=next((j for j,ej,cj in found[key] if same(ej,e,cj,c)),None)
        if match is None:found[key].append((i,e,c));reps[i]=i
        else:reps[i]=match
    return reps

if __name__=='__main__':
    out={}
    for path in sorted(ROOT.glob('*.cases')):
        key=path.name.removesuffix('.cases'); reps=representatives(read_cases(path));out[key]=list(reps.values())
        print(key,len(reps),len(set(reps.values())),sorted(set(reps.values()))[:28])
    (ROOT/'residualiso.json').write_text(json.dumps(out,separators=(',',':')))
