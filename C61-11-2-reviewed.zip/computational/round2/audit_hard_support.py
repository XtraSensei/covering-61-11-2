"""Exact replay of the support cover and the conditional moment certificates for 9-37."""
from collections import Counter
from itertools import combinations
from pathlib import Path
import gzip
import json
import sys

from audit_base import check_base
from audit_gram import extra_row
from audit_first import verify_first
from cliquelp import verify as verify_cliques
from flagmath import flagdata
from momentsdp import Moments, ROOT
from neighborhood import check as verify_neighbors


def maximal_supports(n, blocked, edges):
    allowed=set(range(n))-set(blocked)
    graph={i:allowed-{i} for i in allowed}
    for i,j in edges:
        if i in allowed and j in allowed:
            graph[i].discard(j);graph[j].discard(i)
    def visit(selected,possible,used):
        if not (possible or used):
            yield tuple(sorted(selected));return
        pivot=max(possible|used,key=lambda i:len(graph[i]&possible))
        for i in sorted(possible-graph[pivot]):
            yield from visit(selected|{i},possible&graph[i],used&graph[i])
            possible.remove(i);used.add(i)
    return sorted(visit(set(),allowed,set()))


def verify(directory):
    key="9-37.0"
    verify_first(key);verify_neighbors(key);verify_cliques(key)
    model=Moments(key)
    assert tuple(map(int,model.orb))==tuple(range(model.nvar))
    deny=tuple(i for _,i,_ in json.loads((ROOT/"firstflags"/(key+".json")).read_text()) if i>=0)
    check_base(model,(),deny,())
    supports=maximal_supports(model.n,model.blocked,model.conflicts)
    assert len(supports)==121
    tags=json.loads((ROOT/"gramcerts"/(key+".json")).read_text())["tags"]
    A,G=model.A.tocsr(),model.G.tocsr()
    owner=[(i,) for i in range(model.n)]
    for i,j,idx,end in zip(model.pi,model.pj,model.py,list(model.py[1:])+[model.nvar]):
        assert len(owner)==idx
        owner.extend([(int(i),int(j))]*(end-idx))
    expanded={};base_rows={}
    closed_matrix=directory/'support-matrix.json.gz'
    track='--write-matrix' in sys.argv or closed_matrix.exists()
    def leaf(s,decisions,doc,sources=()):
        exclude=set(range(model.n))-set(s)
        exclude.update(i for i,k in decisions if k==0)
        upper=[0 if any(i in exclude for i in group) else int(u) for group,u in zip(owner,model.ub)]
        coeff=Counter();rhs=0
        for tag,mat,b in (("y",A,model.B),("z",G,model.H)):
            for j,w in doc[tag]:
                assert type(j) is int and j>=0 and type(w) is int and (tag=="y" or w<=0)
                if j<mat.shape[0]:
                    a,z=mat.indptr[j:j+2];r=zip(mat.indices[a:z],mat.data[a:z]);v=int(b[j])
                elif tag=="z":
                    t=j-mat.shape[0]
                    if t<len(tags):
                        if t not in expanded:
                            c,v=extra_row(model,tags[t]);expanded[t]=([(i,x) for i,x in enumerate(c) if x],v)
                        r,v=expanded[t]
                    else:
                        source,which=divmod(t-len(tags),len(s)+1)
                        hit=set(s)-set(supports[sources[source]])
                        if not which:r,v=[(i,-1) for i in hit],-1
                        else:
                            i=s[which-1];r,v=[(i,int(i not in hit))],0
                            for j2 in hit:
                                p=model.pair_map.get(tuple(sorted((i,j2))))
                                if p is not None:r.append((p,-1-int(i==j2)))
                else:
                    group,offset=divmod(j-mat.shape[0],model.n+1)
                    i,k=decisions[group]
                    if offset==0:r,v=[(i,1)],k
                    else:
                        t=offset-1;p=model.pair_map.get(tuple(sorted((i,t))))
                        r=[(t,int(t==i)-k)]+([] if p is None else [(p,1+int(t==i))]);v=0
                if track and (tag=='y' and j<A.shape[0] or tag=='z' and j<G.shape[0]+len(tags)):
                    r=[(int(pos),int(val)) for pos,val in r if val]
                    name=tag+str(j)
                    entry=[int(v),[list(t) for t in r]]
                    if name in base_rows:assert base_rows[name]==entry
                    else:base_rows[name]=entry
                rhs+=v*w
                for c,vv in r:coeff[int(c)]+=int(vv)*w
        gap=rhs-sum(max(0,c)*upper[i] for i,c in coeff.items())
        assert type(doc["gap"]) is int and gap==doc["gap"] and gap>0
        return 1
    def branch(i,s,decisions):
        label="-".join(f"{j}v{k}" for j,k in decisions) or "root"
        doc=json.loads((directory/"hard-slices"/f"{i:03}-{label}.json").read_text())
        if "gap" in doc:return leaf(s,decisions,doc)
        j=doc["split"]
        assert j in s and j not in dict(decisions)
        return sum(branch(i,s,decisions+[(j,k)]) for k in range(int(model.U[j])+1))
    leaves=0;closed=set()
    for i,s in enumerate(supports):
        old=directory/f"gram-support-{key}-{i:03}.json"
        if old.exists():
            doc=json.loads(old.read_text());assert doc["support"]==list(s) and doc["seed"] is True
            leaves+=leaf(s,[],doc);closed.add(i)
    hitfile=directory/'support-hits.json'
    if hitfile.exists():
        for i,doc in json.loads(hitfile.read_text()):
            assert i not in closed and set(doc['sources'])<=closed
            leaves+=leaf(supports[i],[],doc,doc['sources']);closed.add(i)
    if track:
        source=dict(n=model.n,blocked=sorted(map(int,model.blocked)),conflicts=sorted([list(map(int,e)) for e in model.conflicts]),
                    owner=[list(t) for t in owner],upper=list(map(int,model.ub)),cut=G.shape[0]+len(tags),
                    pairs=[[int(i),int(j),int(idx)] for (i,j),idx in sorted(model.pair_map.items())],rows=base_rows)
        if '--write-matrix' in sys.argv:
            with gzip.open(closed_matrix,'wt',encoding='utf8') as f:json.dump(source,f,separators=(',',':'))
        else:
            with gzip.open(closed_matrix,'rt',encoding='utf8') as f:assert json.load(f)==source
    if __name__=='__main__' and '--priced-only' in sys.argv:
        print(f'{key}: audited {leaves} strict integer certificates on {len(closed)} of {len(supports)} supports.');return leaves
    index=directory/'support-tree-index.json'
    if index.exists():
        sys.path.insert(0,str(directory));from verify_tree import Box,replay
        data=json.loads(index.read_text());assert data['supports']==list(map(list,supports))
        colors,widths,capacity,_,_,_,_=flagdata(key,(),deny)
        assert colors[0][0]==0 and widths==list(model.W)
        fixed=sum(1<<(j-1) for j in range(1,len(widths)) if widths[j]==1)
        vectors=[list(map(int,v)) for v in model.T]
        assert all(v in (0,1) for s in vectors for v in s[1:])
        prim=[sum(1<<(j-1) for j in range(1,len(s)) if s[j]) for s in vectors]
        types=[[m,m&fixed,sum(s),int(u)] for m,s,u in zip(prim,vectors,model.U)]
        seats=[[[i for i,s in enumerate(vectors) if s[j]],widths[j]*capacity[j]] for j in range(1,len(widths))]
        seats.append([list(range(len(types))),52]);assert all(t[2]==7 for t in types)
        problem=dict(empty=widths[0],types=types,seats=seats);assert problem==data['model']
        nodes=0
        for i in data['order']:
            with gzip.open(directory/'support-trees'/f'{i:03}.json.gz','rt') as f:doc=json.load(f)
            assert i not in closed and set(doc['sources'])<=closed
            nodes+=replay(Box(problem,supports[i],[supports[j] for j in doc['sources']]),doc);closed.add(i)
        assert len(closed)==len(supports)
        print(f'{key}: all {len(closed)} supports rejected; {leaves} Farkas certificates and {len(data["order"])} trees with {nodes} nodes.');return leaves
    for i,s in enumerate(supports):
        if i not in closed:leaves+=branch(i,s,[])
    print(f"{key}: all {len(supports)} maximal supports excluded by {leaves} integer Farkas leaves.")
    return leaves

if __name__=="__main__":
    if not __debug__:raise RuntimeError('Run without -O.')
    source=ROOT.parent/"portable_prices"
    verify(source if source.is_dir() else ROOT.parent.parent/"integer")
