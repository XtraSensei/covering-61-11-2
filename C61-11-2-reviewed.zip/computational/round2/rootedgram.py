"""Distinguish the actual blank photos of a unique member of a required type."""
from momentsdp import Moments,ROOT,json
from flagmath import flagdata,anchor_orbits,base
from concurrent.futures import ProcessPoolExecutor
def unique_anchor(key,group):
    a,rows,fr,people=base(key);_,ex,orb=anchor_orbits(key)
    denied=tuple(i for _,i,_ in json.loads((ROOT/'firstflags'/(key+'.json')).read_text()) if i>=0)
    C,W,cap,F,T,U,E=flagdata(key,(),denied);sig=T[group]
    colmask=[sum(1<<j for j in range(38) if (rows[j] if j<len(rows) else 0)==low) for low,_ in C]
    choice=next((p,r) for p,r in people if tuple((p&m).bit_count() for m in colmask)==sig)
    ident=orb[choice[0]&((1<<len(rows))-1),choice[1]]
    # This solver is used only when the excluded root type orbit consists of
    # the one parent type whose population is known to be exactly one.
    alltypes={tuple((p&m).bit_count() for m in colmask) for p,r in people if orb[p&((1<<len(rows))-1),r]==ident}
    assert alltypes=={sig}
    return choice[0],ident

def run(key,group,which):
    anchor,denied=unique_anchor(key,group);M=Moments(key,(anchor,),(denied,))
    cond=[]
    if which>=0:
        S=tuple(i for i,p in enumerate(M.proj) if p in (16,17))
        cond=[(S,which)];M.condition(cond)
    folder=ROOT/'rootedgram';folder.mkdir(exist_ok=True);file=folder/f'{key}_{group}_{which}.json'
    old=json.loads(file.read_text()) if file.exists() else {}
    if old.get('status')=='excluded':return
    C,t,status=M.solve(iterations=90,seed=old.get('tags',[]))
    file.write_text(json.dumps(dict(status=status,anchors=[anchor],extra_deny=[denied],unique_group=group,
                                  decisions=cond,tags=t,cert=C),separators=(',',':')))
    print(key,group,which,M.n,M.nq,len(t),status,flush=True)
if __name__=='__main__':
    import sys
    with ProcessPoolExecutor(2) as pool:
        for f in [pool.submit(run,'9-41.0',101,int(i)) for i in sys.argv[1:]]:f.result()
