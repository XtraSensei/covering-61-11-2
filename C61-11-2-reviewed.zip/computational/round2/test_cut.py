"""Small exhaustive checks of grouping, cut optimization, and the cubic reduction."""
from pathlib import Path
from itertools import combinations,product
from random import Random
from subprocess import check_output
from cut_exact import strongest_cut
import sys
ROOT=Path(__file__).resolve().parent

def value(types,b,k,x):
    h=sum(q*t[1] for q,t in zip(x,types));q,s=divmod(h,b);cap=(b-s)*q*(k-q)+s*(q+1)*(k-q-1)
    crossing=sum((xi*(v-xj)+xj*(u-xi)) for ((p,h,u),xi),((r,l,v),xj) in combinations(zip(types,x),2) if not p&r)
    return crossing-cap

def direct(types,b,k):
    return max(value(types,b,k,x) for x in product(*(range(w+1) for p,h,w in types)))

def cubic(edges,n):
    supports=[0]*n;c=0
    for i,j in combinations(range(n),2):
        if (i,j) not in edges:supports[i]|=1<<c;supports[j]|=1<<c;c+=1
    alpha=max(mask.bit_count() for mask in range(1<<n) if all(not(mask>>i&mask>>j&1) for i,j in edges))
    return [(p,1,1) for p in supports],n//2,2,2*alpha

def run():
    rng=Random(61);tests=[]
    for _ in range(65):
        n=rng.randrange(3,7);b=rng.randrange(2,5)
        t=[(rng.randrange(1,64),rng.randrange(1,b+1),rng.randrange(1,4)) for i in range(n)]
        s=sum(h*w for p,h,w in t)
        if s%b or s//b<2:continue
        k=s//b;tests.append((t,b,k,direct(t,b,k)))
    for n,edges in ((6,{(i,j) for i in range(3) for j in range(3,6)}),
                     (8,{(i,j) for i,j in combinations(range(8),2) if (i^j).bit_count()==1}),
                     (10,{tuple(sorted(e)) for i in range(5) for e in [(i,(i+1)%5),(i,i+5),(i+5,(i+2)%5+5)]})):
        tests.append(cubic(edges,n))
    inp=''.join(f'{len(t)} {b} {k}\n'+''.join(f'{p} {h} {w}\n' for p,h,w in t) for t,b,k,v in tests)
    exe=ROOT/('cutfast.exe' if sys.platform=='win32' else 'cutfast')
    out=check_output([str(exe)],input=inp,text=True).splitlines()
    assert len(out)==len(tests)
    for (t,b,k,v),line in zip(tests,out):
        best,mask,leaves=map(int,line.split());assert v==best and leaves==2**(len(t)-1)
        assert value(t,b,k,[w*((mask>>i)&1) for i,(p,h,w) in enumerate(t)])==best
        edges=[[wi*wj if i!=j and not p&q else 0 for j,(q,hj,wj) in enumerate(t)]
               for i,(p,hi,wi) in enumerate(t)]
        opt,chosen=strongest_cut(edges,[h*w for p,h,w in t],b,k)
        assert opt==best and value(t,b,k,[w*(i in chosen) for i,(p,h,w) in enumerate(t)])==opt
    print('cut checks',len(tests),'cubic graphs',3)
if __name__=='__main__':run()
