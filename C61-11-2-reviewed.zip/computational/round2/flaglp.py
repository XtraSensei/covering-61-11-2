"""One- and two-person incidence relaxations relative to prescribed people."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from collections import defaultdict
from itertools import combinations_with_replacement
from pathlib import Path
from array import array
import json,warnings
import numpy as np
from scipy.sparse import coo_matrix,csc_matrix,hstack
from scipy.optimize import linprog
from flagmath import flagdata,anchor_orbits,base
from family import ROOT
warnings.filterwarnings('ignore',message='Unrecognized options')

def first(key,anchors,deny):
    _,wid,cap,freq,T,U,_=flagdata(key,anchors,deny);N=sum(freq)
    mat=np.asarray([list(s)+[int(sum(s)==r) for r,v in enumerate(freq,7) if v] for s in T],dtype=np.int32)
    rhs=np.array([w*c for w,c in zip(wid,cap)]+[v for v in freq if v],dtype=np.int32)
    if not len(T):return {'empty':True}
    ma=csc_matrix(mat.T);c=np.zeros(len(T)+1);c[-1]=1
    res=linprog(c,A_eq=hstack([ma,csc_matrix(rhs[:,None])],format='csc'),b_eq=rhs,
                bounds=[(0,u) for u in U]+[(0,1)],options={'threads':1})
    if res.success and res.fun>1e-7:
        for scale in (1e4,1e7,1e9):
            y=np.rint(res.eqlin.marginals*scale).astype(np.int64)
            val=mat@y
            maximum=int(np.maximum(val,0)@U);need=int(rhs@y)
            if need>maximum:return dict(y=y.tolist(),need=need,maximum=maximum)
    return None

class SparseRows:
    def __init__(self):
        self.id={};self.rhs=[];self.i=array('i');self.j=array('i');self.x=array('i')
    def add(self,name,c,v,rhs=0):
        if not v:return
        k=self.id.get(name)
        if k is None:k=len(self.rhs);self.id[name]=k;self.rhs.append(rhs)
        self.i.append(k);self.j.append(c);self.x.append(v)
    def finish(self,n):
        return coo_matrix((np.frombuffer(self.x,dtype=np.int32),(np.frombuffer(self.i,dtype=np.int32),np.frombuffer(self.j,dtype=np.int32))),
                          shape=(len(self.rhs),n)).tocsc(),np.array(self.rhs,dtype=np.int64)

def system(key,anchors,deny):
    _,W,C,F,T,U,E=flagdata(key,anchors,deny)
    return incidence_system(W,C,F,T,U,E)

def incidence_system(W,C,F,T,U,E):
    n=len(T);N=sum(F);nc=len(W);r=[sum(s) for s in T]
    sel=[[(j,v) for j,v in enumerate(s) if v] for s in T]
    partial=[{j for j,v in z if v<W[j]} for z in sel]
    eq=SparseRows();ub=SparseRows()
    for i,si in enumerate(T):
        eq.add((0,r[i]),i,1,F[r[i]-7])
        for k,v in sel[i]:eq.add((1,k),i,v,W[k]*C[k])
        eq.add((2,i),i,-(N-1))
        for k in range(nc):eq.add((3,i,k),i,-(W[k]*C[k]-si[k]))
        for k in sorted(partial[i]):eq.add((4,i,k),i,-si[k]*(C[k]-1))
        for rank,f in enumerate(F,7):
            if f and rank>7:eq.add((5,i,rank),i,-(f-(r[i]==rank)))
        ub.add((0,i),i,1,U[i])
        for u in range(1,U[i]):ub.add((1,i,u),i,u,u*(u+1)//2)
        ub.add((2,i),i,-(E[i]//(r[i]-1)))
        for j in range(n):ub.add((3,i,j),i,-(U[j]-(i==j)))
        for q in (2,3,4):ub.add((6,i,q),i,-(E[i]//q))
    col=n;pairs=[];colend=[];delta=[]
    for i,j in combinations_with_replacement(range(n),2):
        if i==j and U[i]<=1:continue
        si=T[i];sj=T[j];low=[];vary=[];over=0;maximum=0
        for k,v in sel[i]:
            if sj[k]:
                l=max(0,v+sj[k]-W[k]);u=min(v,sj[k]);over+=l;maximum+=u
                if l:low.append((k,l))
                if u>l:vary.append((k,u-l))
        if not maximum:continue
        y=col;col+=1;pairs.append(y)
        for s,t in ((i,j),(j,i)):
            eq.add((2,s),y,1)
            for k,v in sel[t]:eq.add((3,s,k),y,v)
            for k,v in low:
                if k in partial[s]:eq.add((4,s,k),y,v)
            if r[t]>7:eq.add((5,s,r[t]),y,1)
            ub.add((3,s,t),y,1)
            for q in (2,3,4):ub.add((6,s,q),y,max(0,over-1)//q)
        if i==j:
            for u in range(1,U[i]):ub.add((1,i,u),y,-1,u*(u+1)//2)
            ub.add((2,i),y,2*(over-r[i]+1))
        if not over:ub.add((4,i,j),y,1)
        for k,di in vary:
            v=col;col+=1;delta.append((v,di))
            for s in (i,j):
                if k in partial[s]:eq.add((4,s,k),v,1)
            if i==j:ub.add((2,i),v,2)
            if not over:ub.add((4,i,j),v,-1)
            ub.add((5,i,j,k),v,1);ub.add((5,i,j,k),y,-di)
        colend.append(col)
    A,B=eq.finish(col);G,H=ub.finish(col)
    return n,N,A,B,G,H,np.array(pairs),np.array(colend),delta

def second(key,anchors,deny,secs):
    n,N,A,B,G,H,ix,end,delta=system(key,anchors,deny);nvar=A.shape[1]
    if not len(ix):return None,'empty-pair-graph'
    obj=np.zeros(nvar+1);obj[-1]=1
    res=linprog(obj,A_eq=hstack([A,csc_matrix(B[:,None])],format='csc'),b_eq=B,
                A_ub=hstack([G,csc_matrix((len(H),1))],format='csc'),b_ub=H,
                options={'threads':1,'time_limit':secs},method='highs')
    if res.success and res.fun>1e-6:
        for scale in (1e5,1e7,1e9):
            y=np.rint(res.eqlin.marginals*scale).astype(np.int64)
            z=np.minimum(0,np.rint(res.ineqlin.marginals*scale).astype(np.int64))
            cost=A.T@y+G.T@z;weight=np.zeros(nvar,dtype=np.int64)
            for k,v in delta:weight[k]=max(0,int(cost[k]))*v
            ac=np.r_[0,np.cumsum(weight)]
            upper=N*int(cost[:n].max())+N*(N-1)//2*int(np.max(cost[ix]+ac[end]-ac[ix+1]))
            rhs=int(B@y+H@z)
            if rhs>upper:
                nz=lambda a:[[int(j),int(a[j])] for j in np.where(a!=0)[0]]
                return dict(y=nz(y),z=nz(z),need=rhs,maximum=upper),f'excluded {n} {nvar}'
    return None,('pass' if res.success else 'limited')+f' {n} {nvar}'

def first_case(key):
    orbits,examples,classes=anchor_orbits(key);denied=[];proof=[]
    for step in range(8):
        fixed=tuple(denied);found=[]
        if cert:=first(key,(),fixed):
            proof.append((fixed,-1,cert));break
        for i in examples:
            if i in fixed:continue
            if cert:=first(key,(examples[i],),fixed):
                found.append(i);proof.append((fixed,i,cert))
        if not found:break
        denied+=found
    d=ROOT/'firstflags';d.mkdir(exist_ok=True)
    (d/(key+'.json')).write_text(json.dumps(proof,separators=(',',':')))
    print(key,len(orbits),len(denied),'closed' if proof and proof[-1][1]==-1 else 'open',flush=True)

def second_case(key,id,seconds=50):
    f=ROOT/'firstflags'/(key+'.json');data=json.loads(f.read_text()) if f.exists() else []
    if data and data[-1][1]==-1:return
    denied=tuple(v for _,v,_ in data)
    if id in denied:return
    e=anchor_orbits(key)[1];anc=() if id<0 else (e[id],)
    cert,status=second(key,anc,denied,seconds)
    print(key,id,status,flush=True)
    if cert:
        folder=ROOT/'secondflags';folder.mkdir(exist_ok=True)
        (folder/(key+'_'+str(id)+'.json')).write_text(json.dumps(dict(anchors=anc,deny=denied,cert=cert),separators=(',',':')))
if __name__=='__main__':
    from concurrent.futures import ProcessPoolExecutor
    import sys
    with ProcessPoolExecutor(2) as pool:
        if sys.argv[1]=='first':jobs=[pool.submit(first_case,key) for key in sys.argv[2:]]
        else:
            secs=int(sys.argv[2]);jobs=[pool.submit(second_case,key,int(i),secs) for a in sys.argv[3:] for key,i in [a.split(':')]]
        for f in jobs:f.result()
