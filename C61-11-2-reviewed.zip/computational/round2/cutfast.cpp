#include <algorithm>
#include <cstdint>
#include <iostream>
#include <limits>
#include <vector>
using U=std::uint64_t;
struct Type {U primary;int h,weight;};
int main(int argc,char** argv){
    const bool stop_early=argc>1;
    int n,b,k;
    while(std::cin>>n>>b>>k){
        if(n<1||n>63||b<=0||k<2)return 1;
        std::vector<Type> t(n);for(auto &v:t)std::cin>>v.primary>>v.h>>v.weight;
        std::vector<std::vector<int>> edges(n,std::vector<int>(n));
        std::vector<int> degree(n),inside(n);
        for(int i=0;i<n;i++)for(int j=0;j<i;j++)if(!(t[i].primary&t[j].primary)){
            int w=t[i].weight*t[j].weight;edges[i][j]=edges[j][i]=w;degree[i]+=w;degree[j]+=w;
        }
        auto capacity=[&](int h){
            int q=h/b,r=h%b;return (b-r)*q*(k-q)+r*(q+1)*(k-q-1);
        };
        int best=0;U selected=0,leaves=0;
        auto scan=[&](auto &self,int i,int seats,int crossings,U set)->void{
            if(stop_early&&best>0)return;
            if(i==n-1){leaves++;int val=crossings-capacity(seats);if(val>best){best=val;selected=set;}return;}
            self(self,i+1,seats,crossings,set);
            for(int j=i+1;j<n-1;j++)inside[j]+=edges[i][j];
            self(self,i+1,seats+t[i].weight*t[i].h,crossings+degree[i]-2*inside[i],set|(U(1)<<i));
            for(int j=i+1;j<n-1;j++)inside[j]-=edges[i][j];
        };
        scan(scan,0,0,0,0);std::cout<<best<<" "<<selected<<" "<<leaves<<"\n";
    }
}
