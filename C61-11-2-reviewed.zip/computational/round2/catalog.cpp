#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>

using Mask = std::uint64_t;
using Code = std::array<unsigned char, 20>;
using Perm = std::array<int,12>;
struct CodeHash {
    std::size_t operator()(const Code& code) const {
        Mask result=1469598103934665603ULL;
        for (auto x:code) result=(result^x)*1099511628211ULL;
        return result;
    }
};
struct Catalog {
    int a, q, graph, num_edges=0, generators_seen[12][12]{};
    int colour[12][12]{},edge[12][12]{},signature[12]{},id[4096]{};
    long long nodes=0,completions=0,orbits=0,group_order=0;
    int selected[20]{},base_pair_count[12]{};
    std::vector<int> fixed,tri_masks,by_edge[60];
    std::vector<Mask> tri_edges;
    std::vector<std::vector<int>> actions;
    std::unordered_set<Code,CodeHash> covered;
    std::ostream& out;
    Catalog(int graph,const std::string& line,std::ostream& out):graph(graph),out(out) {
        std::istringstream s(line);s>>a>>q;
        for(int g=0;g<q;g++) fixed.push_back(15<<(4*g));
        int z;
        while(s>>z){int i=z/a,j=z%a;fixed.push_back((1<<i)|(1<<j));base_pair_count[i]++;base_pair_count[j]++;}
        for(int mask:fixed) for(int i=0;i<a;i++) for(int j=i+1;j<a;j++)
            if((mask>>i&1)&&(mask>>j&1))colour[i][j]=colour[j][i]=__builtin_popcount(mask);
        for(int i=0;i<a;i++){
            int nq=i/4<q?1:0,np=base_pair_count[i];
            int deg=a-1-3*nq-np;
            if(deg<0||deg%2)throw std::logic_error("invalid leave degree");
            int ns=6-nq-np-deg/2;
            if(ns<0)throw std::logic_error("too many mandatory photos");
            for(int p=0;p<ns;p++)fixed.push_back(1<<i);
            signature[i]=10*nq+np;
        }
        for(int i=0;i<a;i++) for(int j=i+1;j<a;j++)if(!colour[i][j])edge[i][j]=edge[j][i]=num_edges++;
        if(num_edges>60||num_edges%3)throw std::logic_error("invalid residual edge count");
        for(int i=0;i<a;i++)for(int j=i+1;j<a;j++)for(int k=j+1;k<a;k++){
            if(colour[i][j]||colour[i][k]||colour[j][k])continue;
            int tm=(1<<i)|(1<<j)|(1<<k),t=tri_masks.size();
            id[tm]=t;tri_masks.push_back(tm);Mask m=0;
            for(int e:{edge[i][j],edge[i][k],edge[j][k]}){m|=Mask(1)<<e;by_edge[e].push_back(t);}
            tri_edges.push_back(m);
        }
    }
    void symmetries(int i,int taken,Perm& p){
        if(i==a){
            group_order++;int first=0;while(first<a&&p[first]==first)first++;
            if(first==a||generators_seen[first][p[first]])return;
            generators_seen[first][p[first]]=1;
            std::vector<int> image;
            for(int m:tri_masks){int mapped=0;for(int v=0;v<a;v++)if(m>>v&1)mapped|=1<<p[v];image.push_back(id[mapped]);}
            actions.push_back(std::move(image));return;
        }
        for(int v=0;v<a;v++)if(!(taken>>v&1)&&signature[i]==signature[v]){
            bool ok=true;for(int j=0;j<i;j++)if(colour[i][j]!=colour[v][p[j]]){ok=false;break;}
            if(ok){p[i]=v;symmetries(i+1,taken|(1<<v),p);}
        }
    }
    void record(int length){
        completions++;Code item;item.fill(255);for(int i=0;i<length;i++)item[i]=selected[i];
        std::sort(item.begin(),item.begin()+length);
        if(!covered.insert(item).second)return;
        orbits++;out<<a<<" "<<graph<<" "<<orbits;
        std::vector<int> rows=fixed;for(int j=0;j<length;j++)rows.push_back(tri_masks[item[j]]);
        std::sort(rows.begin(),rows.end());
        for(int m:rows)out<<" "<<m;out<<"\n";
        std::vector<Code> pending{item};
        while(!pending.empty()){
            auto current=pending.back();pending.pop_back();
            for(const auto& act:actions){
                auto next=current;
                for(int j=0;j<length;j++)next[j]=act[current[j]];
                std::sort(next.begin(),next.begin()+length);
                if(covered.insert(next).second)pending.push_back(next);
            }
        }
    }
    void solve(Mask left,int depth){
        nodes++;
        if(!left){record(depth);return;}
        int min_count=100,best=-1;
        for(Mask s=left;s;s&=s-1){
            int e=__builtin_ctzll(s),n=0;
            for(int t:by_edge[e])if((left&tri_edges[t])==tri_edges[t])n++;
            if(n<min_count){best=e;min_count=n;if(!n)break;}
        }
        for(int t:by_edge[best])if((left&tri_edges[t])==tri_edges[t])
            {selected[depth]=t;solve(left^tri_edges[t],depth+1);}
    }
    void run(){Perm p{};symmetries(0,0,p);solve((Mask(1)<<num_edges)-1,0);
        if(covered.size()!=static_cast<std::size_t>(completions))throw std::logic_error("orbit count mismatch");}
};
int main(int argc,char**argv){
    if(argc!=3)return 1;
    std::ifstream f(argv[1]);std::ofstream out(argv[2]);if(!f||!out)return 2;
    std::string line;int g=0;
    while(std::getline(f,line)){Catalog c(g++,line,out);c.run();
        std::cout<<c.a<<" "<<c.graph<<" "<<c.group_order<<" "<<c.nodes<<" "<<c.completions<<" "<<c.orbits<<"\n";}
}
