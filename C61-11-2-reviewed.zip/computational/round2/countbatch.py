from family import *
from pathlib import Path
from collections import Counter,defaultdict
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys,json
import os

def inputfile(key):
    name,i=key.split('.');a,rows=catalog()[name];freq=FREQUENCIES[a][int(i)]
    types,ub=setup(a,rows,freq)
    flagged=os.environ.get('COVER_FLAGS')=='1'
    if flagged:
        from flagmath import anchor_orbits,flagdata
        certpath=ROOT/'firstflags'/(key+'.json');data=json.loads(certpath.read_text())
        deny={v for _,v,_ in data if v>=0};_,_,class_of=anchor_orbits(key)
        allowed=[j for j,t in enumerate(types) if class_of[t] not in deny]
        types=[types[j] for j in allowed];ub=[ub[j] for j in allowed]
    eq,rhs=equations(rows,freq,types);eqs=[(v,v,k) for k,v in zip(eq,rhs)]
    grouped=defaultdict(list)
    for j,(p,r) in enumerate(types):grouped[p].append(j)
    eqs.extend((0,upper_bound(a,p),ids) for p,ids in grouped.items() if len(ids)>1)
    if flagged:
        color,width,cap,fr,sorted_types,upper,_=flagdata(key,(),tuple(sorted(deny)))
        root={q:u for q,u in zip(sorted_types,upper)};same_shape=defaultdict(list)
        for j,(p,r) in enumerate(types):
            hist=Counter(rows[z] for z in range(len(rows)) if p>>z&1)
            hist[0]=r-p.bit_count()
            same_shape[tuple(hist[m] for m,_ in color)].append(j)
        eqs.extend((0,root[s],ids) for s,ids in same_shape.items() if len(ids)>1)
    d=ROOT/('countsflags' if flagged else 'counts');d.mkdir(exist_ok=True);f=d/(key+'.in')
    f.write_text(f'{len(types)} {38-len(rows)} {len(eqs)}\n'+''.join(f'{p} {r} {u}\n' for (p,r),u in zip(types,ub))
                 +''.join(f'{l} {h} {len(ids)} '+' '.join(map(str,ids))+'\n' for l,h,ids in eqs))
    return f

def job(key,lim,save,level):
    f=inputfile(key);out=f.with_suffix('.layouts');res=subprocess.check_output(
        [str(ROOT/'countsearch.exe'),str(f),str(out),str(lim),str(save),str(level)],text=True).strip()
    f.with_suffix('.stats').write_text(res+'\n');print(key,res,flush=True)

if __name__=='__main__':
    lim,save,level=map(int,sys.argv[1:4])
    with ThreadPoolExecutor(3) as pool:
        fs=[pool.submit(job,key,lim,save,level) for key in sys.argv[4:]]
        for f in fs:f.result()
