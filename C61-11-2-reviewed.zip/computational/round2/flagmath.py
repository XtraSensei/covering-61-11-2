"""Row-color orbits of people after prescribing the photos of several anchors."""
from collections import Counter,defaultdict
from functools import lru_cache
from itertools import combinations,product
from family import ROOT,FREQUENCIES,catalog,setup

@lru_cache(None)
def base(key):
    name,i=key.split('.');a,rows=catalog()[name];freq=FREQUENCIES[a][int(i)];b=38-len(rows)
    types,upper=setup(a,rows,freq);full=[]
    for p,r in types:
        for z in combinations(range(len(rows),38),r-p.bit_count()):
            full.append((p|sum(1<<j for j in z),r))
    return a,rows,freq,full

@lru_cache(None)
def automorphisms(rows,a):
    family=Counter(rows);sizes=[[0]*a for _ in range(a)]
    for f in family:
        for i,j in combinations((i for i in range(a) if f>>i&1),2):sizes[i][j]=sizes[j][i]=f.bit_count()
    c=[(family[1<<i],tuple(sorted(sizes[i]))) for i in range(a)]
    by_last=[[] for _ in range(a)]
    for f in family:by_last[f.bit_length()-1].append(tuple(i for i in range(a) if f>>i&1))
    order=[]
    def visit(k,mask,perm):
        if k==a:order.append(tuple(perm));return
        for j in range(a):
            if mask>>j&1 or c[k]!=c[j] or any(sizes[k][u]!=sizes[j][v] for u,v in enumerate(perm)):continue
            perm.append(j)
            if all(family.get(sum(1<<perm[u] for u in group),0)==family[sum(1<<u for u in group)] for group in by_last[k]):
                visit(k+1,mask|(1<<j),perm)
            perm.pop()
    visit(0,0,[])
    return tuple(order)

@lru_cache(None)
def anchor_orbits(key):
    a,rows,freq,full=base(key);nr=len(rows);lows=tuple(sorted(set(rows)))
    sgn=lambda x:tuple(sorted(rows[j] for j in range(nr) if x>>j&1))
    types,upp=setup(a,rows,freq)
    simple={(sgn(p),r) for p,r in types}
    actions=automorphisms(rows,a)
    maps=[{m:sum(1<<perm[i] for i in range(a) if m>>i&1) for m in lows} for perm in actions]
    blocks={};member={}
    for s,r in sorted(simple):
        if (s,r) in member:continue
        ori={ (tuple(sorted(action[m] for m in s)),r) for action in maps}
        k=len(blocks);blocks[k]=min(ori)
        for v in ori:member[v]=k
    examples={}
    for m,r in full:
        k=member[(sgn(m),r)]
        if k not in examples:examples[k]=m
    proj={p:member[(sgn(p),r)] for p,r in types if freq[r-7] and sum(freq)==freq[r-7]}
    class_type={(p,r):member[(sgn(p),r)] for p,r in types}
    return blocks,examples,class_type

def minpairs(width,total):
    v,s=divmod(total,width)
    return width*v*(v-1)//2+s*v

def flagdata(key,anchors=(),deny=()):
    a,rows,freq,full=base(key);rows=rows+(0,)*(38-len(rows));counts=list(freq)
    for m in anchors:counts[m.bit_count()-7]-=1
    assert min(counts)>=0
    col=defaultdict(int)
    for j,l in enumerate(rows):
        tag=sum(1<<i for i,m in enumerate(anchors) if m>>j&1)
        col[l,tag]|=1<<j
    colors=sorted(col);parts=[col[c] for c in colors];width=[p.bit_count() for p in parts]
    cap=[11-l.bit_count()-tag.bit_count() for l,tag in colors]
    forbidden=set(deny)
    if forbidden:_,_,orb=anchor_orbits(key)
    nr=sum(bool(v) for v in rows);primarymask=(1<<nr)-1
    group={}
    for x,r in full:
        if not counts[r-7] or any((m&x)==0 for m in anchors):continue
        if forbidden and orb[x&primarymask,r] in forbidden:continue
        s=tuple((p&x).bit_count() for p in parts)
        if s in group:continue
        remain=10*(r-6)-sum((m&x).bit_count()-1 for m in anchors)
        if remain<0:continue
        u=min([counts[r-7],*(width[k]*cap[k]//v for k,v in enumerate(s) if v)])
        for q in range(2,u+1):
            meet=sum(minpairs(w,q*v) for w,v in zip(width,s) if v)
            if 2*meet-q*(q-1)>q*remain:
                u=q-1;break
        if u:group[s]=(x,u,remain)
    types=sorted(group);U=[group[s][1] for s in types];rep=[group[s][2] for s in types]
    return colors,width,cap,counts,types,U,rep

if __name__=='__main__':
    import sys
    for key in sys.argv[1:]:
        a,rows,freq,full=base(key);B,E,C=anchor_orbits(key)
        sample=[(k,len(flagdata(key,(E[k],))[4])) for k in list(B)[:4]]
        print(key,'sym',len(automorphisms(rows,a)),'orbits',len(E),'special',sum(x.bit_count()>7 for x in E.values()),'root types',len(flagdata(key)[4]),'samples',sample,flush=True)
