"""Canonical leaves for the low-replication incidence skeleton at a=10 and 11."""
from collections import defaultdict
from itertools import combinations
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def graph_key(G):
    n=len(G); c=[m.bit_count() for m in G]
    while True:
        f=[(c[i],tuple(sorted(c[j] for j in range(n) if G[i]>>j&1))) for i in range(n)]
        colors={v:k for k,v in enumerate(sorted(set(f)))}
        d=[colors[x] for x in f]
        if len(set(d))==len(set(c)):
            return tuple(sorted(f)),d
        c=d

def same(G,H,c,d):
    n=len(G)
    order=sorted(range(n),key=lambda i:d.count(c[i]))
    mapping={}
    def visit(k,free):
        if k==n:return True
        x=order[k]
        for y in range(n):
            if not free>>y&1 or c[x]!=d[y]:continue
            if any((G[x]>>u&1)!=(H[y]>>v&1) for u,v in mapping.items()):continue
            mapping[x]=y
            if visit(k+1,free^(1<<y)):return True
            del mapping[x]
        return False
    return visit(0,(1<<n)-1)

def ten():
    layer=[()];shapes=[]
    for n in range(1,11):
        buckets=defaultdict(list)
        for G in layer:
            allowed=[i for i,m in enumerate(G) if m.bit_count()<3]
            for k in range(min(3,n-1)+1):
                if n==10 and k!=3:continue
                for subset in combinations(allowed,k):
                    bit=sum(1<<j for j in subset)
                    H=tuple(m|((1<<(n-1)) if i in subset else 0) for i,m in enumerate(G))+(bit,)
                    if n==10 and any(m.bit_count()!=3 for m in H):continue
                    key,colors=graph_key(H);found=buckets[key]
                    if not any(same(G0,H,c0,colors) for G0,c0 in found):found.append((H,colors))
        layer=[G for group in buckets.values() for G,c in group]
        if n not in (1,4,7,10):continue
        for G in layer:
            new=sum(3-m.bit_count() for m in G);left=10-n-new
            if left<0 or left%2:continue
            edges=[(i,j) for i in range(n) for j in range(i+1,n) if G[i]>>j&1]
            p=n
            for i,m in enumerate(G):
                for _ in range(3-m.bit_count()):edges.append((i,p));p+=1
            while p<10:edges.append((p,p+1));p+=2
            shapes.append((10,0,edges))
    return shapes

def eleven():
    def partition(total,lower=3):
        if not total:
            yield ()
        else:
            for k in range(lower,total+1):
                for rest in partition(total-k,k):yield (k,)+rest
    out=[]
    for count in (4,7,10):
        for parts in partition(count):
            edges=[];start=0
            for size in parts:
                edges.extend(tuple(sorted((start+i,start+(i+1)%size))) for i in range(size))
                start+=size
            out.append((11,0,edges))
    return out

if __name__=='__main__':
    small=ten()+eleven()
    print('graphs',sum(a==10 for a,q,e in small),sum(a==11 for a,q,e in small))
    full=[' '.join(map(str,(a,q,*(a*i+j for i,j in edges)))) for a,q,edges in small]
    twelves=(ROOT.parent/'leave12.txt').read_text().splitlines()
    full+=['12 '+l for l in twelves]
    (ROOT/'shapes.txt').write_text('\n'.join(full)+'\n')
