"""Finite checks in the elementary affine-plane proof (Section 2 of lemmas.txt)."""
from itertools import combinations, product
from math import comb

from family import catalog


def verify():
    a, rows = catalog()['9-49']
    lines = [s for s in rows if s.bit_count() == 3]
    assert a == 9 and len(lines) == 12 and len(rows) == 30
    assert all(rows.count(1 << i) == 2 for i in range(9))
    assert all(sum(line & pair == pair for line in lines) == 1
               for i, j in combinations(range(9), 2) for pair in [(1 << i) | (1 << j)])
    directions = sorted({tuple(sorted(t for t in lines if t == l or not t & l)) for l in lines})
    assert len(directions) == 4 and all(len(d) == 3 for d in directions)
    assert all(u | v | w == 511 for u, v, w in directions)

    # In a direction with X full-line people and Y double-line people, the
    # number of single-line people selecting a line minus the number of
    # double-line people omitting it is 8-X-Y, constant on its three lines.
    # The two counts cannot both be positive. A full-line person can meet
    # a single-line person only in this same direction.
    local = []
    for x in range(9):
        for y in range(25):
            s = max(0, 8 - x - y)
            omitted = max(0, x + y - 8)
            if 3 * omitted == y:
                local.append((x, y, 3 * s))
    patterns = set()
    for ds in product(local, repeat=4):
        x, y, z = map(sum, zip(*ds))
        if x + y + z != 52 or 3 * x + 2 * y + z != 96:
            continue
        if any(ds[i][0] and ds[j][2] for i in range(4) for j in range(4) if i != j):
            continue
        patterns.add(tuple(sorted(ds)))
    assert patterns == {((0, 12, 0), (0, 12, 0), (0, 12, 0), (4, 0, 12))}
    assert 2 * (3 * comb(4, 2) + 9 * 2 * comb(4, 2) - comb(12, 2)) == 12 * 10

    # Test all 512 assignments of the representative XOR differences on nine
    # points, for each possible horizontal direction. None permits a mixed
    # value on a horizontal line. Complementary choices in each other row
    # must therefore include a pair of people that cannot meet.
    for horizontal in directions:
        other = [m for m in lines if m not in horizontal]
        possible = [mask for mask in range(512) if all((mask & m).bit_count() % 2 for m in other)]
        assert len(possible) == 4
        assert all((mask & row) in (0, row) for mask in possible for row in horizontal)
    return 'four directions, four constant-on-rows assignments each'


if __name__ == '__main__':
    print(verify())
