"""Project indistinguishable singleton photos before enumerating outsider counts."""
from flagmath import flagdata,base
from family import ROOT
from collections import defaultdict,Counter
from concurrent.futures import ThreadPoolExecutor
import json,sys,subprocess,os

def grouped(key):
    f=ROOT/'firstflags'/(key+'.json')
    deny=[k for _,k,_ in json.loads(f.read_text()) if k>=0] if f.exists() else []
    col,w,c,freq,types,upper,rep=flagdata(key,(),tuple(deny))
    assert col[0][0]==0
    p=[sum(1<<(j-1) for j in range(1,len(col)) if s[j]) for s in types]
    assert all(all(v<=1 for v in s[1:]) for s in types)
    ranks=[sum(s) for s in types]
    eq=[([i for i,s in enumerate(types) if s[j]],w[j]*c[j]) for j in range(1,len(col))]
    eq.extend(([i for i,r in enumerate(ranks) if r==rank],v) for rank,v in enumerate(freq,7) if v)
    return col,w,c,list(zip(p,ranks,upper)),eq

def run(key,limit,save):
    mode=os.environ.get('COVER_STRONG','');strong=bool(mode)
    col,w,c,t,eq=grouped(key);d=ROOT/({'1':'groupstrong','2':'groupgraph','3':'groupclique'}.get(mode,'groupcounts'));d.mkdir(exist_ok=True)
    inp=d/(key+'.in');out=d/(key+'.layouts')
    guaranteed=sum(1<<(j-1) for j in range(1,len(w)) if w[j]==1)
    extra=''
    if mode in ('2','3'):
        src=ROOT/('cliquecerts' if mode=='3' else 'neighborcerts')/(key+'.json')
        data=json.loads(src.read_text());dead=data['blocked'];edges=data['edges']
        extra='conflicts '+f'{len(dead)} {len(edges)}\n'+' '.join(map(str,dead))+'\n'+''.join(f'{i} {j}\n' for i,j in edges)
    inp.write_text(f'{len(t)} {w[0]} {len(eq)}\n'+''.join(f'{p} {r} {u}\n' for p,r,u in t)
        +''.join(f'{n} {n} {len(g)} '+' '.join(map(str,g))+'\n' for g,n in eq)
        +'guaranteed\n'+' '.join(str(p&guaranteed) for p,r,u in t)+'\n'+extra)
    exe=ROOT/('countgraph.exe' if mode in ('2','3') else ('countstrong.exe' if strong else 'countsearch.exe'))
    result=subprocess.check_output([str(exe),str(inp),str(out),str(limit),str(save),'-4' if strong else '4'],text=True).strip()
    (d/(key+'.stats')).write_text(result+'\n');print(key,result,flush=True)
if __name__=='__main__':
    with ThreadPoolExecutor(3) as pool:
        jobs=[pool.submit(run,key,int(sys.argv[1]),int(sys.argv[2])) for key in sys.argv[3:]]
        for f in jobs:f.result()
