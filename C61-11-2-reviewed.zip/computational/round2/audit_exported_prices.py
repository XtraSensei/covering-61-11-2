"""Rebuild the geometric source of every exported two-person and rooted price row."""
import gzip
import json
from pathlib import Path

from audit_base import check_base
from audit_gram import extra_row
from audit_first import verify_first
from cliquelp import verify as verify_cliques
from flagmath import flagdata
from momentsdp import Moments,ROOT
from neighborhood import check as verify_neighbors
from rootedgram import unique_anchor

def read(path):
    return json.loads(path.read_text(encoding='utf8'))

def verify(directory):
    count=0;done=set()
    path=ROOT/'routes.json'
    routes=read(path if path.exists() else ROOT.parent/'proof-package'/'round2'/'routes.json')
    need={k+'/moment' for k,v in routes.items() if v=='moment'}|{f'9-41.0/root/{j}' for j in range(5)}
    with gzip.open(directory/'prices.jsonl.gz','rt',encoding='utf8') as inp:
        for raw in inp:
            record=json.loads(raw);key=record.get('case')
            if record['kind'] not in ('rooted','moment'):continue
            name=record['id'];assert name in need;need.remove(name)
            if key not in done:
                verify_first(key)
                if (ROOT/'cliquecerts'/(key+'.json')).is_file():verify_neighbors(key);verify_cliques(key)
                done.add(key)
            origin='gramcerts/'+key+'.json'
            if record['kind']=='rooted':
                k=int(name.rsplit('/',1)[1]);assert key=='9-41.0'
                origin='rootedgram/'+key+'_101_-1.json' if k==1 else f'gramslices/{key}_101v{k}.json'
            assert record['source']==origin
            witness=read(ROOT/origin);assert witness['status']=='excluded'
            anchors=tuple(witness.get('anchors',[]));extra=tuple(witness.get('extra_deny',[]))
            dec=witness.get('decisions',[])
            first={i for _,i,_ in read(ROOT/'firstflags'/(key+'.json')) if i>=0}
            if record['kind']=='moment':
                assert not anchors and not extra and not dec
            else:
                colors,widths,_,_,types,caps,_=flagdata(key,(),tuple(sorted(first)))
                sig=types[101]
                required=[1+2**5+2**6,2+2**4+2**7,4+2**3+2**8]
                assert sum(sig)==7 and caps[101]==4 and colors[0][0]==0 and sig[0]==4 and widths[0]==11
                assert sorted(mask for ((mask,_),w,s) in zip(colors[1:],widths[1:],sig[1:]) if s==1 and w==1)==sorted(required)
                if k==1:
                    assert witness['unique_group']==101 and not dec
                    a,i=unique_anchor(key,101);assert anchors==(a,) and extra==(i,)
                else:
                    assert not anchors and not extra and dec==[[[101],k]]
            model=Moments(key,anchors,extra);model.condition(dec)
            check_base(model,anchors,tuple(sorted(first|set(extra))),dec)
            assert all(u==int(u) and u>=0 for u in model.ub)
            assert record['upper']==list(map(int,model.ub))
            origins=[];rows=[]
            for label,M,rhs,sign in [('y',model.A,model.B,'='),('z',model.G,model.H,'<=')]:
                M=M.tocsr()
                for j,w in witness['cert'][label]:
                    if j<M.shape[0]:
                        p,q=M.indptr[j:j+2];v=M.data[p:q];ix=M.indices[p:q]
                        assert rhs[j]==int(rhs[j]) and all(c==int(c) for c in v)
                        pairs=[[int(i),int(c)] for i,c in zip(ix,v) if c];b=int(rhs[j])
                    else:
                        assert label=='z'
                        row,b=extra_row(model,witness['tags'][j-M.shape[0]])
                        pairs=[[i,int(c)] for i,c in enumerate(row) if c]
                    origins.append([label,j]);rows.append([sign,w,b,pairs])
            assert record['origins']==origins and record['rows']==rows and record['gap']==witness['cert']['gap']
            count+=1
    assert not need and count==34
    print(f'Reconstructed every selected row and bound for {count} exported moment and rooted prices.')

if __name__=='__main__':
    if not __debug__:raise RuntimeError('Run without -O.')
    source=ROOT.parent/'portable_prices';verify(source if source.is_dir() else ROOT.parent.parent/'integer')
