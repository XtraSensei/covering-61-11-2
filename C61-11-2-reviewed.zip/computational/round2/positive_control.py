"""Apply the same pair counting model to a known, fully valid 39-photo covering."""
from collections import Counter
from itertools import combinations, combinations_with_replacement
from pathlib import Path

import numpy as np
from flaglp import incidence_system
from flagmath import minpairs


def verify(src=None):
    src=src or Path(__file__).resolve().parent.parent/'prior'/'cover39.txt'
    photos=[set(map(int,line.split())) for line in src.read_text().splitlines()]
    signatures={i:sum(1<<b for b,row in enumerate(photos) if i in row) for i in range(1,62)}
    ranks={i:s.bit_count() for i,s in signatures.items()}
    assert Counter(ranks.values())=={6:4,7:52,8:4,9:1}
    lows=sorted(i for i in ranks if ranks[i]==6)
    seven=next(i for i in ranks if ranks[i]==7)
    eight=next(i for i in ranks if ranks[i]==8)
    checked=[]
    for anchors in ((),(seven,),(seven,eight)):
        fixed=set(lows)|set(anchors)
        people=sorted(set(ranks)-fixed)
        colors=[tuple(sorted(photo&fixed)) for photo in photos]
        classes=sorted(set(colors))
        color_masks=[sum(1<<b for b,c in enumerate(colors) if c==typ) for typ in classes]
        W=[m.bit_count() for m in color_masks]
        C=[11-len(c) for c in classes]
        F=[sum(ranks[i]==r for i in people) for r in (7,8,9)]
        person_type={i:tuple((signatures[i]&m).bit_count() for m in color_masks) for i in people}
        P=sorted(set(person_type.values()))
        rank={s:k for k,s in enumerate(P)}
        ids=[rank[person_type[i]] for i in people]
        how_many=Counter(ids)
        U=[];E=[]
        for t,s in enumerate(P):
            r=sum(s)
            spent=sum(sum(s[j] for j,c in enumerate(classes) if a in c)-1 for a in anchors)
            residual=10*(r-6)-spent
            cap=min([F[r-7],*(W[j]*C[j]//v for j,v in enumerate(s) if v)])
            for q in range(2,cap+1):
                if 2*sum(minpairs(w,q*v) for w,v in zip(W,s))-q*(q-1)>q*residual:
                    cap=q-1
                    break
            assert cap>=how_many[t] and residual>=0
            U.append(cap);E.append(residual)
        n,N,A,B,G,H,*_=incidence_system(W,C,F,P,U,E)
        z=np.zeros(A.shape[1],dtype=np.int64)
        z[:n]=[how_many[i] for i in range(n)]
        pos=n;columns={}
        for i,j in combinations_with_replacement(range(n),2):
            maxima=[min(a,b) for a,b in zip(P[i],P[j])]
            minima=[max(0,a+b-w) for a,b,w in zip(P[i],P[j],W)]
            if (i==j and U[i]<=1) or not any(maxima):
                continue
            y=pos;pos+=1;extra={}
            for c in range(len(W)):
                if maxima[c]>minima[c]:
                    extra[c]=pos
                    pos+=1
            columns[i,j]=(y,minima,extra)
        assert pos==len(z)
        for i,j in combinations(range(len(people)),2):
            y,minima,delta=columns[tuple(sorted((ids[i],ids[j])))]
            common=signatures[people[i]]&signatures[people[j]]
            assert common
            z[y]+=1
            for c,p in delta.items():
                z[p]+=(common&color_masks[c]).bit_count()-minima[c]
        assert N==len(people) and min(z)>=0
        assert np.array_equal(A@z,B) and np.all(G@z<=H)
        checked.append((len(anchors),n,A.shape[0],G.shape[0]))
    print('Valid 39-photo controls (fixed people, types, equalities, inequalities):',checked,flush=True)
