"""Necessary incidence inequalities on the union of photos of connected anchors."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import json,sys,warnings
from itertools import combinations
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csc_matrix,hstack
from groupbatch import grouped
from flagmath import automorphisms,base
from family import ROOT
warnings.filterwarnings('ignore',message='Unrecognized options')

class Problem:
    def __init__(self,key):
        self.key=key;C,W,c,T,eq=grouped(key);self.T=T;self.n=len(T);self.a,self.rows,*_=base(key)
        n=self.n;self.W=W;self.b=W[0];self.col=C
        self.h=[r-p.bit_count() for p,r,u in T];self.ub=np.array([u for p,r,u in T],dtype=np.int32)
        self.A=np.zeros((len(eq),n),dtype=np.int32);self.B=np.array([v for ix,v in eq],dtype=np.int32)
        for i,(ix,v) in enumerate(eq):self.A[i,ix]=1
        self.D=np.array([[int(not(p&q)) for q,s,v in T] for p,r,u in T],dtype=np.int32)
        fixed=sum(1<<(k-1) for k in range(1,len(W)) if W[k]==1)
        self.repeat=np.array([[max(0,(p&q&fixed).bit_count()-1) for q,s,v in T] for p,r,u in T],dtype=np.int32)
        where={(p,r):i for i,(p,r,u) in enumerate(T)};names={m:j-1 for j,(m,_) in enumerate(C) if j}
        actions=set()
        for perm in automorphisms(self.rows,self.a):
            rowmap={k:names[sum(1<<perm[i] for i in range(self.a) if m>>i&1)] for m,k in names.items()}
            actions.add(tuple(where[sum(1<<rowmap[k] for k in range(len(W)-1) if p>>k&1),r] for p,r,u in T))
        self.actions=sorted(actions);self.blocked=set();self.edges=set()
        self.hard={(i,j) for i,j in combinations(range(n),2) if self.D[i,j] and min(self.h[i],self.h[j])==0}
        self.edges.update(self.hard)
    def orbit(self,S):
        return sorted({tuple(sorted(g[i] for i in S)) for g in self.actions})
    def model(self,S):
        n=self.n;lo=np.zeros(n,dtype=np.int32);up=self.ub.copy()
        if self.blocked:up[list(self.blocked)]=0
        for i in S:
            lo[i]=1
            for j in range(n):
                if tuple(sorted((i,j))) in self.edges:up[j]=0
        if np.any(lo>up):return 'bound'
        gs=[];bs=[]
        for i in S:
            p,r,_=self.T[i];gs.append(self.D[i]);bs.append(10*self.h[i])
            for q in (1,2,3,4):
                rr=self.repeat[i]//q
                if np.any(rr):gs.append(rr);bs.append(10*(r-6)//q+rr[i])
        # Any connected subset of required pairs shares at most
        # 1+sum(h_i-1) distinct blank photos.
        for size in range(2,len(S)+1):
            for A in combinations(S,size):
                connected={A[0]}
                for _ in A:connected|={j for j in A if any(self.D[i,j] for i in connected)}
                if len(connected)!=len(A):continue
                gs.append(np.maximum.reduce(self.D[list(A)]));bs.append(11+10*sum(self.h[i]-1 for i in A))
        G=np.asarray(gs,dtype=np.int32).reshape(-1,n);H=np.asarray(bs,dtype=np.int32)
        return self.A,self.B-self.A@lo,G,H-G@lo,up-lo
    def probe(self,S,provided=None):
        model=self.model(S)
        if isinstance(model,str):return {'bound':True}
        A,B,G,H,U=model;n=self.n
        if provided is None:
            cost=np.zeros(n+1);cost[-1]=1
            gu=csc_matrix(np.column_stack([G,H])) if len(H) else None
            mat=csc_matrix(np.column_stack([A,B]))
            res=linprog(cost,A_eq=mat,b_eq=B,A_ub=gu,b_ub=H if len(H) else None,
                       bounds=[(0,int(u)) for u in U]+[(0,1)],options={'threads':1})
            if not res.success or res.fun<1.e-7:return None
            ys=res.eqlin.marginals;zs=res.ineqlin.marginals if len(H) else np.zeros(0)
            candidates=[(np.rint(ys*s).astype(np.int64),np.minimum(0,np.rint(zs*s).astype(np.int64))) for s in (1e3,1e5,1e7)]
        else:
            assert 'bound' not in provided
            # Object arrays route all signed price arithmetic through Python integers.
            y=np.zeros(len(B),dtype=object);z=np.zeros(len(H),dtype=object)
            for rows,vector in ((provided['y'],y),(provided['z'],z)):
                assert len({k for k,_ in rows})==len(rows)
                for k,v in rows:
                    assert type(k) is int and 0<=k<len(vector) and type(v) is int
                    vector[k]=v
            assert all(z<=0);candidates=[(y,z)]
        for y,z in candidates:
            v=A.T@y+G.T@z;upper=int(np.maximum(v,0)@U);target=int(B@y+H@z)
            if target>upper:
                nz=lambda s:[[int(k),int(s[k])] for k in np.where(s)[0]]
                return dict(y=nz(y),z=nz(z),gap=target-upper)
        return None
    def apply(self,S):
        for orb in self.orbit(S):
            if len(orb)==1:self.blocked.add(orb[0])
            elif len(orb)==2:self.edges.add(orb)
            else:raise ValueError('unexpected arity')

def run(key):
    P=Problem(key);proof=[];closed=False
    for iteration in range(12):
        if cert:=P.probe(()):
            proof.append([[],cert]);closed=True;break
        changed=0
        for size in (1,2):
            done=set()
            for S in combinations(range(P.n),size):
                if S in done or set(S)&P.blocked or (size==2 and S in P.edges):continue
                done.update(P.orbit(S))
                if cert:=P.probe(S):
                    proof.append([S,cert]);P.apply(S);changed+=1
        if not changed:break
    d=ROOT/'neighborcerts';d.mkdir(exist_ok=True)
    out=dict(proof=proof,closed=closed,blocked=sorted(P.blocked),edges=sorted(P.edges))
    (d/(key+'.json')).write_text(json.dumps(out,separators=(',',':')))
    print(key,P.n,len(P.blocked),len(P.edges),'closed' if closed else 'open',flush=True)

def check(key):
    P=Problem(key);data=json.loads((ROOT/'neighborcerts'/(key+'.json')).read_text())
    for S,cert in data['proof']:
        assert P.probe(tuple(S),cert)==cert
        if S:P.apply(tuple(S))
    assert sorted(P.blocked)==data['blocked'] and [list(e) for e in sorted(P.edges)]==data['edges']
    return data['closed']
if __name__=='__main__':
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor(2) as pool:list(pool.map(run,sys.argv[1:]))
