"""Reconstruct the incident-person identities independently of the sparse row builder.

Only rows admitted by a direct counting identity or a listed necessary inequality
are accepted. Rows are compared after summing columns in each symmetry orbit.
"""
from collections import Counter
from itertools import combinations_with_replacement

from flagmath import flagdata


def check_base(M, anchors, denied, decisions):
    _, W, C, F, profiles, U, E = flagdata(M.key, anchors, denied)
    n = len(profiles)
    ranks = list(map(sum, profiles))
    N = sum(F)
    col = tuple(map(int, M.orb))
    eq = set()
    le = set()

    def signature(row, rhs):
        return int(rhs), tuple(sorted((i, v) for i,v in row.items() if v))

    for matrix, rhs, remaining in ((M.A, M.B, eq), (M.G, M.H, le)):
        mat = matrix.tocsr()
        for i in range(len(rhs)):
            l, h = mat.indptr[i:i+2]
            remaining.add(signature(dict(zip(map(int, mat.indices[l:h]), map(int, mat.data[l:h]))), rhs[i]))

    def admit(remaining, row, rhs=0):
        remaining.discard(signature(row, rhs))

    def poprow(ids):
        return Counter(col[i] for i in ids)

    # Independently recover the complete variable ordering from feasible
    # intersections of two incidence profiles. Missing columns mean value zero.
    links = [[] for _ in range(n)]
    pair = {}
    offset = n
    for i,u in enumerate(U):
        assert int(M.ub[col[i]]) == (0 if i in M.blocked else u)
    for i,j in combinations_with_replacement(range(n),2):
        u = [min(a,b) for a,b in zip(profiles[i],profiles[j])]
        l = [max(0,a+b-w) for a,b,w in zip(profiles[i],profiles[j],W)]
        if (i == j and U[i] < 2) or not any(u):
            continue
        yi = col[offset]
        pair[i,j] = yi
        cap = U[i]*U[j] if i != j else U[i]*(U[i]-1)//2
        if i in M.blocked or j in M.blocked or (i,j) in M.conflicts:
            cap = 0
        assert int(M.ub[yi]) == cap
        delta = {}
        offset += 1
        for c in range(len(W)):
            if u[c] > l[c]:
                z = col[offset]
                offset += 1
                delta[c] = z
                assert int(M.ub[z]) == cap*(u[c]-l[c])
                r = Counter({z:1}); r[yi] -= u[c]-l[c]
                admit(le,r)
        if not any(l):
            r = Counter({yi:1}); r.subtract(delta.values()); admit(le,r)
        for a,b in ((i,j),(j,i)):
            links[a].append((b,yi,l,delta))
    assert offset == len(col)

    for rank,f in enumerate(F,7):
        if f:
            admit(eq,poprow(i for i in range(n) if ranks[i]==rank),f)
    for c,w in enumerate(W):
        r = Counter()
        for i,s in enumerate(profiles):
            r[col[i]] += s[c]
        admit(eq,r,w*C[c])

    for i, s in enumerate(profiles):
        x = col[i]
        arcs = links[i]
        r = Counter(v for j,v,l,d in arcs); r[x] -= N-1; admit(eq,r)
        for c,w in enumerate(W):
            totals = Counter()
            overlap = Counter()
            for j,v,l,d in arcs:
                totals[v] += profiles[j][c]
                overlap[v] += l[c]
                if c in d:
                    overlap[d[c]] += 1
            totals[x] -= w*C[c]-s[c]; admit(eq,totals)
            overlap[x] -= s[c]*(C[c]-1); admit(eq,overlap)
        for rank,f in enumerate(F,7):
            if f:
                r = Counter(v for j,v,l,d in arcs if ranks[j]==rank)
                r[x] -= f-int(ranks[i]==rank); admit(eq,r)
        admit(le,Counter({x:1}),U[i])
        diag = pair.get((i,i))
        for k in range(1,U[i]):
            r=Counter({x:k})
            if diag is not None: r[diag] -= 1
            admit(le,r,k*(k+1)//2)
        # Fully coincident people consume r-1 repeats each. For a same-type
        # partner with overlap z, z-(r-1) is bounded above by [z == r].
        r=Counter({x:-(E[i]//(ranks[i]-1))})
        for j,v,l,d in arcs:
            if i==j:
                r[v] += sum(l)-ranks[i]+1
                r.update(d.values())
        admit(le,r)
        for j in range(n):
            r=Counter({x:-(U[j]-int(i==j))})
            y=pair.get((min(i,j),max(i,j)))
            if y is not None: r[y]+=1+int(i==j)
            admit(le,r)
        for k in (2,3,4):
            r=Counter({x:-(E[i]//k)})
            for j,v,l,d in arcs: r[v]+=max(0,sum(l)-1)//k
            admit(le,r)

    def group_bound(ids, k, remaining):
        admit(remaining,poprow(ids),k)
        for j in range(n):
            r=Counter({col[j]:-k})
            for i in ids:
                if i==j: r[col[j]]+=1
                y=pair.get((min(i,j),max(i,j)))
                if y is not None: r[y]+=1+int(i==j)
            admit(remaining,r)

    for ids,k in decisions:
        group_bound(ids,k,eq)
    if anchors:
        from flagmath import base
        import json
        from family import ROOT
        initial = tuple(i for _,i,_ in json.loads((ROOT/'firstflags'/(M.key+'.json')).read_text()) if i>=0)
        colors,_,_,_,orig,upper,_=flagdata(M.key,(),initial)
        _,rows,_,_=base(M.key)
        colors2=flagdata(M.key,anchors,denied)[0]
        masks=list(rows)+[0]*(38-len(rows))
        parents=[orig.index(tuple(sum(s[j] for j,c in enumerate(colors2) if c[0]==low)
                                  for low,_ in colors)) for s in profiles]
        fixed=Counter(orig.index(tuple(sum((m>>j)&1 for j,mask in enumerate(masks) if mask==low)
                                       for low,_ in colors)) for m in anchors)
        for p in set(parents):
            group_bound([i for i in range(n) if parents[i]==p],upper[p]-fixed[p],le)
    assert not eq and not le, (M.key,len(eq),len(le),next(iter(eq or le),None))
