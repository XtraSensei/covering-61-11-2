"""One-blank components and their mandatory photo attendees."""
from collections import Counter
from pathlib import Path
from family import ROOT,catalog

def implications(types,blank_count):
    people=[(p,r-p.bit_count()) for p,r,w in types for _ in range(w)]
    n=len(people)
    masks=[sum(1<<j for j,(q,_) in enumerate(people) if not p&q) for p,_ in people]
    singles=sum(1<<i for i,(_,h) in enumerate(people) if h==1)
    forced=[]
    while singles:
        queue=singles&-singles;comp=queue;singles^=queue
        need=comp
        while queue:
            first=queue&-queue;queue^=first
            neighbors=masks[first.bit_length()-1];need|=neighbors
            more=neighbors&singles;queue|=more;comp|=more;singles^=more
        forced.append((comp,need))
    return people,masks,forced

def analyze(types,b):
    people,_,forced=implications(types,b)
    if any(need.bit_count()>11 for comp,need in forced):return 'capacity'
    # Two incompatible groups cannot be placed on the same photo. A clique
    # containing an anchor forces this person to attend all its distinct photos.
    for i,(p,h) in enumerate(people):
        required=[need for _,need in forced if need>>i&1]
        if len(required)<=h:continue
        edges=[sum(1<<j for j,y in enumerate(required) if (x|y).bit_count()>11) for x in required]
        def clique(mask,left):
            if left==0:return True
            while mask.bit_count()>=left:
                bit=mask&-mask;mask^=bit
                if clique(mask&edges[bit.bit_length()-1],left-1):return True
            return False
        if clique((1<<len(required))-1,h+1):return 'anchor'
    return None

def read_cases(path):
    for line in path.read_text().splitlines():
        yield [tuple(map(int,s.split(','))) for s in line.split()]

if __name__=='__main__':
    c=catalog()
    for path in sorted(ROOT.glob('*.cases')):
        key=path.name.removesuffix('.cases');_,rows=c[key.split('.')[0]]
        out=Counter(analyze(types,38-len(rows)) or 'keep' for types in read_cases(path))
        print(key,dict(out))
