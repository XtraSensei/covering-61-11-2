"""Low-replication skeletons and admissible types of the remaining people."""
from itertools import combinations
from pathlib import Path

ROOT=Path(__file__).resolve().parent
FREQUENCIES={9:((52,0,0),),10:((50,1,0),),11:((48,2,0),(49,0,1)),12:((46,3,0),)}

def nine_rows(line):
    triples=[tuple(int(c)-1 for c in s) for s in line.split()]
    pairs={p for t in triples for p in combinations(t,2)}
    rows=triples+[p for p in combinations(range(9),2) if p not in pairs]
    for v in range(9):
        rows.extend([(v,)]*(6-sum(v in r for r in rows)))
    return tuple(sum(1<<x for x in row) for row in rows)

def catalog():
    data={}
    for i,line in enumerate((ROOT.parent/'nine_kernels.txt').read_text().splitlines()):
        data[f'9-{i:02}']=(9,nine_rows(line))
    for line in (ROOT/'skeletons.txt').read_text().splitlines():
        a,g,i,*rows=map(int,line.split())
        data[f'{a}-{g:03}-{i:02}']=a,tuple(rows)
    return data

def partitions(rows,a):
    by_person=[[i for i,r in enumerate(rows) if r>>v&1] for v in range(a)]
    def visit(rem,p):
        if not rem:
            yield p
        else:
            v=(rem&-rem).bit_length()-1
            for i in by_person[v]:
                if rem&rows[i]==rows[i]:
                    yield from visit(rem^rows[i],p|1<<i)
    return sorted(visit((1<<a)-1,0))

def setup(a,rows,freq):
    empty=38-len(rows)
    quartets=sum(1<<i for i,r in enumerate(rows) if r.bit_count()==4)
    patterns=partitions(rows,a)
    types=[];upper=[]
    for p in patterns:
        size=p.bit_count()
        for d,pop in enumerate(freq,start=7):
            if pop==0 or not 0<=d-size<=empty:continue
            if a==12 and d==8 and p&quartets!=quartets:continue
            # Other people of the same type share every primary photo in p.
            u=min(pop,1+10*(d-6)//(size-1))
            if a==12 and d==7:
                fixed=3*max(0,(p&quartets).bit_count()-1)
                u=min(u,1+(10-fixed)//(size-1))
            types.append((p,d));upper.append(u)
    return types,upper

def upper_bound(a,p):
    return max(a-9,1+10//(p.bit_count()-1))

def equations(rows,freq,types):
    rhs=[11-r.bit_count() for r in rows]+[n for n in freq if n]
    eq=[[i for i,(p,d) in enumerate(types) if p>>j&1] for j in range(len(rows))]
    eq.extend([i for i,(p,r) in enumerate(types) if r==d] for d,c in enumerate(freq,7) if c)
    return eq,rhs
