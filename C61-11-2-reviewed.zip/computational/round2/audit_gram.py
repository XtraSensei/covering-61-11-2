"""Check moment-certificate inequalities with Python arbitrary-precision integers."""
from pathlib import Path
from momentsdp import Moments,ROOT,json
from itertools import combinations
from math import lcm
import sys

def extra_row(M,tag):
    kind,c,k,v=tag
    if kind=='clique':
        assert k==0 and -1<=c<M.n and v==sorted(set(v))
        assert all((i,j) in M.conflicts for i,j in combinations(v,2))
        L=lcm(*(M.U[i] for i in v));row=[0]*M.nq
        if c<0:
            for i in v:row[int(M.orb[i])]+=L//M.U[i]
            return row,L
        row[int(M.orb[c])]-=L
        for i in v:
            weight=L//M.U[i]
            if i==c:row[int(M.orb[i])]+=weight
            p=M.pair_map.get(tuple(sorted((i,c))))
            if p is not None:row[int(M.orb[p])]+=weight*(1+int(i==c))
        return row,0
    assert kind in ('counts','photos','center') and type(k) is int
    n=M.n;assert len(v)==n and all(type(x) is int for x in v)
    if kind=='counts':assert c==-1;w=1;s=[1]*n
    else:
        assert 0<=c<len(M.W) and M.W[c]>1
        w=M.W[c];s=[int(M.T[i,c]) for i in range(n)]
    if kind=='center':assert k==0
    rhs=0 if kind=='center' else w*k*(k+1)
    coef=[0]*M.nq;orb=list(map(int,M.orb))
    for i in range(n):
        if kind=='center':v0=v[i]*v[i]*(w*s[i]-s[i]*s[i])
        else:v0=s[i]*(v[i]*v[i]-(2*k+1)*v[i])
        coef[orb[i]]-=v0
    for e,(a,b,y) in enumerate(zip(M.pi,M.pj,M.py)):
        i,j,pos=int(a),int(b),int(y);cross=2*v[i]*v[j]
        if not cross:continue
        if kind=='counts':coef[orb[pos]]-=cross;continue
        low=max(0,s[i]+s[j]-w);high=min(s[i],s[j])
        if kind=='photos':coef[orb[pos]]-=cross*low;factor=cross
        else:coef[orb[pos]]-=cross*(w*low-s[i]*s[j]);factor=w*cross
        if high>low:
            # The columns immediately following this pair are its variable
            # intersections, in increasing photo-color order.
            before=sum(min(int(M.T[i,d]),int(M.T[j,d]))>max(0,int(M.T[i,d])+int(M.T[j,d])-M.W[d]) for d in range(c))
            coef[orb[pos+1+before]]-=factor
    return coef,rhs

def verify(key,path=None):
    file=path or ROOT/'gramcerts'/(key+'.json');d=json.loads(file.read_text());assert d['status']=='excluded'
    if 'anchors' in d:
        from rootedgram import unique_anchor
        a,i=unique_anchor(key,d['unique_group'])
        assert d['anchors']==[a] and d['extra_deny']==[i]
    M=Moments(key,tuple(d.get('anchors',[])),tuple(d.get('extra_deny',[])));M.condition(d.get('decisions',[]))
    from audit_base import check_base
    initial=tuple(i for _,i,_ in json.loads((ROOT/'firstflags'/(key+'.json')).read_text()) if i>=0)
    check_base(M,tuple(d.get('anchors',[])),tuple(sorted(set(initial)|set(d.get('extra_deny',[])))),d.get('decisions',[]))
    s=d['cert'];coef=[0]*M.nq;target=0;A=M.A.tocsr();G=M.G.tocsr();touched=0
    def addrow(scale,row,rhs):
        nonlocal target
        target+=scale*int(rhs)
        for j,v in row:coef[int(j)]+=scale*int(v)
    for tag,mat,rhs in [('y',A,M.B),('z',G,M.H)]:
        seen=set()
        for i,weight in s[tag]:
            assert type(i) is int and i>=0 and i not in seen and type(weight) is int
            seen.add(i)
            if tag=='z':assert weight<=0
            if i<mat.shape[0]:
                start,end=mat.indptr[i:i+2]
                addrow(weight,zip(mat.indices[start:end],mat.data[start:end]),rhs[i])
            else:
                assert tag=='z'
                row,K=extra_row(M,d['tags'][i-mat.shape[0]])
                addrow(weight,enumerate(row),K);touched+=1
    maximum=sum(max(0,c)*int(u) for c,u in zip(coef,M.ub));gap=target-maximum
    assert gap==s['gap'] and gap>0,(key,gap,s['gap'])
    return key,M.nq,touched,gap
if __name__=='__main__':
    keys=sys.argv[1:] or [p.stem for p in sorted((ROOT/'gramcerts').glob('*.json')) if json.loads(p.read_text())['status']=='excluded']
    for key in keys:print(*verify(key),flush=True)
