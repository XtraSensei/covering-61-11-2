"""Verify the second part of the nonexistence proof without calling an optimizer."""
from collections import Counter
from itertools import combinations
from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile

from family import FREQUENCIES, ROOT, catalog
from forced import read_cases


ENUMERATION = {
    '9-03.0': 'raw', '9-07.0': 'raw', '9-14.0': 'raw-flags',
    '9-16.0': 'group', '9-22.0': 'group', '9-23.0': 'raw',
    '9-37.0': 'group-clique', '10-021-03.0': 'raw',
    '10-045-02.0': 'mult', '11-057-03.0': 'mult', '11-057-03.1': 'mult',
}
HARD = '9-41.0'
AFFINE = '9-49.0'


def exe(stem):
    return str(ROOT / (stem + ('.exe' if os.name == 'nt' else '')))


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def enumeration(key, strategy):
    from groupbatch import grouped
    from countbatch import inputfile
    from check_rows import check
    from residualiso import representatives
    from multiplicity import multiplicities, assignments, cut

    name, profile = key.split('.')
    a, rows = catalog()[name]
    b = 38 - len(rows)
    source = ROOT / (key + '.cases')
    old = list(read_cases(source)) if source.exists() else []
    normalized = lambda t: tuple(sorted(t))
    checked = {normalized(t) for t in old}
    if strategy == 'mult':
        freq = FREQUENCIES[a][int(profile)]
        patterns, it, node_count = multiplicities(a, rows, freq)
        layouts = [normalized(t) for w in it for t in assignments(a, rows, freq, patterns, w)
                   if cut(t, b) is None]
        nodes = node_count()
    else:
        with tempfile.TemporaryDirectory(dir=ROOT) as scratch:
            out = Path(scratch) / 'layouts.txt'
            if strategy.startswith('raw'):
                os.environ['COVER_FLAGS'] = str(int(strategy == 'raw-flags'))
                inp = inputfile(key)
            else:
                col, widths, cap, types, equations = grouped(key)
                inp = Path(scratch) / 'system.txt'
                certain = sum(1 << (i-1) for i in range(1, len(col)) if widths[i] == 1)
                records = [f'{len(types)} {b} {len(equations)}']
                records.extend(f'{p} {r} {u}' for p,r,u in types)
                records.extend(f'{v} {v} {len(ids)} ' + ' '.join(map(str, ids))
                               for ids,v in equations)
                records.extend(['guaranteed', ' '.join(str(p & certain) for p,r,u in types)])
                if strategy == 'group-clique':
                    cert = read_json(ROOT/'cliquecerts'/(key+'.json'))
                    dead, edges = cert['blocked'], cert['edges']
                    records.extend([f'conflicts {len(dead)} {len(edges)}', ' '.join(map(str, dead))])
                    records.extend(f'{i} {j}' for i,j in edges)
                inp.write_text('\n'.join(records)+'\n')
            level = -4 if strategy == 'group-clique' else 4
            if key == '10-021-03.0':
                level = 3
            log = subprocess.check_output([exe('countsearch'), str(inp), str(out), str(2**60),
                                           str(max(1, len(old)+1)), str(level)], text=True).split()
            assert len(log) == 5 and log[-1] == 'complete'
            layouts = [normalized(t) for t in read_cases(out)]
            assert len(layouts) == int(log[3])
            nodes = int(log[1])
    assert len(layouts) == len(old) and set(layouts) == checked, (key,len(layouts),len(old))
    reps = sorted(set(representatives(old).values()))
    paths = []
    for rep in reps:
        filename = f'{key}-{rep:04}.json'
        candidates = [ROOT / d / filename for d in ('blankcerts', 'starcerts')]
        paths.append(next(path for path in candidates if path.exists()))
    for path in paths:
        _, result = check(path)
        assert int(result.split()[-1]) > 0
    return f'{nodes} nodes, {len(layouts)} inventories, {len(reps)} photo certificates'


def verify_hard(key):
    from audit_gram import verify
    from flagmath import base
    from momentsdp import Moments
    from rootedgram import unique_anchor
    assert key == HARD
    M = Moments(key)
    group = 101
    assert [i for i in range(M.n) if M.orb[i] == M.orb[group]] == [group]
    assert M.ub[M.orb[group]] == 4
    gaps = []
    for k in range(5):
        if k == 1:
            file = ROOT/'rootedgram'/(key+'_101_-1.json')
            d = read_json(file)
            m, denied = unique_anchor(key, group)
            assert d['unique_group'] == group and d['anchors'] == [m]
            assert d['extra_deny'] == [denied] and d['decisions'] == []
            a,rows,_,_ = base(key)
            assert (m >> len(rows)).bit_count() == 4 and 38-len(rows) == 11
        else:
            file = ROOT/'gramslices'/(key+f'_101v{k}.json')
            d = read_json(file)
            assert not d.get('anchors') and not d.get('extra_deny')
            assert d['decisions'] == [[[group], k]]
        gaps.append(verify(key, file)[-1])
    return 'positive margins for 0,1,2,3,4: ' + ','.join(map(str,gaps))


def verify_cases():
    from affine import verify as affine
    from audit_first import check_screen, verify_first
    from audit_gram import verify
    from flagmath import base, anchor_orbits
    from neighborhood import check as verify_neighborhood
    from cliquelp import verify as verify_cliques

    screen = read_json(ROOT/'screen.json')
    catalog_data = catalog()
    expected = {f'{key}.{i}' for key,(a,_) in catalog_data.items()
                for i in range(len(FREQUENCIES[a]))}
    assert set(screen) == expected and len(expected) == 251
    check_screen()
    ledger = {}
    for key in sorted(expected):
        if screen[key][0] == 'price':
            ledger[key] = 'seat'
            continue
        first = read_json(ROOT/'firstflags'/(key+'.json'))
        verify_first(key)
        if (ROOT/'cliquecerts'/(key+'.json')).exists():
            verify_neighborhood(key)
            verify_cliques(key)
        if any(i == -1 for _,i,_ in first):
            route, detail = 'anchor', 'root contradiction'
        elif key == AFFINE:
            route, detail = 'affine', affine()
        elif key == HARD:
            route, detail = 'rooted', verify_hard(key)
        elif key in ENUMERATION:
            route, detail = 'enumeration', enumeration(key, ENUMERATION[key])
        else:
            file = ROOT/'gramcerts'/(key+'.json')
            d = read_json(file)
            assert not d.get('decisions') and not d.get('anchors') and not d.get('extra_deny')
            _, columns, touched, gap = verify(key, file)
            route, detail = 'moment', f'{columns} columns, {touched} extra inequalities, margin {gap}'
        print(key, route, detail, flush=True)
        ledger[key] = route
        base.cache_clear()
        anchor_orbits.cache_clear()
    assert set(ledger) == expected
    if (ROOT/'routes.json').exists():
        assert ledger == read_json(ROOT/'routes.json')
    print('All 251 cases:', dict(sorted(Counter(ledger.values()).items())), flush=True)
    return ledger


def verify_catalog():
    from shapes import ten, eleven
    sys.path.insert(0, str(ROOT.parent))
    from leave12 import run
    leaves = [' '.join(map(str,(a,q,*(a*i+j for i,j in edges)))) for a,q,edges in ten()+eleven()]
    extra = [row for n in (1,2,3) for row in run(n)]
    assert extra == (ROOT.parent/'leave12.txt').read_text().splitlines()
    leaves.extend('12 '+row for row in extra)
    assert leaves == (ROOT/'shapes.txt').read_text().splitlines() and len(leaves) == 134
    with tempfile.TemporaryDirectory(dir=ROOT) as temp:
        out = Path(temp)/'systems.txt'
        log = subprocess.check_output([exe('catalog'), str(ROOT/'shapes.txt'), str(out)], text=True)
        assert out.read_text().splitlines() == (ROOT/'skeletons.txt').read_text().splitlines()
    stats = [list(map(int,l.split())) for l in log.splitlines()]
    assert len(stats)==134 and sum(row[3] for row in stats)==170203
    cat = catalog()
    assert Counter(a for a,rows in cat.values()) == {9:50,10:65,11:36,12:64}
    for a,rows in cat.values():
        assert all(m and m < 1<<a for m in rows) and len(rows)<=38
        for i in range(a):
            assert sum((r >> i) & 1 for r in rows)==6
            for j in range(i):
                assert sum(bool(r>>i&1 and r>>j&1) for r in rows)==1
    print('Enumerated skeletons:', len(cat), 'colored leaves:', len(leaves),
          'exact-cover nodes:', sum(row[3] for row in stats), flush=True)
