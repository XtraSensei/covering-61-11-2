"""Exact maximum cut-capacity violation on a weighted graph of person types."""


def strongest_cut(edges, seats, photo_count, photo_size):
    """Return the optimum and a set of type indices attaining it.

    edges[i][j] is the number of as-yet-uncovered pairs between types i and j.
    Members of each type have identical partners outside the type, have no
    missing internal pair, and require identical numbers of remaining photos.
    seats[i] is their total required appearances. Singleton types always work.
    The caller supplies the aggregated graph. Two depth-first traversals
    avoid making a potentially long copy on every improvement of the optimum.
    """
    g = len(seats)
    if not g or photo_count <= 0 or photo_size <= 0 or sum(seats) != photo_count * photo_size:
        raise ValueError("inconsistent photo and attendance totals")
    if any(len(row) != g for row in edges) or len(edges) != g or min(seats) < 0:
        raise ValueError("invalid graph or negative attendance")
    if any(edges[i][i] or any(edges[i][j] < 0 or edges[i][j] != edges[j][i]
                              for j in range(i)) for i in range(g)):
        raise ValueError("expected a symmetric nonnegative zero-diagonal matrix")

    degree = [sum(row) for row in edges]
    chosen = [False] * g
    prior = [0] * g
    best = 0

    def search(i, attendance, crossing, find_witness):
        nonlocal best
        if i == g - 1:
            q, rem = divmod(attendance, photo_count)
            capacity = ((photo_count - rem) * q * (photo_size - q)
                        + rem * (q + 1) * (photo_size - q - 1))
            value = crossing - capacity
            if find_witness:
                return value == best
            best = max(best, value)
            return False
        if search(i + 1, attendance, crossing, find_witness):
            return True
        chosen[i] = True
        for j in range(i + 1, g - 1):
            prior[j] += edges[i][j]
        if search(i + 1, attendance + seats[i], crossing + degree[i] - 2 * prior[i], find_witness):
            return True
        for j in range(i + 1, g - 1):
            prior[j] -= edges[i][j]
        chosen[i] = False
        return False

    search(0, 0, 0, False)
    if not search(0, 0, 0, True):
        raise RuntimeError("failed to reconstruct a maximizing cut")
    return best, tuple(i for i, take in enumerate(chosen) if take)
