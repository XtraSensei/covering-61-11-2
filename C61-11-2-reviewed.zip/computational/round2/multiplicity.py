"""Exact enumeration after projection onto the nonempty regular-point photos."""
from collections import Counter
from itertools import combinations, combinations_with_replacement
from pathlib import Path
import json
from family import ROOT,FREQUENCIES,catalog,partitions,upper_bound

def propagation(eqs,needs,upper):
    nodes=0
    def visit(lo,hi):
        nonlocal nodes
        nodes+=1
        while True:
            changed=False
            for row,need in zip(eqs,needs):
                lower=sum(lo[i] for i in row);higher=sum(hi[i] for i in row)
                if lower>need or higher<need:return
                for i in row:
                    L=max(lo[i],need-(higher-hi[i]));H=min(hi[i],need-(lower-lo[i]))
                    if L>H:return
                    if (lo[i],hi[i])!=(L,H):lo[i]=L;hi[i]=H;changed=True
            if not changed:break
        if lo==hi:
            yield tuple(lo);return
        i=min((i for i in range(len(lo)) if lo[i]<hi[i]),key=lambda i:hi[i]-lo[i])
        for k in range(lo[i],hi[i]+1):
            low=lo.copy();high=hi.copy();low[i]=high[i]=k;yield from visit(low,high)
    return visit([0]*len(upper),upper.copy()),lambda:nodes

def multiplicities(a,rows,freq):
    Q=sum(1<<j for j,r in enumerate(rows) if r.bit_count()==4)
    P=[p for p in partitions(rows,a) if p.bit_count()<=max(r for r,n in enumerate(freq,7) if n)
       and (p.bit_count()<=7 or a!=12 or p&Q==Q)]
    n=len(P)
    upper=[upper_bound(a,p) for p in P]
    if a==12:
        for i,p in enumerate(P):
            can=p&Q==Q
            # If all special people share the four-regular photos in p, they
            # already account for repeated meetings of an ordinary participant.
            e=3*max(0,(p&Q).bit_count()-1)
            normal=0 if p.bit_count()>7 else 1+(10-e)//(p.bit_count()-1)
            upper[i]=min(upper[i],normal+(3 if can else 0))
    eqs=[tuple(i for i,p in enumerate(P) if p>>j&1) for j in range(len(rows))]+[tuple(range(n))]
    values=[11-r.bit_count() for r in rows]+[61-a]
    iterator,nodecount=propagation(eqs,values,upper)
    return P,iterator,nodecount

def assignments(a,rows,freq,P,W):
    ids=[i for i in range(len(P)) if W[i]]
    p=[P[i] for i in ids];w=[W[i] for i in ids];n=len(p)
    blanks=38-len(rows)
    d=[sum(v for t,v in zip(p,w) if not x&t) for x in p]
    minrank=[max(7,x.bit_count(),x.bit_count()+(v+9)//10) for x,v in zip(p,d)]
    # A person with empty-photo count h can meet at most ten previously unseen people per photo.
    Q=sum(1<<k for k,r in enumerate(rows) if r.bit_count()==4)
    def select(r,num,available):
        choices=[i for i in range(n) if available[i] and 0<=r-p[i].bit_count()<=blanks
                 and (r!=8 or a!=12 or p[i]&Q==Q) and minrank[i]<=r]
        for seq in combinations_with_replacement(choices,num):
            v=Counter(seq)
            if all(t<=available[i] for i,t in v.items()):yield v
    if sum(max(0,r-7)*v for r,v in zip(minrank,w))>a-9:return
    for nines in select(9,freq[2],w):
        left=[v-nines[i] for i,v in enumerate(w)]
        for eights in select(8,freq[1],left):
            normals=[v-eights[i] for i,v in enumerate(left)]
            if any(v and minrank[i]>7 for i,v in enumerate(normals)):continue
            if any(v and not 0<=7-p[i].bit_count()<=blanks for i,v in enumerate(normals)):continue
            out=[(p[i],r,counts[i]) for i in range(n) for r,counts in ((7,normals),(8,eights),(9,nines)) if counts[i]]
            yield out

def cut(types,b,max_size=4):
    p=[x for x,_,_ in types]; w=[v for _,_,v in types]
    h=[v*(r-x.bit_count()) for x,r,v in types]
    n=len(p);deg=[v*sum(t for y,t in zip(p,w) if not x&y) for x,v in zip(p,w)]
    price=lambda mass: (lambda q,rem:(b-rem)*q*(11-q)+rem*(q+1)*(10-q))(*divmod(mass,b))
    maxH=sum(h);caps=[price(t) for t in range(maxH+1)]
    def visit(group,i,H,d):
        if d>caps[H]:return tuple(group)
        if len(group)==max_size:return None
        for j in range(i,n):
            overlap=sum(w[j]*w[k] for k in group if not p[j]&p[k])
            result=visit(group+[j],j+1,H+h[j],d+deg[j]-2*overlap)
            if result is not None:return result
        return None
    return visit([],0,0,0)

def run(case):
    key,a,rows,freq=case;P,iterator,nodes=multiplicities(a,rows,freq)
    count=Counter()
    path=ROOT/(key+'.cases')
    with path.open('w') as f:
        for W in iterator:
            count['primary']+=1
            for types in assignments(a,rows,freq,P,W):
                count['degree']+=1
                witness=cut(types,38-len(rows))
                if witness is not None:
                    count['cut']+=1;continue
                count['survive']+=1
                f.write(' '.join(f'{p},{r},{w}' for p,r,w in types)+'\n')
    print(key,nodes(),dict(count),flush=True)
    return key,{'nodes':nodes(),**count}

if __name__=='__main__':
    import sys
    from concurrent.futures import ProcessPoolExecutor
    data=json.loads((ROOT/'screen.json').read_text());c=catalog()
    jobs=[]
    for key,(stage,_,n) in data.items():
        if stage!='integer':continue
        name,i=key.split('.');a,b=c[name];freq=FREQUENCIES[a][int(i)]
        if len(sys.argv)>1:
            if key not in sys.argv[1:]:continue
        elif not (a==11 or (a==12 and n<40) or key.startswith('10-045')):continue
        jobs.append((key,a,b,freq))
    with ProcessPoolExecutor(4) as pool:
        results=dict(pool.map(run,jobs))
    (ROOT/'multiplicity-log.json').write_text(json.dumps(results,indent=1))
