"""Symmetry-reduced integer cuts for type counts and photo incidence Gram matrices."""
from flaglp import ROOT,np,json,flagdata,system,linprog,csc_matrix,hstack
from flagmath import automorphisms,base
from scipy.sparse import csr_matrix,vstack
from itertools import combinations_with_replacement
from functools import reduce
from math import gcd
from math import lcm
from pathlib import Path
import sys

def unique_rows(matrix,rhs):
    a=matrix.tocsr();a.sum_duplicates();a.eliminate_zeros();a.sort_indices();chosen=[];seen=set()
    for i in range(len(rhs)):
        v,w=a.indptr[i:i+2];tag=(a.indices[v:w].tobytes(),a.data[v:w].tobytes(),int(rhs[i]))
        if tag not in seen:seen.add(tag);chosen.append(i)
    return a[chosen].tocsc(),rhs[chosen]

class Moments:
    def __init__(self,key,anchors=(),extra_deny=()):
        self.key=key;a,rows,_,_=base(key)
        initial_deny=tuple(i for _,i,_ in json.loads((ROOT/'firstflags'/(key+'.json')).read_text()) if i>=0)
        deny=tuple(sorted(set(initial_deny)|set(extra_deny)))
        colors,W,C,F,T,U,E=flagdata(key,anchors,deny);n,N,A,B,G,H,indices,ends,delta=system(key,anchors,deny)
        self.n=n;self.N=N;self.T=np.array(T,dtype=np.int32);self.W=W;self.U=U
        nvar=A.shape[1];self.nvar=nvar
        graphfile=ROOT/'cliquecerts'/(key+'.json')
        doc=json.loads(graphfile.read_text()) if graphfile.exists() else {'blocked':[],'edges':[]}
        ban=set(doc['blocked']);edges=set(map(tuple,doc['edges']));parent_caps=[]
        if anchors:
            original,W0,C0,F0,T0,U0,_=flagdata(key,(),initial_deny)
            where0={s:i for i,s in enumerate(T0)};agg=[[j for j,(m,_) in enumerate(colors) if m==low] for low,_ in original]
            proj=[where0[tuple(sum(s[j] for j in sub) for sub in agg)] for s in T]
            self.proj=proj;self.original_ub=U0
            # Convert original type restrictions to the refined types.
            for m in anchors:
                s=tuple(sum(1 for j in range(38) if m>>j&1 and (rows[j] if j<len(rows) else 0)==low) for low,_ in original)
                parent_caps.append(where0[s])
            old_ban,old_edges=ban,edges
            ban={i for i,p in enumerate(proj) if p in old_ban or any(tuple(sorted((p,q))) in old_edges for q in parent_caps)}
            edges={(i,j) for i,j in combinations_with_replacement(range(n),2) if i<j and tuple(sorted((proj[i],proj[j]))) in old_edges}
        fullub=np.zeros(nvar,dtype=np.int64);fullub[:n]=U
        for i in ban:fullub[i]=0
        pair={};vary={};ixit=iter(indices);blocks=[]
        for i,j in combinations_with_replacement(range(n),2):
            if i==j and U[i]<=1:continue
            lo=np.maximum(0,self.T[i]+self.T[j]-W);hi=np.minimum(self.T[i],self.T[j])
            if not np.any(hi):continue
            k=int(next(ixit));pair[i,j]=k;M=U[i]*U[j] if i!=j else U[i]*(U[i]-1)//2
            if i in ban or j in ban or (i,j) in edges:M=0
            fullub[k]=M;v=[]
            for l in np.flatnonzero(hi>lo):
                z=k+1+len(v);vary[i,j,int(l)]=z;v.append((int(l),z));fullub[z]=(hi[l]-lo[l])*M
            blocks.append((i,j,k,lo,v))
        assert next(ixit,None) is None
        self.pair_map=pair;self.conflicts=edges;self.blocked=ban
        self.pi=np.array([i for i,j,k,l,v in blocks]);self.pj=np.array([j for i,j,k,l,v in blocks])
        self.py=np.array([k for i,j,k,l,v in blocks])
        self.pos={k:(np.array([int(l[k]) for i,j,c,l,v in blocks],dtype=np.int32),
                     np.array([dict(v).get(k,-1) for i,j,c,l,v in blocks],dtype=int)) for k,w in enumerate(W) if w>1}
        parent=list(range(nvar))
        def root(i):
            while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
            return i
        def merge(i,j):
            u,v=root(i),root(j)
            if u!=v:parent[max(u,v)]=min(u,v)
        cix={c:i for i,c in enumerate(colors)};where={tuple(s):i for i,s in enumerate(T)}
        for perm in automorphisms(rows,a):
            if perm==tuple(range(a)):continue
            renamed=[(sum(1<<perm[u] for u in range(a) if low>>u&1),tag) for low,tag in colors]
            if any(c not in cix for c in renamed):continue
            cm=[cix[c] for c in renamed]
            if any(W[i]!=W[j] for i,j in enumerate(cm)):continue
            inv=np.argsort(cm);tm=[where[tuple(s[inv])] for s in self.T]
            for i,j in enumerate(tm):merge(i,j)
            for (i,j),v in pair.items():
                u,w=sorted((tm[i],tm[j]));merge(v,pair[u,w])
            for (i,j,k),v in vary.items():
                u,w=sorted((tm[i],tm[j]));merge(v,vary[u,w,cm[k]])
        roots=[root(i) for i in range(nvar)];rep=sorted(set(roots));reverse={j:i for i,j in enumerate(rep)}
        self.orb=np.array([reverse[j] for j in roots],dtype=np.int32);self.nq=len(rep)
        self.ub=fullub[rep];assert np.array_equal(self.ub[self.orb],fullub)
        Z=csr_matrix((np.ones(nvar,dtype=np.int32),(np.arange(nvar),self.orb)),shape=(nvar,self.nq))
        self.A,self.B=unique_rows(A@Z,B);self.G,self.H=unique_rows(G@Z,H)
        if anchors:
            # Every integer original type count is bounded even after splitting
            # it across several anchor-relative classes of blank photos.
            add=[];rhs=[]
            for q in sorted(set(proj)):
                ids=[i for i,j in enumerate(proj) if j==q];cap=U0[q]-parent_caps.count(q)
                if len(ids)==1 and cap>=U[ids[0]]:continue
                row=np.zeros(self.nq,dtype=np.int32)
                for i in ids:row[self.orb[i]]+=1
                add.append(row);rhs.append(cap)
                for j in range(n):
                    row=np.zeros(self.nq,dtype=np.int32);row[self.orb[j]]-=cap
                    for i in ids:
                        y=pair.get((min(i,j),max(i,j)))
                        if i==j:row[self.orb[j]]+=1
                        if y is not None:row[self.orb[y]]+=1+(i==j)
                    add.append(row);rhs.append(0)
            if add:self.G,self.H=unique_rows(vstack((self.G,csc_matrix(np.array(add))),format='csc'),np.r_[self.H,rhs])
        self.g=self.G;self.rhs=self.H.copy()
        from cliquelp import maximal_cliques
        self.cliques=[] if anchors else [tuple(sorted(k)) for k in maximal_cliques(n,edges,ban)]
        self.cw=np.zeros((len(self.cliques),n),dtype=np.int64);self.cr=np.zeros(len(self.cliques),dtype=np.int64)
        for j,k in enumerate(self.cliques):
            L=lcm(*(U[i] for i in k));self.cr[j]=L
            for i in k:self.cw[j,i]=L//U[i]

    def condition(self,decisions):
        new=[];right=[]
        for selected,k in decisions:
            S=tuple(sorted(selected))
            # A conditional family is averaged only under relabelings preserving
            # it. Taking a union of complete type orbits guarantees this.
            assert all((i in S)==(j in S) for i in range(self.n) for j in range(self.n) if self.orb[i]==self.orb[j])
            row=np.zeros(self.nq,dtype=np.int32)
            for i in S:row[self.orb[i]]+=1
            new.append(row);right.append(k)
            for j in range(self.n):
                row=np.zeros(self.nq,dtype=np.int32);row[self.orb[j]]-=k
                for i in S:
                    v=self.pair_map.get((min(i,j),max(i,j)))
                    if i==j:row[self.orb[j]]+=1
                    if v is not None:row[self.orb[v]]+=1+(i==j)
                new.append(row);right.append(0)
        if new:self.A,self.B=unique_rows(vstack((self.A,csc_matrix(np.array(new))),format='csc'),np.r_[self.B,right])

    def features(self,z):
        x=z[self.orb];mu=x[:self.n];pi,pj=self.pi,self.pj
        pair=x[self.py]
        X=np.diag(mu.copy());np.add.at(X,(pi,pj),pair);np.add.at(X,(pj,pi),pair)
        M={}
        for c,(lo,parts) in self.pos.items():
            f=lo*pair;v=parts>=0;f[v]+=x[parts[v]]
            H=np.diag(self.T[:,c]*mu);np.add.at(H,(pi,pj),f);np.add.at(H,(pj,pi),f);M[c]=H
        return mu,X,M

    def inequality(self,tag):
        kind,c,threshold,raw=tag;v=np.array(raw,dtype=np.int64);pi,pj=self.pi,self.pj
        coef=np.zeros(self.nvar,dtype=np.int64)
        if kind=='clique':
            C=tuple(map(int,raw));L=lcm(*(self.U[i] for i in C))
            assert all(tuple(sorted((i,j))) in self.conflicts for i,j in combinations_with_replacement(C,2) if i!=j)
            if c<0:
                for i in C:coef[i]=L//self.U[i]
            else:
                coef[c]=-L
                for i in C:
                    w=L//self.U[i];pair=self.pair_map.get((min(i,c),max(i,c)))
                    if i==c:coef[c]+=w
                    if pair is not None:coef[pair]+=w*(2 if i==c else 1)
            folded=np.zeros(self.nq,dtype=np.int64);np.add.at(folded,self.orb,coef)
            return folded,L if c<0 else 0
        # Build the left side of a nonnegative quadratic expectation, then negate.
        def counts(a,m):
            coef[:self.n]+=m*a*a
            coef[self.py]+=m*2*a[pi]*a[pj]
        def photos(a,k,m):
            coef[:self.n]+=m*a*a*self.T[:,k]
            lo,parts=self.pos[k];term=m*2*a[pi]*a[pj];coef[self.py]+=term*lo
            ok=parts>=0;coef[parts[ok]]+=term[ok]
        C=threshold*(threshold+1)
        if kind=='counts':
            counts(v,1);coef[:self.n]-=(2*threshold+1)*v
        elif kind=='center':
            photos(v,c,self.W[c]);counts(v*self.T[:,c],-1);C=0
        elif kind=='photos':
            photos(v,c,1);coef[:self.n]-=(2*threshold+1)*v*self.T[:,c];C*=self.W[c]
        else:raise ValueError(kind)
        folded=np.zeros(self.nq,dtype=np.int64);np.add.at(folded,self.orb,-coef)
        return folded,int(C)

    def proposals(self,z,have):
        mu,X,M=self.features(z);n=self.n
        cov=X-np.outer(mu,mu);sources=[('counts',-1,cov)]
        for k,H in M.items():
            s=self.T[:,k];sources.append(('center',k,self.W[k]*H-X*np.outer(s,s)))
        proposed={}
        if len(self.cliques):
            diff=self.cw@X-self.cr[:,None]*mu
            for off in np.argsort(-diff.ravel())[:150]:
                k,i=divmod(int(off),n)
                if diff[k,i]<=1e-6:break
                tag=('clique',i,0,self.cliques[k])
                if tag in have:continue
                row,rhs=self.inequality(tag);gap=float(row@z-rhs)
                if gap>1e-6:proposed[tag]=(gap/max(1,np.linalg.norm(row)),row,rhs)
        def add(kind,c,v):
            if not np.any(v):return
            div=reduce(gcd,map(abs,map(int,v)));v=v//div
            if v[np.flatnonzero(v)[0]]<0:v=-v
            if kind=='counts':mean=float(mu@v);second=float(v@X@v);wid=1
            elif kind=='photos':mean=float((mu*self.T[:,c])@v);second=float(v@M[c]@v);wid=self.W[c]
            else:
                mean=0;wid=1;w=v*self.T[:,c];second=float(self.W[c]*(v@M[c]@v)-w@X@w)
            t=0 if kind=='center' else int(np.floor(mean/wid+1e-10))
            gap=(2*t+1)*mean-wid*t*(t+1)-second
            if gap<1e-5:return
            tag=(kind,c,t,tuple(map(int,v)))
            if tag in have or tag in proposed:return
            a,b=self.inequality(tag)
            if a@z-b<1e-6:return
            norm=max(1,np.linalg.norm(a));proposed[tag]=(gap/norm,a,b)
        for kind,c,Z in sources:
            eig,V=np.linalg.eigh(Z);bad=np.where(eig< -1e-7)[0]
            for idx in bad[:12]:
                f=V[:,idx];top=np.argsort(-np.abs(f))
                for size in (4,8,n):
                    sel=top[:size];vec=np.zeros(n)
                    vec[sel]=f[sel]/np.max(abs(f))
                    for scale in (1,2,4,7):
                        v=np.rint(vec*scale).astype(np.int64);add(kind,c,v)
                        if kind=='center':add('photos',c,v)
            if kind=='counts':
                for i in range(n):
                    v=np.zeros(n,dtype=np.int64);v[i]=1;add(kind,c,v)
        ordered=sorted(proposed,key=lambda t:-proposed[t][0])
        selected=[];seen=set()
        for tag in ordered:
            _,row,rhs=proposed[tag];ident=(row.tobytes(),rhs)
            if ident in seen:continue
            seen.add(ident);selected.append((tag,row,rhs))
            if len(selected)>=32:break
        return selected

    def solve(self,seconds=60,iterations=60,seed=()):
        tags=[(k,c,v,tuple(r)) for k,c,v,r in seed];have=set(tags);cost=np.zeros(self.nq+1);cost[-1]=1
        if tags:
            add=[self.inequality(t) for t in tags]
            self.g=vstack((self.g,csc_matrix(np.array([v for v,b in add]))),format='csc')
            self.rhs=np.r_[self.rhs,[b for v,b in add]]
        for it in range(iterations+1):
            res=linprog(cost,A_eq=hstack((self.A,csc_matrix(self.B[:,None])),format='csc'),b_eq=self.B,
                A_ub=hstack((self.g,csc_matrix(self.rhs[:,None])),format='csc'),b_ub=self.rhs,
                bounds=[(0,int(u)) for u in self.ub]+[(0,1)],options={'threads':1,'time_limit':seconds})
            if not res.success:return None,tags,'limited'
            if res.fun>1e-7:
                for q in (10**6,10**8,10**10):
                    y=np.rint(res.eqlin.marginals*q).astype(np.int64);z=np.minimum(0,np.rint(res.ineqlin.marginals*q).astype(np.int64))
                    row=self.A.T@y+self.g.T@z;target=int(self.B@y+self.rhs@z)
                    upper=int(np.maximum(row,0)@self.ub)
                    if target>upper:
                        enc=lambda a:[[int(k),int(a[k])] for k in np.where(a)[0]]
                        return dict(y=enc(y),z=enc(z),gap=target-upper),tags,'excluded'
                return None,tags,'unpriced'
            fresh=self.proposals(res.x[:-1],have)
            if not fresh:return None,tags,'relaxed'
            for t,vec,b in fresh:have.add(t);tags.append(t)
            self.g=vstack((self.g,csc_matrix(np.array([v for t,v,b in fresh]))),format='csc')
            self.rhs=np.r_[self.rhs,[b for t,v,b in fresh]]
        return None,tags,'iterlimit'

def run(key):
    M=Moments(key);d=ROOT/'gramcerts';d.mkdir(exist_ok=True);file=d/(key+'.json')
    previous=json.loads(file.read_text()) if file.exists() else {}
    if previous.get('status')=='excluded':return
    C,t,status=M.solve(iterations=150 if previous else 70,seed=previous.get('tags',[]))
    (d/(key+'.json')).write_text(json.dumps(dict(status=status,tags=t,cert=C),separators=(',',':')))
    print(key,M.nq,len(t),status,flush=True)

if __name__=='__main__':
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor(2) as pool:list(pool.map(run,sys.argv[1:]))
