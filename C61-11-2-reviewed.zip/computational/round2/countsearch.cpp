#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
using Mask=std::uint64_t;
struct Type{Mask p,gp;int r,w,h;};
struct Equation{int low,high;std::vector<int> items;};
struct Search{
 int n,b;long long limit,nodes=0,full=0,keep=0;bool capped=false,useRepeat=false,enhanced=false;int save,level;
 std::vector<Type> t;std::vector<Equation> eq;std::vector<std::vector<int>> adj,dual;
 std::vector<std::vector<std::pair<int,int>>> repeat[4];
 std::vector<std::vector<int>> conflict;std::vector<int> forbidden;
 std::vector<std::vector<unsigned char>> missing;
 std::vector<int> capacity;std::ofstream out;
 Search(const char* input,const char* output,long long limit,int save,int level):limit(limit),useRepeat(level<0),save(save),level(std::abs(level)),out(output){
  std::ifstream f(input);int neq;f>>n>>b>>neq;t.resize(n);adj.resize(n);dual.resize(n);
  for(auto &v:t){f>>v.p>>v.r>>v.w;v.h=v.r-__builtin_popcountll(v.p);v.gp=v.p;}
  for(int i=0;i<n;i++)for(int j=0;j<n;j++)if(!(t[i].p&t[j].p))adj[i].push_back(j);
  for(int k=0;k<neq;k++){int l,u,s;f>>l>>u>>s;Equation e{l,u,{}};
   for(int z=0,j;z<s;z++){f>>j;e.items.push_back(j);dual[j].push_back(k);}eq.push_back(e);}
  conflict.resize(n);std::string extra;while(f>>extra){
    if(extra=="guaranteed"){for(auto &v:t)f>>v.gp;}
    else if(extra=="conflicts"){int nb,np;f>>nb>>np;enhanced=true;for(int j=0,i;j<nb;j++){f>>i;forbidden.push_back(i);}
      for(int k=0,i,j;k<np;k++){f>>i>>j;conflict[i].push_back(j);conflict[j].push_back(i);}}
    else throw std::runtime_error("invalid optional section");
  }
  missing.assign(n,std::vector<unsigned char>(n));for(int i=0;i<n;i++)for(int j:adj[i])missing[i][j]=1;
  for(int q=0;q<4;q++){
    repeat[q].resize(n);
    for(int i=0;i<n;i++)for(int j=0;j<n;j++){
      int cost=std::max(0,__builtin_popcountll(t[i].gp&t[j].gp)-1)/(q+1);
      if(cost)repeat[q][i].push_back({j,cost});
    }
  }
  for(int h=0;h<=11*b;h++){int q=h/b,s=h%b;capacity.push_back((b-s)*q*(11-q)+s*(q+1)*(10-q));}
 }
 struct Domain{std::vector<int> l,u;};
 bool connected(Domain &d,bool &change){
   std::vector<int> one,centers;
   for(int i=0;i<n;i++)if(d.l[i]){
     if(t[i].h==1)one.push_back(i);else if(t[i].h>1&&t[i].h<=4)centers.push_back(i);
     for(int j:conflict[i]){if(d.l[j])return false;if(d.u[j]){d.u[j]=0;change=true;}}
   }
   auto budget=[&](const std::vector<int> &group,int cap)->bool{
     std::vector<unsigned char> neighbor(n,0);int total=0;
     for(int i:group)for(int j:adj[i])if(!neighbor[j]){neighbor[j]=1;total+=d.l[j];}
     if(total>cap)return false;
     for(int j=0;j<n;j++)if(neighbor[j]&&d.u[j]>d.l[j]+cap-total){d.u[j]=d.l[j]+cap-total;change=true;}
     return true;
   };
   std::vector<std::vector<int>> comps;std::vector<unsigned char> done(n,0);
   for(int i:one)if(!done[i]){
     std::vector<int> reach{i};done[i]=1;
     for(std::size_t z=0;z<reach.size();z++)for(int j:one)if(!done[j]&&missing[reach[z]][j]){reach.push_back(j);done[j]=1;}
     if(reach.size()>1&&!budget(reach,11))return false;comps.push_back(std::move(reach));
   }
   for(int i:centers){
     std::vector<int> group{i};
     for(auto &comp:comps)if(std::any_of(comp.begin(),comp.end(),[&](int j){return missing[i][j];}))
        group.insert(group.end(),comp.begin(),comp.end());
     if(group.size()>1&&!budget(group,11+10*(t[i].h-1)))return false;
   }
   return true;
 }
 bool propagate(Domain &d){
   bool change=true;while(change){change=false;
    if(enhanced&&!connected(d,change))return false;
    for(auto &e:eq){
      int suml=0,sumu=0;for(int i:e.items){suml+=d.l[i];sumu+=d.u[i];}
      if(suml>e.high||sumu<e.low)return false;
      for(int i:e.items){int l=std::max(d.l[i],e.low-sumu+d.u[i]),u=std::min(d.u[i],e.high-suml+d.l[i]);
       if(l>u)return false;if(l!=d.l[i]||u!=d.u[i]){d.l[i]=l;d.u[i]=u;change=true;}}
    }
    std::vector<int> deg(n,0);
    for(int i=0;i<n;i++)if(d.u[i]){
       for(int q=0;q<(useRepeat?4:0);q++){
         int cap=10*(t[i].r-6)/(q+1)+std::max(0,__builtin_popcountll(t[i].gp)-1)/(q+1);
         int used=0;for(auto [j,c]:repeat[q][i])used+=c*d.l[j];
         if(used>cap){if(d.l[i])return false;d.u[i]=0;change=true;break;}
         if(d.l[i])for(auto [j,c]:repeat[q][i]){
           int u=std::min(d.u[j],d.l[j]+(cap-used)/c);if(u<d.u[j]){d.u[j]=u;change=true;}
         }
       }
       if(!d.u[i])continue;
       for(int j:adj[i])deg[i]+=d.l[j];
       int cap=1000;
       for(int k=1;k<=d.u[i];k++){
           int mass=k*t[i].h;
           if(mass>11*b){
               if(k<=d.l[i])return false;
               d.u[i]=k-1;change=true;break;
           }
           cap=std::min(cap,capacity[mass]/k);
           if(deg[i]>cap){if(k<=d.l[i])return false;d.u[i]=k-1;change=true;break;}
           if(k==d.l[i]){
               for(int j:adj[i]){int u=std::min(d.u[j],cap-deg[i]+d.l[j]);if(u<d.u[j]){d.u[j]=u;change=true;}}
           }
       }
    }
    for(int i=0;i<n;i++)if(d.l[i])for(int j=0;j<i;j++)if(d.l[j]){
        int u=d.l[i],v=d.l[j],miss=u*deg[i]+v*deg[j]-2*u*v*(!(t[i].p&t[j].p));
        int mass=u*t[i].h+v*t[j].h;
        if(mass>11*b||miss>capacity[mass])return false;
    }
   }return true;
 }
 bool cut(const std::vector<int>& w){
   std::vector<int> ix,degree(n),m;
   for(int i=0;i<n;i++)if(w[i]){ix.push_back(i);for(int j:adj[i])degree[i]+=w[j];}
   auto rec=[&](auto &self,int start,int h,int cost)->bool{
     if(cost>capacity[h])return true;if((int)m.size()==level)return false;
     for(int pos=start;pos<(int)ix.size();pos++){
       int i=ix[pos],twice=0;for(int j:m)if(!(t[i].p&t[j].p))twice+=2*w[j];
       m.push_back(i);
       if(self(self,pos+1,h+w[i]*t[i].h,cost+w[i]*(degree[i]-twice)))return true;
       m.pop_back();
     }return false;
   };return rec(rec,0,0,0);
 }
 void visit(Domain d){
   if(nodes>=limit){capped=true;return;}nodes++;if(!propagate(d))return;
   if(enhanced){
     int v=-1,best=0;for(int i=0;i<n;i++)if(!d.l[i]&&d.u[i]){
       int s=0;for(int j:conflict[i])if(d.u[j])s++;if(s>best){best=s;v=i;}}
     if(v>=0&&best>=3){Domain active=d;active.l[v]=1;visit(std::move(active));if(capped)return;
       d.u[v]=0;visit(std::move(d));return;}
   }
   int best=-1,range=10000;double bestWeight=-1;std::vector<double> impact(n,0);
   for(const auto &e:eq){
     int open=0,spread=0;for(int j:e.items){if(d.l[j]!=d.u[j])open++;spread+=d.u[j]-d.l[j];}
     if(!open)continue;for(int j:e.items)if(d.l[j]!=d.u[j])impact[j]+=1.0/(open*spread);
   }
   for(int i=0;i<n;i++)if(d.l[i]<d.u[i]){
     int v=d.u[i]-d.l[i];if(v<range||(v==range&&impact[i]>bestWeight)){best=i;range=v;bestWeight=impact[i];}}
   if(best==-1){full++;if(cut(d.l))return;keep++;if(keep<=save){
        bool first=true;for(int i=0;i<n;i++)if(d.l[i]){if(!first)out<<" ";first=false;out<<t[i].p<<","<<t[i].r<<","<<d.l[i];}out<<"\n";
    }return;}
   for(int v=d.l[best];v<=d.u[best];v++){Domain child=d;child.l[best]=child.u[best]=v;visit(std::move(child));if(capped)return;}
 }
 void run(){Domain d;d.l.assign(n,0);for(auto v:t)d.u.push_back(v.w);for(int i:forbidden)d.u[i]=0;visit(d);
   std::cout<<n<<" "<<nodes<<" "<<full<<" "<<keep<<" "<<(capped?"limited":"complete")<<"\n";}
};
int main(int argc,char **argv){
 if(argc!=6)return 1;Search s(argv[1],argv[2],std::stoll(argv[3]),std::stoi(argv[4]),std::stoi(argv[5]));s.run();
}
