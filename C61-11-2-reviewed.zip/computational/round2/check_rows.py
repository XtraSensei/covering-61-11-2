"""Translate human-readable certificate data to the independent integer checker."""
from itertools import combinations
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from family import ROOT,catalog
from forced import read_cases
import json,subprocess,tempfile,sys

def read_certificate(path):
    key,idx=path.stem.rsplit('-',1);i=int(idx);d=json.loads(path.read_text())
    t=list(read_cases(ROOT/(key+'.cases')))[i];b=38-len(catalog()[key.split('.')[0]][1])
    if 'types' in d:assert list(map(tuple,d['types']))==t and d['b']==b
    terms=[(0,i,0,0,0,()) for i in range(len(t))]
    terms.extend((1,i,j,0,0,()) for i,j in combinations(range(len(t)),2) if not t[i][0]&t[j][0])
    for i,S,kind,v,s,_ in d.get('tags',[]):
        terms.append((2 if kind=='H' else 3,i,0,v,s,S))
    assert len(d['price'])==len(terms)
    kept=[(e,w) for e,w in zip(terms,d['price']) if w]
    # Each single-photo coefficient is at most 121 in absolute value,
    # except for rounded stars where the supplied positive shift is included.
    total=sum(abs(w)*max(121,11*(11+e[4]+1)) for e,w in kept)
    rhs_bound=sum(abs(w)*max(61*61,61*(61+38*e[4]+1)) for e,w in kept)
    assert max(total*38,rhs_bound,abs(d['top']),abs(d['rhs'])) < (1<<62)
    header=f'{len(t)} {b} {len(kept)} {d["top"]} {d["rhs"]}\n'
    body=''.join(f'{p} {r} {w}\n' for p,r,w in t)
    tail=''.join(f'{kind} {i} {j} {v} {s} {weight} {len(S)} '+' '.join(map(str,S))+'\n' for ((kind,i,j,v,s,S),weight) in kept)
    return header+body+tail

def check(path):
    with tempfile.NamedTemporaryFile(mode='w',dir=ROOT,delete=False) as tmp:
        tmp.write(read_certificate(path))
    try:
        ex=ROOT/('audit_prices.exe' if sys.platform=='win32' else 'audit_prices')
        return path.name,subprocess.check_output([str(ex),tmp.name],text=True).strip()
    finally:Path(tmp.name).unlink()
if __name__=='__main__':
    files=sorted((ROOT/'blankcerts').glob('*.json'))+sorted((ROOT/'starcerts').glob('*.json'))
    with ThreadPoolExecutor(3) as pool:
        for key,result in pool.map(check,files):print(key,result,flush=True)
