"""Generate all path/cycle shapes of the two-regular-point photos, up to relabelling."""
from itertools import product,permutations
from collections import Counter
from pathlib import Path

def canonical_cycle(c):
    return min(a[i:]+a[:i] for a in (c,c[::-1]) for i in range(len(c)))
def run(k):
    def words(size):
        for w in product(range(k),repeat=size):
            if all(w[j]!=w[j-1] for j in range(1,size)) and all(w.count(j)<=4 for j in range(k)):
                yield w
    paths=[w for size in range(4*k+1) for w in words(size) if w<=w[::-1]] if k<3 else []
    cycles=[w for size in range(3,4*k+1) for w in words(size) if w[0]!=w[-1] and w==canonical_cycle(w)]
    shapes=set()
    def visit(choices,start,remaining,groups,rooms,phase):
        if remaining==0 and phase=='path':
            return visit(cycles,0,0,groups,rooms,'cycle')
        if phase=='cycle':
            single=sum(rooms)
            if (single-2*k)%3==0:
                names=[]
                for p in permutations(range(k)):
                    chunks=[]
                    for typ,w in groups:
                        z=tuple(p[c] for c in w)
                        chunks.append((typ,canonical_cycle(z) if typ=='c' else min(z,z[::-1])))
                    names.append(tuple(sorted(chunks)))
                shapes.add(min(names))
        for j in range(start,len(choices)):
            w=choices[j];after=tuple(n-w.count(i) for i,n in enumerate(rooms))
            if min(after)<0:continue
            visit(choices,j,remaining-1 if phase=='path' else 0,groups+[(phase[0],w)],after,phase)
    visit(paths,0,(12-4*k)//2,[],(4,)*k,'path')
    out=[]
    for shape in sorted(shapes):
        cursor=[4*i for i in range(k)];tail=4*k;edges=[]
        for typ,w in shape:
            z=[]
            for c in w:z.append(cursor[c]);cursor[c]+=1
            if typ=='p':
                seq=[tail,*z,tail+1];tail+=2
            else:seq=[*z,z[0]]
            edges.extend(tuple(sorted(pair)) for pair in zip(seq,seq[1:]))
        assert tail==12
        out.append(' '.join([str(k),*(str(12*a+b) for a,b in sorted(edges))]))
    return out
if __name__=='__main__':
    groups=[run(k) for k in (1,2,3)]
    print([len(g) for g in groups])
    Path('work/leave12.txt').write_text('\n'.join(sum(groups,[]))+'\n')
