"""Replay the integer certificates and check coverage of the degree-profile ledger."""
from collections import Counter
from itertools import combinations
import json
from pathlib import Path
import re
import sys

here=Path(__file__).resolve().parent
sys.path.insert(0,str(here))
from verify_anchors import FREQ,verify as anchors
from verify_catalogue_link import verify as tables
from verify_four import verify as four
from verify_graphs import verify as graphs
from verify_hard import verify as hard
from verify_inventories import KEYS,verify as inventories
from verify_moment_source import verify as moments
from verify_prices import verify as prices
from verify_tree import require

def run():
    construction=here.parent/'cover39.txt'
    if not construction.is_file():construction=here.parent.parent/'outputs'/'C61-11-2-cover39.txt'
    rows=[tuple(sorted(map(int,line.split()))) for line in construction.read_text().splitlines()]
    require(len(rows)==39 and all(len(row)==len(set(row))==11 and 1<=row[0]<=row[-1]<=61 for row in rows))
    require({pair for row in rows for pair in combinations(row,2)}==set(combinations(range(1,62),2)))
    lean=here.parent/'lean'
    if not lean.is_dir():lean=here.parent/'leanproof'
    source=(lean/'Cover61'/'Upper.lean').read_text(encoding='utf8')
    masks,=re.findall(r'private def rowMasks : Array Nat := #\[([\d,\s]+)\]',source)
    require(list(map(int,re.findall(r'\d+',masks)))==[sum(1<<(i-1) for i in row) for row in rows])
    print('39 explicit blocks of size 11 cover all 1830 pairs.',flush=True)
    cat=json.loads((here/'catalogue.json').read_text())
    expected={f'{s}.{i}' for s,(a,_) in cat.items() for i in range(len(FREQ[a]))}
    ledger={}
    def mark(key,kind):
        require(key in expected and key not in ledger);ledger[key]=kind
    tables(here);four(here/'four-local.json')
    prices(here)
    funds=json.loads((here/'price-index.json').read_text())
    for key,kind in funds.items():
        if kind=='seat':mark(key,'seat')
        if kind=='moment':
            source,suffix=key.split('/');require(suffix=='moment');mark(source,'moment')
    anchor=json.loads((here/'anchor-input.json').read_text())
    for key,src in anchor.items():
        if any(m==0 for _,_,m,_,_ in src['steps']):mark(key,'anchor')
    roots={s for s,v in funds.items() if v=='rooted'}
    require(roots=={f'9-41.0/root/{j}' for j in range(5)});mark('9-41.0','rooted')
    denied=anchors(here);checked_graphs=graphs(here,denied);moments(here,denied,checked_graphs)
    hard(here);mark('9-37.0','enumeration')
    inventories(KEYS,True,True,denied)
    for key in KEYS:mark(key,'enumeration')
    # The geometric case is the separate theorem Cover61.Catalog.s9_49_excluded.
    mark('9-49.0','affine')
    require(set(ledger)==expected and len(ledger)==251)
    print(f'All {len(cat)} skeletons and {len(ledger)} degree-profile entries accounted for: {dict(sorted(Counter(ledger.values()).items()))}.')

if __name__=='__main__':run()
