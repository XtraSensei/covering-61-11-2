"""Independently replay all 121 supports of 9-37 using arbitrary-precision integers."""
from collections import Counter
import gzip
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from verify_tree import Box,replay,require

def read(path):
    with (gzip.open(path,'rt',encoding='utf8') if path.suffix=='.gz' else path.open(encoding='utf8')) as f:return json.load(f)

def supports_for(n,blocked,conflicts):
    active=set(range(n))-set(blocked)
    allowed={i:active-{i} for i in active}
    for i,j in conflicts:
        if i in active and j in active:allowed[i].discard(j);allowed[j].discard(i)
    def visit(chosen,nexts,earlier):
        if not (nexts or earlier):
            yield tuple(sorted(chosen));return
        pivot=max(nexts|earlier,key=lambda i:len(nexts&allowed[i]))
        for i in sorted(nexts-allowed[pivot]):
            yield from visit(chosen|{i},nexts&allowed[i],earlier&allowed[i])
            nexts.remove(i);earlier.add(i)
    return [list(s) for s in sorted(visit(set(),active,set()))]

def verify(directory):
    data=read(directory/'support-tree-index.json');matrix=read(directory/'support-matrix.json.gz')
    require(type(matrix['n']) is int and type(matrix['cut']) is int and matrix['n']>0)
    require(len(matrix['owner'])==len(matrix['upper']) and all(type(u) is int and u>=0 for u in matrix['upper']))
    require(all(len(t) in (1,2) and all(type(i) is int and 0<=i<matrix['n'] for i in t) for t in matrix['owner']))
    supports=supports_for(matrix['n'],matrix['blocked'],matrix['conflicts'])
    require(len(supports)==121 and supports==data['supports'])
    lean=directory.parent/'lean'
    if not lean.is_dir():lean=directory.parent/'leanproof'
    lines=(lean/'Cover61'/'Nine37Supports.lean').read_text(encoding='utf8').splitlines()
    fmt=lambda v:'{'+','.join(map(str,sorted(v)))+'}' if v else '∅'
    layout=lambda name,typ,seq:f'def {name} (i : {typ}) : Finset Label := (#['+', '.join(map(fmt,seq))+'] : Array (Finset Label))[i.val]!'
    adjacency=[set() for _ in range(matrix['n'])]
    for i,j in matrix['conflicts']:adjacency[i].add(j);adjacency[j].add(i)
    require(f'abbrev Label := Fin {matrix["n"]}' in lines and f'abbrev Rep := Fin {len(supports)}' in lines)
    require(layout('conflict','Label',adjacency) in lines and layout('representatives','Rep',supports) in lines)
    require('def active : Finset Label := '+fmt(set(range(matrix['n']))-set(matrix['blocked'])) in lines)
    pairs={(i,j):p for i,j,p in matrix['pairs']};done=set();used=set();n=matrix['n']
    def price(idx,doc,sources):
        require(0<=idx<len(supports) and idx not in done and set(sources)<=done)
        s=supports[idx];inside=set(s);c=Counter();rhs=0
        for k in ('y','z'):
            for j,w in doc[k]:
                require(type(j) is int and j>=0 and type(w) is int and (k=='y' or w<=0))
                if k=='z' and j>=matrix['cut']:
                    group,v=divmod(j-matrix['cut'],len(s)+1);require(group<len(sources))
                    hit=inside-set(supports[sources[group]])
                    if v==0:b=-1;row=[(i,-1) for i in hit]
                    else:
                        i=s[v-1];b=0;row=[(i,int(i not in hit))]
                        for t in hit:
                            p=pairs.get(tuple(sorted((i,t))))
                            if p is not None:row.append((p,-1-int(i==t)))
                else:
                    name=k+str(j);b,row=matrix['rows'][name];used.add(name)
                require(type(b) is int);rhs+=w*b
                for pos,x in row:
                    require(type(pos) is int and 0<=pos<len(matrix['upper']) and type(x) is int)
                    c[pos]+=w*x
        gap=rhs-sum(v*matrix['upper'][j] for j,v in c.items() if v>0 and all(i in inside for i in matrix['owner'][j]))
        require(type(doc['gap']) is int and gap==doc['gap'] and gap>0);done.add(idx)
    for i,s in enumerate(supports):
        f=directory/f'gram-support-9-37.0-{i:03}.json'
        if f.is_file():
            doc=read(f);require(doc['support']==s and doc['seed'] is True);price(i,doc,[])
    require(len(done)==93)
    for i,doc in read(directory/'support-hits.json'):price(i,doc,doc['sources'])
    require(len(done)==100 and used==set(matrix['rows']))
    nodes=0
    for i in data['order']:
        doc=read(directory/'support-trees'/f'{i:03}.json.gz')
        require(i not in done and set(doc['sources'])<=done)
        nodes+=replay(Box(data['model'],supports[i],[supports[j] for j in doc['sources']]),doc)
        done.add(i)
    require(done==set(range(len(supports))))
    print(f'9-37.0: {len(done)} supports, 100 integer Farkas certificates, {len(data["order"])} trees, {nodes} nodes.')

if __name__=='__main__':verify(HERE)
