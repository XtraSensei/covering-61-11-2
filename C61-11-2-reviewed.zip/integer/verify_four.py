"""Replay the five local four-low-point obstructions using only Python integers."""
from collections import Counter
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
import sys


def histograms(degree):
    def visit(s, n, seats, capacity, prefix):
        if seats < s*n or seats > 7*n:
            return
        if s == 7:
            if capacity + 28*n >= 350:
                yield (*prefix,n)
            return
        for k in range(n+1):
            yield from visit(s+1,n-k,seats-k*s,capacity+k*s*(11-s),(*prefix,k))
    return set(visit(0,17,42+degree,0,()))


def margin(e, R, h, prices):
    groups = [tuple(i for i in range(7) if e[i]==v) for v in sorted(set(e))]
    def color(mask):
        return tuple(sum(mask>>i&1 for i in g) for g in groups)
    orbit = list(dict.fromkeys(color(m) for m in range(128)))
    masks = [next(m for m in range(128) if color(m)==t) for t in orbit]
    small = [j for j,t in enumerate(orbit) if sum(t)<=3]
    pairs = [(j,orbit.index(color(127^masks[j]))) for j in small]
    sizes = [sum(t) for t in orbit]
    def capacity(s):
        return min(h[s]*h[7-s],4*h[s],4*h[7-s])
    upper = [h[s] for s in sizes] + [capacity(sizes[i]) for i,j in pairs]
    result = [0]*len(upper)
    target = 0
    for tag,scale in prices:
        k,*args = tag
        if type(scale) is not int or (k not in ('visits','size','chosen') and scale>0):
            raise ValueError("inadmissible price sign")
        v=[0]*len(upper)
        rhs=0
        if k in ('visits','budget'):
            c,=args
            rhs=len(groups[c])*(6+e[groups[c][0]] if k=='visits' else 10*(1+e[groups[c][0]]))
            for j,t in enumerate(orbit):v[j]=t[c]*(1 if k=='visits' else sizes[j]-1)
        elif k=='size':
            s,=args;rhs=h[s];v[:len(orbit)]=[int(t==s) for t in sizes]
        elif k=='chosen':
            rhs=R;v[len(orbit):]=[1]*len(pairs)
        elif k in ('four','opposite'):
            p,j=args;a,b=pairs[p]
            if j not in (a,b):raise ValueError("not a pair endpoint")
            v[len(orbit)+p]=1;v[j]=-4 if k=='four' else -h[sizes[b if j==a else a]]
        elif k=='mass':
            s,=args;rhs=capacity(s);v[len(orbit):]=[int(sizes[a]==s) for a,b in pairs]
        elif k=='price':
            key,div=args
            costs,need=rounded(tuple(e),tuple(tuple(x) for x in key),div,tuple(masks))
            rhs=-(50-R)*need
            v[:len(orbit)]=[-c*(11-s) for c,s in zip(costs,sizes)]
            v[len(orbit):]=[costs[a]+costs[b] for a,b in pairs]
        else:raise ValueError(k)
        target+=scale*rhs
        for j,c in enumerate(v):result[j]+=scale*c
    return target-sum(u*max(c,0) for u,c in zip(upper,result))


@lru_cache(None)
def rounded(e,key,div,masks):
    if type(div) is not int or div<=0:raise ValueError("invalid divisor")
    groups=[tuple(i for i in range(7) if e[i]==v) for v in sorted(set(e))]
    costs=[0]*len(masks);need=0
    for w in product(range(3),repeat=7):
        if tuple(tuple(sorted(w[i] for i in g)) for g in groups)!=key:continue
        need+=(sum(w)+div-1)//div
        for j,m in enumerate(masks):
            costs[j]+=(sum(a for i,a in enumerate(w) if m>>i&1)+div-1)//div
    return costs,need


def verify(path):
    cases=json.loads(path.read_text(encoding="utf-8"))
    expected={((1,),5),((2,),7),((1,1),7),((3,),8),((2,1),8)}
    total=0;prices=0
    for case in cases:
        e,R=case["e"],case["required"]
        expected.remove((tuple(v for v in e if v),R))
        hs=[tuple(h) for h in case["histograms"]];ix=case["indices"];ws=case["prices"]
        if len(e)!=7 or len(hs)!=len(set(hs)) or set(hs)!=histograms(sum(e)) or len(ix)!=len(hs):
            raise ValueError("incomplete histogram list")
        if any(not 0<=i<len(ws) or margin(e,R,h,ws[i])<=0 for h,i in zip(hs,ix)):
            raise ValueError("failed integer separation")
        total+=len(hs);prices+=len(ws)
    if expected:raise ValueError("missing case")
    print(f"Verified {total} histograms with {prices} integer prices.")

if __name__=="__main__":
    verify(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name("four-local.json"))
