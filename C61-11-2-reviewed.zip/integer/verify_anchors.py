"""Reconstruct anchored seat-price rows from the low-point skeleton and the prices."""
from collections import Counter
from itertools import combinations
import json
from pathlib import Path
import sys

FREQ={9:((52,0,0),),10:((50,1,0),),11:((48,2,0),(49,0,1)),12:((46,3,0),)}

def partitions(rows,remaining):
    if not remaining:
        yield ()
        return
    x=remaining&-remaining
    for j,r in enumerate(rows):
        if r&x and r&remaining==r:
            for tail in partitions(rows,remaining^r):yield (j,*tail)

def minpairs(w,n):
    q,r=divmod(n,w)
    return w*q*(q-1)//2+q*r

def inventory(rows,a,pop,anchor,denied):
    masks=tuple(rows)+(0,)*(38-len(rows))
    colors=sorted({(v,(anchor>>j)&1) for j,v in enumerate(masks)})
    color=[colors.index((v,(anchor>>j)&1)) for j,v in enumerate(masks)]
    width=[color.count(j) for j in range(len(colors))]
    room=[11-low.bit_count()-fixed for low,fixed in colors]
    counts=list(pop)
    if anchor:counts[anchor.bit_count()-7]-=1
    if min(counts)<0:raise ValueError("unavailable anchor rank")
    blank=[j for j,(m,f) in enumerate(colors) if not m]
    fixedblank=next((width[j] for j in blank if colors[j][1]),0)
    freeblank=38-len(rows)-fixedblank
    quads={j for j,m in enumerate(rows) if m.bit_count()==4}
    types={}
    for P in partitions(rows,(1<<a)-1):
        sig=tuple(sorted(rows[j] for j in P))
        for r,n in enumerate(counts,7):
            h=r-len(P)
            if not n or h<0 or (r,sig) in denied or (a,r)==(12,8) and not quads.issubset(P):continue
            for k in range(max(0,h-freeblank),min(h,fixedblank)+1):
                s=[0]*len(colors)
                for j in P:s[color[j]]+=1
                for j in blank:s[j]=k if colors[j][1] else h-k
                s=tuple(s)
                hits=sum(s[j] for j,c in enumerate(colors) if c[1])
                if anchor and not hits:continue
                budget=10*(r-6)-(hits-1 if anchor else 0)
                if budget<0 or s in types:continue
                cap=min([n]+[w*c//v for w,c,v in zip(width,room,s) if v])
                for q in range(2,cap+1):
                    if 2*sum(minpairs(w,q*v) for w,v in zip(width,s))-q*(q-1)>q*budget:
                        cap=q-1;break
                if cap:types[s]=cap
    ranks=[r for r,n in enumerate(counts,7) if n]
    return [w*c for w,c in zip(width,room)]+[counts[r-7] for r in ranks],ranks,types

def verify(directory):
    catalog=json.loads((directory/"catalogue.json").read_text())
    cases=json.loads((directory/"anchor-input.json").read_text())
    total=0;closed=[];exclusions={}
    for key,record in cases.items():
        name,profile=key.split(".");a,rows=catalog[name];pop=FREQ[a][int(profile)]
        images=[]
        for p in record["symmetry"]:
            if sorted(p)!=list(range(a)):raise ValueError("invalid point permutation")
            transform=lambda m:sum(1<<p[i] for i in range(a) if m>>i&1)
            image={m:transform(m) for m in rows}
            if Counter(image[m] for m in rows)!=Counter(rows):raise ValueError("permutation changes skeleton")
            images.append(image)
        proven={}
        for deny,i,m,price,gap in record["steps"]:
            if m<0 or m>=1<<38 or (i==-1)!=(m==0):raise ValueError("invalid distinguished person")
            blocked=set().union(*(proven[j] for j in deny))
            if m:
                sig=tuple(sorted(v for j,v in enumerate(rows) if m>>j&1))
                if sum(v.bit_count() for v in sig)!=a or sum(sig)!=(1<<a)-1:raise ValueError("invalid partition")
                if m.bit_count() not in [r for r,n in enumerate(pop,7) if n]:raise ValueError("invalid rank")
            rhs,ranks,types=inventory(rows,a,pop,m,blocked)
            if price is None:
                if types or not ranks:raise ValueError("expected empty family")
            else:
                if len(price)!=len(rhs) or any(type(v) is not int for v in price):raise ValueError("invalid prices")
                target=sum(v*b for v,b in zip(price,rhs))
                top=sum(u*max(0,sum(x*y for x,y in zip(s,price))+price[len(s)+ranks.index(sum(s))]) for s,u in types.items())
                if target-top!=gap or gap<=0:raise ValueError("failed anchored separation")
            if m:proven[i]={(m.bit_count(),tuple(sorted(p[v] for v in sig))) for p in images}
            else:closed.append(key)
            total+=1
        exclusions[key]=set().union(*proven.values())
    if len(cases)!=46 or total!=371 or len(set(closed))!=4:raise ValueError("incomplete anchored screen")
    print(f"Reconstructed {total} anchored integer certificates on {len(cases)} instances; {len(closed)} root exclusions.")
    return exclusions

if __name__=="__main__":
    verify(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent)
