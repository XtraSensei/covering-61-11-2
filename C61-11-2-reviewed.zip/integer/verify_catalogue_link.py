"""Compare the finite row tables used by Lean with the signed-price input, entry by entry."""
from pathlib import Path
import json
import re
from collections import defaultdict


def require(ok):
    if not ok:raise ValueError('inconsistent Lean and certificate catalogues')

def signature(n,rows):
    incident=[[r for r in rows if r>>i&1] for i in range(n)]
    pairs=[[next((r.bit_count() for r in incident[i] if r>>j&1),0) if i!=j else 0 for j in range(n)] for i in range(n)]
    colors=[tuple(sorted(r.bit_count() for r in v)) for v in incident]
    for _ in range(n):
        marks=[(colors[i],tuple(sorted((pairs[i][j],colors[j]) for j in range(n)))) for i in range(n)]
        names={v:i for i,v in enumerate(sorted(set(marks)))};new=[names[v] for v in marks]
        if new==colors:break
        colors=new
    return (n,tuple(sorted(marks)),tuple(sorted(r.bit_count() for r in rows))),pairs,colors

def equivalent(src,dst):
    a,A,c=src;b,B,d=dst;n=len(A);p=[-1]*n
    order=sorted(range(n),key=lambda i:d.count(c[i]))
    def visit(k,used):
        if k==n:return sorted(sum(1<<p[i] for i in range(n) if r>>i&1) for r in a)==sorted(b)
        i=order[k]
        for j in range(n):
            if used>>j&1 or c[i]!=d[j] or any(A[i][v]!=B[j][p[v]] for v in order[:k]):continue
            p[i]=j
            if visit(k+1,used|1<<j):return True
        return False
    return visit(0,0)

def row_tables(directory):
    lean=directory.parent/'lean'
    if not lean.is_dir():lean=directory.parent/'leanproof'
    for name,n,q,m in [('candidates',9,0,50),('rows10_0',10,0,65),('rows11_0',11,0,36),
                       ('rows12_1',12,1,22),('rows12_2',12,2,23),('rows12_3',12,3,19)]:
        file='NineData.lean' if n==9 else 'LayerData.lean'
        lines=(lean/'Cover61'/file).read_text(encoding='utf8').splitlines()
        header=f'def {name} (j : Fin {m}) : Rows {n} := fun i =>'
        require(lines.count(header)==1)
        body=lines[lines.index(header)+1]
        prefix='  ((#[';suffix=f'] : Array (Array (Row {n})))[j.val]!)[i.val]!'
        require(body.startswith(prefix) and body.endswith(suffix))
        tables=body[len(prefix):-len(suffix)].split('], #[')
        require(len(tables)==m and tables[0].startswith('#[') and tables[-1].endswith(']'))
        tables[0]=tables[0][2:];tables[-1]=tables[-1][:-1]
        for j,t in enumerate(tables):
            masks=[]
            for token in t.split(', '):
                if token=='∅':masks.append(0);continue
                require(re.fullmatch(r'\{\d+(,\d+)*\}',token))
                pts=list(map(int,token[1:-1].split(',')))
                require(len(pts)==len(set(pts)) and all(0<=x<n for x in pts))
                masks.append(sum(1<<x for x in pts))
            require(len(masks)==38 and sum(mask.bit_count()==4 for mask in masks)==q)
            yield n,q,j,masks

def verify(directory):
    catalogue=json.loads((directory/'catalogue.json').read_text())
    expected={(n,tuple(rows+[0]*(38-len(rows)))):name for name,(n,rows) in catalogue.items()}
    require(len(expected)==len(catalogue)==215)
    lean=directory.parent/'lean'
    if not lean.is_dir():lean=directory.parent/'leanproof'
    open_rows=set(re.findall(r'^(\d+[-\d]+) open$',(lean/'catalog-status.txt').read_text(),re.M))
    require(len(open_rows)==45)
    covered=set();live={}
    for n,q,j,masks in row_tables(directory):
        key=expected[n,tuple(masks)];require(key not in covered);covered.add(key)
        if n==9:require(key==f'9-{j:02}')
        if (n,q) not in live:
            source=(lean/'Cover61'/f'Keep{n}_{q}.lean').read_text(encoding='utf8')
            found=re.findall(fr'^def live{n}_{q} : Finset \(Fin \d+\) := (∅|\{{[\d,]+\}})$',source,re.M)
            require(len(found)==1);live[n,q]=set(map(int,re.findall(r'\d+',found[0])))
        require((j in live[n,q])==(key in open_rows))
    require(covered==set(catalogue))
    seen=defaultdict(list)
    for n,rows in catalogue.values():
        key,adj,colors=signature(n,rows);source=(rows,adj,colors)
        require(all(not equivalent(source,other) for other in seen[key]));seen[key].append(source)
    print('Matched all 215 Lean row tables to certificate input, with all 38 block indices preserved. No two are isomorphic. Matched all 45 remaining row indices.')

if __name__=='__main__':verify(Path(__file__).resolve().parent)
