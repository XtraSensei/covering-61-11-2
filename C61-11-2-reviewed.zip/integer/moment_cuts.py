"""Expand integer quadratic and clique inequalities in person-pair coordinates."""
from collections import Counter
from itertools import combinations
from math import lcm
from moment_rows import signature
from verify_tree import require


def quadratic(m,tag):
    kind,c,k,v=tag;co=Counter();x=m.orb
    if kind=='clique':
        require(type(c) is int and -1<=c<m.n and k==0 and v==sorted(set(v)))
        require(all(type(i) is int and 0<=i<m.n for i in v) and all(p in m.edges for p in combinations(v,2)))
        K=lcm(*(m.U[i] for i in v))
        if c<0:
            for i in v:co[x[i]]+=K//m.U[i]
            return signature('<=',K,co)
        co[x[c]]-=K
        for i in v:
            p=m.P.get(tuple(sorted((i,c))));w=K//m.U[i]
            if i==c:co[x[i]]+=w
            if p:co[x[p[0]]]+=w*(1+int(i==c))
        return signature('<=',0,co)
    require(kind in ('counts','photos','center') and len(v)==m.n and all(type(t) is int for t in [k,c,*v]))
    if kind=='counts':require(c==-1);w=1;s=[1]*m.n
    else:require(0<=c<len(m.W) and m.W[c]>1);w=m.W[c];s=[a[c] for a in m.T]
    if kind=='center':require(k==0)
    for i,t in enumerate(v):
        if kind=='center':co[x[i]]-=t*t*(w*s[i]-s[i]*s[i])
        else:co[x[i]]-=s[i]*t*(t-2*k-1)
    for (i,j),(y,l,e) in m.P.items():
        cross=2*v[i]*v[j]
        if not cross:continue
        if kind=='counts':co[x[y]]-=cross;continue
        if kind=='photos':co[x[y]]-=cross*l[c];scale=1
        else:co[x[y]]-=cross*(w*l[c]-s[i]*s[j]);scale=w
        if c in e:co[x[e[c]]]-=scale*cross
    return signature('<=',0 if kind=='center' else w*k*(k+1),co)
