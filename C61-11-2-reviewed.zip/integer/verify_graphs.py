"""Rebuild the type-conflict graphs by exact conditional prices and point relabellings."""
from collections import Counter
from itertools import combinations
import json
from math import lcm
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from verify_anchors import verify as anchors
from verify_inventories import read_json
from inventory_models import model_for
from verify_prices import farkas
from verify_tree import Box,require


def clique_rows(box,edges,blocked):
    active=set(range(box.n))-blocked
    adjacent={i:set() for i in active}
    for i,j in edges:
        if i in active and j in active:adjacent[i].add(j);adjacent[j].add(i)
    def visit(s,p,x):
        if not p:
            if not x and len(s)>=2:yield tuple(sorted(s))
            return
        v=max(p|x,key=lambda i:len(p&adjacent[i]))
        for i in sorted(p-adjacent[v]):
            yield from visit(s+[i],p&adjacent[i],x&adjacent[i]);p.remove(i);x.add(i)
    groups=sorted(visit([],active,set()),key=lambda s:(-len(s),s))
    if len(groups)>380:
        seen=Counter();chosen=[]
        for group in groups:
            if min(seen[i] for i in group)>=12:continue
            chosen.append(group);seen.update(group)
        groups=chosen[:380]
    rows=[]
    for group in groups:
        require(all((i,j) in edges for i,j in combinations(group,2)))
        k=lcm(*(box.upper[i] for i in group))
        rows.append(({i:k//box.upper[i] for i in group},None,k))
    return rows


def actions(rows,n,types,perms):
    masks=sorted(set(rows));where={(p,r):i for i,(p,g,r,u) in enumerate(types)}
    for p in perms:
        require(sorted(p)==list(range(n)))
        f=lambda m:sum(1<<p[j] for j in range(n) if m>>j&1)
        require(Counter(map(f,rows))==Counter(rows))
        perm=[masks.index(f(m)) for m in masks]
        move=lambda m:sum(1<<j for k,j in enumerate(perm) if m>>k&1)
        mapping=[where[move(m),r] for m,g,r,u in types]
        require(sorted(mapping)==list(range(len(types))))
        yield mapping


def conditional(box,blocked,edges,S,groups,cert):
    require(len(set(S))==len(S) and all(type(i) is int and 0<=i<box.n for i in S))
    lo=[int(i in S) for i in range(box.n)];hi=box.upper.copy()
    for j in range(box.n):
        if j in blocked or any(tuple(sorted((i,j))) in edges for i in S):hi[j]=0
    if any(a>b for a,b in zip(lo,hi)):require(cert=={'bound':True});return
    extra=[]
    for i in S:
        extra.append((dict.fromkeys(box.miss[i],1),None,10*box.h[i]))
        for d in (1,2,3,4):
            row=box.row(['R',i,d],lo)
            if row[0]:extra.append(row)
    if len(S)==2 and S[1] in box.miss[S[0]]:extra.append(box.row(['N',S],lo))
    rows=[];extra.extend(groups)
    for tag in ('y','z'):
        for j,w in cert[tag]:
            require(type(j) is int and 0<=j<(len(box.seats) if tag=='y' else len(extra)))
            if tag=='y':co,b=box.seats[j]
            else:co,_,b=extra[j]
            rows.append(['=' if tag=='y' else '<=',w,b-sum(c*lo[i] for i,c in co.items()),list(co.items())])
    require(type(cert['gap']) is int and 0<cert['gap']==farkas({'rows':rows,'upper':[v-u for u,v in zip(lo,hi)]}))


def verify(here,denied):
    root=here.parent/'computational'/'round2'
    if not root.is_dir():root=here.parent/'proof-package'/'round2'
    catalog=read_json(here/'catalogue.json');anchors=read_json(here/'anchor-input.json')
    families={f.stem for f in (root/'neighborcerts').glob('*.json')}
    require(len(families)==8 and families=={f.stem for f in (root/'cliquecerts').glob('*.json')})
    steps=0;result={}
    for key in sorted(families):
        n,rows=catalog[key.split('.')[0]];model=model_for(key,catalog,denied[key],True)
        box=Box(model,list(range(len(model['types']))),[])
        maps=list(actions(rows,n,box.types,anchors[key]['symmetry']));blocked=set()
        edges={(i,j) for i,j in combinations(range(box.n),2) if j in box.miss[i] and min(box.h[i],box.h[j])==0}
        for mode in ('neighbor','clique'):
            doc=read_json(root/(mode+'certs')/(key+'.json'));require(doc['closed'] is False)
            for stage in ([doc['proof']] if mode=='neighbor' else doc['history']):
                groups=[] if mode=='neighbor' else clique_rows(box,edges,blocked)
                for S,cert in stage:
                    require(1<=len(S)<=2)
                    try:conditional(box,blocked,edges,S,groups,cert)
                    except ValueError as error:raise ValueError(f'{key} {mode}, conditional types {S}') from error
                    steps+=1
                    for f in maps:
                        if len(S)==1:blocked.add(f[S[0]])
                        else:edges.add(tuple(sorted(f[i] for i in S)))
            require(sorted(blocked)==doc['blocked'] and [list(t) for t in sorted(edges)]==doc['edges'])
        if key=='9-37.0':
            hard=read_json(here/'support-matrix.json.gz');trees=read_json(here/'support-tree-index.json')
            require(hard['n']==box.n and hard['blocked']==sorted(blocked) and hard['conflicts']==[list(t) for t in sorted(edges)])
            require(json.loads(json.dumps(model))==trees['model'])
        result[key]=(blocked,edges)
    print(f'Reconstructed all {len(families)} conflict graphs from {steps} conditional integer prices and interval contradictions.',flush=True)
    return result

if __name__=='__main__':
    here=Path(__file__).resolve().parent
    verify(here,anchors(here))
