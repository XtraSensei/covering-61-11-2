"""Reconstruct population boxes, replay their proofs and validate residual-layout bijections."""
from pathlib import Path
import argparse
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from inventory_models import model_for
from verify_anchors import verify as anchors
from verify_photo_price import check,photo_price
from verify_tree import Box,replay

KEYS=('9-03.0','9-07.0','9-14.0','9-16.0','9-22.0','9-23.0',
      '10-021-03.0','10-045-02.0','11-057-03.0','11-057-03.1')

def read_json(path):
    with (gzip.open(path,'rt',encoding='utf8') if path.suffix=='.gz' else path.open(encoding='utf8')) as f:
        return json.load(f)

def isomorphism(types,representative,mapping):
    n=len(types)
    check(len(representative)==n and len(mapping)==n and all(type(i) is int for i in mapping) and sorted(mapping)==list(range(n)))
    for i,(p,r,u) in enumerate(types):
        mask,rank,mass=representative[mapping[i]]
        check((r-p.bit_count(),u)==(rank-mask.bit_count(),mass))
        for j in range(i):
            check(bool(p&types[j][0])==bool(mask&representative[mapping[j]][0]))

def verify(keys,photos,trees,denied=None):
    root=HERE.parent/'computational'/'round2'
    if not root.is_dir():root=HERE.parent/'proof-package'/'round2'
    cat=read_json(HERE/'catalogue.json');links=read_json(HERE/'photo-links.json.gz')
    check(set(links)==set(KEYS) and len(set(keys))==len(keys) and set(keys)<=set(KEYS))
    if denied is None:denied=anchors(HERE) if trees else {}
    tot=[0,0,0]
    for key in keys:
        types=[[tuple(map(int,s.split(','))) for s in line.split()] for line in (root/(key+'.cases')).read_text().splitlines()]
        check(len(types)==len(links[key]))
        reps=set()
        for layout,(idx,mapping) in zip(types,links[key]):
            check(type(idx) is int and 0<=idx<len(types))
            isomorphism(layout,types[idx],mapping);reps.add(idx)
        for idx in sorted(reps):
            filename=f'{key}-{idx:04}.json'
            files=[root/d/filename for d in ('blankcerts','starcerts') if (root/d/filename).is_file()]
            check(len(files)==1)
            if photos:photo_price(types[idx],38-len(cat[key.split('.')[0]][1]),read_json(files[0]))
        nodes=0
        if trees:
            m=model_for(key,cat,denied[key],key in ('9-16.0','9-22.0'))
            doc=read_json(HERE/'inventory-trees'/(key+'.json.gz'))
            nodes=replay(Box(m,list(range(len(m['types']))),[]),doc,types)
        print(f'{key}: {nodes} tree nodes, {len(types)} layout maps, {len(reps)} representatives.',flush=True)
        tot=[x+y for x,y in zip(tot,(nodes,len(types),len(reps)))]
    if set(keys)==set(KEYS):check(tot[1:]==[3351,142])
    print(f'Total {tot[0]} nodes, {tot[1]} explicit isomorphisms, {tot[2]} residual-block prices; '
          f'prices replayed={photos}, trees replayed={trees}.')

if __name__=='__main__':
    args=argparse.ArgumentParser(description=__doc__)
    args.add_argument('keys',nargs='*')
    args.add_argument('--only-maps',action='store_true')
    args.add_argument('--only-photos',action='store_true')
    args.add_argument('--only-trees',action='store_true')
    opts=args.parse_args();check(sum([opts.only_maps,opts.only_photos,opts.only_trees])<=1)
    verify(opts.keys or KEYS,not (opts.only_maps or opts.only_trees),not (opts.only_maps or opts.only_photos))
