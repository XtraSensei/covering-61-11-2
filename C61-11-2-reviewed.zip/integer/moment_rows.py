"""Generate necessary rows directly from counts, partner seats and repeat budgets."""
from collections import Counter
from verify_tree import require


def signature(sign,rhs,terms):
    return sign,rhs,tuple(sorted((i,c) for i,c in terms.items() if c))


def base_rows(m,decisions):
    n=m.n;people=sum(m.F);x=m.orb[:n]
    def row(sign,b,terms):
        r=Counter()
        for j,c in terms:r[j]+=c
        return signature(sign,b,r)
    def bound(ids,k,sign):
        yield row(sign,k,[(x[i],1) for i in ids])
        for i in range(n):
            terms=[(x[i],-k+int(i in ids))]
            for j in ids:
                p=m.P.get(tuple(sorted((i,j))))
                if p:terms.append((m.orb[p[0]],1+int(i==j)))
            yield row(sign,0,terms)
    for r,count in enumerate(m.F,7):
        if count:yield row('=',count,[(x[i],1) for i in range(n) if m.rank[i]==r])
    for c,w in enumerate(m.W):
        yield row('=',w*m.C[c],[(x[i],s[c]) for i,s in enumerate(m.T)])
    for (i,j),(k,lo,parts) in m.P.items():
        y=m.orb[k]
        for c,z in parts.items():
            height=min(m.T[i][c],m.T[j][c])-lo[c]
            yield row('<=',0,[(m.orb[z],1),(y,-height)])
        if not any(lo):yield row('<=',0,[(y,1),*[(m.orb[z],-1) for z in parts.values()]])
    for i,s in enumerate(m.T):
        arcs=m.links[i];r=m.rank[i]
        yield row('=',0,[(x[i],1-people),*[(y,1) for j,y,l,e in arcs]])
        for c,w in enumerate(m.W):
            yield row('=',0,[(x[i],s[c]-w*m.C[c]),*[(y,m.T[j][c]) for j,y,l,e in arcs]])
            terms=[(x[i],-s[c]*(m.C[c]-1))]
            for j,y,l,e in arcs:
                terms.append((y,l[c]))
                if c in e:terms.append((e[c],1))
            yield row('=',0,terms)
        for rank,mass in enumerate(m.F,7):
            if mass:yield row('=',0,[(x[i],int(r==rank)-mass),*[(y,1) for j,y,l,e in arcs if m.rank[j]==rank]])
        yield row('<=',m.U[i],[(x[i],1)])
        diag=m.P.get((i,i))
        for k in range(1,m.U[i]):
            yield row('<=',k*(k+1)//2,[(x[i],k)]+([(m.orb[diag[0]],-1)] if diag else []))
        terms=[(x[i],-(m.E[i]//(r-1)))]
        for j,y,l,e in arcs:
            if j==i:terms.extend([(y,sum(l)-r+1),*[(z,1) for z in e.values()]])
        yield row('<=',0,terms)
        for j in range(n):
            p=m.P.get(tuple(sorted((i,j))))
            yield row('<=',0,[(x[i],int(i==j)-m.U[j])]+([(m.orb[p[0]],1+int(i==j))] if p else []))
        for d in (2,3,4):
            yield row('<=',0,[(x[i],-(m.E[i]//d)),*[(y,max(0,sum(l)-1)//d) for j,y,l,e in arcs]])
    for ids,k in decisions:
        require(len(ids)==len(set(ids)) and all(type(i) is int and 0<=i<n for i in ids))
        require(all((i in ids)==(j in ids) for i in range(n) for j in range(n) if x[i]==x[j]))
        yield from bound(ids,k,'=')
    for ids,k in m.parents:yield from bound(ids,k,'<=')
