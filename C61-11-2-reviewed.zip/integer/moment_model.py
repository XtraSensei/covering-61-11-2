"""Construct person and person-pair columns, bounds and relabelling orbits from the blocks."""
from collections import Counter
from itertools import combinations_with_replacement
from verify_anchors import FREQ,inventory
from verify_tree import require


class Model:
    def __init__(self,key,catalog,denied,perms,graphs,anchor=0):
        name,profile=key.split('.');a,rows=catalog[name];pop=FREQ[a][int(profile)]
        blocks=rows+[0]*(38-len(rows));fixed=[(m,(anchor>>j)&1) for j,m in enumerate(blocks)]
        self.colors=sorted(set(fixed));self.W=[fixed.count(c) for c in self.colors]
        self.C=[11-m.bit_count()-b for m,b in self.colors];self.F=list(pop);self.parents=[]
        ban,edges=graphs.get(key,(set(),set()))
        if anchor:
            require(key=='9-41.0' and 0<anchor<1<<38 and anchor.bit_count()==7)
            self.F[0]-=1;sig=tuple(sorted(m for m,b in fixed if m and b))
            require(sig==(97,146,268) and all(rows.count(m)==1 for m in sig) and (anchor>>len(rows)).bit_count()==4 and len(blocks)-len(rows)==11)
            original=Model(key,catalog,denied,perms,graphs)
            anchor_sig=tuple(sum(b for mask,b in fixed if low==mask) for low,_ in original.colors)
            require(original.T[101]==anchor_sig and original.U[101]==4)
            den=denied|{(7,sig)}
        else:den=denied
        room,ranks,caps=inventory(rows,a,pop,anchor,den)
        self.T=sorted(caps);self.U=[caps[s] for s in self.T];n=len(self.T);self.n=n
        self.rank=list(map(sum,self.T))
        self.E=[10*(sum(s)-6)-(sum(t for t,(_,b) in zip(s,self.colors) if b)-1 if anchor else 0) for s in self.T]
        require(room[:len(self.W)]==[w*c for w,c in zip(self.W,self.C)])
        if anchor:
            parent=[original.T.index(tuple(sum(t for t,(mask,b) in zip(s,self.colors) if low==mask)
                        for low,_ in original.colors)) for s in self.T]
            for p in sorted(set(parent)):
                self.parents.append(([i for i,q in enumerate(parent) if p==q],original.U[p]-int(p==101)))
            ban={i for i,p in enumerate(parent) if p in ban or tuple(sorted((p,101))) in edges}
            edges={(i,j) for i in range(n) for j in range(i+1,n) if tuple(sorted((parent[i],parent[j]))) in edges}
        self.ban,self.edges=ban,edges
        self.raw=[('x',i) for i in range(n)];upper=[0 if i in ban else u for i,u in enumerate(self.U)]
        self.P={}
        for i,j in combinations_with_replacement(range(n),2):
            lo=tuple(max(0,s+t-w) for s,t,w in zip(self.T[i],self.T[j],self.W))
            hi=tuple(map(min,zip(self.T[i],self.T[j])))
            if i==j and self.U[i]<2 or not any(hi):continue
            bound=self.U[i]*self.U[j] if i!=j else self.U[i]*(self.U[i]-1)//2
            if i in ban or j in ban or (i,j) in edges:bound=0
            y=len(self.raw);self.raw.append(('y',i,j));upper.append(bound);parts={}
            for c,(l,u) in enumerate(zip(lo,hi)):
                if u>l:
                    parts[c]=len(self.raw);self.raw.append(('z',i,j,c));upper.append((u-l)*bound)
            self.P[i,j]=(y,lo,parts)
        index={v:i for i,v in enumerate(self.raw)};roots=list(range(len(index)))
        def root(i):
            while roots[i]!=i:roots[i]=roots[roots[i]];i=roots[i]
            return i
        where={s:i for i,s in enumerate(self.T)};colidx={c:i for i,c in enumerate(self.colors)}
        for p in perms:
            require(sorted(p)==list(range(a)))
            move=lambda m:sum(1<<p[i] for i in range(a) if m>>i&1)
            require(Counter(map(move,rows))==Counter(rows))
            colors=[(move(m),tag) for m,tag in self.colors]
            if any(c not in colidx for c in colors):continue
            cm=[colidx[c] for c in colors]
            if any(self.W[i]!=self.W[j] for i,j in enumerate(cm)):continue
            if cm==list(range(len(cm))):continue
            back=sorted(range(len(cm)),key=cm.__getitem__)
            tm=[where[tuple(s[i] for i in back)] for s in self.T]
            for k,(tag,*args) in enumerate(self.raw):
                if tag=='x':target=('x',tm[args[0]])
                else:
                    i,j=sorted((tm[args[0]],tm[args[1]]))
                    target=('y',i,j) if tag=='y' else ('z',i,j,cm[args[2]])
                u,v=root(k),root(index[target]);roots[max(u,v)]=min(u,v)
        roots=list(map(root,range(len(roots))));reps=sorted(set(roots));compact={v:k for k,v in enumerate(reps)}
        self.orb=[compact[v] for v in roots];self.upper=[upper[i] for i in reps]
        require(all(self.upper[self.orb[i]]==u for i,u in enumerate(upper)))
        self.links=[[] for _ in range(n)]
        for (i,j),(y,lo,parts) in self.P.items():
            e={c:self.orb[k] for c,k in parts.items()}
            self.links[i].append((j,self.orb[y],lo,e));self.links[j].append((i,self.orb[y],lo,e))
