"""Replay a branching certificate using exact integer row combinations and box bounds."""
from collections import Counter


def require(ok):
    if not ok:raise ValueError('invalid integer tree certificate')


class Box:
    def __init__(self, model, support, excluded):
        self.ids=list(support);self.n=len(support);self.b=model['empty']
        require(type(self.b) is int and self.b>0 and len(set(support))==len(support))
        require(all(type(j) is int and 0<=j<len(model['types']) for j in support))
        self.types=[model['types'][i] for i in support]
        require(all(all(type(v) is int for v in t) and p>0 and g>=0 and g&p==g and u>=0 and 0<=r-p.bit_count()<=self.b for t in self.types for p,g,r,u in [t]))
        require(all(type(b) is int for ids,b in model['seats']) and all(type(a) is type(b) is int for ids,a,b in model.get('bounds',[])))
        self.upper=[u for _,_,_,u in self.types]
        self.h=[r-p.bit_count() for p,g,r,u in self.types]
        self.miss=[{j for j,(q,_,_,_) in enumerate(self.types) if not p&q} for p,_,_,_ in self.types]
        self.seats=[({j:1 for j,i in enumerate(support) if i in ids},b) for ids,b in model['seats']]
        self.hits=[{j:1 for j,i in enumerate(support) if i not in denied} for denied in excluded]
        self.extra=[({j:1 for j,i in enumerate(support) if i in ids},a,b) for ids,a,b in model.get('bounds',[])]

    def row(self, tag, lo):
        kind,*args=tag
        if kind in ('E','H','B','R'):require(all(type(v) is int for v in args))
        if kind=='E':
            j,=args;require(0<=j<len(self.seats));v,b=self.seats[j];return v,b,b
        if kind=='H':
            j,=args;require(0<=j<len(self.hits));return self.hits[j],1,None
        if kind=='B':
            j,=args;require(0<=j<len(self.extra));return self.extra[j]
        if kind=='L':
            weights,=args;row=Counter();target=0
            for j,w in weights:
                require(type(j) is int and 0<=j<len(self.seats) and type(w) is int)
                v,b=self.seats[j];target+=w*b
                for k,c in v.items():row[k]+=w*c
            return {k:c for k,c in row.items() if c},target,target
        if kind=='R':
            i,d=args;require(0<=i<self.n and lo[i]>0 and d>0)
            _,g,r,_=self.types[i]
            co={j:max(0,(g&v).bit_count()-1)//d for j,(_,v,_,_) in enumerate(self.types)}
            return {j:c for j,c in co.items() if c},None,10*(r-6)//d+co[i]
        if kind=='C':
            sample,=args;indices=[i for i,t in sample]
            require(len(set(indices))==len(indices) and all(type(i) is type(t) is int and 0<=i<self.n and 0<t<=lo[i] for i,t in sample))
            mass=sum(t*self.h[i] for i,t in sample)
            if mass>11*self.b:return {},None,-1
            q,e=divmod(mass,self.b);cap=(self.b-e)*q*(11-q)+e*(q+1)*(10-q)
            co=Counter()
            for i,t in sample:
                for j in self.miss[i]:co[j]+=t
            return co,None,cap+sum(t*co[i] for i,t in sample)
        if kind=='N':
            group,=args;require(group and len(group)==len(set(group)))
            used=set();neighbors=set()
            for i in group:
                require(type(i) is int and 0<=i<self.n and lo[i]>0 and self.h[i]>=1 and (not used or i in neighbors))
                used.add(i);neighbors.update(self.miss[i])
            return dict.fromkeys(neighbors,1),None,11+10*sum(self.h[i]-1 for i in group)
        raise ValueError('unknown row')


def tighten(row, lo, hi):
    coeff,left,right=row
    minimum=sum(c*(lo[j] if c>0 else hi[j]) for j,c in coeff.items())
    maximum=sum(c*(hi[j] if c>0 else lo[j]) for j,c in coeff.items())
    if left is not None and maximum<left or right is not None and minimum>right:return -1
    changed=False
    for j,c in coeff.items():
        require(type(c) is int and c!=0)
        a,b=lo[j],hi[j]
        if left is not None:
            if c>0:a=max(a,hi[j]-(maximum-left)//c)
            else:b=min(b,lo[j]+(maximum-left)//-c)
        if right is not None:
            if c>0:b=min(b,lo[j]+(right-minimum)//c)
            else:a=max(a,hi[j]-(right-minimum)//-c)
        if a>b:return -1
        changed|=(a,b)!=(lo[j],hi[j]);lo[j],hi[j]=a,b
    return int(changed)


def replay(box, doc, accepted=()):
    tags=doc['rules'];steps=iter(doc['tree']);nodes=0
    def walk(lo,hi):
        nonlocal nodes
        nodes+=1
        ins=next(steps)
        while ins>=0:
            require(type(ins) is int and ins<len(tags))
            result=tighten(box.row(tags[ins],lo),lo,hi)
            if result<0:return
            ins=next(steps)
        require(type(ins) is int);j=-1-ins
        if j==box.n:
            k=next(steps);require(lo==hi and type(k) is int and 0<=k<len(accepted))
            observed=sorted((p,r,v) for (p,g,r,_),v in zip(box.types,lo) if v)
            require(observed==sorted(tuple(t) for t in accepted[k]));return
        require(0<=j<box.n and 0<=lo[j]<hi[j])
        for value in range(lo[j],hi[j]+1):
            a,b=lo.copy(),hi.copy();a[j]=b[j]=value;walk(a,b)
    walk([0]*box.n,box.upper.copy())
    end=object();require(next(steps,end) is end and type(doc['nodes']) is int and doc['nodes']==nodes)
    return nodes
