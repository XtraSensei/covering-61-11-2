"""Check the geometric origin of each priced sparse row using only the Python standard library."""
from collections import Counter
import gzip
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from moment_cuts import quadratic
from moment_model import Model
from moment_rows import base_rows,signature
from verify_anchors import verify as anchors
from verify_graphs import verify as graphs
from verify_inventories import read_json
from verify_tree import require


def canonical(sign,b,terms):
    require(type(b) is int and sign in ('=','<='))
    co=Counter()
    for i,x in terms:
        require(type(i) is type(x) is int);co[i]+=x
    return signature(sign,b,co)


def check_rows(model,decisions,selected,tags):
    missing=set(selected)
    for row in base_rows(model,decisions):missing.discard(row)
    for tag in tags:
        if not missing:break
        missing.discard(quadratic(model,tag))
    if missing:raise ValueError(f'{len(missing)} sparse rows have no valid origin; example {str(next(iter(missing)))[:250]}')


def verify(here,denied,graphs_checked):
    raw=here.parent/'computational'/'round2'
    if not raw.is_dir():raw=here.parent/'round2'
    catalog=read_json(here/'catalogue.json');acts=read_json(here/'anchor-input.json');count=0
    roots=set();models={}
    def build(key,anchor=0):
        if (key,anchor) not in models:
            models.clear()
            models[key,anchor]=Model(key,catalog,denied[key],acts[key]['symmetry'],graphs_checked,anchor)
        return models[key,anchor]
    with gzip.open(here/'prices.jsonl.gz','rt',encoding='utf8') as data:
        for line in data:
            doc=json.loads(line)
            if doc['kind'] not in ('moment','rooted'):continue
            key=doc['case'];dec=[];anchor=0
            if doc['kind']=='moment':
                require(doc['id']==key+'/moment');source=raw/'gramcerts'/(key+'.json')
            else:
                require(key=='9-41.0');k=int(doc['id'].rsplit('/',1)[1]);require(doc['id']==key+'/root/'+str(k) and 0<=k<=4 and k not in roots)
                roots.add(k)
                if k==1:
                    source=raw/'rootedgram'/(key+'_101_-1.json');anchor,=read_json(source)['anchors']
                else:source=raw/'gramslices'/(key+f'_101v{k}.json');dec=[([101],k)]
                unmarked=build(key);require(unmarked.U[101]==4)
                require([(mask,t) for (mask,_),t in zip(unmarked.colors,unmarked.T[101]) if t]==[(0,4),(97,1),(146,1),(268,1)])
            m=build(key,anchor)
            if doc['upper']!=m.upper:raise ValueError(f'{doc["id"]}: mismatched person-pair column bounds')
            selected=[canonical(sign,b,row) for sign,w,b,row in doc['rows']]
            try:check_rows(m,dec,selected,read_json(source)['tags'])
            except ValueError as error:raise ValueError(doc['id']) from error
            count+=1
    require(count==34 and roots==set(range(5)))
    key='9-37.0';m=build(key);stored=read_json(here/'support-matrix.json.gz')
    require(m.orb==list(range(len(m.raw))) and m.upper==stored['upper'])
    require(stored['owner']==[list(a[1:2] if a[0]=='x' else a[1:3]) for a in m.raw])
    require(stored['pairs']==[[i,j,y] for (i,j),(y,l,e) in sorted(m.P.items())])
    selected=[canonical('=' if label[0]=='y' else '<=',b,row) for label,(b,row) in stored['rows'].items()]
    check_rows(m,[],selected,read_json(raw/'gramcerts'/(key+'.json'))['tags'])
    print(f'Reconstructed bounds and all priced matrix rows for {count} moment/root certificates and the 9-37 support matrix with standard-library integer arithmetic.',flush=True)

if __name__=='__main__':
    denied=anchors(HERE);verify(HERE,denied,graphs(HERE,denied))
