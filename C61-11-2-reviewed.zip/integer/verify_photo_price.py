"""Check an integer residual-block price directly from a population layout."""
from itertools import combinations


def check(ok):
    if not ok:raise ValueError('invalid residual-block price')


def photo_price(types,b,doc):
    check(type(b) is int and b>0 and all(all(type(v) is int for v in t) for t in types))
    n=len(types);size=[w for p,r,w in types];h=[r-p.bit_count() for p,r,w in types]
    check(all(p>0 and r>=7 and w>0 and 0<=k<=b for (p,r,w),k in zip(types,h)))
    check(sum(u*v for u,v in zip(size,h))==11*b)
    if 'types' in doc:check(list(map(tuple,doc['types']))==types and doc['b']==b)
    pairs=[(i,j) for i,j in combinations(range(n),2) if not types[i][0]&types[j][0]]
    terms=[('E',i,None,None,None,()) for i in range(n)]+[('P',i,j,None,None,()) for i,j in pairs]
    for i,subset,kind,v,s,_ in doc.get('tags',[]):
        check(all(type(x) is int for x in (i,v,s,*subset)))
        check(kind in ('H','R') and 0<=i<n and len(subset)==len(set(subset)))
        check(all(0<=j<n and not types[i][0]&types[j][0] for j in subset))
        total=sum(size[j] for j in subset)
        check((h[i]==2 and 0<=2*v<total) if kind=='H' else v>0 and s>=0)
        terms.append(('H' if kind=='H' else 'S',i,total,v,s,subset))
    prices=doc['price'];check(len(prices)==len(terms) and all(type(w) is int for w in prices))
    fixed=[];target=0
    for term,w in zip(terms,prices):
        k,i,j,v,s,subset=term
        check(k=='E' or w>=0)
        if not w:continue
        fixed.append((term,w))
        if k=='E':target+=w*h[i]*size[i]
        if k=='P':target+=w*size[i]*size[j]
        if k=='S':target+=w*size[i]*((j+h[i]*s+v-1)//v)
    check(type(doc['rhs']) is int and type(doc['top']) is int and target==doc['rhs'] and b*doc['top']<target)
    known=[[j for j,t in enumerate(types) if p&t[0]] for p,r,u in types]
    limit=[10*h[i]-sum(size[j] for j in range(n) if j not in known[i])+1 for i in range(n)]
    suffix=[0]*(n+1)
    for i in reversed(range(n)):suffix[i]=suffix[i+1]+(size[i] if h[i] else 0)
    q=[0]*n;seen=[0]*n;best=None
    def walk(i,left):
        nonlocal best
        if left>suffix[i]:return
        if not left:
            if any(q[j] and seen[j]>limit[j] for j in range(n)):return
            value=0
            for (k,a,j,v,s,items),w in fixed:
                x=q[a]
                if k=='P':x*=q[j]
                if k in ('H','S'):
                    z=sum(q[t] for t in items)
                    x*=(int(z>=j-v)-int(z<=v)) if k=='H' else (z+s+v-1)//v
                value+=w*x
            check(value<=doc['top'])
            best=value if best is None else max(value,best)
            return
        if i==n:return
        walk(i+1,left)
        high=min(left,size[i] if h[i] else 0,limit[i]-seen[i])
        high=min([high]+[limit[j]-seen[j] for j in known[i] if j<i and q[j]])
        for count in range(1,high+1):
            q[i]=count
            for j in known[i]:seen[j]+=1
            walk(i+1,left-count)
        q[i]=0
        for j in known[i]:seen[j]-=max(0,high)
    walk(0,11);check(best==doc['top'])
    return target-b*best
