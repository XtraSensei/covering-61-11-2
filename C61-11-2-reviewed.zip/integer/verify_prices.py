"""Portable exact-integer verifier for seat prices and sparse Farkas witnesses."""
from collections import Counter, defaultdict
import gzip
import json
from pathlib import Path
import sys


def need(test, message):
    if not test:
        raise ValueError(message)


def patterns(rows, remaining):
    if not remaining:
        yield 0
        return
    first = remaining & -remaining
    for j, row in enumerate(rows):
        if row & first and row & remaining == row:
            for rest in patterns(rows, remaining ^ row):
                yield rest | (1 << j)


def seats(record, entry):
    a, rows = entry
    pop, price = record["frequency"], record["price"]
    rg = [d for d, n in enumerate(pop, 7) if n]
    need(len(price) == len(rows) + len(rg), "missing seat price")
    need(all(type(v) is int for v in [*price, *pop]), "nonintegral seat price or population")
    quad = sum(1 << j for j, m in enumerate(rows) if m.bit_count() == 4)
    rhs = [11 - m.bit_count() for m in rows] + [pop[d - 7] for d in rg]
    demand = sum(y * v for y, v in zip(price, rhs))
    supply = 0
    for pattern in patterns(rows, (1 << a) - 1):
        k = pattern.bit_count()
        need(k > 1, "unexpected single-row partition")
        scores = []
        for index, d in enumerate(rg):
            if not 0 <= d - k <= 38 - len(rows):
                continue
            if a == 12 and d == 8 and pattern & quad != quad:
                continue
            used = 3 * max(0, (pattern & quad).bit_count() - 1) if (a, d) == (12, 7) else 0
            cap = min(pop[d - 7], 1 + (10 * (d - 6) - used) // (k - 1))
            score = price[len(rows) + index] + sum(y for j, y in enumerate(price[:len(rows)]) if pattern >> j & 1)
            scores.extend([max(0, score)] * cap)
        group_cap = max(a - 9, 1 + 10 // (k - 1))
        supply += sum(sorted(scores, reverse=True)[:group_cap])
    return demand - supply


def farkas(record):
    bounds = record["upper"]
    need(all(type(u) is int and u >= 0 for u in bounds), "invalid variable bound")
    column = defaultdict(int)
    target = 0
    for relation, multiplier, rhs, row in record["rows"]:
        need(relation == "=" or (relation == "<=" and multiplier <= 0), "illegal multiplier")
        need(type(multiplier) is int and type(rhs) is int, "nonintegral row")
        target += multiplier * rhs
        for j, value in row:
            need(type(j) is int and 0 <= j < len(bounds) and type(value) is int, "invalid coefficient")
            column[j] += multiplier * value
    return target - sum(max(0, value) * bounds[j] for j, value in column.items())


def verify(directory):
    catalogue = json.loads((directory / "catalogue.json").read_text(encoding="utf-8"))
    need(Counter(a for a, _ in catalogue.values()) == {9: 50, 10: 65, 11: 36, 12: 64}, "catalogue counts")
    for a, rows in catalogue.values():
        need(len(rows) <= 38 and all(0 < m < (1 << a) for m in rows), "invalid row")
        for i in range(a):
            need(sum(m >> i & 1 for m in rows) == 6, "incorrect replication")
            for j in range(i):
                need(sum((m >> i & 1) * (m >> j & 1) for m in rows) == 1, "incorrect pair multiplicity")
    ledger = json.loads((directory / "price-index.json").read_text(encoding="utf-8"))
    checked = {}
    with gzip.open(directory / "prices.jsonl.gz", "rt", encoding="utf-8") as source:
        for line in source:
            record = json.loads(line)
            name, kind = record["id"], record["kind"]
            need(name not in checked and ledger.get(name) == kind, "duplicate or unexpected certificate")
            if kind == "seat":
                pop = record["frequency"]
                skeleton, suffix = name.split(".")
                a, rows = catalogue[skeleton]
                profiles = {9: [(52,0,0)], 10: [(50,1,0)], 11: [(48,2,0),(49,0,1)], 12: [(46,3,0)]}[a]
                need(suffix in [str(i) for i in range(len(profiles))] and tuple(pop)==profiles[int(suffix)], "invalid frequency profile")
                gap = seats(record, (a, rows))
            else:
                need(kind in ("anchor", "moment", "rooted"), "unknown certificate")
                gap = farkas(record)
            need(type(record["gap"]) is int and gap == record["gap"] and gap > 0, f"{name}: gap {gap}")
            checked[name] = kind
    need(checked == ledger, "missing certificate")
    need(Counter(checked.values()) == {"seat":205, "anchor":371, "moment":29, "rooted":5}, "missing proof family")
    print("Verified", len(checked), "strict integer contradictions.", dict(sorted(Counter(checked.values()).items())))


if __name__ == "__main__":
    verify(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent)
