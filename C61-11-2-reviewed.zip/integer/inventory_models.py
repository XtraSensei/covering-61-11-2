"""Rebuild unmarked-block population variables from the labelled low-point rows."""
from collections import defaultdict
from verify_anchors import FREQ,inventory,partitions


def model_for(key, catalogue, denied, grouped):
    name,p=key.split('.');a,rows=catalogue[name];population=FREQ[a][int(p)]
    b=38-len(rows);keys=sorted(set([0]+rows));width=[(rows+[0]*b).count(m) for m in keys]
    room,ranks,cap=inventory(rows,a,population,0,denied)
    if grouped:
        fixed=sum(1<<(j-1) for j in range(1,len(keys)) if width[j]==1)
        types=[];signatures=sorted(cap)
        for s in signatures:
            if any(v>1 for v in s[1:]):raise ValueError('invalid main-block multiplicity')
            mask=sum(1<<(j-1) for j in range(1,len(keys)) if s[j]);types.append((mask,mask&fixed,sum(s),cap[s]))
        seats=[([i for i,s in enumerate(signatures) if s[j]],room[j]) for j in range(1,len(keys))]
        seats.extend(([i for i,s in enumerate(signatures) if sum(s)==r],population[r-7]) for r in ranks)
        return dict(empty=b,types=types,seats=seats)
    types=[];same=defaultdict(list);ranked=defaultdict(list)
    for cells in sorted(partitions(rows,(1<<a)-1),key=lambda s:sum(1<<j for j in s)):
        mask=sum(1<<j for j in cells);k=len(cells);sig=tuple(sorted(rows[i] for i in cells))
        for r in ranks:
            s=tuple(r-k if m==0 else sig.count(m) for m in keys)
            if s not in cap:continue
            # Every pair in this raw type shares k named core blocks.
            u=min(cap[s],1+10*(r-6)//(k-1));idx=len(types)
            types.append((mask,mask,r,u));same[mask].append(idx);ranked[s].append(idx)
    seats=[([i for i,(m,_,_,_) in enumerate(types) if m>>j&1],11-v.bit_count()) for j,v in enumerate(rows)]
    seats.extend(([i for i,(_,_,v,_) in enumerate(types) if v==r],population[r-7]) for r in ranks)
    bounds=[(ids,0,max(a-9,1+10//(m.bit_count()-1))) for m,ids in same.items() if len(ids)>1]
    bounds.extend((ids,0,cap[s]) for s,ids in ranked.items() if len(ids)>1)
    return dict(empty=b,types=types,seats=seats,bounds=bounds)
