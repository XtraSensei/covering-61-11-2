"""Run a single local Lean check or Lake build inside the project's resource limits."""

import argparse
import json
import os
from pathlib import Path
import shutil
import sys

from resource_guard import GuardError, acquire


WORK = Path(__file__).resolve().parent
PROJECT = WORK / "leanproof"
if not PROJECT.is_dir() and (WORK.parent / "lean" / "lean-toolchain").is_file():
    PROJECT = WORK.parent / "lean"
BIN = WORK / "lean-4.36.0-windows" / "bin"
if not (BIN / "lake.exe").is_file():
    elan_root = Path(os.environ.get("ELAN_HOME", str(Path.home() / ".elan")))
    BIN = Path(os.environ.get("COVER61_LEAN_BIN", str(elan_root / "toolchains" / "leanprover--lean4---v4.36.0" / "bin")))


def lake_command():
    # Reuse the already installed package directories without running parallel
    # Git probes during Lake workspace loading. Keep its source manifest intact.
    data = json.loads((PROJECT / "lake-manifest.json").read_text(encoding="utf-8"))
    entries = []
    for package in data["packages"]:
        directory = Path(data["packagesDir"]) / package["name"]
        entry = {k: package[k] for k in ("name", "scope", "configFile", "manifestFile", "inherited") if k in package}
        entry.update(type="path", dir=directory.as_posix())
        entries.append(entry)
    overrides = WORK / "local-lake-packages.json"
    content = json.dumps({"version": data["version"], "packages": entries})
    if not overrides.exists() or overrides.read_text(encoding="utf-8") != content:
        overrides.write_text(content, encoding="utf-8")
    return [BIN / "lake.exe", f"--packages={overrides}", "--offline", "--fail-fast", "build"]


def environment():
    env = os.environ.copy()
    search = [str(BIN)]
    # Git for Windows' cmd wrapper starts another process. Select its real executable.
    git = shutil.which("git")
    if git:
        backend = Path(git).parent.parent / "mingw64" / "bin"
        if (backend / "git.exe").is_file():
            search.append(str(backend))
    env["PATH"] = os.pathsep.join([*search, env["PATH"]])
    manifest = json.loads((PROJECT / "lake-manifest.json").read_text(encoding="utf-8"))
    packages = PROJECT / manifest["packagesDir"]
    paths = [packages / p["name"] for p in manifest["packages"]]
    env["LEAN_PATH"] = os.pathsep.join(str(p / ".lake/build/lib/lean") for p in [PROJECT, *paths])
    return env


def main():
    sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("check", "build"))
    parser.add_argument("target", nargs="?")
    args = parser.parse_args()
    if args.mode == "check":
        if not args.target:
            parser.error("check requires a Lean source file")
        command = [BIN / "lean.exe", "-j1", "-DElab.async=false", args.target]
    else:
        command = lake_command()
        if args.target:
            command.append(args.target)
    name = Path(args.target or "default").stem if args.mode == "check" else args.target or "default"
    log = WORK / f"serial-{args.mode}-{name}.log"
    with acquire() as guard:
        result = guard.run(command, cwd=PROJECT, log=log, env=environment())
    print(log.read_text(encoding="utf-8", errors="replace")[-3600:])
    return result


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (GuardError, OSError) as error:
        sys.exit(str(error))
