"""Run one Windows workload under the Cover61 project's shared hard limits."""

import argparse
import ctypes as ct
from ctypes import wintypes as wt
from contextlib import ExitStack, contextmanager
from dataclasses import dataclass
import msvcrt
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


GIB = 1 << 30
MEMORY_CAP = 16 * GIB
PHYSICAL_RESERVE = 16 * GIB
COMMIT_RESERVE = 8 * GIB
PROCESS_CAP = 2  # The command itself and one child, across all generations.
CPU_RATE = 400  # Windows CPU rate units are 1/100 of a percent.
IDLE_PRIORITY_CLASS = 0x40
POLL_MS = 500
JOB_NAME = r"Local\Codex.Cover61.ResourceGuard"
STOP_NAME = JOB_NAME + ".Stop"
DEFAULT_LOG = Path(__file__).resolve().with_name("guard-last-run.log")

kernel = ct.WinDLL("kernel32", use_last_error=True)
psapi = ct.WinDLL("psapi", use_last_error=True)
size_t = ct.c_size_t
ptr = wt.LPVOID
handle = wt.HANDLE
dword = wt.DWORD


def bind(dll, name, result, *args):
    function = getattr(dll, name)
    function.restype = result
    function.argtypes = args
    return function


class PerformanceInfo(ct.Structure):
    _fields_ = [
        ("cb", dword),
        *((name, size_t) for name in (
            "CommitTotal", "CommitLimit", "CommitPeak", "PhysicalTotal",
            "PhysicalAvailable", "SystemCache", "KernelTotal", "KernelPaged",
            "KernelNonpaged", "PageSize",
        )),
        ("HandleCount", dword), ("ProcessCount", dword), ("ThreadCount", dword),
    ]


class BasicLimits(ct.Structure):
    _fields_ = [
        ("ProcessTime", ct.c_int64), ("JobTime", ct.c_int64), ("Flags", dword),
        ("MinWorkingSet", size_t), ("MaxWorkingSet", size_t),
        ("ActiveProcesses", dword), ("Affinity", size_t),
        ("PriorityClass", dword), ("SchedulingClass", dword),
    ]


class ExtendedLimits(ct.Structure):
    _fields_ = [
        ("Basic", BasicLimits), ("IoCounters", ct.c_uint64 * 6),
        ("ProcessMemory", size_t), ("JobMemory", size_t),
        ("PeakProcessMemory", size_t), ("PeakJobMemory", size_t),
    ]


class CpuLimits(ct.Structure):
    _fields_ = [("Flags", dword), ("Rate", dword)]


class Accounting(ct.Structure):
    _fields_ = [
        ("Times", ct.c_int64 * 4), ("PageFaults", dword),
        ("TotalProcesses", dword), ("ActiveProcesses", dword),
        ("TerminatedProcesses", dword),
    ]


class ProcessListHeader(ct.Structure):
    _fields_ = [("assigned", dword), ("listed", dword)]


class ProcessMemory(ct.Structure):
    _fields_ = [
        ("cb", dword), ("pageFaults", dword), ("peakWorkingSet", size_t),
        ("workingSet", size_t), ("remainingCounters", size_t * 6),
    ]


class StartupInfo(ct.Structure):
    _fields_ = [
        ("cb", dword), ("reserved", wt.LPWSTR), ("desktop", wt.LPWSTR),
        ("title", wt.LPWSTR),
        *((name, dword) for name in (
            "x", "y", "xSize", "ySize", "xChars", "yChars", "fill", "flags",
        )),
        ("show", wt.WORD), ("reservedBytes", wt.WORD), ("reservedPtr", ptr),
        ("stdin", handle), ("stdout", handle), ("stderr", handle),
    ]


class StartupInfoEx(ct.Structure):
    _fields_ = [("info", StartupInfo), ("attributes", ptr)]


class ProcessInfo(ct.Structure):
    _fields_ = [
        ("process", handle), ("thread", handle), ("pid", dword), ("tid", dword),
    ]


get_performance = bind(psapi, "GetPerformanceInfo", wt.BOOL, ptr, dword)
get_process_memory = bind(psapi, "GetProcessMemoryInfo", wt.BOOL, handle, ptr, dword)
open_process = bind(kernel, "OpenProcess", handle, dword, wt.BOOL, dword)
current_process = bind(kernel, "GetCurrentProcess", handle)
get_affinity = bind(kernel, "GetProcessAffinityMask", wt.BOOL, handle, ptr, ptr)
close = bind(kernel, "CloseHandle", wt.BOOL, handle)
create_job = bind(kernel, "CreateJobObjectW", handle, ptr, wt.LPCWSTR)
set_job = bind(kernel, "SetInformationJobObject", wt.BOOL, handle, ct.c_int, ptr, dword)
query_job = bind(kernel, "QueryInformationJobObject", wt.BOOL, handle, ct.c_int, ptr, dword, ptr)
in_job = bind(kernel, "IsProcessInJob", wt.BOOL, handle, handle, ptr)
terminate_job = bind(kernel, "TerminateJobObject", wt.BOOL, handle, wt.UINT)
create_event = bind(kernel, "CreateEventW", handle, ptr, wt.BOOL, wt.BOOL, wt.LPCWSTR)
open_event = bind(kernel, "OpenEventW", handle, dword, wt.BOOL, wt.LPCWSTR)
signal_event = bind(kernel, "SetEvent", wt.BOOL, handle)
wait = bind(kernel, "WaitForSingleObject", dword, handle, dword)
duplicate = bind(kernel, "DuplicateHandle", wt.BOOL, handle, handle, handle, ptr, dword, wt.BOOL, dword)
init_attributes = bind(kernel, "InitializeProcThreadAttributeList", wt.BOOL, ptr, dword, dword, ptr)
update_attribute = bind(kernel, "UpdateProcThreadAttribute", wt.BOOL, ptr, dword, size_t, ptr, size_t, ptr, ptr)
delete_attributes = bind(kernel, "DeleteProcThreadAttributeList", None, ptr)
create_process = bind(
    kernel, "CreateProcessW", wt.BOOL, wt.LPCWSTR, wt.LPWSTR, ptr, ptr, wt.BOOL,
    dword, ptr, wt.LPCWSTR, ptr, ptr,
)
resume = bind(kernel, "ResumeThread", dword, handle)
get_exit_code = bind(kernel, "GetExitCodeProcess", wt.BOOL, handle, ptr)

# JobObjectExtendedLimitInformation, JobObjectCpuRateControlInformation,
# JobObjectBasicAccountingInformation (WinNT.h).
EXTENDED_LIMITS, CPU_LIMITS, ACCOUNTING = 9, 15, 1
# ACTIVE_PROCESS | AFFINITY | PRIORITY_CLASS | JOB_MEMORY | KILL_ON_JOB_CLOSE.
LIMIT_FLAGS = 0x8 | 0x10 | 0x20 | 0x200 | 0x2000
CPU_FLAGS = 0x1 | 0x4  # ENABLE | HARD_CAP.
WAIT_OBJECT_0, WAIT_TIMEOUT = 0, 258


class GuardError(RuntimeError):
    pass


def checked(value):
    if not value:
        raise ct.WinError(ct.get_last_error())
    return value


def signaled(obj, timeout=0):
    result = wait(obj, timeout)
    if result == WAIT_TIMEOUT:
        return False
    if result != WAIT_OBJECT_0:
        raise ct.WinError(ct.get_last_error())
    return True


@dataclass(frozen=True)
class Memory:
    total: int
    available: int
    commit_available: int

    def allowance(self):
        return max(0, min(
            MEMORY_CAP, self.total // 2, self.available - PHYSICAL_RESERVE,
            self.commit_available - COMMIT_RESERVE,
        ))

    def require_reserves(self):
        if self.available <= PHYSICAL_RESERVE:
            raise GuardError("Available physical RAM reached the 16 GiB reserve.")
        if self.commit_available <= COMMIT_RESERVE:
            raise GuardError("Available system commit reached the 8 GiB reserve.")


def memory_now():
    info = PerformanceInfo()
    info.cb = ct.sizeof(info)
    checked(get_performance(ct.byref(info), info.cb))
    return Memory(
        info.PhysicalTotal * info.PageSize, info.PhysicalAvailable * info.PageSize,
        (info.CommitLimit - info.CommitTotal) * info.PageSize,
    )


def one_cpu():
    allowed, system = size_t(), size_t()
    checked(get_affinity(current_process(), ct.byref(allowed), ct.byref(system)))
    if not allowed.value:
        raise GuardError("No logical CPU is available to the controller.")
    return 1 << (allowed.value.bit_length() - 1)


def limits_of(job, info_class, struct_type):
    result = struct_type()
    checked(query_job(job, info_class, ct.byref(result), ct.sizeof(result), None))
    return result


def terminate_tree(job, root_process):
    checked(terminate_job(job, 1))
    if not signaled(root_process, 3000):
        raise GuardError("Windows is still finishing root process termination.")
    deadline = time.monotonic() + 3
    while limits_of(job, ACCOUNTING, Accounting).ActiveProcesses:
        if time.monotonic() >= deadline:
            raise GuardError("Windows is still finishing job termination.")
        time.sleep(0.02)


def job_pids(job):
    # Exiting processes can remain listed briefly alongside the runnable members.
    slots = PROCESS_CAP + 2
    prefix = ct.sizeof(ProcessListHeader)
    while slots <= 256:
        data = ct.create_string_buffer(prefix + slots * ct.sizeof(size_t))
        header = ProcessListHeader.from_buffer(data)
        ok = query_job(job, 3, data, ct.sizeof(data), None)  # JobObjectBasicProcessIdList
        error = ct.get_last_error()
        if ok and header.listed == header.assigned and header.listed <= slots:
            return list((size_t * header.listed).from_buffer(data, prefix))
        if not ok and error != 234:  # ERROR_MORE_DATA
            raise ct.WinError(error)
        slots = max(slots * 2, header.assigned + 1)
    raise GuardError("Windows could not return a complete job PID snapshot within the monitor budget.")


def working_set_bytes(job):
    # Count only live job members. Shared resident pages may count twice.
    total = 0
    for pid in job_pids(job):
        process = open_process(0x100000 | 0x400 | 0x10, False, pid)
        if not process:
            if ct.get_last_error() == 87:  # A PID can exit between the two calls.
                continue
            raise ct.WinError(ct.get_last_error())
        try:
            member = wt.BOOL()
            checked(in_job(process, job, ct.byref(member)))
            if member.value and not signaled(process):
                counters = ProcessMemory()
                counters.cb = ct.sizeof(counters)
                if get_process_memory(process, ct.byref(counters), counters.cb):
                    total += counters.workingSet
                else:
                    error = ct.get_last_error()
                    if not signaled(process):
                        raise ct.WinError(error)
        finally:
            close(process)
    return total


def apply_limits(job, memory_cap):
    extended = ExtendedLimits()
    affinity = one_cpu()
    extended.Basic.Flags = LIMIT_FLAGS
    extended.Basic.ActiveProcesses = PROCESS_CAP
    extended.Basic.Affinity = affinity
    extended.Basic.PriorityClass = IDLE_PRIORITY_CLASS
    extended.JobMemory = memory_cap
    cpu = CpuLimits(CPU_FLAGS, CPU_RATE)
    for info_class, value in ((EXTENDED_LIMITS, extended), (CPU_LIMITS, cpu)):
        checked(set_job(job, info_class, ct.byref(value), ct.sizeof(value)))

    actual = limits_of(job, EXTENDED_LIMITS, ExtendedLimits)
    actual_cpu = limits_of(job, CPU_LIMITS, CpuLimits)
    if (
        actual.Basic.Flags & LIMIT_FLAGS != LIMIT_FLAGS
        or actual.Basic.Flags & (0x800 | 0x1000)  # No process breakaway.
        or actual.Basic.ActiveProcesses != PROCESS_CAP
        or actual.Basic.Affinity != affinity
        or actual.Basic.PriorityClass != IDLE_PRIORITY_CLASS
        or actual.JobMemory != memory_cap
        or (actual_cpu.Flags, actual_cpu.Rate) != (CPU_FLAGS, CPU_RATE)
    ):
        raise GuardError("Windows did not confirm all requested hard limits.")


def child_environment(env):
    result = {k.upper(): v for k, v in env.items()}
    for key in (
        "OMP_NUM_THREADS", "OMP_THREAD_LIMIT", "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "RAYON_NUM_THREADS",
        "GOMAXPROCS",
    ):
        result[key] = "1"
    return ct.create_unicode_buffer("\0".join(f"{k}={v}" for k, v in sorted(result.items())) + "\0")


def inheritable_copy(stack, stream):
    result = handle()
    me = current_process()
    checked(duplicate(me, msvcrt.get_osfhandle(stream.fileno()), me,
                      ct.byref(result), 0, True, 2))  # DUPLICATE_SAME_ACCESS
    stack.callback(close, result)
    return result.value


def launch(job, argv, cwd, env, output):
    """Windows assigns the job during creation, before any child code can run."""
    exe = shutil.which(os.fspath(argv[0]), path=env.get("PATH"))
    if not exe or Path(exe).suffix.lower() != ".exe":
        raise GuardError(f"Expected a Windows .exe, got {argv[0]!s}.")
    exe = str(Path(exe).resolve(strict=True))
    command = ct.create_unicode_buffer(subprocess.list2cmdline([exe, *map(os.fspath, argv[1:])]))
    environment = child_environment(env)
    with ExitStack() as stack:
        null = stack.enter_context(open(os.devnull, "rb"))
        stdin = inheritable_copy(stack, null)
        stdout = inheritable_copy(stack, output)
        jobs = (handle * 1)(job)
        std_handles = (handle * 2)(stdin, stdout)
        length = size_t()
        if init_attributes(None, 2, 0, ct.byref(length)) or ct.get_last_error() != 122:
            raise GuardError("Windows could not size the process attributes.")
        attributes = ct.create_string_buffer(length.value)
        checked(init_attributes(attributes, 2, 0, ct.byref(length)))
        stack.callback(delete_attributes, attributes)
        # PROC_THREAD_ATTRIBUTE_JOB_LIST and PROC_THREAD_ATTRIBUTE_HANDLE_LIST.
        for key, values in ((0x2000D, jobs), (0x20002, std_handles)):
            checked(update_attribute(attributes, 0, key, values, ct.sizeof(values), None, None))
        startup = StartupInfoEx()
        startup.info.cb = ct.sizeof(startup)
        startup.info.flags = 0x100  # STARTF_USESTDHANDLES
        startup.info.stdin, startup.info.stdout, startup.info.stderr = stdin, stdout, stdout
        startup.attributes = ct.cast(attributes, ptr)
        child = ProcessInfo()
        # SUSPENDED | UNICODE_ENVIRONMENT | EXTENDED_STARTUPINFO_PRESENT | NO_WINDOW
        flags = 0x4 | 0x400 | 0x80000 | 0x08000000
        checked(create_process(exe, command, None, None, True, flags, environment,
                               str(cwd), ct.byref(startup), ct.byref(child)))
        stack.callback(close, child.thread)
        try:
            member = wt.BOOL()
            checked(in_job(child.process, job, ct.byref(member)))
            if not member.value:
                raise GuardError("Child job membership could not be verified.")
            if resume(child.thread) == 0xFFFFFFFF:
                raise ct.WinError(ct.get_last_error())
            return child.process
        except BaseException:
            # The job-list attribute already owns the suspended child.
            try:
                terminate_tree(job, child.process)
            finally:
                close(child.process)
            raise


class Guard:
    def __init__(self, job, cancel, memory_cap):
        self.job, self.cancel, self.memory_cap = job, cancel, memory_cap

    def check(self):
        if signaled(self.cancel):
            raise GuardError("Stop requested.")
        memory = memory_now()
        memory.require_reserves()
        if working_set_bytes(self.job) > self.memory_cap:
            raise GuardError("The combined process working sets exceeded the job budget.")
        return memory

    def run(self, argv, *, cwd, log, env=None):
        # Recheck the admission budget between serial targets, before spawning.
        current_cap = min(self.memory_cap, self.check().allowance())
        if current_cap < self.memory_cap:
            apply_limits(self.job, current_cap)
            self.memory_cap = current_cap
        with open(log, "wb") as output:
            process = launch(self.job, argv, cwd, os.environ if env is None else env, output)
            try:
                while not signaled(process, POLL_MS):
                    self.check()
                self.check()
                code = dword()
                checked(get_exit_code(process, ct.byref(code)))
                # Process handles can signal just before the job's accounting
                # reflects the exit. Keep the slot occupied while it drains.
                deadline = time.monotonic() + 1
                while limits_of(self.job, ACCOUNTING, Accounting).ActiveProcesses:
                    if time.monotonic() >= deadline:
                        raise GuardError(f"The command exited with {code.value} and left the job occupied.")
                    self.check()
                    time.sleep(0.05)
                return code.value
            except BaseException:
                terminate_tree(self.job, process)
                raise
            finally:
                close(process)


@contextmanager
def acquire(*, tighter_memory_cap=None):
    # The named job is both the limit container and the per-session project lock.
    ct.set_last_error(0)
    job = checked(create_job(None, JOB_NAME))
    try:
        if ct.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
            raise GuardError("Another Cover61 workload already owns the job.")
        ct.set_last_error(0)
        cancel = checked(create_event(None, True, False, STOP_NAME))
        try:
            if ct.get_last_error() == 183:
                raise GuardError("The previous stop event is still open.")
            snapshot = memory_now()
            snapshot.require_reserves()
            cap = snapshot.allowance()
            if tighter_memory_cap is not None:
                if tighter_memory_cap <= 0:
                    raise ValueError("A diagnostic cap must be positive.")
                cap = min(cap, tighter_memory_cap)
            apply_limits(job, cap)
            yield Guard(job, cancel, cap)
        finally:
            close(cancel)
    finally:
        close(job)  # Last job handle closes, including when the controller exits.


def access_stop_event(*, request=False):
    access = 0x2 if request else 0x100000  # EVENT_MODIFY_STATE or SYNCHRONIZE.
    event = open_event(access, False, STOP_NAME)
    if not event:
        if ct.get_last_error() == 2:  # ERROR_FILE_NOT_FOUND
            return False
        raise ct.WinError(ct.get_last_error())
    try:
        if request:
            checked(signal_event(event))
        return True
    finally:
        close(event)


def print_status():
    snapshot = memory_now()
    print(f"Project controller active: {access_stop_event()}")
    print(f"Physical RAM: {snapshot.total/GIB:.2f} GiB total, {snapshot.available/GIB:.2f} GiB available")
    print(f"System commit available: {snapshot.commit_available/GIB:.2f} GiB")
    print(f"Job memory ceiling: {MEMORY_CAP/GIB:.0f} GiB; current launch allowance: {snapshot.allowance()/GIB:.2f} GiB")
    print("One workload; up to two active processes; one logical CPU; 4% system CPU hard cap; idle priority.")
    print("Watchdog: combined working sets, 16 GiB available physical RAM and 8 GiB system commit, checked every 0.5 s.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action")
    actions.add_parser("status", help="show policy and available memory without starting a workload")
    actions.add_parser("stop", help="request cancellation of the active guarded workload")
    run = actions.add_parser("run", help="start one guarded executable")
    run.add_argument("--cwd", type=Path, default=Path.cwd())
    run.add_argument("--log", type=Path, default=DEFAULT_LOG)
    run.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.action in (None, "status"):
        print_status()
        return 0
    if args.action == "stop":
        print("Stop requested." if access_stop_event(request=True) else "No guarded workload is active.")
        return 0
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("run requires an executable")
    with acquire() as guard:
        print(f"Job cap {guard.memory_cap/GIB:.2f} GiB. Output: {args.log.resolve()}", flush=True)
        return guard.run(command, cwd=args.cwd, log=args.log)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (GuardError, OSError) as error:
        sys.exit(f"Resource guard: {error}")
    except KeyboardInterrupt:
        sys.exit(130)
