"""Build the imported project modules one at a time and run the public axiom audit."""
from pathlib import Path
import re
import sys
from lean_task import BIN,PROJECT,WORK,environment,lake_command
from resource_guard import GuardError,acquire


def dependencies(name):
    file=PROJECT/(name.replace('.','/')+'.lean')
    return re.findall(r'^import (Cover61(?:\.\w+)*)\s*$',file.read_text(encoding='utf-8-sig'),re.M)


def build(target,finish):
    seen=set();ordered=[]
    def visit(name):
        if name in seen:return
        seen.add(name)
        for dependency in dependencies(name):visit(dependency)
        ordered.append(name)
    visit(target)
    command=lake_command();env=environment()
    lib=PROJECT/'.lake'/'build'/'lib'/'lean'
    def artifact(name):return lib/(name.replace('.','/')+'.olean')
    with acquire() as guard:
        for name in ordered:
            result=artifact(name)
            source=PROJECT/(name.replace('.','/')+'.lean')
            inputs=[source,*(artifact(dep) for dep in dependencies(name))]
            if result.is_file() and all(p.is_file() and p.stat().st_mtime_ns<=result.stat().st_mtime_ns for p in inputs):
                continue
            log=WORK/f'serial-build-{name}.log'
            print(f'Building {name}',flush=True)
            code=guard.run([*command,name],cwd=PROJECT,log=log,env=env)
            if code:
                print(log.read_text(encoding='utf8',errors='replace')[-2200:]);return code
        if finish:
            for cmd,file in [(command,'serial-build-default.log'),([BIN/'lean.exe','-j1','-DElab.async=false','Audit.lean'],'serial-check-Audit.log')]:
                code=guard.run(cmd,cwd=PROJECT,log=WORK/file,env=env)
                if code:return code
        print(f'Finished {target}. Checked {len(ordered)} module paths. Full build and axiom audit: {finish}.',flush=True)
        return 0

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8',errors='backslashreplace')
    try:
        name=sys.argv[1] if len(sys.argv)>1 else 'Cover61'
        sys.exit(build(name,name=='Cover61'))
    except (GuardError,OSError) as e:
        sys.exit(str(e))
