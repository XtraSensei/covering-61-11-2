import Cover61.AGChart
import Cover61.AGSaturation
import Mathlib.Data.Fintype.EquivFin

namespace Cover61.Affine

theorem no_scene (g : Scene) : False := by
  classical
  obtain ⟨d,_,single,pop⟩ := g.populations
  have four (r : Loc) := (single r).1
  obtain ⟨p,hp⟩ := g.hasRole (S d 0) (by rw [four]; decide)
  obtain ⟨q,hq⟩ := g.hasRole (S d 1) (by rw [four]; decide)
  let pool := g.group (S d 2)
  let ix : (↥pool) ≃ Fin 4 := Fintype.equivFinOfCardEq (by simpa [pool,Scene.n] using four 2)
  let c (s : Fin 4) : g.O := (ix.symm s).val
  have hc (s : Fin 4) : (g.profile (c s)).r = S d 2 := (Finset.mem_filter.mp (ix.symm s).property).2
  have inj : Function.Injective c := fun _ _ eq => ix.symm.injective (Subtype.ext eq)
  let bits (z : g.O) (row : Loc) : Row := fun i => (g.profile z).bit (coord d row i)
  have rowsMeet (s : Fin 4) : ∃ i, bits q 0 i = bits (c s) 0 i := by
    obtain ⟨k,hk⟩ := g.encounter q (c s)
    obtain ⟨qk,ck⟩ := Finset.mem_inter.mp hk
    have qa := (g.profile q).support qk
    have ca := (g.profile (c s)).support ck
    rw [hq] at qa
    rw [hc] at ca
    obtain ⟨i,pk⟩ := rowsMeetOnFirst d k qa ca
    exact ⟨i,(g.profile q).readCommon _ qk ck pk
      (hq ▸ (offOther d i).1) (hc s ▸ (offOther d i).2.1)⟩
  have bitsEq := same_six_bits (bits p 1) (bits p 2) (bits q 0) (bits q 2)
    (fun s => bits (c s) 0) (fun s => bits (c s) 1) (by
      intro i j
      have dy := ((pop (cuttingDir d i j) (cutDifferent d i j)).2 (omitted d i j)).2
      obtain ⟨w,hw⟩ := g.hasRole (omittedRole d i j) (by change 0 < g.n (D _ _); rw [dy]; decide)
      refine ⟨(g.profile w).bit (coord d 0 i),(g.profile w).bit (coord d 1 j),
        (g.profile w).bit (coord d 2 (i+j)),?_⟩
      have comp (z : g.O) (r : Loc) (zr : (g.profile z).r=S d r) :=
        (g.profile z).comparison (g.profile w) d r i j zr hw
          (g.once d four z w (zr ▸ horizSingle d r) (hw ▸ notDouble d _ _))
      exact ⟨comp p 0 hp,comp q 1 hq,fun s => comp (c s) 2 (hc s)⟩) rowsMeet
  have same (s : Fin 4) : (g.profile (c s)).U = (g.profile (c 0)).U :=
    (g.profile (c s)).agreeThird _ d (hc s) (hc 0)
      (congrFun (bitsEq s).1) (congrFun (bitsEq s).2)
  have twins (s : Fin 4) : 7 ≤ partners g.B (c 0).val (c s).val := by
    rw [← g.common,same s,Finset.inter_self,(g.profile (c 0)).count]
  have ne {i j : Fin 4} (ij : i ≠ j) : (c i).val ≠ (c j).val :=
    fun eq => ij (inj (Subtype.ext eq))
  exact seven_has_no_two_twins g.B g.cover (c 0).val (c 1).val (c 2).val (g.degreeSeven (c 0))
    (ne (by decide)) (ne (by decide)) (ne (by decide)) (twins 1) (twins 2)

/-- No pair covering with nine points of replication six has the incidence
pattern of the order-three affine plane on those points. -/
theorem excluded (B : Family 38) (h : IsCover B) (nine : (lows B).card = 9) :
    ¬ Weighted.Realizes B planeRows := by
  rintro ⟨p,e,six,rows⟩
  obtain ⟨g⟩ := normalized h nine p e six rows
  exact no_scene g

end Cover61.Affine
