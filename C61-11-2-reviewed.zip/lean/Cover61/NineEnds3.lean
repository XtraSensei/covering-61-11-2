import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end42 : EndOK 42 := by decide +kernel

theorem end43 : EndOK 43 := by decide +kernel

theorem end44 : EndOK 44 := by decide +kernel

theorem end45 : EndOK 45 := by decide +kernel

theorem end46 : EndOK 46 := by decide +kernel

theorem end47 : EndOK 47 := by decide +kernel

theorem end48 : EndOK 48 := by decide +kernel

theorem end49 : EndOK 49 := by decide +kernel

theorem end50 : EndOK 50 := by decide +kernel

theorem end51 : EndOK 51 := by decide +kernel

theorem end52 : EndOK 52 := by decide +kernel

theorem end53 : EndOK 53 := by decide +kernel

theorem end54 : EndOK 54 := by decide +kernel

theorem end55 : EndOK 55 := by decide +kernel

theorem reg15 : Regular (candidates 15) := by decide +kernel

theorem reg16 : Regular (candidates 16) := by decide +kernel

theorem reg17 : Regular (candidates 17) := by decide +kernel

theorem reg18 : Regular (candidates 18) := by decide +kernel

theorem reg19 : Regular (candidates 19) := by decide +kernel

end Cover61.Nine
