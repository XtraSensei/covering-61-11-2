import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end154 : EndOK 154 := by decide +kernel

theorem end155 : EndOK 155 := by decide +kernel

theorem end156 : EndOK 156 := by decide +kernel

theorem end157 : EndOK 157 := by decide +kernel

theorem end158 : EndOK 158 := by decide +kernel

theorem end159 : EndOK 159 := by decide +kernel

theorem end160 : EndOK 160 := by decide +kernel

theorem end161 : EndOK 161 := by decide +kernel

theorem end162 : EndOK 162 := by decide +kernel

end Cover61.Nine
