import Mathlib.Data.List.Defs
import Mathlib.Data.List.Permutation
import Mathlib.Tactic.FinCases

namespace Cover61.LatinFive

def encode : List Nat → Nat
  | [] => 0
  | x :: xs => x + 5*encode xs

def digit (p i : Nat) := p / 5^i % 5
def indices := List.range 5
def permutations := indices.permutations'.map encode
def first := encode indices
def separate (p q : Nat) := indices.all (fun i => digit p i != digit q i)
def accepts (s : List Nat) (p : Nat) :=
  digit p 0 == s.length && s.all (separate p)
def levels : Nat → List (List Nat)
  | 0 => [[first]]
  | n+1 => (levels n).flatMap (fun s =>
      ((permutations.filter (accepts s)).map (fun p => s++[p])))
def squares := levels 4

theorem row_is_considered (r : List Nat) (perm : r.Perm indices) : encode r ∈ permutations :=
  List.mem_map.mpr ⟨r,List.mem_permutations'.mpr perm,rfl⟩

theorem extend {s : List Nat} {p n : Nat} (hs : s ∈ levels n) (hp : p ∈ permutations)
    (ok : accepts s p = true) : s++[p] ∈ levels (n+1) :=
  List.mem_flatMap.mpr ⟨s,hs,List.mem_map.mpr ⟨p,List.mem_filter.mpr ⟨hp,ok⟩,rfl⟩⟩

def rowPrefix (r : Nat → Nat) (n : Nat) := (List.range n).map r

theorem complete (r : Nat → Nat) (start : r 0 = first)
    (perm : ∀ i < 5, r i ∈ permutations)
    (front : ∀ i < 5, digit (r i) 0 = i)
    (cols : ∀ i < 5, ∀ j < i, separate (r i) (r j) = true) : rowPrefix r 5 ∈ squares := by
  have build (n : Nat) (hn : n < 5) : rowPrefix r (n+1) ∈ levels n := by
    induction n with
    | zero => simpa [rowPrefix,levels,start]
    | succ n ih =>
      have ok : accepts (rowPrefix r (n+1)) (r (n+1)) = true := by
        simp only [accepts,rowPrefix,List.length_map,List.length_range,Bool.and_eq_true,beq_iff_eq]
        refine ⟨front _ hn,List.all_eq_true.mpr ?_⟩
        intro v hv
        obtain ⟨j,hj,rfl⟩ := List.mem_map.mp hv
        exact cols _ hn j (List.mem_range.mp hj)
      have ex := extend (ih (by omega)) (perm _ hn) ok
      simpa only [rowPrefix,List.range_succ,List.map_append,List.map_singleton] using ex
  exact build 4 (by decide)

def cellMask (p : Nat) : Nat := (indices.map (fun i => 2^(5*i+digit p i))).sum
def transversals (s : List Nat) := (permutations.filter (fun p =>
  ((indices.map (fun i => digit (s[i]?.getD 0) (digit p i))).eraseDups.length == 5))).map cellMask
def disjoint (p q : Nat) := p &&& q == 0
def once (p q : Nat) := let v := p &&& q; v != 0 && (v &&& (v-1) == 0)
def classes (ts : List Nat) :=
  (ts.map (fun p => ts.filter (fun q => p == q || disjoint p q))).eraseDups
def classTest (ts : List Nat) : Bool :=
  let cs := classes ts
  ts.length == 3 || (ts.length == 15 && cs.length == 3 &&
    cs.all (fun c => c.length == 5 && c.all (fun p => c.all (fun q => p == q || disjoint p q))) &&
    ts.all (fun p => (cs.filter (fun c => c.contains p)).length == 1))
def throughTest (ts : List Nat) : Bool :=
  ts.all (fun p => ts.all (fun q => !(disjoint p q) ||
    let good := ts.filter (fun z => once z p && once z q)
    (List.range 25).all (fun k => (good.filter (fun z => z.testBit k)).length ≤ 2)))
def survey (s : List Nat) := let t := transversals s; classTest t && throughTest t

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

theorem square_count : squares.length = 56 := by decide +kernel

theorem certified : squares.all survey = true := by decide +kernel

theorem reduced_square_survey (r : Nat → Nat) (start : r 0 = first)
    (perm : ∀ i < 5, r i ∈ permutations) (front : ∀ i < 5, digit (r i) 0 = i)
    (cols : ∀ i < 5, ∀ j < i, separate (r i) (r j) = true) :
    classTest (transversals (rowPrefix r 5)) = true ∧ throughTest (transversals (rowPrefix r 5)) = true :=
  Bool.and_eq_true_iff.mp (List.all_eq_true.mp certified _ (complete r start perm front cols))

end Cover61.LatinFive
