import Cover61.Partitions
import Mathlib.Data.Fintype.EquivFin

namespace Cover61.Skeleton

abbrev Row (n : Nat) := Finset (Fin n)
abbrev Sys (n : Nat) := Finset (Row n)
def rename {n : Nat} (p : Fin n → Fin n) (H : Sys n) : Sys n :=
  H.image (fun s => s.image p)
def Iso {n : Nat} (H K : Sys n) := ∃ p : Equiv.Perm (Fin n), rename p H = K
def free {n : Nat} (t : Row n) (H : Sys n) : Bool :=
  decide (∀ s ∈ H, (t ∩ s).card ≤ 1)
def Packing {n : Nat} (H : Sys n) := (∀ s ∈ H, s.card=3) ∧
  ∀ s ∈ H, ∀ t ∈ H, s ≠ t → (s ∩ t).card ≤ 1

theorem compose {n : Nat} {a b c : Sys n} (h : Iso a b) (g : Iso b c) : Iso a c := by
  obtain ⟨u,rfl⟩ := h
  obtain ⟨v,rfl⟩ := g
  use u.trans v
  simp [rename,Finset.image_image,Function.comp_def]

theorem free_transport {n : Nat} (p : Equiv.Perm (Fin n)) (t : Row n) (H : Sys n)
    (ok : free t H = true) : free (t.image p) (rename p H) = true := by
  apply decide_eq_true
  intro s hs
  obtain ⟨k,hk,rfl⟩ := Finset.mem_image.mp hs
  rw [← Finset.image_inter _ _ p.injective,Finset.card_image_of_injective _ p.injective]
  exact (of_decide_eq_true ok) k hk

/-- A transition from every admissible one-triple extension suffices to cover
all partial triple systems, up to simultaneous permutation of their points. -/
theorem catalogue {n : Nat} {ι : Type} (states : ι → Sys n) (root : ι)
    (empty : states root = ∅)
    (step : ∀ j t, t.card=3 → free t (states j) = true → ∃ k, Iso (insert t (states j)) (states k))
    (H : Sys n) (valid : Packing H) : ∃ j, Iso H (states j) := by
  induction H using Finset.induction_on with
  | empty => exact ⟨root,Equiv.refl _,by simp [rename,empty]⟩
  | @insert t h new ih =>
    have lift {s : Row n} (hs : s ∈ h) : s ∈ insert t h := Finset.mem_insert_of_mem hs
    have sub : Packing h :=
      ⟨fun s hs => valid.1 s (lift hs),fun s hs v hv => valid.2 s (lift hs) v (lift hv)⟩
    obtain ⟨j,p,eq⟩ := ih sub
    have ht := valid.1 t (Finset.mem_insert_self t h)
    have good : free t h = true := by
      apply decide_eq_true
      intro s hs
      exact valid.2 _ (Finset.mem_insert_self t h) _ (lift hs) (fun e => new (e ▸ hs))
    have tr := free_transport p t h good
    rw [eq] at tr
    obtain ⟨k,hk⟩ := step j (t.image p) (by rwa [Finset.card_image_of_injective _ p.injective]) tr
    exact ⟨k,compose ⟨p,by simp [rename,← eq]⟩ hk⟩

/-- A cheaply decoded finite map; inverse checks make each proposed point
renaming into a permutation before a transition can be used. -/
def digits (n : Nat) (k : Nat) (i : Fin n) : Fin n :=
  ⟨k / n^i.val % n, Nat.mod_lt _ (Nat.zero_lt_of_lt i.isLt)⟩
structure Code where
  forward : Nat
  backward : Nat

def ValidCode (n : Nat) (c : Code) := ∀ i : Fin n,
  digits n c.backward (digits n c.forward i) = i ∧ digits n c.forward (digits n c.backward i) = i
instance (n : Nat) (c : Code) : Decidable (ValidCode n c) := by unfold ValidCode; infer_instance
def permutation {n : Nat} (c : Code) (h : ValidCode n c) : Equiv.Perm (Fin n) :=
  ⟨digits n c.forward,digits n c.backward,fun i => (h i).1,fun i => (h i).2⟩

end Cover61.Skeleton
