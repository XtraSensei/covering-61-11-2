import Cover61.AffineShape

namespace Cover61.Affine

abbrev Dir := Fin 4
abbrev Loc := Fin 3
abbrev Role := Fin 28

def line (d : Dir) (l : Loc) : Photo := ⟨3*d.val+l.val, by omega⟩
def onePhoto (a : Labels) (b : Bool) : Photo := ⟨12+2*a.val+b.toNat, by cases b <;> simp <;> omega⟩
def tag (i : Photo) : Labels := ⟨((i.val-12)/2)%9,Nat.mod_lt _ (by decide)⟩

def T (d : Dir) : Role := ⟨d.val, by omega⟩
def D (d : Dir) (l : Loc) : Role := ⟨4+3*d.val+l.val, by omega⟩
def S (d : Dir) (l : Loc) : Role := ⟨16+3*d.val+l.val, by omega⟩

def dir (r : Role) : Dir :=
  if h : r.val < 4 then ⟨r.val,h⟩
  else if h : r.val < 16 then ⟨(r.val-4)/3,by omega⟩
  else ⟨(r.val-16)/3,by omega⟩

def lines (r : Role) : Finset Photo :=
  ((Finset.univ : Finset Loc).filter (fun l =>
    if r.val < 4 then True else if r.val < 16 then l.val ≠ (r.val-4)%3
    else l.val = (r.val-16)%3)).image (line (dir r))

def onLine (r : Role) (a : Labels) : Bool :=
  decide (∃ k ∈ lines r, a ∈ planeRows k)

def allowed (r : Role) (i : Photo) : Bool :=
  if i.val < 12 then decide (i ∈ lines r) else if i.val < 30 then !(onLine r (tag i)) else decide (r.val<16)

theorem geometry0 : ∀ d : Dir, ∀ i : Photo, i.val < 12 → i.val/3=d.val → i ∈ lines (T d) := by decide +kernel
theorem geometry1 : ∀ d : Dir, ((lines (T d)).powerset.erase ∅) ⊆ Finset.univ.image lines := by decide +kernel
theorem tripleSize : ∀ (d : Dir) (l : Loc), (planeRows (line d l)).card = 3 := by decide +kernel
theorem singleLineSize : ∀ r : Role, 16 ≤ r.val → (lines r).card = 1 := by decide +kernel
theorem singletonGeometry : ∀ (a : Labels) (b : Bool), planeRows (onePhoto a b) = {a} ∧
    tag (onePhoto a b) = a ∧ 12 ≤ (onePhoto a b).val ∧ (onePhoto a b).val < 30 := by decide +kernel
theorem labelSources : ∀ (a : Labels) (i : Photo), a ∈ planeRows i →
    i.val < 12 ∨ i = onePhoto a false ∨ i = onePhoto a true := by decide +kernel
theorem tagOn : ∀ i : Photo, 12 ≤ i.val → i.val < 30 → tag i ∈ planeRows i := by decide +kernel
theorem lineSource : ∀ (r : Role) (i : Photo), i ∈ lines r → i.val < 12 := by decide +kernel
theorem uniquePhoto : ∀ a b c d, onePhoto a b = onePhoto c d → a = c ∧ b = d := by decide +kernel

theorem chooseRole (U : Finset Photo) (size : U.card=7)
    (fits : Weighted.Fits planeRows U Finset.univ) : ∃ r, triples U = lines r := by
  obtain ⟨pos,_,_,_,dd,hd,subset⟩ := shape U size fits
  let d : Dir := ⟨dd,hd⟩
  have sub : triples U ⊆ lines (T d) := fun i hi =>
    geometry0 d i (Finset.mem_filter.mp hi).2 (subset i hi)
  have ne : triples U ≠ ∅ := Finset.nonempty_iff_ne_empty.mp (Finset.card_pos.mp pos)
  have hmem := geometry1 d (Finset.mem_erase.mpr ⟨ne,Finset.mem_powerset.mpr sub⟩)
  obtain ⟨r,_,eq⟩ := Finset.mem_image.mp hmem
  exact ⟨r,eq.symm⟩

theorem onLine_iff (r : Role) (a : Labels) : onLine r a = true ↔ ∃ i ∈ lines r, a ∈ planeRows i := by
  simp [onLine]

/-- A participant in the affine plane, with the actual set of all attended blocks. -/
structure Profile where
  U : Finset Photo
  r : Role
  count : U.card = 7
  fits : Weighted.Fits planeRows U Finset.univ
  role : triples U = lines r

namespace Profile

theorem meetLabel (p : Profile) (a : Labels) : (p.U.filter (fun i => a ∈ planeRows i)).card=1 := by
  simpa using p.fits a

theorem lineMem (p : Profile) {i : Photo} (hi : i.val < 12) : i ∈ p.U ↔ i ∈ lines p.r := by
  rw [← p.role]
  simp [triples, hi]

theorem uniq (p : Profile) (a : Labels) {i j : Photo} (hi : i ∈ p.U) (hj : j ∈ p.U)
    (ai : a ∈ planeRows i) (aj : a ∈ planeRows j) : i=j := by
  by_contra ne
  have sub : ({i,j} : Finset Photo) ⊆ p.U.filter (fun k => a ∈ planeRows k) := by
    intro k hk
    simp only [Finset.mem_insert,Finset.mem_singleton] at hk
    rcases hk with rfl | rfl <;> simp [*]
  have le := Finset.card_le_card sub
  simp [ne,meetLabel] at le

theorem support (p : Profile) {i : Photo} (hi : i ∈ p.U) : allowed p.r i = true := by
  unfold allowed
  split
  next hl => simpa using (p.lineMem hl).mp hi
  next hnl =>
    split
    next hs =>
      suffices onLine p.r (tag i) ≠ true by simpa using this
      intro hon
      obtain ⟨j,hj,ha⟩ := (onLine_iff _ _).mp hon
      have lt := lineSource _ _ hj
      have eq := p.uniq (tag i) hi ((p.lineMem lt).mpr hj) (tagOn i (by omega) hs) ha
      exact hnl (eq.symm ▸ lt)
    next hns =>
      apply decide_eq_true
      by_contra! hr
      have sz := singleLineSize _ hr
      have sh := (shape p.U p.count p.fits).2.2.2.1
      rw [p.role,sz] at sh
      have mem : i ∈ blanks p.U := Finset.mem_filter.mpr ⟨hi,by omega⟩
      have pos := Finset.card_pos.mpr (show (blanks p.U).Nonempty from ⟨i,mem⟩)
      omega

def bit (p : Profile) (a : Labels) : Bool := decide (onePhoto a true ∈ p.U)

theorem bitMem (p : Profile) (a : Labels) (off : onLine p.r a = false) (b : Bool) :
    onePhoto a b ∈ p.U ↔ p.bit a = b := by
  classical
  obtain ⟨i,hi⟩ := Finset.card_pos.mp (show 0 < (p.U.filter (fun i => a ∈ planeRows i)).card by rw [p.meetLabel]; decide)
  obtain ⟨hi,ha⟩ := Finset.mem_filter.mp hi
  have either : i=onePhoto a false ∨ i=onePhoto a true := by
    rcases labelSources a i ha with hl | hl | hl
    · have bad := (onLine_iff _ _).mpr ⟨i,(p.lineMem hl).mp hi,ha⟩
      rw [off] at bad
      contradiction
    · exact Or.inl hl
    · exact Or.inr hl
  have noBoth (hm : onePhoto a false ∈ p.U) (hn : onePhoto a true ∈ p.U) : False := by
    have label (v : Bool) : a ∈ planeRows (onePhoto a v) := by rw [(singletonGeometry a v).1]; simp
    have eq := p.uniq a hm hn (label false) (label true)
    exact Bool.noConfusion (uniquePhoto _ _ _ _ eq).2
  cases b with
  | true => simp [bit]
  | false =>
    simp only [bit,decide_eq_false_iff_not]
    constructor
    · exact noBoth
    · intro hn
      rcases either with he | he <;> subst i
      · exact hi
      · contradiction

end Profile
end Cover61.Affine
