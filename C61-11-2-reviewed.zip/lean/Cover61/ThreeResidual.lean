import Cover61.FivePeople

namespace Cover61.LocalRows

def residual (B : Family 38) (i : Photo) := Finset.univ \ (groups B i ∪ cells B i)

theorem group_sizes_sum (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    ∑ j ∈ groups B i,(marked B j).card=(lows B).card := by
  have sum := block_sum B (groups B i) (lows B)
  rw [Finset.sum_congr rfl (g := fun _ => 1) (five_group_cover B h i five).2.1] at sum
  simpa [marked] using sum

theorem no_companion_cell (B : Family 38) (h : IsCover B) (i : Photo) (j : Photo) (jc : j ∈ cells B i) :
    Disjoint (companions B i) (B j) := by
  apply Finset.disjoint_left.mpr
  intro x xh xj
  obtain ⟨y,ym,one,_⟩ := single_intersection B h _ (marked_sub B i) (marked_six B i) jc
  have both := Finset.mem_inter.mpr ⟨(Finset.mem_sdiff.mp xh).1,xj⟩
  have eq : x=y := Finset.mem_singleton.mp (one ▸ both)
  exact (Finset.mem_sdiff.mp xh).2 (eq ▸ (Finset.mem_inter.mp ym).1)

theorem ordinary_residual_visits (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (x : Point) (hx : x ∈ ordinary B i) :
    (appearances B (residual B i) x).card+5=degree B x := by
  have all : appearances B (residual B i) x ∪ line B i x=appearances B Finset.univ x := by
    ext j
    by_cases xj : x ∈ B j
    · have no : j ∉ groups B i := fun g => ordinary_away B i hx g xj
      by_cases cj : j ∈ cells B i <;> simp [appearances,residual,line,xj,cj,no]
    · simp [appearances,line,xj]
  have dis : Disjoint (appearances B (residual B i) x) (line B i x) := Finset.disjoint_left.mpr (fun j jr jc =>
    (Finset.mem_sdiff.mp (Finset.mem_filter.mp jr).1).2 (Finset.mem_union_right _ (Finset.mem_filter.mp jc).1))
  have eq := congrArg Finset.card all
  rw [Finset.card_union_of_disjoint dis,outside_line_count B h i five x (ordinary_away B i hx (five_group_cover B h i five).1)] at eq
  exact eq

theorem ordinary_seven (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (eq : (∑ x,(degree B x-7))=excess B (companions B i)) (x : Point) (xo : x ∈ ordinary B i) : degree B x=7 := by
  have xi := ordinary_away B i xo (five_group_cover B h i five).1
  have xh : x ∉ companions B i := fun m => xi (Finset.mem_sdiff.mp m).1
  have nn := Finset.sum_le_univ_sum_of_nonneg (s := insert x (companions B i)) (f := fun z => degree B z-7) (fun _ => Nat.zero_le _)
  rw [Finset.sum_insert xh,eq] at nn
  change degree B x-7+excess B (companions B i)≤_ at nn
  have lo := degree_ge_six B h x
  have notLow := fun (m : x ∈ lows B) => (Finset.mem_sdiff.mp xo).2 (low_in_groups B h i five m)
  have six : degree B x≠6 := fun r => notLow (Finset.mem_filter.mpr ⟨Finset.mem_univ _,r⟩)
  omega

theorem group_three_sizes (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (three : (groups B i).card=3) :
    (ordinary B i).card=40 ∧ (residual B i).card=10 ∧
    (∑ j ∈ residual B i,amount B i j)=30 ∧ ∀ j ∈ residual B i,amount B i j=3 := by
  obtain ⟨f,a,d⟩|⟨f,_⟩|⟨f,_⟩ := group_count_cases B h i five <;> try omega
  let H := companions B i
  let O := ordinary B i
  let G := groups B i
  let C := cells B i
  let K := residual B i
  have count := companion_card B h i
  have hc : H.card=6 := by change (companions B i).card=6;omega
  have noextra := exception_bound B h i five
  have em : exceptional B i=∅ := Finset.card_eq_zero.mp (by omega)
  have unionAll : groupPeople B i=H ∪ lows B := by
    apply Finset.Subset.antisymm
    · intro x xg
      by_contra outside
      have mem : x ∈ exceptional B i := Finset.mem_sdiff.mpr ⟨xg,outside⟩
      simpa [em] using mem
    · exact Finset.union_subset (Finset.sdiff_subset.trans (pivot_in_groups B h i five)) (low_in_groups B h i five)
  have disHL : Disjoint H (lows B) := Finset.disjoint_left.mpr (fun _ xh xl => (Finset.mem_sdiff.mp xh).2 xl)
  have oc : O.card=40 := by
    rw [show O=Finset.univ \ groupPeople B i from rfl,Finset.card_sdiff_of_subset (Finset.subset_univ _),unionAll,
      Finset.card_union_of_disjoint disHL,hc,a];decide
  have kc : K.card=10 := by
    rw [show K=Finset.univ \ (G ∪ C) from rfl,Finset.card_sdiff_of_subset (Finset.subset_univ _),
      Finset.card_union_of_disjoint (cells_groups_disjoint B h i five).symm,three,cells_count B h i five];decide
  have groupRows (x : Point) (xh : x ∈ H) : appearances B K x ∪ G=appearances B Finset.univ x := by
    ext j
    by_cases g : j ∈ G
    · have xj := (Finset.mem_filter.mp g).2.1 xh
      simp [g,xj,appearances]
    · by_cases c : j ∈ C
      · have notHere : x ∉ B j := fun xj => Finset.disjoint_left.mp (no_companion_cell B h i j c) xh xj
        simp [g,appearances,notHere]
      · simp [K,residual,appearances,g,c,G,C] at *
  have visits (x : Point) (xh : x ∈ H) : (appearances B K x).card=4+(degree B x-7) := by
    have rel := congrArg Finset.card (groupRows x xh)
    have dis : Disjoint (appearances B K x) G := Finset.disjoint_left.mpr (fun j jx jg =>
      (Finset.mem_sdiff.mp (Finset.mem_filter.mp jx).1).2 (Finset.mem_union_left _ jg))
    rw [Finset.card_union_of_disjoint dis,three] at rel
    change _+3=degree B x at rel
    have := degree_companion B h i x xh
    omega
  have seats := block_sum B K H
  rw [Finset.sum_congr rfl visits,Finset.sum_add_distrib] at seats
  simp only [Finset.sum_const,Nat.nsmul_eq_mul,hc] at seats
  change (∑ j ∈ K,amount B i j)=6*4+excess B (companions B i) at seats
  rw [d] at seats
  have meet (x : Point) (xh : x ∈ H) (y : Point) (yo : y ∈ O) : ∃ j ∈ K, x ∈ B j ∧ y ∈ B j := by
    have ne : x≠y := fun eq => ordinary_away B i yo (five_group_cover B h i five).1 (eq ▸ (Finset.mem_sdiff.mp xh).1)
    obtain ⟨j,xj,yj⟩ := h.2 x y ne
    have ng : j ∉ G := fun jg => ordinary_away B i yo jg yj
    have nc : j ∉ C := fun jc => Finset.disjoint_left.mp (no_companion_cell B h i j jc) xh xj
    exact ⟨j,Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,fun m => (Finset.mem_union.mp m).elim ng nc⟩,xj,yj⟩
  have person (y : Point) (yo : y ∈ O) : 6≤∑ j ∈ appearances B K y,amount B i j := by
    have inc : H ⊆ (appearances B K y).biUnion (fun j => H ∩ B j) := by
      intro x xh;obtain ⟨j,jk,xj,yj⟩ := meet x xh y yo
      exact Finset.mem_biUnion.mpr ⟨j,Finset.mem_filter.mpr ⟨jk,yj⟩,Finset.mem_inter.mpr ⟨xh,xj⟩⟩
    exact hc ▸ (Finset.card_le_card inc).trans Finset.card_biUnion_le
  have cross := Finset.sum_le_sum person
  rw [weighted_visits,Finset.sum_const,Nat.nsmul_eq_mul,oc] at cross
  have cap (j : Photo) : (O ∩ B j).card≤11-amount B i j := by
    have dis : Disjoint (O ∩ B j) (H ∩ B j) := Finset.disjoint_left.mpr (fun x xo xh =>
      ordinary_away B i (Finset.mem_inter.mp xo).1 (five_group_cover B h i five).1 (Finset.mem_sdiff.mp (Finset.mem_inter.mp xh).1).1)
    have le := Finset.card_le_card (show (O ∩ B j) ∪ (H ∩ B j) ⊆ B j from Finset.union_subset Finset.inter_subset_right Finset.inter_subset_right)
    rw [Finset.card_union_of_disjoint dis,h.1] at le
    change _+amount B i j≤11 at le;omega
  have lo := cross.trans (Finset.sum_le_sum (s := K) (fun j _ => Nat.mul_le_mul_right (amount B i j) (cap j)))
  have tariff (k : Fin 7) : (11-k.val)*k.val+(if k.val=3 then 0 else 1) ≤ 5*k.val+9 := by decide +revert
  have row (j : Photo) (_ : j ∈ K) : (11-amount B i j)*amount B i j+(if amount B i j=3 then 0 else 1) ≤ 5*amount B i j+9 :=
    tariff ⟨_,Nat.lt_succ_of_le ((Finset.card_le_card Finset.inter_subset_left).trans_eq hc)⟩
  have price := Finset.sum_le_sum row
  simp only [Finset.sum_add_distrib,←Finset.mul_sum,Finset.sum_const,Nat.nsmul_eq_mul,kc,seats] at price
  refine ⟨oc,kc,seats,?_⟩
  intro j hj;by_contra ne
  have single := Finset.single_le_sum (s := K) (f := fun j => if amount B i j=3 then 0 else 1)
    (fun _ _ => Nat.zero_le _) hj
  simp [ne] at single
  omega

end Cover61.LocalRows
