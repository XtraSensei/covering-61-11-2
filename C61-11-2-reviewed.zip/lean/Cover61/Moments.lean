import Cover61.Frequencies

namespace Cover61

def lowCount (B : Family 38) (i : Fin 38) := (lows B ∩ B i).card

theorem low_seat_identity (B : Family 38) : ∑ i, lowCount B i = (lows B).card * 6 := by
  calc
    _ = ∑ i, ∑ x ∈ lows B, if x ∈ B i then 1 else 0 := by simp [lowCount]
    _ = ∑ x ∈ lows B, ∑ i, if x ∈ B i then 1 else 0 := Finset.sum_comm
    _ = ∑ _x ∈ lows B, 6 := by
      apply Finset.sum_congr rfl
      intro x hx
      simpa [degree] using (Finset.mem_filter.mp hx).2
    _ = _ := by simp

theorem low_second_moment (B : Family 38) (h : IsCover B) :
    ∑ i, lowCount B i * lowCount B i = (lows B).card * ((lows B).card + 5) := by
  rw [show (∑ i, lowCount B i * lowCount B i) = ∑ x ∈ lows B, ∑ y ∈ lows B, partners B x y
    from (cross_sum B (lows B) (lows B)).symm]
  have line (x : Point) (hx : x ∈ lows B) : ∑ y ∈ lows B, partners B x y = (lows B).card+5 := by
    have hd : degree B x = 6 := (Finset.mem_filter.mp hx).2
    have diag : partners B x x = 6 := by simpa [partners,degree] using hd
    have off : ∑ y ∈ (lows B).erase x, partners B x y = ((lows B).erase x).card := by
      rw [Finset.sum_congr rfl (g := fun _ => 1) (fun y hy =>
        six_meets_once B h x y hd (Finset.mem_erase.mp hy).1.symm)]
      simp
    have eq := Finset.sum_erase_add (lows B) (partners B x) hx
    rw [off,diag,Finset.card_erase_of_mem hx] at eq
    have pos := Finset.card_pos.mpr (show (lows B).Nonempty from ⟨x,hx⟩)
    omega
  rw [Finset.sum_congr rfl line]
  simp

/-- A bound on the number of full low-point rows from the first two moments. -/
theorem full_rows_needed (B : Family 38) (h : IsCover B) (k : Nat)
    (bound : ∀ i, lowCount B i ≤ k+1) :
    (lows B).card * ((lows B).card + 5) ≤
    k*((lows B).card*6) + (k+1)*(Finset.univ.filter (fun i => lowCount B i = k+1)).card := by
  have each (i : Fin 38) :
      lowCount B i * lowCount B i ≤ k * lowCount B i +
        (k+1) * (if lowCount B i = k+1 then 1 else 0) := by
    by_cases hh : lowCount B i = k+1
    · simp [hh,Nat.add_mul]
    · have hi := bound i
      have hk : lowCount B i ≤ k := by omega
      simpa [hh] using Nat.mul_le_mul_right (lowCount B i) hk
  have allRows := Finset.sum_le_sum (s := Finset.univ) (fun i _ => each i)
  simpa only [low_second_moment B h,Finset.sum_add_distrib,← Finset.mul_sum,
    low_seat_identity,Finset.sum_boole,Nat.cast_id] using allRows

/-- Two other people cannot both share all seven appearances of one person. -/
theorem seven_has_no_two_twins (B : Family 38) (h : IsCover B) (x y z : Point)
    (r : degree B x = 7) (xy : x ≠ y) (xz : x ≠ z) (yz : y ≠ z)
    (py : 7 ≤ partners B x y) (pz : 7 ≤ partners B x z) : False := by
  let V := (Finset.univ : Finset Point).erase x
  have my : y ∈ V := Finset.mem_erase.mpr ⟨xy.symm,Finset.mem_univ _⟩
  have mz : z ∈ V.erase y := Finset.mem_erase.mpr ⟨yz.symm,Finset.mem_erase.mpr ⟨xz.symm,Finset.mem_univ _⟩⟩
  have e1 := Finset.sum_erase_add V (partners B x) my
  have e2 := Finset.sum_erase_add (V.erase y) (partners B x) mz
  have total : ∑ v ∈ V, partners B x v = 70 := by rw [partnerSum B h, r]
  have low := Finset.sum_le_sum (s := (V.erase y).erase z) (f := fun _ => 1) (g := partners B x)
    (fun v hv => partners_pos B h x v (Finset.mem_erase.mp
      (Finset.mem_erase.mp (Finset.mem_erase.mp hv).2).2).1.symm)
  have cv : V.card = 60 := by simp [V]
  simp only [Finset.sum_const,Nat.nsmul_eq_mul,Nat.mul_one,
    Finset.card_erase_of_mem mz,Finset.card_erase_of_mem my,cv] at low
  omega

end Cover61
