import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes10_1_48 : List (Branch 9 152) := [
  ⟨{{0}, {1}, {2}, {3,6,7}, {4}, {5,8}},142,⟨4690173852,7248193056⟩⟩,
  ⟨{{0}, {1}, {2}, {3,6,7}, {4,5}, {8}},142,⟨4739610852,6285197043⟩⟩,
  ⟨{{0}, {1}, {2}, {3,6,7}, {4,8}, {5}},142,⟨4693710582,7158296043⟩⟩,
  ⟨{{0}, {1}, {2,4,6}, {3}, {5,8}, {7}},148,⟨6839457012,6839457012⟩⟩,
  ⟨{{0}, {1}, {2,5,7}, {3}, {4,8}, {6}},148,⟨6893547021,7839546102⟩⟩,
  ⟨{{0}, {1}, {2,3,8}, {4,5}, {6}, {7}},148,⟨6573849012,3579846012⟩⟩,
  ⟨{{0}, {1,3,5}, {2}, {4,8}, {6}, {7}},148,⟨6837549102,3869547021⟩⟩,
  ⟨{{0}, {1,4,7}, {2}, {3}, {5,8}, {6}},148,⟨6897453201,7869453201⟩⟩,
  ⟨{{0}, {1,6,8}, {2}, {3}, {4,5}, {7}},148,⟨6539847201,6539847201⟩⟩,
  ⟨{{0,1,2}, {3}, {4}, {5,8}, {6}, {7}},142,⟨4652178390,1348792650⟩⟩,
  ⟨{{0,1,2}, {3}, {4,5}, {6}, {7}, {8}},142,⟨4785612390,1785692340⟩⟩,
  ⟨{{0,1,2}, {3}, {4,8}, {5}, {6}, {7}},142,⟨4658712930,2658791340⟩⟩,
  ⟨{{0,3,4}, {1}, {2}, {5,8}, {6}, {7}},148,⟨6873459120,3879456120⟩⟩,
  ⟨{{0,5,6}, {1}, {2}, {3}, {4,8}, {7}},148,⟨6879543210,6879543210⟩⟩,
  ⟨{{0,7,8}, {1}, {2}, {3}, {4,5}, {6}},148,⟨6597843120,7569843120⟩⟩
]

theorem checked10_1_48 : ∃ cert, Checked (rows9_0 48) rows10_1 1 cert :=
  ⟨routes10_1_48, by decide +kernel⟩

private def routes10_1_49 : List (Branch 9 152) := [
  
]

theorem checked10_1_49 : ∃ cert, Checked (rows9_0 49) rows10_1 1 cert :=
  ⟨routes10_1_49, by decide +kernel⟩

theorem balanced10_1_48 : Balanced (rows10_1 48) := by decide +kernel

theorem balanced10_1_49 : Balanced (rows10_1 49) := by decide +kernel

theorem balanced10_1_50 : Balanced (rows10_1 50) := by decide +kernel

theorem balanced10_1_51 : Balanced (rows10_1 51) := by decide +kernel

theorem balanced10_1_52 : Balanced (rows10_1 52) := by decide +kernel

theorem balanced10_1_53 : Balanced (rows10_1 53) := by decide +kernel

theorem balanced10_1_54 : Balanced (rows10_1 54) := by decide +kernel

theorem balanced10_1_55 : Balanced (rows10_1 55) := by decide +kernel

theorem balanced10_1_56 : Balanced (rows10_1 56) := by decide +kernel

theorem balanced10_1_57 : Balanced (rows10_1 57) := by decide +kernel

theorem balanced10_1_58 : Balanced (rows10_1 58) := by decide +kernel

theorem balanced10_1_59 : Balanced (rows10_1 59) := by decide +kernel

end Cover61.Layers
