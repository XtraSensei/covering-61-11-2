import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes11_0_0 : List (Branch 10 36) := [
  ⟨{{0,1}, {2}, {3}, {4,5}, {6,7}, {8,9}},0,⟨15413829345,173102303945⟩⟩,
  ⟨{{0,2}, {1}, {3}, {4,5}, {6,7}, {8,9}},0,⟨77356416115,251766070215⟩⟩,
  ⟨{{0,3}, {1}, {2}, {4,5}, {6,7}, {8,9}},0,⟨25678050345,253927386745⟩⟩
]

theorem checked11_0_0 : ∃ cert, Checked (rows10_0 0) rows11_0 0 cert :=
  ⟨routes11_0_0, by decide +kernel⟩

private def routes11_0_1 : List (Branch 10 36) := [
  ⟨{{0,1}, {2}, {3}, {4,5}, {6,7}, {8,9}},1,⟨73028829005,221362847805⟩⟩,
  ⟨{{0,2}, {1}, {3}, {4,5}, {6,7}, {8,9}},1,⟨77356416115,251766070215⟩⟩,
  ⟨{{0,3}, {1}, {2}, {4,5}, {6,7}, {8,9}},1,⟨65299407415,119138974515⟩⟩
]

theorem checked11_0_1 : ∃ cert, Checked (rows10_0 1) rows11_0 0 cert :=
  ⟨routes11_0_1, by decide +kernel⟩

private def routes11_0_2 : List (Branch 10 36) := [
  
]

theorem checked11_0_2 : ∃ cert, Checked (rows10_0 2) rows11_0 0 cert :=
  ⟨routes11_0_2, by decide +kernel⟩

private def routes11_0_3 : List (Branch 10 36) := [
  
]

theorem checked11_0_3 : ∃ cert, Checked (rows10_0 3) rows11_0 0 cert :=
  ⟨routes11_0_3, by decide +kernel⟩

private def routes11_0_4 : List (Branch 10 36) := [
  
]

theorem checked11_0_4 : ∃ cert, Checked (rows10_0 4) rows11_0 0 cert :=
  ⟨routes11_0_4, by decide +kernel⟩

private def routes11_0_5 : List (Branch 10 36) := [
  
]

theorem checked11_0_5 : ∃ cert, Checked (rows10_0 5) rows11_0 0 cert :=
  ⟨routes11_0_5, by decide +kernel⟩

private def routes11_0_6 : List (Branch 10 36) := [
  
]

theorem checked11_0_6 : ∃ cert, Checked (rows10_0 6) rows11_0 0 cert :=
  ⟨routes11_0_6, by decide +kernel⟩

private def routes11_0_7 : List (Branch 10 36) := [
  ⟨{{0,4}, {1,5}, {2,7}, {3,9}, {6}, {8}},9,⟨123828543575,141189539975⟩⟩,
  ⟨{{0,4}, {1,5}, {2,8}, {3,9}, {6}, {7}},12,⟨51236873715,247022968815⟩⟩,
  ⟨{{0,4}, {1,6}, {2,7}, {3,9}, {5}, {8}},9,⟨71107537045,167122484245⟩⟩,
  ⟨{{0,4}, {1,6}, {2,8}, {3,9}, {5}, {7}},8,⟨72276767305,167141971405⟩⟩
]

theorem checked11_0_7 : ∃ cert, Checked (rows10_0 7) rows11_0 0 cert :=
  ⟨routes11_0_7, by decide +kernel⟩

private def routes11_0_8 : List (Branch 10 36) := [
  ⟨{{0,4}, {1,5}, {2,7}, {3,9}, {6}, {8}},11,⟨123867488635,148204921535⟩⟩,
  ⟨{{0,4}, {1,5}, {2,8}, {3,9}, {6}, {7}},6,⟨48879087075,152705061175⟩⟩,
  ⟨{{0,4}, {1,6}, {2,7}, {3,9}, {5}, {8}},11,⟨71146482105,174137865805⟩⟩,
  ⟨{{0,4}, {1,6}, {2,8}, {3,9}, {5}, {7}},10,⟨44425588695,124077076095⟩⟩
]

theorem checked11_0_8 : ∃ cert, Checked (rows10_0 8) rows11_0 0 cert :=
  ⟨routes11_0_8, by decide +kernel⟩

private def routes11_0_9 : List (Branch 10 36) := [
  ⟨{{0,4}, {1,5}, {2,7}, {3,9}, {6}, {8}},9,⟨178056012225,151921531625⟩⟩,
  ⟨{{0,4}, {1,5}, {2,8}, {3,9}, {6}, {7}},12,⟨124182707595,117627457995⟩⟩,
  ⟨{{0,4}, {1,6}, {2,7}, {3,9}, {5}, {8}},9,⟨43065000565,173165259965⟩⟩,
  ⟨{{0,4}, {1,6}, {2,8}, {3,9}, {5}, {7}},7,⟨178458346905,126432150905⟩⟩
]

theorem checked11_0_9 : ∃ cert, Checked (rows10_0 9) rows11_0 0 cert :=
  ⟨routes11_0_9, by decide +kernel⟩

private def routes11_0_10 : List (Branch 10 36) := [
  ⟨{{0,4}, {1,5}, {2,8}, {3,9}, {6}, {7}},4,⟨126575926545,126201972745⟩⟩,
  ⟨{{0,4}, {1,6}, {2,8}, {3,9}, {5}, {7}},4,⟨179101859785,230103892285⟩⟩,
  ⟨{{0,4}, {1,7}, {2,8}, {3,9}, {5}, {6}},4,⟨129423748905,253881755105⟩⟩
]

theorem checked11_0_10 : ∃ cert, Checked (rows10_0 10) rows11_0 0 cert :=
  ⟨routes11_0_10, by decide +kernel⟩

private def routes11_0_11 : List (Branch 10 36) := [
  ⟨{{0,3}, {1,5}, {2,7}, {4}, {6}, {8,9}},10,⟨174255647735,201691095535⟩⟩,
  ⟨{{0,3}, {1,6}, {2,7}, {4}, {5}, {8,9}},6,⟨100903181285,178700973685⟩⟩,
  ⟨{{0,4}, {1,3}, {2,7}, {5}, {6}, {8,9}},4,⟨103488254365,253889740965⟩⟩,
  ⟨{{0,4}, {1,5}, {2,3}, {6}, {7}, {8,9}},8,⟨100617535255,151922423755⟩⟩,
  ⟨{{0,4}, {1,6}, {2,3}, {5}, {7}, {8,9}},10,⟨77029530495,248603194995⟩⟩
]

theorem checked11_0_11 : ∃ cert, Checked (rows10_0 11) rows11_0 0 cert :=
  ⟨routes11_0_11, by decide +kernel⟩

theorem balanced11_0_0 : Balanced (rows11_0 0) := by decide +kernel

theorem balanced11_0_1 : Balanced (rows11_0 1) := by decide +kernel

theorem balanced11_0_2 : Balanced (rows11_0 2) := by decide +kernel

theorem balanced11_0_3 : Balanced (rows11_0 3) := by decide +kernel

theorem balanced11_0_4 : Balanced (rows11_0 4) := by decide +kernel

theorem balanced11_0_5 : Balanced (rows11_0 5) := by decide +kernel

theorem balanced11_0_6 : Balanced (rows11_0 6) := by decide +kernel

theorem balanced11_0_7 : Balanced (rows11_0 7) := by decide +kernel

theorem balanced11_0_8 : Balanced (rows11_0 8) := by decide +kernel

theorem balanced11_0_9 : Balanced (rows11_0 9) := by decide +kernel

theorem balanced11_0_10 : Balanced (rows11_0 10) := by decide +kernel

theorem balanced11_0_11 : Balanced (rows11_0 11) := by decide +kernel

end Cover61.Layers
