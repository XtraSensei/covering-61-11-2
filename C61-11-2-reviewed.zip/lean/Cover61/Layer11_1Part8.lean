import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced11_1_96 : Balanced (rows11_1 96) := by decide +kernel

theorem balanced11_1_97 : Balanced (rows11_1 97) := by decide +kernel

theorem balanced11_1_98 : Balanced (rows11_1 98) := by decide +kernel

theorem balanced11_1_99 : Balanced (rows11_1 99) := by decide +kernel

theorem balanced11_1_100 : Balanced (rows11_1 100) := by decide +kernel

theorem balanced11_1_101 : Balanced (rows11_1 101) := by decide +kernel

theorem balanced11_1_102 : Balanced (rows11_1 102) := by decide +kernel

theorem balanced11_1_103 : Balanced (rows11_1 103) := by decide +kernel

theorem balanced11_1_104 : Balanced (rows11_1 104) := by decide +kernel

theorem balanced11_1_105 : Balanced (rows11_1 105) := by decide +kernel

theorem balanced11_1_106 : Balanced (rows11_1 106) := by decide +kernel

theorem balanced11_1_107 : Balanced (rows11_1 107) := by decide +kernel

end Cover61.Layers
