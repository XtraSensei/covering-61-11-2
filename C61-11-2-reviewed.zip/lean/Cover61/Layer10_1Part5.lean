import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced10_1_60 : Balanced (rows10_1 60) := by decide +kernel

theorem balanced10_1_61 : Balanced (rows10_1 61) := by decide +kernel

theorem balanced10_1_62 : Balanced (rows10_1 62) := by decide +kernel

theorem balanced10_1_63 : Balanced (rows10_1 63) := by decide +kernel

theorem balanced10_1_64 : Balanced (rows10_1 64) := by decide +kernel

theorem balanced10_1_65 : Balanced (rows10_1 65) := by decide +kernel

theorem balanced10_1_66 : Balanced (rows10_1 66) := by decide +kernel

theorem balanced10_1_67 : Balanced (rows10_1 67) := by decide +kernel

theorem balanced10_1_68 : Balanced (rows10_1 68) := by decide +kernel

theorem balanced10_1_69 : Balanced (rows10_1 69) := by decide +kernel

theorem balanced10_1_70 : Balanced (rows10_1 70) := by decide +kernel

theorem balanced10_1_71 : Balanced (rows10_1 71) := by decide +kernel

end Cover61.Layers
