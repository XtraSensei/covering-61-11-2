import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_2_84 : List (Branch 11 23) := [
  
]

theorem checked12_2_84 : ∃ cert, Checked (rows11_1 84) rows12_2 2 cert :=
  ⟨routes12_2_84, by decide +kernel⟩

private def routes12_2_85 : List (Branch 11 23) := [
  
]

theorem checked12_2_85 : ∃ cert, Checked (rows11_1 85) rows12_2 2 cert :=
  ⟨routes12_2_85, by decide +kernel⟩

private def routes12_2_86 : List (Branch 11 23) := [
  ⟨{{0,5,6}, {1,3}, {2,7}, {4}, {8}, {9,10}},15,⟨4516398138065,6819291860590⟩⟩
]

theorem checked12_2_86 : ∃ cert, Checked (rows11_1 86) rows12_2 2 cert :=
  ⟨routes12_2_86, by decide +kernel⟩

private def routes12_2_87 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,6}, {3,5,9}, {4}, {7,10}, {8}},15,⟨1127326367948,1027043182935⟩⟩,
  ⟨{{0,7,9}, {1,6}, {2,3}, {4}, {5,10}, {8}},12,⟨316561311759,2484227875943⟩⟩
]

theorem checked12_2_87 : ∃ cert, Checked (rows11_1 87) rows12_2 2 cert :=
  ⟨routes12_2_87, by decide +kernel⟩

private def routes12_2_88 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,4,8}, {6}, {7}, {9,10}},15,⟨429852099281,6819288874607⟩⟩,
  ⟨{{0,2}, {1,6}, {3,4,8}, {5}, {7}, {9,10}},15,⟨361923206370,2051660260331⟩⟩
]

theorem checked12_2_88 : ∃ cert, Checked (rows11_1 88) rows12_2 2 cert :=
  ⟨routes12_2_88, by decide +kernel⟩

private def routes12_2_89 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,4,5}, {7}, {8,10}, {9}},10,⟨3162155952626,4969490306781⟩⟩
]

theorem checked12_2_89 : ∃ cert, Checked (rows11_1 89) rows12_2 2 cert :=
  ⟨routes12_2_89, by decide +kernel⟩

private def routes12_2_90 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,5}, {2,6,8}, {4,10}, {7}, {9}},9,⟨3913753089708,3969402711780⟩⟩,
  ⟨{{0,4}, {1,3}, {2,6,8}, {5,10}, {7}, {9}},12,⟨3722016344079,2484228124774⟩⟩
]

theorem checked12_2_90 : ∃ cert, Checked (rows11_1 90) rows12_2 2 cert :=
  ⟨routes12_2_90, by decide +kernel⟩

private def routes12_2_91 : List (Branch 11 23) := [
  
]

theorem checked12_2_91 : ∃ cert, Checked (rows11_1 91) rows12_2 2 cert :=
  ⟨routes12_2_91, by decide +kernel⟩

private def routes12_2_92 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,5,8}, {4,10}, {7}, {9}},8,⟨3913764003776,4540812553959⟩⟩,
  ⟨{{0,4}, {1,3}, {2,5,8}, {6,10}, {7}, {9}},11,⟨3913758073258,3003627990759⟩⟩
]

theorem checked12_2_92 : ∃ cert, Checked (rows11_1 92) rows12_2 2 cert :=
  ⟨routes12_2_92, by decide +kernel⟩

private def routes12_2_93 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,7,9}, {4}, {6,10}, {8}},11,⟨2551576060330,3003627743655⟩⟩,
  ⟨{{0,6,9}, {1,5}, {2,3}, {4}, {7,10}, {8}},13,⟨1127315433156,1028297297940⟩⟩
]

theorem checked12_2_93 : ∃ cert, Checked (rows11_1 93) rows12_2 2 cert :=
  ⟨routes12_2_93, by decide +kernel⟩

private def routes12_2_94 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,4,9}, {2,6}, {5}, {7}, {8,10}},19,⟨2480371600641,2356537057545⟩⟩,
  ⟨{{0,4}, {1,5}, {2,3,8}, {6}, {7}, {9,10}},17,⟨1775163446782,767716356572⟩⟩
]

theorem checked12_2_94 : ∃ cert, Checked (rows11_1 94) rows12_2 2 cert :=
  ⟨routes12_2_94, by decide +kernel⟩

private def routes12_2_95 : List (Branch 11 23) := [
  
]

theorem checked12_2_95 : ∃ cert, Checked (rows11_1 95) rows12_2 2 cert :=
  ⟨routes12_2_95, by decide +kernel⟩

end Cover61.Layers
