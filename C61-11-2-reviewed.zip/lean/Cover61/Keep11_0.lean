import Cover61.CatalogueBridge
import Cover61.Catalog
import Cover61.Weights
import Cover61.NineCover
import Cover61.LayerData
namespace Cover61.Remainder
set_option maxRecDepth 60000
set_option maxHeartbeats 4000000
def live11_0 : Finset (Fin 36) := {5,22}
theorem keep11_0 (B : Family 38) (h : IsCover B) (j : Fin 36)
    (real : Weighted.Realizes B (Layers.rows11_0 j)) : j ∈ live11_0 := by
  fin_cases j
  · exact False.elim (Catalog.w11_051_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w11_051_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w11_052_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w11_052_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s11_052_03_excluded B h (pointed_of_realizes real 9
      [0,1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.s11_053_01_excluded B h (pointed_of_realizes real 13
      [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_053_02_excluded B h (pointed_of_realizes real 13
      [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_053_03_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_053_04_excluded B h (pointed_of_realizes real 9
      [0,1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_053_05_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_053_06_excluded B h (pointed_of_realizes real 20
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_053_07_excluded B h (pointed_of_realizes real 10
      [0,1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_054_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_055_01_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_055_02_excluded B h (pointed_of_realizes real 3
      [0,1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_055_03_excluded B h (pointed_of_realizes real 23
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_056_01_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_056_02_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_056_03_excluded B h (pointed_of_realizes real 21
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_057_01_excluded B h (pointed_of_realizes real 5
      [0,1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_057_02_excluded B h (pointed_of_realizes real 5
      [0,1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.s11_058_01_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_02_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_03_excluded B h (pointed_of_realizes real 8
      [0,1,2,3,4,5,6,7,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_04_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_05_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_06_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_07_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_08_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_09_excluded B h (pointed_of_realizes real 9
      [0,1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_10_excluded B h (pointed_of_realizes real 12
      [0,1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_11_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_12_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s11_058_13_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
end Cover61.Remainder
