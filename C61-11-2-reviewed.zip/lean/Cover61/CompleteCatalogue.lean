import Cover61.TwelveCatalogue
import Cover61.PartI
import Cover61.Profiles

namespace Cover61

theorem cover_profiles (B : Family 38) (h : IsCover B) :
    let freq := fun s t u v w => frequency B 6=s ∧ frequency B 7=t ∧ frequency B 8=u ∧ frequency B 9=v ∧ frequency B 10=w
    freq 9 52 0 0 0 ∨ freq 10 50 1 0 0 ∨ freq 11 48 2 0 0 ∨ freq 11 49 0 1 0 ∨ freq 12 46 3 0 0 :=
  allowed_profiles B h (low_count_range B h).2

theorem cover_catalogue (B : Family 38) (h : IsCover B) :
    ((lows B).card=9 ∧ ∃ j : Fin 50,Weighted.Realizes B (Nine.candidates j)) ∨
    ((lows B).card=10 ∧ ∃ j : Fin 65,Weighted.Realizes B (Layers.rows10_0 j)) ∨
    ((lows B).card=11 ∧ ∃ j : Fin 36,Weighted.Realizes B (Layers.rows11_0 j)) ∨
    ((lows B).card=12 ∧ ((∃ j : Fin 22,Weighted.Realizes B (Layers.rows12_1 j)) ∨
      (∃ j : Fin 23,Weighted.Realizes B (Layers.rows12_2 j)) ∨
      (∃ j : Fin 19,Weighted.Realizes B (Layers.rows12_3 j)))) := by
  have range := low_count_range B h
  have possibilities : (lows B).card=9 ∨ (lows B).card=10 ∨ (lows B).card=11 ∨ (lows B).card=12 := by omega
  rcases possibilities with a|a|a|a
  · exact Or.inl ⟨a,nine_catalogue B h a⟩
  · exact Or.inr (Or.inl ⟨a,ten_catalogue B h a⟩)
  · exact Or.inr (Or.inr (Or.inl ⟨a,eleven_catalogue B h a⟩))
  · exact Or.inr (Or.inr (Or.inr ⟨a,twelve_catalogue B h a⟩))

end Cover61
