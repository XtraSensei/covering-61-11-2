import Cover61.FourRows
import Cover61.NineComplete
import Cover61.AGCatalog

namespace Cover61

/-- Enumerate all the six-fold points without adding a labelling assumption. -/
theorem label_lows (B : Family 38) {n : Nat} (count : (lows B).card=n) :
    ∃ p : Fin n ↪ Point, (∀ x, degree B (p x)=6) ∧
      ∀ i, (Partitions.lowRow B p i).map p = LocalRows.marked B i := by
  classical
  let e : (↥(lows B)) ≃ Fin n := Fintype.equivFinOfCardEq (by simpa using count)
  let p : Fin n ↪ Point := ⟨fun j => (e.symm j).val,fun _ _ eq => e.symm.injective (Subtype.ext eq)⟩
  refine ⟨p,fun x => (Finset.mem_filter.mp (e.symm x).property).2,?_⟩
  intro i
  ext y
  constructor
  · intro hy
    obtain ⟨x,hx,rfl⟩ := Finset.mem_map.mp hy
    exact Finset.mem_inter.mpr ⟨(e.symm x).property,(Finset.mem_filter.mp hx).2⟩
  · intro hy
    obtain ⟨yl,yi⟩ := Finset.mem_inter.mp hy
    let z : ↥(lows B) := ⟨y,yl⟩
    have eq : p (e z) = y := congrArg Subtype.val (e.symm_apply_apply z)
    exact Finset.mem_map.mpr ⟨e z,Finset.mem_filter.mpr ⟨Finset.mem_univ _,eq ▸ yi⟩,eq⟩

/-- Nine six-fold points force one of the fifty representatives without
assuming the maximum number of six-fold points per row. -/
theorem nine_catalogue (B : Family 38) (h : IsCover B) (count : (lows B).card=9) :
    ∃ j : Fin 50, Weighted.Realizes B (Nine.candidates j) := by
  obtain ⟨p,six,eq⟩ := label_lows B count
  apply Nine.exhaustive B h p six
  intro i
  have sz := congrArg Finset.card (eq i)
  rw [Finset.card_map] at sz
  exact sz.trans_le (LocalRows.nine_width B h count i)

theorem nine_nonaffine (B : Family 38) (h : IsCover B) (count : (lows B).card=9) :
    ∃ j : Fin 50, j ≠ 49 ∧ Weighted.Realizes B (Nine.candidates j) := by
  obtain ⟨j,hj⟩ := nine_catalogue B h count
  refine ⟨j,?_,hj⟩
  rintro rfl
  have eq : ∀ i, Nine.candidates 49 i = Catalog.s9_49Rows i := by decide +kernel
  rw [show Nine.candidates 49 = Catalog.s9_49Rows from funext eq] at hj
  exact Catalog.s9_49_excluded B h count hj

end Cover61
