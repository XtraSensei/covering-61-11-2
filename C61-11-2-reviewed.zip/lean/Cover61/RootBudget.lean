import Cover61.RepeatBudget

namespace Cover61
open LocalRows

/-- A degree-seven type taking three specified primary blocks and four of
eleven other blocks occurs at most four times. -/
theorem root_population_cap (B : Family 38) (h : IsCover B) (V : Finset Point)
    (I J : Finset (Fin 38)) (ic : I.card=3) (jc : J.card=11) (sep : Disjoint I J)
    (seven : ∀ x ∈ V, degree B x=7) (primary : ∀ i ∈ I,V ⊆ B i)
    (blanks : ∀ x ∈ V,(appearances B J x).card=4) : V.card≤4 := by
  by_contra! bad
  obtain ⟨S,sub,sz⟩ := Finset.exists_subset_card_eq (by omega : 5≤V.card)
  let w (j : Fin 38) := (S ∩ B j).card
  have per (x : Point) (xs : x ∈ S) : ∑ y ∈ S,partners B x y≤21 := by
    let E := S.erase x
    have loose := Finset.sum_le_sum_of_subset_of_nonneg (f := fun y => partners B x y-1)
      (show E ⊆ Finset.univ.erase x from Finset.erase_subset_erase _ (Finset.subset_univ _)) (fun _ _ _ => Nat.zero_le _)
    rw [repeat_sum B h,seven x (sub xs)] at loose
    have yes (y : Point) (hy : y ∈ E) : partners B x y=partners B x y-1+1 := by
      have := partners_pos B h x y (Finset.mem_erase.mp hy).1.symm;omega
    have add := Finset.sum_erase_add S (partners B x) xs
    have self : partners B x x=7 := by simpa [partners,degree] using seven x (sub xs)
    change (∑ y ∈ E,partners B x y)+partners B x x=_ at add
    rw [Finset.sum_congr rfl yes,Finset.sum_add_distrib,self] at add
    have cap : E.card=4 := by rw [show E=S.erase x from rfl,Finset.card_erase_of_mem xs,sz]
    simp [cap] at add
    omega
  have total := Finset.sum_le_sum per
  rw [cross_sum] at total;simp [sz] at total
  have visits := block_sum B J S
  rw [Finset.sum_congr rfl (fun x hx => blanks x (sub hx))] at visits
  simp [sz] at visits
  have lower (j : Fin 38) (_ : j ∈ J) : 3*w j≤w j*w j+2 := by
    have size := (Finset.card_le_card (Finset.inter_subset_left (s₁ := S) (s₂ := B j))).trans_eq sz
    exact (by decide : ∀ k : Fin 6,3*k.val≤k.val*k.val+2) ⟨w j,Nat.lt_succ_of_le size⟩
  have price := Finset.sum_le_sum lower
  change ∑ j ∈ J,w j=20 at visits
  rw [←Finset.mul_sum,visits,Finset.sum_add_distrib] at price
  simp [jc] at price
  have core (j : Fin 38) (hj : j ∈ I) : w j*w j=25 := by
    change (S ∩ B j).card*(S ∩ B j).card=25
    rw [Finset.inter_eq_left.mpr (sub.trans (primary j hj)),sz]
  have room := Finset.sum_le_univ_sum_of_nonneg (s := I ∪ J) (f := fun j => w j*w j) (fun _ => Nat.zero_le _)
  rw [Finset.sum_union sep,Finset.sum_congr rfl core] at room
  simp [ic] at room
  change (∑ j,w j*w j)≤105 at total
  omega

end Cover61
