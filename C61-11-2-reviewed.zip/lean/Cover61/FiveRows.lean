import Cover61.LocalCapacity

namespace Cover61.LocalRows

def groups (B : Family 38) (i : Photo) : Finset Photo :=
  Finset.univ.filter (fun j => companions B i ⊆ B j ∧ (marked B j).Nonempty)

theorem five_group_cover (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    i ∈ groups B i ∧
    (∀ y ∈ lows B, (appearances B (groups B i) y).card=1) ∧
    (groups B i).erase i ⊆ clear B i (marked B i) := by
  have hc := companion_card B h i
  have non := Finset.card_pos.mp (show 0 < (companions B i).card by omega)
  obtain ⟨z,zH⟩ := non
  have zlow : z ∉ lows B := (Finset.mem_sdiff.mp zH).2
  have hi : i ∈ groups B i := Finset.mem_filter.mpr ⟨Finset.mem_univ _,Finset.sdiff_subset,
    Finset.card_pos.mp (show 0 < (marked B i).card by omega)⟩
  refine ⟨hi,?_,?_⟩
  · intro y yl
    have six := (Finset.mem_filter.mp yl).2
    have yz : y ≠ z := fun e => zlow (e ▸ yl)
    have pair := six_meets_once B h y z six yz
    have incl : appearances B (groups B i) y ⊆ Finset.univ.filter (fun j => y ∈ B j ∧ z ∈ B j) := by
      intro j hj
      obtain ⟨jg,yj⟩ := Finset.mem_filter.mp hj
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,yj,(Finset.mem_filter.mp jg).2.1 zH⟩
    have le : (appearances B (groups B i) y).card ≤ 1 := (Finset.card_le_card incl).trans_eq pair
    suffices (appearances B (groups B i) y).Nonempty by
      have := Finset.card_pos.mpr this
      omega
    by_cases yi : y ∈ B i
    · exact ⟨i,Finset.mem_filter.mpr ⟨hi,yi⟩⟩
    · obtain ⟨j,only,allH⟩ := five_forces_group B h i (marked B i) (marked_sub B i)
          (marked_six B i) five y yi six
      have yj : y ∈ B j := (Finset.mem_filter.mp (only ▸ Finset.mem_singleton_self j :
        j ∈ appearances B (clear B i (marked B i)) y)).2
      have jg : j ∈ groups B i := Finset.mem_filter.mpr ⟨Finset.mem_univ _,companion_eq B i ▸ allH,
        ⟨y,Finset.mem_inter.mpr ⟨yl,yj⟩⟩⟩
      exact ⟨j,Finset.mem_filter.mpr ⟨jg,yj⟩⟩
  · intro j hj
    obtain ⟨ji,jg⟩ := Finset.mem_erase.mp hj
    exact companion_only_clear B h (marked B i) (marked_sub B i) (marked_six B i)
      (companion_eq B i ▸ zH) ((Finset.mem_filter.mp jg).2.1 zH) ji

theorem five_group_size (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    (lows B).card ≤ 5*(groups B i).card := by
  obtain ⟨_,one,_⟩ := five_group_cover B h i five
  have exactSeats := block_sum B (groups B i) (lows B)
  rw [Finset.sum_congr rfl one] at exactSeats
  simp at exactSeats
  have each (j : Photo) : (lows B ∩ B j).card ≤ 5 := by
    have eq : lows B ∩ B j = (B j).filter (fun x => degree B x=6) := by ext x; simp [lows,and_comm]
    rw [eq]; exact at_most_five B h j
  have le := Finset.sum_le_sum (s := groups B i) (fun j _ => each j)
  rw [exactSeats] at le
  simpa [Nat.mul_comm] using le

private theorem sum_price {J K : Finset Photo} (inside : K ⊆ J) (s : Photo → Nat)
    (m c bonus : Nat) (bound : ∀ j ∈ J, s j ≤ 6) (full : ∀ j ∈ K, s j = 6)
    (price : ∀ k : Fin 7, room k.val + (if k.val=6 then bonus else 0) ≤ m*k.val+c) :
    (∑ j ∈ J, room (s j)) + bonus*K.card ≤ m*(∑ j ∈ J, s j) + c*J.card := by
  have row (j : Photo) (hj : j ∈ J) :
      room (s j) + (if j ∈ K then bonus else 0) ≤ m*s j+c := by
    have p := price ⟨s j,Nat.lt_succ_of_le (bound j hj)⟩
    change room (s j) + (if s j=6 then bonus else 0) ≤ m*s j+c at p
    by_cases jk : j ∈ K
    · simpa only [if_pos jk,if_pos (full j jk)] using p
    · rw [if_neg jk,Nat.add_zero]; exact (Nat.le_add_right ..).trans p
  have sum := Finset.sum_le_sum row
  rw [Finset.sum_add_distrib,Finset.sum_add_distrib,← Finset.mul_sum,← Finset.sum_filter] at sum
  have eq : J.filter (fun j => j ∈ K) = K := by ext j; simp only [Finset.mem_filter]; exact ⟨And.right,fun h => ⟨inside h,h⟩⟩
  rw [eq] at sum
  simpa [Nat.mul_comm] using sum

theorem five_group_excess (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    2*(groups B i).card ≤ excess B (companions B i) ∧
    3*((groups B i).card+1) ≤ 2*excess B (companions B i) := by
  obtain ⟨hi,_,inside⟩ := five_group_cover B h i five
  have cap := local_capacity B h i
  have total := total_companion_visits B h i
  have count := (counts B h i (marked B i) (marked_sub B i) (marked_six B i)).2
  have hc := companion_card B h i
  have six : (companions B i).card=6 := by omega
  have bound (j : Photo) (_ : j ∈ clear B i (marked B i)) : amount B i j ≤ 6 :=
    (Finset.card_le_card Finset.inter_subset_left).trans_eq six
  have full (j : Photo) (hj : j ∈ (groups B i).erase i) : amount B i j = 6 := by
    have inc := (Finset.mem_filter.mp (Finset.mem_erase.mp hj).2).2.1
    unfold amount; rw [Finset.inter_eq_left.mpr inc,six]
  have a := sum_price inside (amount B i) 6 6 12 bound full (by decide)
  have b := sum_price inside (amount B i) 4 12 6 bound full (by decide)
  rw [Finset.card_erase_of_mem hi,total] at a b
  have pos := Finset.card_pos.mpr (show (groups B i).Nonempty from ⟨i,hi⟩)
  rw [six] at cap a b
  omega

/-- With at most fourteen six-fold points no block contains five of them. -/
theorem no_five_of_le_fourteen (B : Family 38) (h : IsCover B) (small : (lows B).card ≤ 14) (i : Photo) :
    (marked B i).card ≤ 4 := by
  have eq : marked B i = (B i).filter (fun x => degree B x=6) := by ext x; simp [marked,lows,and_comm]
  have hi := at_most_five B h i
  rw [← eq] at hi
  by_contra! no
  have five : (marked B i).card=5 := by omega
  have a := five_group_size B h i five
  have b := (five_group_excess B h i five).1
  have c := local_excess_le B h i
  omega

end Cover61.LocalRows
