import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced11_1_84 : Balanced (rows11_1 84) := by decide +kernel

theorem balanced11_1_85 : Balanced (rows11_1 85) := by decide +kernel

theorem balanced11_1_86 : Balanced (rows11_1 86) := by decide +kernel

theorem balanced11_1_87 : Balanced (rows11_1 87) := by decide +kernel

theorem balanced11_1_88 : Balanced (rows11_1 88) := by decide +kernel

theorem balanced11_1_89 : Balanced (rows11_1 89) := by decide +kernel

theorem balanced11_1_90 : Balanced (rows11_1 90) := by decide +kernel

theorem balanced11_1_91 : Balanced (rows11_1 91) := by decide +kernel

theorem balanced11_1_92 : Balanced (rows11_1 92) := by decide +kernel

theorem balanced11_1_93 : Balanced (rows11_1 93) := by decide +kernel

theorem balanced11_1_94 : Balanced (rows11_1 94) := by decide +kernel

theorem balanced11_1_95 : Balanced (rows11_1 95) := by decide +kernel

end Cover61.Layers
