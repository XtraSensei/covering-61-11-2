import Cover61.FourTariffs
import Mathlib.Tactic.FinCases

namespace Cover61.LocalRows.FourCase4
open FourView
set_option maxRecDepth 100000
set_option maxHeartbeats 6000000

def extra (i : Fin 7) : Nat := (#[2,1,0,0,0,0,0] : Array Nat)[i.val]!
private def classify (C : SevenSet) : Fin 24 := (#[0,1,2,3,4,5,6,7,4,5,6,7,8,9,10,11,4,5,6,7,8,9,10,11,8,9,10,11,12,13,14,15,4,5,6,7,8,9,10,11,8,9,10,11,12,13,14,15,8,9,10,11,12,13,14,15,12,13,14,15,16,17,18,19,4,5,6,7,8,9,10,11,8,9,10,11,12,13,14,15,8,9,10,11,12,13,14,15,12,13,14,15,16,17,18,19,8,9,10,11,12,13,14,15,12,13,14,15,16,17,18,19,12,13,14,15,16,17,18,19,16,17,18,19,20,21,22,23] : Array (Fin 24))[(mask C)%128]!
private def widths (i : Fin 24) : Nat := (#[0,1,1,2,1,2,2,3,2,3,3,4,3,4,4,5,4,5,5,6,5,6,6,7] : Array (Nat))[i.val]!
private def opposite (i : Fin 24) : Fin 24 := (#[23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0] : Array (Fin 24))[i.val]!
private def colors : Colors 24 where
  cls := classify
  size := widths
  other := opposite
  card := by decide +kernel
  complement := by decide +kernel
  otherSize := by decide +kernel

private def groups (i : Fin 3) : SevenSet := (#[{2,3,4,5,6},{1},{0}] : Array (SevenSet))[i.val]!
private def units (j : Fin 3) (i : Fin 24) : Nat :=
  ((#[#[0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5],#[0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1],#[0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1]] : Array (Array Nat))[j.val]!)[i.val]!
private theorem units_ok : ∀ j C, units j (classify C)=(groups j ∩ C).card := by decide +kernel

private def words0 : List Nat := [2052,1890,1404,1836,1350,1188,2034,1872,1386,1980,1656,684,1764,1278,1602,630,954,468,1800,1314,1152,1746,1260,1584,612,936,450,1044,882,396]
private def pay0 (i : Fin 24) : Nat := (#[0,0,0,0,36,36,36,36,72,72,72,72,108,108,108,108,144,144,144,144,180,180,180,180] : Array (Nat))[i.val]!
private theorem costs0 : ∀ C : SevenSet, tariffs 1 words0 C=pay0 (classify C) := by decide +kernel
private theorem need0 : tariffs 1 words0 Finset.univ=180 := by decide +kernel
private theorem valid0 (v : FourView 8 extra) : v.ValidPrice (fun C => pay0 (classify C)) 180 := by
  have a := many_tariffs v 1 words0 (by decide)
  rw [need0,funext costs0] at a
  exact a

private def words1 : List Nat := [2179]
private def pay1 (i : Fin 24) : Nat := (#[0,1,0,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,3,2,3] : Array (Nat))[i.val]!
private theorem costs1 : ∀ C : SevenSet, tariffs 5 words1 C=pay1 (classify C) := by decide +kernel
private theorem need1 : tariffs 5 words1 Finset.univ=3 := by decide +kernel
private theorem valid1 (v : FourView 8 extra) : v.ValidPrice (fun C => pay1 (classify C)) 3 := by
  have a := many_tariffs v 5 words1 (by decide)
  rw [need1,funext costs1] at a
  exact a

private def words2 : List Nat := [2136,2082,1920,1434,2118,2010,1686,714,2046,1884,1398,1992,1668,696,1776,1290,1614,642,966,480]
private def pay2 (i : Fin 24) : Nat := (#[0,0,20,20,28,28,48,48,56,56,76,76,84,84,104,104,112,112,132,132,140,140,160,160] : Array (Nat))[i.val]!
private theorem costs2 : ∀ C : SevenSet, tariffs 1 words2 C=pay2 (classify C) := by decide +kernel
private theorem need2 : tariffs 1 words2 Finset.univ=160 := by decide +kernel
private theorem valid2 (v : FourView 8 extra) : v.ValidPrice (fun C => pay2 (classify C)) 160 := by
  have a := many_tariffs v 1 words2 (by decide)
  rw [need2,funext costs2] at a
  exact a

private def words3 : List Nat := [735,249,87,33,15]
private def pay3 (i : Fin 24) : Nat := (#[0,0,10,10,1,1,11,11,2,2,12,12,3,3,13,13,4,4,14,14,5,5,15,15] : Array (Nat))[i.val]!
private theorem costs3 : ∀ C : SevenSet, tariffs 1 words3 C=pay3 (classify C) := by decide +kernel
private theorem need3 : tariffs 1 words3 Finset.univ=15 := by decide +kernel
private theorem valid3 (v : FourView 8 extra) : v.ValidPrice (fun C => pay3 (classify C)) 15 := by
  have a := many_tariffs v 1 words3 (by decide)
  rw [need3,funext costs3] at a
  exact a

private def words4 : List Nat := [2175,2157,2103,1941,1455]
private def pay4 (i : Fin 24) : Nat := (#[0,0,10,10,9,9,19,19,18,18,28,28,27,27,37,37,36,36,46,46,45,45,55,55] : Array (Nat))[i.val]!
private theorem costs4 : ∀ C : SevenSet, tariffs 1 words4 C=pay4 (classify C) := by decide +kernel
private theorem need4 : tariffs 1 words4 Finset.univ=55 := by decide +kernel
private theorem valid4 (v : FourView 8 extra) : v.ValidPrice (fun C => pay4 (classify C)) 55 := by
  have a := many_tariffs v 1 words4 (by decide)
  rw [need4,funext costs4] at a
  exact a

private def words5 : List Nat := [2164,2128,2020,1696,724]
private def pay5 (i : Fin 24) : Nat := (#[0,5,5,5,4,9,9,9,8,13,13,13,12,17,17,17,16,21,21,21,20,25,25,25] : Array (Nat))[i.val]!
private theorem costs5 : ∀ C : SevenSet, tariffs 2 words5 C=pay5 (classify C) := by decide +kernel
private theorem need5 : tariffs 2 words5 Finset.univ=25 := by decide +kernel
private theorem valid5 (v : FourView 8 extra) : v.ValidPrice (fun C => pay5 (classify C)) 25 := by
  have a := many_tariffs v 2 words5 (by decide)
  rw [need5,funext costs5] at a
  exact a

private def words6 : List Nat := [4]
private def pay6 (i : Fin 24) : Nat := (#[0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1] : Array (Nat))[i.val]!
private theorem costs6 : ∀ C : SevenSet, tariffs 2 words6 C=pay6 (classify C) := by decide +kernel
private theorem need6 : tariffs 2 words6 Finset.univ=1 := by decide +kernel
private theorem valid6 (v : FourView 8 extra) : v.ValidPrice (fun C => pay6 (classify C)) 1 := by
  have a := many_tariffs v 2 words6 (by decide)
  rw [need6,funext costs6] at a
  exact a

private def words7 : List Nat := [2169,2151,2097,1935,1449]
private def pay7 (i : Fin 24) : Nat := (#[0,0,0,0,5,5,5,5,5,5,5,5,10,10,10,10,10,10,10,10,15,15,15,15] : Array (Nat))[i.val]!
private theorem costs7 : ∀ C : SevenSet, tariffs 4 words7 C=pay7 (classify C) := by decide +kernel
private theorem need7 : tariffs 4 words7 Finset.univ=15 := by decide +kernel
private theorem valid7 (v : FourView 8 extra) : v.ValidPrice (fun C => pay7 (classify C)) 15 := by
  have a := many_tariffs v 4 words7 (by decide)
  rw [need7,funext costs7] at a
  exact a

private def pay (i : Fin 8) : Fin 24 → Nat := (#[pay0,pay1,pay2,pay3,pay4,pay5,pay6,pay7] : Array (Fin 24 → Nat))[i.val]!
private def need (i : Fin 8) : Nat := (#[180,3,160,15,55,25,1,15] : Array (Nat))[i.val]!
private def T : Table 8 24 3 8 extra where
  colors := colors
  group := groups
  units := units
  counts := units_ok
  price := pay
  target := need
  prices := by
    intro v j
    fin_cases j
    · exact valid0 v
    · exact valid1 v
    · exact valid2 v
    · exact valid3 v
    · exact valid4 v
    · exact valid5 v
    · exact valid6 v
    · exact valid7 v

private def document0 : List (Int × Rule 24 3 8) := [(4,.visits 1),(4,.visits 2),(-12,.size 3),(-20,.size 4),(1,.endpoint 7 true false),(2,.budget 0)]
private def batch0 : List (List Nat) := [[0,0,0,4,8,2,1,2],[0,0,0,3,10,1,1,2],[0,0,0,2,12,0,1,2],[0,0,0,4,7,4,0,2],[0,0,0,3,9,3,0,2],[0,0,0,2,11,2,0,2],[0,0,0,1,13,1,0,2],[0,0,0,0,15,0,0,2],[0,0,0,5,6,2,3,1],[0,0,0,4,8,1,3,1],[0,0,0,3,10,0,3,1],[0,0,0,4,7,3,2,1],[0,0,0,3,9,2,2,1],[0,0,0,2,11,1,2,1],[0,0,0,1,13,0,2,1],[0,0,0,1,12,2,1,1],[0,0,0,0,14,1,1,1],[0,0,0,6,4,2,5,0],[0,0,0,5,6,1,5,0],[0,0,0,4,8,0,5,0],[0,0,0,4,7,2,4,0],[0,0,0,3,9,1,4,0],[0,0,0,2,11,0,4,0],[0,0,0,1,12,1,3,0],[0,0,0,0,14,0,3,0]]
private theorem checked0 : batch0.all (fun h => valid T (decodeHist h) document0)=true := by decide +kernel

private def document1 : List (Int × Rule 24 3 8) := [(36,.visits 1),(40,.visits 2),(-4,.chosen),(-40,.size 2),(-116,.size 3),(-196,.size 4),(-316,.size 5),(9,.endpoint 3 false false),(6,.endpoint 10 true false),(21,.endpoint 3 true false),(20,.budget 0),(16,.endpoint 6 false true),(4,.endpoint 7 true true),(4,.endpoint 9 false true),(4,.endpoint 12 false true),(4,.mass 2)]
private def batch1 : List (List Nat) := [[0,0,1,1,11,1,1,2],[0,0,1,0,13,0,1,2],[0,0,0,5,5,5,0,2],[0,0,1,2,8,4,0,2],[0,0,1,1,10,3,0,2],[0,0,1,0,12,2,0,2],[0,0,1,2,9,1,3,1],[0,0,1,1,11,0,3,1],[0,0,0,6,3,5,2,1],[0,0,1,3,6,4,2,1],[0,0,0,5,5,4,2,1],[0,0,2,0,9,3,2,1],[0,0,1,2,8,3,2,1],[0,0,1,1,10,2,2,1],[0,0,1,0,12,1,2,1],[0,0,0,7,0,8,1,1],[0,0,1,4,3,7,1,1],[0,0,0,6,2,7,1,1],[0,0,2,1,6,6,1,1],[0,0,1,3,5,6,1,1],[0,0,0,5,4,6,1,1],[0,0,2,0,8,5,1,1],[0,0,1,2,7,5,1,1],[0,0,1,1,9,4,1,1],[0,0,0,3,8,4,1,1],[0,0,1,0,11,3,1,1],[0,0,0,2,10,3,1,1],[0,0,1,5,0,10,0,1],[0,0,1,4,2,9,0,1],[0,0,0,6,1,9,0,1],[0,0,2,1,5,8,0,1],[0,0,1,3,4,8,0,1],[0,0,0,5,3,8,0,1],[0,0,2,0,7,7,0,1],[0,0,1,2,6,7,0,1],[0,0,1,1,8,6,0,1],[0,0,1,0,10,5,0,1],[0,0,0,2,9,5,0,1],[0,0,0,1,11,4,0,1],[0,0,0,0,13,3,0,1],[0,0,1,3,7,1,5,0],[0,0,2,0,10,0,5,0],[0,0,1,2,9,0,5,0],[0,0,0,7,1,5,4,0],[0,0,1,4,4,4,4,0],[0,0,0,6,3,4,4,0],[0,0,2,1,7,3,4,0],[0,0,1,3,6,3,4,0],[0,0,2,0,9,2,4,0],[0,0,1,2,8,2,4,0],[0,0,1,1,10,1,4,0],[0,0,1,0,12,0,4,0],[0,0,1,5,1,7,3,0],[0,0,0,7,0,7,3,0],[0,0,2,2,4,6,3,0],[0,0,1,4,3,6,3,0],[0,0,0,6,2,6,3,0],[0,0,2,1,6,5,3,0],[0,0,1,3,5,5,3,0],[0,0,2,0,8,4,3,0],[0,0,1,2,7,4,3,0],[0,0,1,1,9,3,3,0],[0,0,1,0,11,2,3,0],[0,0,0,2,10,2,3,0],[0,0,1,5,0,9,2,0],[0,0,1,4,2,8,2,0],[0,0,0,6,1,8,2,0],[0,0,2,1,5,7,2,0],[0,0,1,3,4,7,2,0],[0,0,2,0,7,6,2,0],[0,0,1,2,6,6,2,0],[0,0,1,1,8,5,2,0],[0,0,1,0,10,4,2,0],[0,0,0,1,11,3,2,0],[0,0,0,0,13,2,2,0],[0,0,1,4,1,10,1,0],[0,0,0,6,0,10,1,0],[0,0,1,3,3,9,1,0],[0,0,1,2,5,8,1,0],[0,0,1,1,7,7,1,0],[0,0,1,0,9,6,1,0],[0,0,0,1,10,5,1,0],[0,0,0,0,12,4,1,0],[0,0,1,4,0,12,0,0],[0,0,1,1,6,9,0,0],[0,0,1,0,8,8,0,0]]
private theorem checked1 : batch1.all (fun h => valid T (decodeHist h) document1)=true := by decide +kernel

private def document2 : List (Int × Rule 24 3 8) := [(-1,.chosen),(1,.mass 1)]
private def batch2 : List (List Nat) := [[0,1,0,0,11,2,2,1],[0,1,0,0,10,4,1,1],[0,1,0,0,9,6,0,1],[0,1,0,0,11,1,4,0],[0,1,0,0,10,3,3,0],[0,1,0,0,9,5,2,0],[0,1,0,4,0,11,1,0],[1,0,0,0,7,8,1,0],[0,1,0,0,8,7,1,0],[1,0,0,0,6,10,0,0],[0,1,0,0,7,9,0,0],[0,0,0,0,11,6,0,0]]
private theorem checked2 : batch2.all (fun h => valid T (decodeHist h) document2)=true := by decide +kernel

private def document3 : List (Int × Rule 24 3 8) := [(360,.visits 1),(360,.visits 2),(-180,.chosen),(360,.size 1),(-1080,.size 3),(-2160,.size 4),(-6480,.size 6),(180,.endpoint 1 false false),(1,.price 0),(180,.endpoint 7 true false),(270,.endpoint 2 true false),(324,.budget 0)]
private def batch3 : List (List Nat) := [[0,1,0,1,8,5,1,1],[0,0,0,4,6,5,1,1],[0,1,0,2,5,8,0,1],[0,1,0,1,7,7,0,1],[0,0,0,4,5,7,0,1],[0,0,0,3,7,6,0,1],[0,0,0,5,5,3,4,0],[0,1,0,1,9,2,4,0],[0,1,0,2,6,5,3,0],[0,0,0,5,4,5,3,0],[0,1,0,1,8,4,3,0],[0,0,0,4,6,4,3,0],[0,0,0,3,8,3,3,0],[0,1,0,3,3,8,2,0],[0,1,0,2,5,7,2,0],[0,0,0,5,3,7,2,0],[0,1,0,1,7,6,2,0],[0,0,0,4,5,6,2,0],[0,0,0,3,7,5,2,0],[0,0,0,2,9,4,2,0],[0,1,0,3,2,10,1,0],[0,1,0,2,4,9,1,0],[0,1,0,1,6,8,1,0],[0,1,0,3,1,12,0,0],[0,1,0,2,3,11,0,0],[0,1,0,1,5,10,0,0]]
private theorem checked3 : batch3.all (fun h => valid T (decodeHist h) document3)=true := by decide +kernel

private def document4 : List (Int × Rule 24 3 8) := [(2268,.visits 0),(-1476,.chosen),(648,.size 2),(396,.size 3),(-504,.size 4),(-1404,.size 5),(72,.price 1),(7,.price 0),(126,.endpoint 7 true false),(168,.endpoint 3 true true)]
private def batch4 : List (List Nat) := [[0,0,2,2,3,9,0,1],[0,0,2,3,1,9,2,0],[0,0,3,1,1,11,1,0],[0,0,2,3,0,11,1,0],[0,0,3,0,3,10,1,0],[0,0,2,2,2,10,1,0],[0,0,3,1,0,13,0,0],[0,0,2,2,1,12,0,0],[0,0,2,1,3,11,0,0],[0,0,1,3,2,11,0,0],[0,0,0,5,1,11,0,0],[0,0,0,4,3,10,0,0]]
private theorem checked4 : batch4.all (fun h => valid T (decodeHist h) document4)=true := by decide +kernel

private def document5 : List (Int × Rule 24 3 8) := [(-840,.visits 0),(-360,.visits 2),(-320,.chosen),(1400,.size 1),(720,.size 2),(-7680,.size 5),(2,.price 2),(984,.budget 0),(765,.endpoint 3 true true),(390,.endpoint 5 true true)]
private def batch5 : List (List Nat) := [[0,0,3,0,4,8,2,0],[0,0,2,2,3,8,2,0],[0,0,2,1,4,9,1,0],[0,0,2,0,6,8,1,0]]
private theorem checked5 : batch5.all (fun h => valid T (decodeHist h) document5)=true := by decide +kernel

private def document6 : List (Int × Rule 24 3 8) := [(-240,.chosen),(400,.size 1),(400,.size 2),(-1600,.size 5),(-3000,.size 6),(100,.endpoint 1 false false),(4,.price 3),(50,.endpoint 3 false false),(1,.price 0),(100,.endpoint 3 true false),(160,.budget 0),(160,.budget 1)]
private def batch6 : List (List Nat) := [[0,1,1,0,6,7,2,0],[0,1,1,1,3,10,1,0],[0,1,1,0,5,9,1,0],[0,1,1,2,0,13,0,0],[0,1,1,1,2,12,0,0],[0,0,3,0,2,12,0,0],[0,1,1,0,4,11,0,0]]
private theorem checked6 : batch6.all (fun h => valid T (decodeHist h) document6)=true := by decide +kernel

private def document7 : List (Int × Rule 24 3 8) := [(90,.visits 1),(-89,.chosen),(90,.size 1),(-100,.size 3),(-380,.size 4),(1,.price 4),(85,.endpoint 7 true false),(81,.budget 0),(34,.endpoint 9 true true),(18,.endpoint 10 false true),(80,.endpoint 10 true true),(34,.endpoint 12 false true)]
private def batch7 : List (List Nat) := [[0,0,0,5,2,9,1,0]]
private theorem checked7 : batch7.all (fun h => valid T (decodeHist h) document7)=true := by decide +kernel

private def document8 : List (Int × Rule 24 3 8) := [(180,.visits 1),(-195,.chosen),(180,.size 1),(-200,.size 3),(-760,.size 4),(2,.price 4),(40,.endpoint 9 false false),(45,.endpoint 10 false false),(85,.endpoint 12 false false),(80,.endpoint 10 true false),(45,.endpoint 9 true false),(170,.endpoint 7 true false),(162,.budget 0)]
private def batch8 : List (List Nat) := [[0,0,0,4,4,8,1,0],[0,0,0,3,6,7,1,0],[0,0,0,3,5,9,0,0]]
private theorem checked8 : batch8.all (fun h => valid T (decodeHist h) document8)=true := by decide +kernel

private def document9 : List (Int × Rule 24 3 8) := [(-540,.chosen),(360,.size 1),(-360,.size 3),(-1440,.size 4),(1,.price 0),(180,.endpoint 10 true false),(180,.endpoint 9 true false),(360,.endpoint 7 true false),(324,.budget 0),(180,.endpoint 9 false true),(180,.endpoint 10 false true),(360,.endpoint 12 false true)]
private def batch9 : List (List Nat) := [[0,0,0,2,8,6,1,0],[0,0,0,2,7,8,0,0],[0,0,0,1,9,7,0,0]]
private theorem checked9 : batch9.all (fun h => valid T (decodeHist h) document9)=true := by decide +kernel

private def document10 : List (Int × Rule 24 3 8) := [(40418656056,.visits 1),(40418656056,.visits 2),(-19818809612,.chosen),(-59554058440,.size 3),(-150740108576,.size 4),(-653532569176,.size 7),(346586832,.price 5),(1781740273,.price 6),(390518416,.price 7),(9567701192,.endpoint 7 true false),(21263725504,.budget 0),(3514665744,.endpoint 12 false true)]
private def batch10 : List (List Nat) := [[1,0,0,1,4,11,0,0]]
private theorem checked10 : batch10.all (fun h => valid T (decodeHist h) document10)=true := by decide +kernel

private def document11 : List (Int × Rule 24 3 8) := [(98,.visits 1),(-36,.visits 2),(-55,.chosen),(72,.size 2),(-380,.size 5),(1,.price 4),(11,.endpoint 3 false false),(22,.endpoint 6 true false),(45,.budget 0),(25,.endpoint 3 true true)]
private def batch11 : List (List Nat) := [[0,0,2,0,5,10,0,0]]
private theorem checked11 : batch11.all (fun h => valid T (decodeHist h) document11)=true := by decide +kernel

private def document12 : List (Int × Rule 24 3 8) := [(-20,.visits 0),(-20,.chosen),(-20,.size 3),(-80,.size 4),(-180,.size 5),(10,.endpoint 10 true false),(10,.endpoint 9 true false),(20,.endpoint 7 true false),(15,.endpoint 5 true false),(30,.endpoint 3 true false),(20,.budget 0),(6,.endpoint 6 true true),(10,.endpoint 9 false true),(10,.endpoint 10 false true),(20,.endpoint 12 false true),(20,.mass 2)]
private def batch12 : List (List Nat) := [[0,0,1,2,4,10,0,0]]
private theorem checked12 : batch12.all (fun h => valid T (decodeHist h) document12)=true := by decide +kernel

private def documents (i : Fin 13) : List (Int × Rule 24 3 8) := (#[document0,document1,document2,document3,document4,document5,document6,document7,document8,document9,document10,document11,document12] : Array (List (Int × Rule 24 3 8)))[i.val]!
private def batches (i : Fin 13) : List (List Nat) := (#[batch0,batch1,batch2,batch3,batch4,batch5,batch6,batch7,batch8,batch9,batch10,batch11,batch12] : Array (List (List Nat)))[i.val]!
private theorem checked (j : Fin 13) : (batches j).all (fun h => valid T (decodeHist h) (documents j))=true := by
  fin_cases j
  · exact checked0
  · exact checked1
  · exact checked2
  · exact checked3
  · exact checked4
  · exact checked5
  · exact checked6
  · exact checked7
  · exact checked8
  · exact checked9
  · exact checked10
  · exact checked11
  · exact checked12

private def containsHistogram (h : List Nat) := (List.finRange 13).any (fun j => (batches j).contains h)
private theorem present : (Histogram.enumerate 7 17 45 350).all containsHistogram=true := by decide +kernel
theorem excluded (v : FourView 8 extra) : False := by
  have seats : 42+(∑ x,extra x)=45 := by decide +kernel
  have hs := v.possible_histogram
  rw [seats] at hs
  obtain ⟨j,_,ok⟩ := List.any_eq_true.mp (List.all_eq_true.mp present _ hs)
  have inside : Histogram.data v.hist 7 ∈ batches j := by simpa using ok
  have price := List.all_eq_true.mp (checked j) _ inside
  rw [read_hist] at price
  exact rejected T v (documents j) price

end Cover61.LocalRows.FourCase4
