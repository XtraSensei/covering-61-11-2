import Cover61.FourRules

namespace Cover61.LocalRows.FourView

def ceilQuot (x k : Nat) := (x+k-1)/k

theorem ceil_rule (x k q : Nat) (pos : 0<k) : ceilQuot x k ≤ q ↔ x ≤ k*q := by
  unfold ceilQuot
  rw [Nat.div_le_iff_le_mul_add_pred pos]
  omega

def weight (code : Nat) (i : Fin 7) := code / 3^i.val % 3
def tariff (k word : Nat) (c : SevenSet) := ceilQuot (∑ x ∈ c, weight word x) k
def tariffs (k : Nat) (words : List Nat) (c : SevenSet) := (words.map (fun w => tariff k w c)).sum
def mask (c : SevenSet) := ∑ x ∈ c,2^x.val

theorem one_tariff {R e} (v : FourView R e) (k word : Nat) (pos : 0<k) :
    v.ValidPrice (tariff k word) (tariff k word Finset.univ) := by
  let w := weight word
  let q := tariff k word Finset.univ
  have round (c : SevenSet) : (∑ x ∈ c, w x) ≤ k*tariff k word c :=
    (ceil_rule _ k _ pos).mp le_rfl
  by_cases zero : q=0
  · have need : ∑ x,w x=0 := by
      have b := round Finset.univ
      change (∑ x,w x) ≤ k*q at b
      simpa [zero] using b
    have all (c : SevenSet) : tariff k word c=0 := by
      apply Nat.eq_zero_of_le_zero
      apply (ceil_rule _ k 0 pos).mpr
      have lb := Finset.sum_le_univ_sum_of_nonneg (s := c) (f := w) (fun _ => Nat.zero_le _)
      simpa [need] using lb
    simp [ValidPrice,all]
  · have need : k*(q-1)<∑ x,w x := by
      by_contra! low
      have le := (ceil_rule (∑ x,w x) k (q-1) pos).mpr low
      change q ≤ q-1 at le
      omega
    exact v.cut w _ k q round need

theorem many_tariffs {R e} (v : FourView R e) (k : Nat) (words : List Nat) (pos : 0<k) :
    v.ValidPrice (tariffs k words) (tariffs k words Finset.univ) := by
  induction words with
  | nil => simp [tariffs,ValidPrice]
  | cons w ws ih =>
    change v.ValidPrice (fun C => tariffs k (w::ws) C) _
    simpa [tariffs] using v.add_price (v.one_tariff k w pos) ih

def decodeHist (xs : List Nat) (s : Nat) := if s≤7 then xs[7-s]?.getD 0 else 0

theorem read_hist {R e} (v : FourView R e) : decodeHist (Histogram.data v.hist 7)=v.hist := by
  funext s
  by_cases hs : s≤7
  · have cases : s=0 ∨ s=1 ∨ s=2 ∨ s=3 ∨ s=4 ∨ s=5 ∨ s=6 ∨ s=7 := by omega
    rcases cases with e|e|e|e|e|e|e|e <;> subst s <;> rfl
  · symm
    rw [decodeHist,if_neg hs]
    apply Finset.card_eq_zero.mpr
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro j hj
    have card := (Finset.mem_filter.mp hj).2
    change (v.C j).card = s at card
    have le := Finset.card_le_univ (v.C j)
    simp only [Fintype.card_fin] at le
    omega

end Cover61.LocalRows.FourView
