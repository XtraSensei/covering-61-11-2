import Cover61.Partitions

namespace Cover61.Catalog

open Partitions

set_option maxRecDepth 50000

set_option maxHeartbeats 3000000

def s10_038_01Head : Finset (Fin 10) := {0,1,2}

def s10_038_01Rest : List (Finset (Fin 10)) := [
  {0,4}, {1,3,4}, {0,5}, {1,5}, {2,3,5}, {0,6}, {2,6}, {3,6}, {4,5,6}, {1,7}, {2,7}, {0,3,7}, {4,7}, {1,8}, {3,8}, {2,4,8}, {5,8}, {6,7,8}, {2,9}, {3,9}, {4,9}, {1,6,9}, {5,7,9}, {0,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_038_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_038_01Head s10_038_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_039_01Head : Finset (Fin 10) := {0,1,3}

def s10_039_01Rest : List (Finset (Fin 10)) := [
  {0,4}, {1,2,4}, {0,5}, {1,5}, {2,3,5}, {0,6}, {2,6}, {3,4,6}, {5,6}, {1,7}, {2,7}, {3,7}, {4,5,7}, {1,8}, {0,2,8}, {3,8}, {4,8}, {6,7,8}, {2,9}, {3,9}, {4,9}, {1,6,9}, {0,7,9}, {5,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_039_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_039_01Head s10_039_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_044_01Head : Finset (Fin 10) := {0,1,2}

def s10_044_01Rest : List (Finset (Fin 10)) := [
  {0,4}, {1,4}, {2,3,4}, {0,5}, {2,5}, {1,3,5}, {1,6}, {3,6}, {4,6}, {2,7}, {3,7}, {5,7}, {0,6,7}, {0,8}, {3,8}, {4,5,8}, {2,6,8}, {1,7,8}, {1,9}, {2,9}, {0,3,9}, {5,6,9}, {4,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_044_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_044_01Head s10_044_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_045_01Head : Finset (Fin 10) := {0,1,2}

def s10_045_01Rest : List (Finset (Fin 10)) := [
  {0,4}, {1,4}, {2,3,4}, {0,5}, {2,5}, {1,3,5}, {1,6}, {3,6}, {5,6}, {2,7}, {3,7}, {4,7}, {0,6,7}, {0,8}, {3,8}, {4,5,8}, {2,6,8}, {1,7,8}, {1,9}, {2,9}, {0,3,9}, {4,6,9}, {5,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_045_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_045_01Head s10_045_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_047_01Head : Finset (Fin 10) := {0,1,2}

def s10_047_01Rest : List (Finset (Fin 10)) := [
  {0,3}, {1,4}, {2,3,4}, {0,5}, {3,5}, {0,6}, {1,6}, {4,6}, {2,5,6}, {1,7}, {2,7}, {4,5,7}, {3,6,7}, {2,8}, {3,8}, {0,4,8}, {1,5,8}, {7,8}, {2,9}, {1,3,9}, {4,9}, {5,9}, {0,7,9}, {6,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_047_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_047_01Head s10_047_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_048_01Head : Finset (Fin 10) := {0,1,2}

def s10_048_01Rest : List (Finset (Fin 10)) := [
  {0,4}, {2,3,4}, {1,5}, {2,5}, {0,3,5}, {0,6}, {1,6}, {3,6}, {4,5,6}, {0,7}, {2,7}, {1,3,7}, {4,7}, {1,8}, {3,8}, {4,8}, {2,6,8}, {5,7,8}, {2,9}, {3,9}, {1,4,9}, {5,9}, {6,7,9}, {0,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_048_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_048_01Head s10_048_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
