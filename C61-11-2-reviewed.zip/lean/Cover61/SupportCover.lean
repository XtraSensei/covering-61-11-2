import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.SDiff

namespace Cover61.Supports

inductive Tree (n m : Nat) where
  | leaf (k : Fin m)
  | split (i : Fin n) (without withType : Tree n m)

def check {n m} (conflict : Fin n→Finset (Fin n)) (reps : Fin m→Finset (Fin n)) :
    Finset (Fin n) → Tree n m → Bool
  | whitelisted,.leaf k => decide (whitelisted ⊆ reps k)
  | whitelisted,.split i no yes =>
    check conflict reps (whitelisted.erase i) no && check conflict reps (whitelisted \ conflict i) yes

/-- The supplied type sets cover every compatible population support. The
branch in which i occurs may discard every type incompatible with i. -/
theorem sound {n m} (conflict : Fin n→Finset (Fin n)) (reps : Fin m→Finset (Fin n))
    (S : Finset (Fin n)) (avoid : ∀ i ∈ S,Disjoint S (conflict i)) (T : Tree n m)
    (whitelisted : Finset (Fin n)) (inside : S ⊆ whitelisted) (accepted : check conflict reps whitelisted T=true) :
    ∃ k,S ⊆ reps k := by
  induction T generalizing whitelisted with
  | leaf k => exact ⟨k,inside.trans (of_decide_eq_true accepted)⟩
  | split i no yes without withType =>
    obtain ⟨a,b⟩ := Bool.and_eq_true_iff.mp accepted
    by_cases member : i ∈ S
    · apply withType _ _ b
      intro j hj
      exact Finset.mem_sdiff.mpr ⟨inside hj,fun edge => Finset.disjoint_left.mp (avoid i member) hj edge⟩
    · apply without _ _ a
      intro j hj
      exact Finset.mem_erase.mpr ⟨fun eq => member (eq ▸ hj),inside hj⟩

def Covered {n m} (conflict : Fin n→Finset (Fin n)) (reps : Fin m→Finset (Fin n)) (U : Finset (Fin n)) :=
  ∀ S ⊆ U,(∀ i ∈ S,Disjoint S (conflict i)) → ∃ k,S ⊆ reps k

theorem cover_leaf {n m} {conflict : Fin n→Finset (Fin n)} {reps : Fin m→Finset (Fin n)}
    {U : Finset (Fin n)} (k : Fin m) (sub : U ⊆ reps k) : Covered conflict reps U :=
  fun _ inside _ => ⟨k,inside.trans sub⟩

theorem cover_split {n m} {conflict : Fin n→Finset (Fin n)} {reps : Fin m→Finset (Fin n)}
    {U L R : Finset (Fin n)} (i : Fin n) (no : U.erase i ⊆ L) (yes : U \ conflict i ⊆ R)
    (left : Covered conflict reps L) (right : Covered conflict reps R) : Covered conflict reps U := by
  intro S sub avoid
  by_cases mem : i ∈ S
  · exact right S (fun _ hj => yes (Finset.mem_sdiff.mpr ⟨sub hj,fun edge => Finset.disjoint_left.mp (avoid i mem) hj edge⟩)) avoid
  · exact left S (fun _ hj => no (Finset.mem_erase.mpr ⟨fun eq => mem (eq ▸ hj),sub hj⟩)) avoid

end Cover61.Supports
