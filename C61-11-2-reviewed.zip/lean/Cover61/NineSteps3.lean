import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext36 : ∀ t, GoodStep 36 t := by decide +kernel

theorem ext37 : ∀ t, GoodStep 37 t := by decide +kernel

theorem ext38 : ∀ t, GoodStep 38 t := by decide +kernel

theorem ext39 : ∀ t, GoodStep 39 t := by decide +kernel

theorem ext40 : ∀ t, GoodStep 40 t := by decide +kernel

theorem ext41 : ∀ t, GoodStep 41 t := by decide +kernel

theorem ext42 : ∀ t, GoodStep 42 t := by decide +kernel

theorem ext43 : ∀ t, GoodStep 43 t := by decide +kernel

theorem ext44 : ∀ t, GoodStep 44 t := by decide +kernel

theorem ext45 : ∀ t, GoodStep 45 t := by decide +kernel

theorem ext46 : ∀ t, GoodStep 46 t := by decide +kernel

theorem ext47 : ∀ t, GoodStep 47 t := by decide +kernel

end Cover61.Nine
