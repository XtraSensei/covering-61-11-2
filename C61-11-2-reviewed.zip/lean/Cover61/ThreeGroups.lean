import Cover61.PhysicalGrid
import Cover61.BipartiteTransversals
import Cover61.TwoResidual

namespace Cover61.LocalRows
open Grid

theorem three_groups_impossible (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (three : (groups B i).card=3) (a : (lows B).card=15) (d : excess B (companions B i)=6) : False := by
  classical
  let G := groups B i
  let O := ordinary B i
  let K := residual B i
  have cash : (∑ x,(degree B x-7)) ≤ excess B (companions B i)+3 := by have := total_excess B h;omega
  obtain ⟨D,red,real⟩ := physical_chart B h i five G (by rfl) three
    (fun j hj => (choose_axes B h i five three a j hj) ▸ (by decide : 4≤5))
  let q (x : Point) := D.stamp (line B i x)
  have path (x : Point) (hx : x ∈ O) := real _ (line_sub B i x)
    (outside_line_count B h i five x (ordinary_away B i hx (five_group_cover B h i five).1))
    (ordinary_crosses B h i five (Finset.Subset.refl G) x hx)
  have eligible (x : Point) (hx : x ∈ O) : q x ∈ LatinFive.transversals (LatinFive.rowPrefix D.word 5) := by
    obtain ⟨P,px⟩ := path x hx
    change D.stamp (line B i x) ∈ _
    rw [←px,D.stamp_path];exact P.transversal
  have per (S : Finset Point) (sub : S ⊆ O) (c : Nat) : (S.filter (fun x => q x=c)).card≤3 :=
    stamp_fibers B h i five G (by rfl) D real cash S sub c
  have sz := (group_three_sizes B h i five three).1
  obtain ⟨S,os,many,dis⟩ := D.large_class red O q sz.ge eligible (fun c _ => per O (by rfl) c)
  have hc := companion_card B h i
  obtain ⟨z,zh⟩ := Finset.card_pos.mp (by omega : 0<(companions B i).card)
  let Pair (x : Point) (p : Photo × Photo) := appearances B K x={p.1,p.2} ∧ z ∈ B p.1 ∧ z ∉ B p.2
  have pos (x : Point) (hx : x ∈ S) : ∃ p,Pair x p := by
    obtain ⟨l,r,lr⟩ := residual_pair B h i five three z zh x (os hx)
    exact ⟨(l,r),lr⟩
  let endpoints (x : Point) := if hx : x ∈ S then Classical.choose (pos x hx) else (i,i)
  have good (x : Point) (hx : x ∈ S) : Pair x (endpoints x) := by
    simpa [endpoints,hx] using Classical.choose_spec (pos x hx)
  have degreeCap (f : Point → Photo) (member : ∀ x ∈ S, f x ∈ appearances B K x) (j : Photo) :
      (S.filter (fun x => f x=j)).card≤8 := by
    let V := S.filter (fun x => f x=j)
    by_cases non : V.Nonempty
    · obtain ⟨x,hx⟩ := non
      have fx := Finset.mem_filter.mp hx
      have jg := (Finset.mem_filter.mp (member x fx.1)).1
      rw [fx.2] at jg
      have sub : V ⊆ O ∩ B j := by
        intro y hy
        obtain ⟨ys,eq⟩ := Finset.mem_filter.mp hy
        exact Finset.mem_inter.mpr ⟨os ys,eq ▸ (Finset.mem_filter.mp (member y ys)).2⟩
      exact (Finset.card_le_card sub).trans (residual_row_capacity B h i five three j jg)
    · change V.card≤8;rw [Finset.not_nonempty_iff_eq_empty.mp non];decide
  have left (j : Photo) := degreeCap (fun x => (endpoints x).1)
    (fun x hx => by rw [(good x hx).1];simp) j
  have right (j : Photo) := degreeCap (fun x => (endpoints x).2)
    (fun x hx => by rw [(good x hx).1];simp) j
  have meet (x : Point) (hx : x ∈ S) (y : Point) (hy : y ∈ S) (ne : q x≠q y) :
      (endpoints x).1=(endpoints y).1 ∨ (endpoints x).2=(endpoints y).2 := by
    obtain ⟨P,px⟩ := path x (os hx);obtain ⟨Q,qy⟩ := path y (os hy)
    have code := dis x hx y hy ne
    change LatinFive.disjoint (D.stamp (line B i x)) (D.stamp (line B i y))=true at code
    rw [←px,←qy,D.stamp_path,D.stamp_path] at code
    have apart := (P.masks_disjoint Q).mp code
    rw [px,qy] at apart
    obtain ⟨j,xj,yj⟩ := h.2 x y (fun e => ne (congrArg q e))
    have noG : j ∉ G := fun m => ordinary_away B i (os hx) m xj
    have noC : j ∉ cells B i := fun m => Finset.disjoint_left.mp apart
      (Finset.mem_filter.mpr ⟨m,xj⟩) (Finset.mem_filter.mpr ⟨m,yj⟩)
    have jk : j ∈ K := Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,fun mem => (Finset.mem_union.mp mem).elim noG noC⟩
    have xpair := good x hx;have ypair := good y hy
    have xp : j ∈ appearances B K x := Finset.mem_filter.mpr ⟨jk,xj⟩
    have yp : j ∈ appearances B K y := Finset.mem_filter.mpr ⟨jk,yj⟩
    rw [xpair.1,Finset.mem_insert,Finset.mem_singleton] at xp
    rw [ypair.1,Finset.mem_insert,Finset.mem_singleton] at yp
    rcases xp with u|u <;> rcases yp with v|v
    · exact Or.inl (u.symm.trans v)
    · exact (ypair.2.2 ((u.symm.trans v) ▸ xpair.2.1)).elim
    · exact (xpair.2.2 ((v.symm.trans u) ▸ ypair.2.1)).elim
    · exact Or.inr (u.symm.trans v)
  have limit := bipartite_color_bound S (fun x => (endpoints x).1) (fun x => (endpoints x).2) q 8 3 left right (per S os) meet
  omega

end Cover61.LocalRows
