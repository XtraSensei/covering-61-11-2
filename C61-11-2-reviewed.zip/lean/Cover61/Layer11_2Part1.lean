import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes11_2_12 : List (Branch 10 54) := [
  ⟨{{0,5,6}, {1,9}, {2,7}, {3,8}, {4}},11,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,3,5}, {2,7}, {4,6}, {9}},11,⟨234569642985,127548448685⟩⟩
]

theorem checked11_2_12 : ∃ cert, Checked (rows10_1 12) rows11_2 2 cert :=
  ⟨routes11_2_12, by decide +kernel⟩

private def routes11_2_13 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,5}, {6,7,8}, {9}},6,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_13 : ∃ cert, Checked (rows10_1 13) rows11_2 2 cert :=
  ⟨routes11_2_13, by decide +kernel⟩

private def routes11_2_14 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,5}, {6,7,8}, {9}},7,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_14 : ∃ cert, Checked (rows10_1 14) rows11_2 2 cert :=
  ⟨routes11_2_14, by decide +kernel⟩

private def routes11_2_15 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,5}, {6,7,8}, {9}},8,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_15 : ∃ cert, Checked (rows10_1 15) rows11_2 2 cert :=
  ⟨routes11_2_15, by decide +kernel⟩

private def routes11_2_16 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,5}, {6,7,8}, {9}},9,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_16 : ∃ cert, Checked (rows10_1 16) rows11_2 2 cert :=
  ⟨routes11_2_16, by decide +kernel⟩

private def routes11_2_17 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,5}, {6,7,8}, {9}},10,⟨258879076995,258879076995⟩⟩,
  ⟨{{0}, {1}, {2,4,8}, {3,6}, {5,7}, {9}},11,⟨22354350795,125190500995⟩⟩
]

theorem checked11_2_17 : ∃ cert, Checked (rows10_1 17) rows11_2 2 cert :=
  ⟨routes11_2_17, by decide +kernel⟩

private def routes11_2_18 : List (Branch 10 54) := [
  ⟨{{0,5,6}, {1}, {2,7}, {3,8}, {4}, {9}},11,⟨127548448685,234569642985⟩⟩
]

theorem checked11_2_18 : ∃ cert, Checked (rows10_1 18) rows11_2 2 cert :=
  ⟨routes11_2_18, by decide +kernel⟩

private def routes11_2_19 : List (Branch 10 54) := [
  ⟨{{0,1,2}, {3,8}, {4,5}, {6,7}, {9}},12,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,3,4}, {1,8}, {2,5}, {6,7}, {9}},13,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_19 : ∃ cert, Checked (rows10_1 19) rows11_2 2 cert :=
  ⟨routes11_2_19, by decide +kernel⟩

private def routes11_2_20 : List (Branch 10 54) := [
  ⟨{{0,1,2}, {3,8}, {4,5}, {6,7}, {9}},14,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,3,4}, {1,8}, {2,5}, {6,7}, {9}},15,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_20 : ∃ cert, Checked (rows10_1 20) rows11_2 2 cert :=
  ⟨routes11_2_20, by decide +kernel⟩

private def routes11_2_21 : List (Branch 10 54) := [
  ⟨{{0,3,4}, {1,8}, {2,5}, {6,7}, {9}},16,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,3,5}, {2,4}, {6,7}, {9}},17,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,3,5}, {2,7}, {4,6}, {9}},8,⟨119723718655,136252031655⟩⟩,
  ⟨{{0,8}, {1,4,7}, {2,5}, {3,6}, {9}},18,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_21 : ∃ cert, Checked (rows10_1 21) rows11_2 2 cert :=
  ⟨routes11_2_21, by decide +kernel⟩

private def routes11_2_22 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,6}, {5,7,8}, {9}},12,⟨258879076995,258879076995⟩⟩,
  ⟨{{0}, {1}, {2,4}, {3,6}, {5,7,8}, {9}},14,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_22 : ∃ cert, Checked (rows10_1 22) rows11_2 2 cert :=
  ⟨routes11_2_22, by decide +kernel⟩

private def routes11_2_23 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,6}, {5,7,8}, {9}},13,⟨258879076995,258879076995⟩⟩,
  ⟨{{0}, {1}, {2,4}, {3,6}, {5,7,8}, {9}},15,⟨258879076995,258879076995⟩⟩,
  ⟨{{0}, {1}, {2,6,8}, {3,7}, {4,5}, {9}},16,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_23 : ∃ cert, Checked (rows10_1 23) rows11_2 2 cert :=
  ⟨routes11_2_23, by decide +kernel⟩

theorem balanced11_2_12 : Balanced (rows11_2 12) := by decide +kernel

theorem balanced11_2_13 : Balanced (rows11_2 13) := by decide +kernel

theorem balanced11_2_14 : Balanced (rows11_2 14) := by decide +kernel

theorem balanced11_2_15 : Balanced (rows11_2 15) := by decide +kernel

theorem balanced11_2_16 : Balanced (rows11_2 16) := by decide +kernel

theorem balanced11_2_17 : Balanced (rows11_2 17) := by decide +kernel

theorem balanced11_2_18 : Balanced (rows11_2 18) := by decide +kernel

theorem balanced11_2_19 : Balanced (rows11_2 19) := by decide +kernel

theorem balanced11_2_20 : Balanced (rows11_2 20) := by decide +kernel

theorem balanced11_2_21 : Balanced (rows11_2 21) := by decide +kernel

theorem balanced11_2_22 : Balanced (rows11_2 22) := by decide +kernel

theorem balanced11_2_23 : Balanced (rows11_2 23) := by decide +kernel

end Cover61.Layers
