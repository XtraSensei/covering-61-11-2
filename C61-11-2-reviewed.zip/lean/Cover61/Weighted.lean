import Cover61.Partitions

namespace Cover61.Weighted
set_option maxHeartbeats 300000

abbrev Rows (n : Nat) := Fin 38 → Finset (Fin n)
abbrev Cost := Fin 38 → Int

def step {n : Nat} (r : Rows n) (w : Cost) (next : Finset (Fin n) → Int → Bool)
    (U : Finset (Fin n)) (q : Int) : Bool :=
  if hu : U.Nonempty then
    (List.finRange 38).all (fun i => if U.min' hu ∈ r i ∧ r i ⊆ U then next (U \ r i) (q-w i) else true)
  else decide (q ≤ 0)

def safe {n : Nat} (r : Rows n) (w : Cost) : Nat → Finset (Fin n) → Int → Bool
  | 0 => fun _ _ => false
  | k+1 => step r w (safe r w k)

def Fits {n : Nat} (r : Rows n) (T : Finset (Fin 38)) (U : Finset (Fin n)) : Prop :=
  ∀ x, (T.filter (fun j => x ∈ r j)).card = if x ∈ U then 1 else 0

theorem safe_sound {n : Nat} (r : Rows n) (w : Cost)
    (emptyCost : ∀ i, r i = ∅ → 0 ≤ w i) (fuel : Nat) (U : Finset (Fin n))
    (q : Int) (T : Finset (Fin 38)) (fits : Fits r T U)
    (ok : safe r w fuel U q = true) : q ≤ ∑ j ∈ T, w j := by
  induction fuel generalizing U q T with
  | zero => exact Bool.noConfusion (show false = true from ok)
  | succ fuel ih =>
    by_cases hu : U.Nonempty
    · have hx := fits (U.min' hu)
      simp only [Finset.min'_mem,ite_true] at hx
      obtain ⟨i,hi⟩ := Finset.card_pos.mp (show 0 < (T.filter (fun j => U.min' hu ∈ r j)).card by omega)
      obtain ⟨hiT,hix⟩ := Finset.mem_filter.mp hi
      have subs (j) (hj : j ∈ T) : r j ⊆ U := by
        intro x hxr
        by_contra hxu
        have hpos := Finset.card_pos.mpr (show (T.filter (fun l => x ∈ r l)).Nonempty from
          ⟨j,Finset.mem_filter.mpr ⟨hj,hxr⟩⟩)
        simpa [fits x,hxu] using hpos
      have rest : Fits r (T.erase i) (U \ r i) := by
        intro x
        have eq : ((T.erase i).filter (fun j => x ∈ r j)) = (T.filter (fun j => x ∈ r j)).erase i := by
          ext j; simp [and_assoc]
        rw [eq]
        by_cases hxr : x ∈ r i
        · rw [Finset.card_erase_of_mem (Finset.mem_filter.mpr ⟨hiT,hxr⟩), fits x]
          simp [hxr,subs i hiT hxr]
        · have hn : i ∉ T.filter (fun j => x ∈ r j) := by simp [hxr]
          rw [Finset.erase_eq_of_notMem hn, fits x]; simp [hxr]
      rw [safe, step, dif_pos hu, List.all_eq_true] at ok
      have branch := ok i (List.mem_finRange _)
      rw [if_pos ⟨hix,subs i hiT⟩] at branch
      have hh := ih _ _ _ rest branch
      have he := Finset.sum_erase_add T w hiT
      omega
    · rw [safe, step, dif_neg hu, decide_eq_true_eq] at ok
      apply ok.trans
      apply Finset.sum_nonneg
      intro i hi
      apply emptyCost
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro x hx
      have hpos := Finset.card_pos.mpr (show (T.filter (fun j => x ∈ r j)).Nonempty from
        ⟨i,Finset.mem_filter.mpr ⟨hi,hx⟩⟩)
      have hnot : x ∉ U := fun h => hu ⟨x,h⟩
      simpa [fits x,hnot] using hpos

def Realizes {n : Nat} (B : Family 38) (r : Rows n) : Prop :=
  ∃ (p : Fin n ↪ Point) (e : Equiv.Perm (Fin 38)),
    (∀ j, degree B (p j) = 6) ∧ ∀ i, Partitions.lowRow B p (e i) = r i

theorem exclude {n : Nat} (r : Rows n) (w : Cost) (q : Int)
    (emptyCost : ∀ i, r i = ∅ → 0 ≤ w i)
    (ok : safe r w (n+1) Finset.univ q = true)
    (gap : ∑ i, ((11 - (r i).card : Nat) : Int) * w i < ((61 - n : Nat) : Int) * q) :
    ∀ B, IsCover B → ¬ Realizes B r := by
  classical
  intro B h ⟨p,e,six,rows⟩
  let O := (Finset.univ : Finset Point) \ Finset.univ.map p
  have size : O.card = 61 - n := by
    rw [Finset.card_sdiff_of_subset (Finset.subset_univ _),Finset.card_map]; simp
  let T (z : Point) := Finset.univ.filter (fun i => z ∈ B (e i))
  have one (z : Point) (hz : z ∈ O) : Fits r (T z) Finset.univ := by
    intro x
    have hx : p x ≠ z := by
      intro eq
      exact (Finset.mem_sdiff.mp hz).2 (Finset.mem_map.mpr ⟨x,Finset.mem_univ _,eq⟩)
    have remap := Equiv.sum_comp e (fun j => if p x ∈ B j ∧ z ∈ B j then (1:Nat) else 0)
    have meet := six_meets_once B h (p x) z (six x) hx
    simp only [Finset.sum_boole] at remap
    rw [← meet]
    simp [T,← rows,Partitions.lowRow,partners,Finset.filter_filter,and_comm] at remap ⊢
    exact remap
  have costs := Finset.sum_le_sum (s := O) (fun z hz => safe_sound r w emptyCost (n+1)
      Finset.univ q (T z) (one z hz) ok)
  have room (i : Fin 38) : (O.filter (fun z => z ∈ B (e i))).card = 11-(r i).card := by
    have part : (O.filter (fun z => z ∈ B (e i))) = B (e i) \ (r i).map p := by
      ext z
      simp only [O,← rows,Partitions.lowRow,Finset.mem_filter,Finset.mem_sdiff,Finset.mem_map,
        Finset.mem_univ,true_and]
      constructor
      · rintro ⟨no, yes⟩
        exact ⟨yes, fun ⟨x,_,eq⟩ => no ⟨x,eq⟩⟩
      · rintro ⟨yes,no⟩
        exact ⟨fun ⟨x,eq⟩ => no ⟨x,eq.symm ▸ yes,eq⟩,yes⟩
    have sub : (r i).map p ⊆ B (e i) := by
      intro z hz
      obtain ⟨x,mem,rfl⟩ := Finset.mem_map.mp hz
      rw [← rows] at mem
      exact (Finset.mem_filter.mp mem).2
    rw [part,Finset.card_sdiff_of_subset sub,h.1,Finset.card_map]
  have count : ∑ z ∈ O, ∑ i ∈ T z, w i = ∑ i, ((11-(r i).card : Nat) : Int) * w i := by
    simp only [T,Finset.sum_filter]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i _
    rw [← room, ← Finset.sum_filter]
    simp
  rw [count] at costs
  simp only [Finset.sum_const, zsmul_eq_mul, nsmul_eq_mul,size] at costs
  omega

end Cover61.Weighted
