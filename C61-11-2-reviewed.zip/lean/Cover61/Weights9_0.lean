import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w9_01Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {1,5,6}, {2,7,8}, {3,5,7}, {4,6,8}, {0,5}, {0,6}, {0,7}, {0,8}, {1,3}, {1,4}, {1,7}, {1,8}, {2,3}, {2,4}, {2,5}, {2,6}, {3,6}, {3,8}, {4,5}, {4,7}, {5,8}, {6,7}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_01Cost : Cost := fun i =>
  ([1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_01Rows :=
  Weighted.exclude _ w9_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_04Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,5}, {1,4,7}, {2,4,8}, {6,7,8}, {0,7}, {0,8}, {1,6}, {1,8}, {2,3}, {2,5}, {2,6}, {2,7}, {3,6}, {3,7}, {3,8}, {4,5}, {4,6}, {5,7}, {5,8}, {0}, {1}, {4}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_04Cost : Cost := fun i =>
  ([0, 0, 0, -1, -1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_04_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_04Rows :=
  Weighted.exclude _ w9_04Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_05Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,5}, {1,4,7}, {2,6,8}, {5,7,8}, {0,7}, {0,8}, {1,6}, {1,8}, {2,3}, {2,4}, {2,5}, {2,7}, {3,6}, {3,7}, {3,8}, {4,5}, {4,6}, {4,8}, {6,7}, {0}, {1}, {5}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_05Cost : Cost := fun i =>
  ([0, 0, 0, 0, -1, -1, -1, 0, 1, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_05_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_05Rows :=
  Weighted.exclude _ w9_05Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_06Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,5}, {1,7,8}, {2,4,7}, {2,6,8}, {0,7}, {0,8}, {1,4}, {1,6}, {2,3}, {2,5}, {3,6}, {3,7}, {3,8}, {4,5}, {4,6}, {4,8}, {5,7}, {5,8}, {6,7}, {0}, {1}, {2}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_06Cost : Cost := fun i =>
  ([1, 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_06_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_06Rows :=
  Weighted.exclude _ w9_06Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
