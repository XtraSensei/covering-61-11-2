import Cover61.Partitions

namespace Cover61.Catalog

open Partitions

set_option maxRecDepth 50000

set_option maxHeartbeats 3000000

def s11_058_04Head : Finset (Fin 11) := {0,3,5}

def s11_058_04Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {0,4,6}, {5,6}, {0,2,7}, {1,3,7}, {6,7}, {2,4,8}, {1,5,8}, {3,6,8}, {7,8}, {0,9}, {1,4,9}, {2,6,9}, {5,7,9}, {8,9}, {10}, {2,5,10}, {1,6,10}, {4,7,10}, {0,8,10}, {3,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_04_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_04Head s11_058_04Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_05Head : Finset (Fin 11) := {0,3,5}

def s11_058_05Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {0,4,6}, {5,6}, {0,2,7}, {1,4,7}, {6,7}, {2,4,8}, {1,5,8}, {3,6,8}, {7,8}, {0,9}, {1,3,9}, {2,6,9}, {5,7,9}, {8,9}, {10}, {2,5,10}, {1,6,10}, {3,7,10}, {0,8,10}, {4,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_05_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_05Head s11_058_05Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_06Head : Finset (Fin 11) := {0,3,5}

def s11_058_06Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {0,4,6}, {5,6}, {0,2,7}, {1,5,7}, {6,7}, {1,4,8}, {2,5,8}, {3,6,8}, {7,8}, {0,9}, {1,3,9}, {2,6,9}, {4,7,9}, {8,9}, {10}, {2,4,10}, {1,6,10}, {3,7,10}, {0,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_06_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_06Head s11_058_06Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_07Head : Finset (Fin 11) := {0,3,5}

def s11_058_07Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {2,4,6}, {5,6}, {0,2,7}, {1,3,7}, {6,7}, {0,4,8}, {2,5,8}, {1,6,8}, {7,8}, {0,9}, {1,4,9}, {3,6,9}, {5,7,9}, {8,9}, {10}, {1,5,10}, {0,6,10}, {4,7,10}, {3,8,10}, {2,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_07_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_07Head s11_058_07Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_08Head : Finset (Fin 11) := {0,3,5}

def s11_058_08Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {1,4,6}, {5,6}, {0,2,7}, {1,3,7}, {6,7}, {0,4,8}, {1,5,8}, {2,6,8}, {7,8}, {0,9}, {2,4,9}, {3,6,9}, {5,7,9}, {8,9}, {10}, {2,5,10}, {0,6,10}, {4,7,10}, {3,8,10}, {1,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_08_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_08Head s11_058_08Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_09Head : Finset (Fin 11) := {1,4,7}

def s11_058_09Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {0,3,5}, {4,5}, {1,3,6}, {5,6}, {0,2,7}, {6,7}, {0,4,8}, {1,5,8}, {2,6,8}, {7,8}, {0,9}, {2,5,9}, {4,6,9}, {3,7,9}, {8,9}, {10}, {2,4,10}, {0,6,10}, {5,7,10}, {3,8,10}, {1,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_09_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_09Head s11_058_09Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_10Head : Finset (Fin 11) := {1,5,8}

def s11_058_10Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {0,3,5}, {4,5}, {1,3,6}, {5,6}, {0,2,7}, {1,4,7}, {6,7}, {2,4,8}, {0,6,8}, {7,8}, {0,9}, {2,5,9}, {4,6,9}, {3,7,9}, {8,9}, {10}, {0,4,10}, {2,6,10}, {5,7,10}, {3,8,10}, {1,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_10_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_10Head s11_058_10Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_11Head : Finset (Fin 11) := {0,3,5}

def s11_058_11Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {0,2,6}, {5,6}, {0,4,7}, {1,5,7}, {6,7}, {1,3,8}, {2,5,8}, {4,6,8}, {7,8}, {0,9}, {1,4,9}, {3,6,9}, {2,7,9}, {8,9}, {10}, {2,4,10}, {1,6,10}, {3,7,10}, {0,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_11_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_11Head s11_058_11Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_12Head : Finset (Fin 11) := {0,3,5}

def s11_058_12Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {1,3,6}, {5,6}, {0,4,7}, {2,5,7}, {6,7}, {0,2,8}, {1,5,8}, {4,6,8}, {7,8}, {0,9}, {1,4,9}, {2,6,9}, {3,7,9}, {8,9}, {10}, {2,4,10}, {0,6,10}, {1,7,10}, {3,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_12_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_12Head s11_058_12Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_13Head : Finset (Fin 11) := {0,3,5}

def s11_058_13Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {2,4,6}, {5,6}, {1,3,7}, {0,4,7}, {6,7}, {1,4,8}, {2,5,8}, {0,6,8}, {7,8}, {0,9}, {1,5,9}, {3,6,9}, {2,7,9}, {8,9}, {10}, {0,2,10}, {1,6,10}, {5,7,10}, {3,8,10}, {4,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_13_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_13Head s11_058_13Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
