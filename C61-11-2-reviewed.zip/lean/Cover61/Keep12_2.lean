import Cover61.CatalogueBridge
import Cover61.Catalog
import Cover61.Weights
import Cover61.NineCover
import Cover61.LayerData
namespace Cover61.Remainder
set_option maxRecDepth 60000
set_option maxHeartbeats 4000000
def live12_2 : Finset (Fin 23) := {1}
theorem keep12_2 (B : Family 38) (h : IsCover B) (j : Fin 23)
    (real : Weighted.Realizes B (Layers.rows12_2 j)) : j ∈ live12_2 := by
  fin_cases j
  · exact False.elim (Catalog.w12_060_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.s12_061_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_061_02_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_065_01_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_065_02_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_065_03_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_066_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_066_02_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_066_03_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_066_04_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_066_05_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_066_06_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_071_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_071_02_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_071_03_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_071_04_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_071_05_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_071_06_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_072_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_072_02_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_072_03_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_072_04_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
end Cover61.Remainder
