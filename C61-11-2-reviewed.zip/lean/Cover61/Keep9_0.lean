import Cover61.CatalogueBridge
import Cover61.Catalog
import Cover61.Weights
import Cover61.NineCover
import Cover61.LayerData
namespace Cover61.Remainder
set_option maxRecDepth 60000
set_option maxHeartbeats 4000000
def live9_0 : Finset (Fin 50) := {3,7,8,13,14,16,20,22,23,26,27,28,32,33,34,35,37,38,39,40,41,42,43,44,45,46,47,48}
theorem keep9_0 (B : Family 38) (h : IsCover B) (count : (lows B).card=9) (j : Fin 50)
    (real : Weighted.Realizes B (Nine.candidates j)) : j ∈ live9_0 := by
  fin_cases j
  · exact False.elim (Catalog.s9_00_excluded B h (pointed_of_realizes real 8
      [0,1,2,3,4,5,6,7,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w9_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s9_02_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.w9_04_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_05_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_06_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · decide +kernel
  · exact False.elim (Catalog.w9_09_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_10_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_11_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_12_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · decide +kernel
  · exact False.elim (Catalog.w9_15_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.w9_17_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_18_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_19_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.w9_21_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · decide +kernel
  · exact False.elim (Catalog.w9_24_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_25_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · exact False.elim (Catalog.w9_29_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_30_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w9_31_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · exact False.elim (Catalog.w9_36_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · decide +kernel
  · exact False.elim (Catalog.s9_49_excluded B h count (rows_of_realizes real (by decide +kernel)))
end Cover61.Remainder
