import Cover61.LatinFive
import Mathlib.Data.Fintype.Pi

namespace Cover61.LatinFive

abbrev Label := Fin 5
def pack (u : Label → Label) := encode [↑(u 0),↑(u 1),↑(u 2),↑(u 3),↑(u 4)]

theorem unpack (u : Label → Label) (i : Label) : digit (pack u) i.val=(u i).val := by
  have a := (u 0).isLt; have b := (u 1).isLt; have c := (u 2).isLt; have d := (u 3).isLt; have e := (u 4).isLt
  fin_cases i <;> simp [pack,digit,encode] <;> omega

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

theorem permutation_code : ∀ u : Label → Label, (∀ i j,u i=u j → i=j) → pack u ∈ permutations := by decide +kernel

theorem first_code (u : Label→Label) (h : ∀ i,u i=i) : pack u=first := by
  simp only [pack,h]
  rfl

theorem columns_apart (u v : Label→Label) (h : ∀ i,u i≠v i) : separate (pack u) (pack v)=true := by
  apply List.all_eq_true.mpr
  intro i hi
  let j : Label := ⟨i,List.mem_range.mp hi⟩
  change (digit (pack u) j.val != digit (pack v) j.val)=true
  simp [unpack,Fin.val_ne_of_ne (h j)]

def commonRows (p q : Nat) := (indices.filter (fun i => digit p i == digit q i)).length

private theorem pair_codes : permutations.all (fun p => permutations.all (fun q =>
    (disjoint (cellMask p) (cellMask q) == (commonRows p q == 0)) &&
    (once (cellMask p) (cellMask q) == (commonRows p q == 1))))=true := by decide +kernel

theorem pair_test {p q : Nat} (hp : p ∈ permutations) (hq : q ∈ permutations) :
    disjoint (cellMask p) (cellMask q)=(commonRows p q == 0) ∧ once (cellMask p) (cellMask q)=(commonRows p q == 1) := by
  have both := Bool.and_eq_true_iff.mp (List.all_eq_true.mp (List.all_eq_true.mp pair_codes _ hp) _ hq)
  exact ⟨beq_iff_eq.mp both.1,beq_iff_eq.mp both.2⟩

private theorem cell_codes : permutations.all (fun p => (List.finRange 5).all (fun i => (List.finRange 5).all (fun j =>
    ((cellMask p).testBit (5*i.val+j.val) == (digit p i.val == j.val)))))=true := by decide +kernel

theorem bit_code {p : Nat} (hp : p ∈ permutations) (i j : Label) :
    (cellMask p).testBit (5*i.val+j.val)=(digit p i.val == j.val) :=
  beq_iff_eq.mp (List.all_eq_true.mp (List.all_eq_true.mp (List.all_eq_true.mp cell_codes _ hp) i (List.mem_finRange _)) j (List.mem_finRange _))

private theorem row_count_codes : permutations.all (fun p => permutations.all (fun q =>
    commonRows p q == (Finset.univ.filter (fun i : Label => digit p i.val=digit q i.val)).card))=true := by decide +kernel

theorem common_count {u v : Label→Label} (hu : Function.Injective u) (hv : Function.Injective v) :
    commonRows (pack u) (pack v)=(Finset.univ.filter (fun i => u i=v i)).card := by
  have bound := beq_iff_eq.mp (List.all_eq_true.mp (List.all_eq_true.mp row_count_codes _ (permutation_code u hu)) _ (permutation_code v hv))
  simpa [unpack,Fin.val_eq_val] using bound

end Cover61.LatinFive
