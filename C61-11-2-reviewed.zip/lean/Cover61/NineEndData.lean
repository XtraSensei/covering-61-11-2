import Cover61.NineData
import Cover61.ForcedCore
namespace Cover61.Nine
open Skeleton

def EndOK (j : Fin 163) : Prop :=
  let (k,c) := terminal j
  feasible (state j) → ValidCode 9 c ∧ rename (digits 9 c.forward) (state j) = diagram (candidates k)
instance (j : Fin 163) : Decidable (EndOK j) := by unfold EndOK; dsimp only; infer_instance

end Cover61.Nine
