import Cover61.PhotoRules

namespace Cover61.Photos

/-- Integer second moments of block loads, including negative prices. -/
theorem centered_moment {α : Type} [DecidableEq α] (J : Finset α) (z : α→Int) :
    (∑ i ∈ J,z i)*(∑ i ∈ J,z i)≤(J.card:Int)*(∑ i ∈ J,z i*z i) := by
  let d (i j : α) := (z i-z j)*(z i-z j)
  let n : Int := J.card
  let m := ∑ i ∈ J,z i
  let s := ∑ i ∈ J,z i*z i
  have pos (i j : α) : 0≤d i j := by
    unfold d;by_cases sign : 0≤z i-z j
    · exact Int.mul_nonneg sign sign
    · exact Int.mul_nonneg_of_nonpos_of_nonpos (le_of_not_ge sign) (le_of_not_ge sign)
  have val (i : α) (_ : i ∈ J) : ∑ j ∈ J,d i j=n*(z i*z i)-(2*z i)*m+s := by
    have eq (j : α) (_ : j ∈ J) : d i j=z i*z i-(2*z i)*z j+z j*z j := by unfold d;grind only
    rw [Finset.sum_congr rfl eq,Finset.sum_add_distrib,Finset.sum_sub_distrib,Finset.sum_const,←Finset.mul_sum]
    simp [nsmul_eq_mul,n,m,s]
  have positive : 0≤∑ i ∈ J,∑ j ∈ J,d i j :=
    Finset.sum_nonneg (fun i _ => Finset.sum_nonneg (fun j _ => pos i j))
  rw [Finset.sum_congr rfl val,Finset.sum_add_distrib,Finset.sum_sub_distrib,←Finset.mul_sum,
    ←Finset.sum_mul,←Finset.mul_sum,Finset.sum_const,nsmul_eq_mul] at positive
  change 0≤n*s-2*m*m+n*s at positive
  change m*m≤n*s
  have eq : 2*m*m=2*(m*m) := by grind only
  rw [eq] at positive;omega

end Cover61.Photos
