import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_3_24 : List (Branch 11 19) := [
  
]

theorem checked12_3_24 : ∃ cert, Checked (rows11_2 24) rows12_3 3 cert :=
  ⟨routes12_3_24, by decide +kernel⟩

private def routes12_3_25 : List (Branch 11 19) := [
  
]

theorem checked12_3_25 : ∃ cert, Checked (rows11_2 25) rows12_3 3 cert :=
  ⟨routes12_3_25, by decide +kernel⟩

private def routes12_3_26 : List (Branch 11 19) := [
  
]

theorem checked12_3_26 : ∃ cert, Checked (rows11_2 26) rows12_3 3 cert :=
  ⟨routes12_3_26, by decide +kernel⟩

private def routes12_3_27 : List (Branch 11 19) := [
  
]

theorem checked12_3_27 : ∃ cert, Checked (rows11_2 27) rows12_3 3 cert :=
  ⟨routes12_3_27, by decide +kernel⟩

private def routes12_3_28 : List (Branch 11 19) := [
  
]

theorem checked12_3_28 : ∃ cert, Checked (rows11_2 28) rows12_3 3 cert :=
  ⟨routes12_3_28, by decide +kernel⟩

private def routes12_3_29 : List (Branch 11 19) := [
  
]

theorem checked12_3_29 : ∃ cert, Checked (rows11_2 29) rows12_3 3 cert :=
  ⟨routes12_3_29, by decide +kernel⟩

private def routes12_3_30 : List (Branch 11 19) := [
  
]

theorem checked12_3_30 : ∃ cert, Checked (rows11_2 30) rows12_3 3 cert :=
  ⟨routes12_3_30, by decide +kernel⟩

private def routes12_3_31 : List (Branch 11 19) := [
  
]

theorem checked12_3_31 : ∃ cert, Checked (rows11_2 31) rows12_3 3 cert :=
  ⟨routes12_3_31, by decide +kernel⟩

private def routes12_3_32 : List (Branch 11 19) := [
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9,10}},9,⟨8387587411885,8613132866789⟩⟩,
  ⟨{{0,9}, {1,3,7}, {2,5}, {4}, {6,8}, {10}},11,⟨2722660734112,6948878967811⟩⟩
]

theorem checked12_3_32 : ∃ cert, Checked (rows11_2 32) rows12_3 3 cert :=
  ⟨routes12_3_32, by decide +kernel⟩

private def routes12_3_33 : List (Branch 11 19) := [
  ⟨{{0,5,6}, {1,4}, {2,3}, {7,8}, {9,10}},16,⟨8607184798234,8201850864009⟩⟩,
  ⟨{{0,5,6}, {1,4}, {2,7}, {3,8}, {9,10}},9,⟨2938859360173,7870124497829⟩⟩,
  ⟨{{0,5,6}, {1,9}, {2,3}, {4}, {7,8}, {10}},18,⟨2072377549561,2345851042997⟩⟩,
  ⟨{{0,5,6}, {1,9}, {2,7}, {3,8}, {4}, {10}},11,⟨4633110711977,6239282352567⟩⟩
]

theorem checked12_3_33 : ∃ cert, Checked (rows11_2 33) rows12_3 3 cert :=
  ⟨routes12_3_33, by decide +kernel⟩

private def routes12_3_34 : List (Branch 11 19) := [
  ⟨{{0}, {1,3,7}, {2,5}, {4}, {6,8}, {9,10}},16,⟨492823807102,6720566715599⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9}, {10}},6,⟨3471460944567,3141503980065⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9,10}},4,⟨1973214994223,590737166107⟩⟩
]

theorem checked12_3_34 : ∃ cert, Checked (rows11_2 34) rows12_3 3 cert :=
  ⟨routes12_3_34, by decide +kernel⟩

private def routes12_3_35 : List (Branch 11 19) := [
  ⟨{{0}, {1,3,7}, {2,5}, {4}, {6,8}, {9,10}},9,⟨4416127701205,7946981254806⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9}, {10}},9,⟨3471890926119,3482049483297⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9,10}},14,⟨1911333480815,590540091207⟩⟩
]

theorem checked12_3_35 : ∃ cert, Checked (rows11_2 35) rows12_3 3 cert :=
  ⟨routes12_3_35, by decide +kernel⟩

end Cover61.Layers
