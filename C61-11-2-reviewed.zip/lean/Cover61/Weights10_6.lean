import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w10_021_01Rows : Rows 10 := fun i =>
  ([{0,3}, {1,2,3}, {1,4}, {2,4}, {0,5}, {1,5}, {2,5}, {3,4,5}, {0,6}, {1,6}, {3,6}, {7}, {2,7}, {0,4,7}, {5,6,7}, {8}, {0,2,8}, {3,8}, {4,6,8}, {1,7,8}, {9}, {0,1,9}, {4,9}, {2,6,9}, {3,7,9}, {5,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_021_01Cost : Cost := fun i =>
  ([0, -1, 0, 0, 0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_021_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_021_01Rows :=
  Weighted.exclude _ w10_021_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_021_02Rows : Rows 10 := fun i =>
  ([{0,1,2}, {0,3}, {1,4}, {2,4}, {0,5}, {1,5}, {2,5}, {3,4,5}, {0,6}, {1,6}, {3,6}, {7}, {2,7}, {1,3,7}, {4,6,7}, {8}, {3,8}, {0,4,8}, {2,6,8}, {5,7,8}, {9}, {2,3,9}, {4,9}, {5,6,9}, {0,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_021_02Cost : Cost := fun i =>
  ([0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_021_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_021_02Rows :=
  Weighted.exclude _ w10_021_02Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_023_01Rows : Rows 10 := fun i =>
  ([{0,1,2}, {0,3}, {1,4}, {2,4}, {0,5}, {1,5}, {3,5}, {0,6}, {2,6}, {3,6}, {4,5,6}, {7}, {1,7}, {2,3,7}, {0,4,7}, {8}, {2,8}, {3,4,8}, {1,6,8}, {5,7,8}, {9}, {1,3,9}, {4,9}, {2,5,9}, {6,7,9}, {0,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_023_01Cost : Cost := fun i =>
  ([0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, 0, 0, 0, -1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_023_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_023_01Rows :=
  Weighted.exclude _ w10_023_01Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_032_01Rows : Rows 10 := fun i =>
  ([{0,1,3}, {0,4}, {1,2,4}, {0,5}, {1,5}, {2,3,5}, {0,6}, {1,6}, {2,6}, {3,4,6}, {1,7}, {2,7}, {3,7}, {4,5,7}, {2,8}, {3,8}, {4,8}, {5,6,8}, {0,7,8}, {0,2,9}, {3,9}, {4,9}, {5,9}, {6,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_032_01Cost : Cost := fun i =>
  ([-1, 0, -1, 1, 0, -1, 0, 1, 0, -1, 0, 1, 0, -1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_032_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_032_01Rows :=
  Weighted.exclude _ w10_032_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
