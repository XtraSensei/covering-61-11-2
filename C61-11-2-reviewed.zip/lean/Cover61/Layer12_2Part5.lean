import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_2_60 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,3}, {2,6,9}, {5}, {7,10}, {8}},21,⟨1070089481219,90881093798⟩⟩
]

theorem checked12_2_60 : ∃ cert, Checked (rows11_1 60) rows12_2 2 cert :=
  ⟨routes12_2_60, by decide +kernel⟩

private def routes12_2_61 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,5}, {2,6,9}, {4}, {7,10}, {8}},20,⟨3799305617866,5227511379387⟩⟩,
  ⟨{{0,5,7}, {1,3}, {2,8}, {4}, {6}, {9,10}},20,⟨1793519461107,7069625880713⟩⟩
]

theorem checked12_2_61 : ∃ cert, Checked (rows11_1 61) rows12_2 2 cert :=
  ⟨routes12_2_61, by decide +kernel⟩

private def routes12_2_62 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,3}, {4,7,9}, {5}, {6}, {8,10}},13,⟨3126638923738,5975622330953⟩⟩,
  ⟨{{0,6,8}, {1,3}, {2,7}, {4}, {5}, {9,10}},13,⟨3212378509637,5779623100361⟩⟩
]

theorem checked12_2_62 : ∃ cert, Checked (rows11_1 62) rows12_2 2 cert :=
  ⟨routes12_2_62, by decide +kernel⟩

private def routes12_2_63 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,6}, {3,4,8}, {5}, {7}, {9,10}},20,⟨3155701474035,7069625901305⟩⟩,
  ⟨{{0,3}, {1,5}, {2,6,9}, {4,10}, {7}, {8}},22,⟨1738170144546,3474003235329⟩⟩
]

theorem checked12_2_63 : ∃ cert, Checked (rows11_1 63) rows12_2 2 cert :=
  ⟨routes12_2_63, by decide +kernel⟩

private def routes12_2_64 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,8}, {4,7,9}, {5,10}},6,⟨5289861115968,2379506109816⟩⟩,
  ⟨{{0,4}, {1,6}, {2,3,5}, {7}, {8}, {9,10}},13,⟨2531287503173,5779623081353⟩⟩
]

theorem checked12_2_64 : ∃ cert, Checked (rows11_1 64) rows12_2 2 cert :=
  ⟨routes12_2_64, by decide +kernel⟩

private def routes12_2_65 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,7}, {2,4,5}, {6}, {8}, {9,10}},17,⟨3772950872097,6752190529810⟩⟩,
  ⟨{{0,7,9}, {1,6}, {2,3}, {4,10}, {5}, {8}},17,⟨321685272843,3046646920559⟩⟩
]

theorem checked12_2_65 : ∃ cert, Checked (rows11_1 65) rows12_2 2 cert :=
  ⟨routes12_2_65, by decide +kernel⟩

private def routes12_2_66 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,4,5}, {7}, {8}, {9,10}},19,⟨1792973170340,7125882818032⟩⟩,
  ⟨{{0,7,9}, {1,5}, {2,3}, {4,10}, {6}, {8}},19,⟨3121923644466,3287893344560⟩⟩
]

theorem checked12_2_66 : ∃ cert, Checked (rows11_1 66) rows12_2 2 cert :=
  ⟨routes12_2_66, by decide +kernel⟩

private def routes12_2_67 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,4,9}, {2,7}, {5}, {6}, {8,10}},2,⟨391980129574,5955958766615⟩⟩
]

theorem checked12_2_67 : ∃ cert, Checked (rows11_1 67) rows12_2 2 cert :=
  ⟨routes12_2_67, by decide +kernel⟩

private def routes12_2_68 : List (Branch 11 23) := [
  
]

theorem checked12_2_68 : ∃ cert, Checked (rows11_1 68) rows12_2 2 cert :=
  ⟨routes12_2_68, by decide +kernel⟩

private def routes12_2_69 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,3}, {2,5,9}, {6}, {7,10}, {8}},14,⟨4546959847628,1027010587515⟩⟩,
  ⟨{{0,1,7}, {2,3}, {4,10}, {5}, {6}, {8,9}},14,⟨2526163334233,4010314840279⟩⟩
]

theorem checked12_2_69 : ∃ cert, Checked (rows11_1 69) rows12_2 2 cert :=
  ⟨routes12_2_69, by decide +kernel⟩

private def routes12_2_70 : List (Branch 11 23) := [
  ⟨{{0,5,8}, {1,6}, {2,3}, {4,10}, {7}, {9}},15,⟨3913764004612,4603159858407⟩⟩
]

theorem checked12_2_70 : ∃ cert, Checked (rows11_1 70) rows12_2 2 cert :=
  ⟨routes12_2_70, by decide +kernel⟩

private def routes12_2_71 : List (Branch 11 23) := [
  ⟨{{0,6,9}, {1,3}, {2,7}, {4}, {5}, {8,10}},16,⟨4482867528425,911379246382⟩⟩
]

theorem checked12_2_71 : ∃ cert, Checked (rows11_1 71) rows12_2 2 cert :=
  ⟨routes12_2_71, by decide +kernel⟩

end Cover61.Layers
