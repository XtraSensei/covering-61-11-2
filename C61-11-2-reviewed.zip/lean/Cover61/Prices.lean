import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Fintype.BigOperators

namespace Cover61.Prices

/-- Signed row for which the assumption is a lower bound on its dot product. -/
structure Row (n : Nat) where
  coeff : Fin n → Int
  rhs : Int

def eval {n : Nat} (a x : Fin n → Int) : Int := ∑ j, a j * x j

def total {m n : Nat} (r : Fin m → Row n) (w : Fin m → Int) (j : Fin n) : Int :=
  ∑ i, w i * (r i).coeff j

/-- Variables in an integer box can contribute at most their positive price times capacity. -/
theorem boxBound {n : Nat} (a x cap : Fin n → Int)
    (lo : ∀ j, 0 ≤ x j) (hi : ∀ j, x j ≤ cap j) :
    eval a x ≤ ∑ j, max (a j) 0 * cap j := by
  apply Finset.sum_le_sum
  intro j _
  exact le_trans (mul_le_mul_of_nonneg_right (le_max_left _ _) (lo j))
    (mul_le_mul_of_nonneg_left (hi j) (le_max_right _ _))

/-- The data-only certificate test uses exact integer arithmetic. -/
def check {m n : Nat} (r : Fin m → Row n) (w : Fin m → Int)
    (cap : Fin n → Int) : Bool :=
  decide ((∑ j, max (total r w j) 0 * cap j) < ∑ i, w i * (r i).rhs)

/-- Signed rows may encode equalities or oriented inequalities. -/
theorem sound {m n : Nat} (r : Fin m → Row n) (w : Fin m → Int)
    (cap x : Fin n → Int) (lo : ∀ j, 0 ≤ x j) (hi : ∀ j, x j ≤ cap j)
    (valid : ∀ i, w i * (r i).rhs ≤ w i * eval (r i).coeff x)
    (cert : check r w cap = true) : False := by
  have h := of_decide_eq_true cert
  have weighted : (∑ i, w i * (r i).rhs) ≤ eval (total r w) x := by
    calc
      _ ≤ ∑ i, w i * eval (r i).coeff x := Finset.sum_le_sum (fun i _ => valid i)
      _ = _ := by
        simp only [eval, total, Finset.mul_sum, Finset.sum_mul, mul_assoc]
        exact Finset.sum_comm
  exact (not_lt_of_ge (weighted.trans (boxBound _ _ _ lo hi))) h

end Cover61.Prices
