import Cover61.Incidence

namespace Cover61

/-- Extend a cover to any larger number of blocks by repeating one used block. -/
theorem extend_cover {k b : Nat} (B : Family k) (h : IsCover B) (enough : k≤b) :
    ∃ C : Family b,IsCover C := by
  obtain ⟨used,_,_⟩ := h.2 (0 : Point) 1 (by decide)
  let idx (j : Fin b) : Fin k := if hj : j.val<k then ⟨j.val,hj⟩ else used
  refine ⟨fun j => B (idx j),fun j => h.1 _,?_⟩
  intro x y ne
  obtain ⟨s,xs,ys⟩ := h.2 x y ne
  let j : Fin b := ⟨s.val,lt_of_lt_of_le s.isLt enough⟩
  have eq : idx j=s := by simp [idx,j,s.isLt]
  refine ⟨j,?_,?_⟩
  · change x ∈ B (idx j)
    rw [eq];exact xs
  · change y ∈ B (idx j)
    rw [eq];exact ys

end Cover61
