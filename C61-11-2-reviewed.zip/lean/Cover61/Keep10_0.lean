import Cover61.CatalogueBridge
import Cover61.Catalog
import Cover61.Weights
import Cover61.NineCover
import Cover61.LayerData
namespace Cover61.Remainder
set_option maxRecDepth 60000
set_option maxHeartbeats 4000000
def live10_0 : Finset (Fin 65) := {0,1,6,14,16,17,20,49,61}
theorem keep10_0 (B : Family 38) (h : IsCover B) (j : Fin 65)
    (real : Weighted.Realizes B (Layers.rows10_0 j)) : j ∈ live10_0 := by
  fin_cases j
  · decide +kernel
  · decide +kernel
  · exact False.elim (Catalog.w10_001_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_001_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_001_03_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_001_04_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.w10_002_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_002_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_002_03_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_003_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_004_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_004_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_004_03_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.w10_005_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · decide +kernel
  · exact False.elim (Catalog.w10_005_04_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_006_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.w10_010_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s10_011_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_011_02_excluded B h (pointed_of_realizes real 12
      [0,1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_012_01_excluded B h (pointed_of_realizes real 21
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_012_02_excluded B h (pointed_of_realizes real 13
      [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_012_03_excluded B h (pointed_of_realizes real 7
      [0,1,2,3,4,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_012_04_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w10_012_05_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_013_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_013_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_013_03_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_014_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_014_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s10_014_03_excluded B h (pointed_of_realizes real 13
      [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_015_01_excluded B h (pointed_of_realizes real 22
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w10_016_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_016_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s10_017_01_excluded B h (pointed_of_realizes real 21
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_017_02_excluded B h (pointed_of_realizes real 1
      [0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_018_01_excluded B h (pointed_of_realizes real 13
      [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_018_02_excluded B h (pointed_of_realizes real 13
      [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_018_03_excluded B h (pointed_of_realizes real 25
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_018_04_excluded B h (pointed_of_realizes real 25
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_019_01_excluded B h (pointed_of_realizes real 10
      [0,1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w10_020_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s10_020_02_excluded B h (pointed_of_realizes real 21
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w10_021_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w10_021_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.w10_023_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s10_025_01_excluded B h (pointed_of_realizes real 13
      [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_026_01_excluded B h (pointed_of_realizes real 13
      [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_027_01_excluded B h (pointed_of_realizes real 13
      [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_029_01_excluded B h (pointed_of_realizes real 12
      [0,1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w10_032_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s10_038_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_039_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s10_044_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w10_044_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s10_045_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.s10_047_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w10_047_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s10_048_01_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
end Cover61.Remainder
