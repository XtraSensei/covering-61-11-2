import Cover61.PhotoRules

namespace Cover61.Photos

theorem clique_capacity {α : Type} [DecidableEq α] (K : Finset α) (x : α→Nat)
    (price : α→Int) (L : Int) (nonnegative : 0≤L)
    (upper : ∀ i ∈ K, price i*(x i:Int)≤L)
    (conflict : ∀ i ∈ K,∀ j ∈ K,i≠j → x i=0 ∨ x j=0) :
    ∑ i ∈ K,price i*(x i:Int)≤L := by
  by_cases yes : ∃ i ∈ K,x i≠0
  · obtain ⟨i,hi,pos⟩ := yes
    rw [Finset.sum_eq_single_of_mem i hi]
    · exact upper i hi
    · intro j hj ne
      simp [(conflict i hi j hj ne.symm).resolve_left pos]
  · have zero (i : α) (hi : i ∈ K) : x i=0 := by by_contra h;exact yes ⟨i,hi,h⟩
    have empty : (∑ i ∈ K,price i*(x i:Int))=0 := Finset.sum_eq_zero (fun i hi => by simp [zero i hi])
    rw [empty];exact nonnegative

/-- Every required partner is counted in at least one of the person's remaining blocks. -/
theorem visits_cover {b : Nat} (B : Family b) (J : Finset (Fin b)) (N : Finset Point)
    (must : ∀ y ∈ N,∃ j ∈ J,y ∈ B j) : N.card≤∑ j ∈ J,(N ∩ B j).card := by
  have sub : N ⊆ J.biUnion (fun j => N ∩ B j) := by
    intro y hy
    obtain ⟨j,hj,yj⟩ := must y hy
    exact Finset.mem_biUnion.mpr ⟨j,hj,Finset.mem_inter.mpr ⟨hy,yj⟩⟩
  exact (Finset.card_le_card sub).trans (Finset.card_biUnion_le)

/-- In a single remaining block, companions outside the required neighbor
set use seats from the surplus of all remaining blocks together. -/
theorem unused_partner_seats {b : Nat} (B : Family b) (h : ∀ j,(B j).card=11)
    (x : Point) (J : Finset (Fin b)) (attends : ∀ k ∈ J,x ∈ B k) (N : Finset Point)
    (out : x ∉ N) (must : ∀ y ∈ N,∃ k ∈ J,y ∈ B k) (j : Fin b) (member : j ∈ J) :
    N.card+(((B j).erase x) \ N).card≤10*J.card := by
  let W := ((B j).erase x) \ N
  have dis : Disjoint N W := Finset.disjoint_left.mpr (fun _ hin hw => (Finset.mem_sdiff.mp hw).2 hin)
  have sub : N ∪ W ⊆ J.biUnion (fun k => (B k).erase x) := by
    intro y hy
    rcases Finset.mem_union.mp hy with hn|hw
    · obtain ⟨k,hk,yk⟩ := must y hn
      exact Finset.mem_biUnion.mpr ⟨k,hk,Finset.mem_erase.mpr ⟨fun eq => out (eq ▸ hn),yk⟩⟩
    · exact Finset.mem_biUnion.mpr ⟨j,member,(Finset.mem_sdiff.mp hw).1⟩
  have row (k : Fin b) (hk : k ∈ J) : ((B k).erase x).card=10 := by
    rw [Finset.card_erase_of_mem (attends k hk),h]
  have cap := (Finset.card_le_card sub).trans Finset.card_biUnion_le
  rw [Finset.card_union_of_disjoint dis,Finset.sum_congr rfl row] at cap
  simpa [W,Nat.mul_comm] using cap

/-- A one-block upper price contradicts joint demands if their weighted
sum exceeds the price times the number of available blocks. -/
theorem block_price {α β : Type} [DecidableEq α] [DecidableEq β] (J : Finset α) (F : Finset β)
    (z : β→α→Int) (price demand : β→Int) (top : Int)
    (terms : ∀ t ∈ F,price t*demand t≤price t*(∑ j ∈ J,z t j))
    (perBlock : ∀ j ∈ J,(∑ t ∈ F,price t*z t j)≤top)
    (gap : (J.card:Int)*top<∑ t ∈ F,price t*demand t) : False := by
  have lower := Finset.sum_le_sum terms
  simp only [Finset.mul_sum] at lower
  rw [Finset.sum_comm] at lower
  have upper := Finset.sum_le_sum perBlock
  rw [Finset.sum_const,nsmul_eq_mul] at upper
  exact (not_lt_of_ge (lower.trans upper)) gap

end Cover61.Photos
