import Cover61.ComplementPrices
import Mathlib.Data.Fintype.EquivFin

namespace Cover61.LocalRows

abbrev SevenSet := Finset (Fin 7)

/-- Incidence data used by the local integer prices. The index sets still
refer to actual blocks and people; the seven companions are relabelled. -/
structure FourView (R : Nat) (e : Fin 7 → Nat) where
  J : Finset Photo
  S : Finset Point
  C : Photo → SevenSet
  left : Point → Photo
  right : Point → Photo
  rows : J.card=17
  chosen : S.card=R
  people : ∀ x, (J.filter (fun j => x ∈ C j)).card=6+e x
  budget : ∀ x, (∑ j ∈ J.filter (fun j => x ∈ C j), ((C j).card-1)) ≤ 10*(1+e x)
  capacity : 350 ≤ ∑ j ∈ J, room (C j).card
  endpoints : ∀ y ∈ S, left y ∈ J ∧ right y ∈ J ∧ (C (left y)).card ≤ 3 ∧ C (right y)=(C (left y))ᶜ
  slots : ∀ (T : Finset Point), T ⊆ S → ∀ (L M : Finset Photo),
    (∀ y ∈ T, left y ∈ L ∧ right y ∈ M) → T.card ≤ min (L.card*M.card) (min (4*L.card) (4*M.card))
  cut : ∀ (w : Fin 7 → Nat) (p : SevenSet → Nat) (k target : Nat),
    (∀ c, ∑ x ∈ c, w x ≤ k*p c) → k*(target-1)<∑ x,w x →
    (50-R)*target+(∑ y ∈ S, (p (C (left y))+p (C (right y)))) ≤
      ∑ j ∈ J, (11-(C j).card)*p (C j)

theorem four_view (B : Family 38) (h : IsCover B) (i : Photo) (four : (marked B i).card=4)
    (width : ∀ j, (marked B j).card ≤ 4) (S : Finset Point) (low : S ⊆ lows B)
    (outside : ∀ y ∈ S, y ∉ B i) (lab : Fin 7 ≃ ↥(companions B i)) :
    Nonempty (FourView S.card (fun x => degree B (lab x).val-7)) := by
  classical
  let H := companions B i
  let J := clear B i (marked B i)
  let emb : Fin 7 ↪ Point := lab.toEmbedding.trans (Function.Embedding.subtype _)
  let C (j : Photo) : SevenSet := Finset.univ.filter (fun x => emb x ∈ B j)
  have full : Finset.univ.map emb=H := by
    ext z
    constructor
    · rintro hz; obtain ⟨x,_,rfl⟩ := Finset.mem_map.mp hz; exact (lab x).property
    · intro hz
      exact Finset.mem_map.mpr ⟨lab.symm ⟨z,hz⟩,Finset.mem_univ _,congrArg Subtype.val (lab.apply_symm_apply _)⟩
  have cm (j : Photo) : (C j).map emb=H ∩ B j := by
    ext z
    constructor
    · rintro hz; obtain ⟨x,hx,rfl⟩ := Finset.mem_map.mp hz
      exact Finset.mem_inter.mpr ⟨(lab x).property,(Finset.mem_filter.mp hx).2⟩
    · rintro hz
      obtain ⟨hp,bp⟩ := Finset.mem_inter.mp hz
      rw [← full] at hp
      obtain ⟨x,_,rfl⟩ := Finset.mem_map.mp hp
      exact Finset.mem_map.mpr ⟨x,Finset.mem_filter.mpr ⟨Finset.mem_univ _,bp⟩,rfl⟩
  have size (j : Photo) : (C j).card=amount B i j := by
    simpa [amount,H] using congrArg Finset.card (cm j)
  have visits (x : Fin 7) : J.filter (fun j => x ∈ C j)=appearances B J (emb x) := by ext j; simp [C,appearances]
  have picks (y : Point) : ∃ j k, y ∈ S → j ≠ k ∧ appearances B J y={j,k} ∧
      amount B i j ≤ 3 ∧ H ∩ B k=H \ (H ∩ B j) := by
    by_cases hy : y ∈ S
    · obtain ⟨j,k,ok⟩ := complementary_order B h i four y (low hy) (outside y hy)
      exact ⟨j,k,fun _ => ok⟩
    · exact ⟨0,0,fun q => (hy q).elim⟩
  choose u v hp using picks
  have endpt (y : Point) (hy : y ∈ S) : u y ∈ J ∧ v y ∈ J ∧ y ∈ B (u y) ∧ y ∈ B (v y) := by
    have hu : u y ∈ appearances B J y := (hp y hy).2.1 ▸ (by simp)
    have hv : v y ∈ appearances B J y := (hp y hy).2.1 ▸ (by simp)
    exact ⟨(Finset.mem_filter.mp hu).1,(Finset.mem_filter.mp hv).1,
      (Finset.mem_filter.mp hu).2,(Finset.mem_filter.mp hv).2⟩
  refine ⟨⟨J,S,C,u,v,?_,rfl,?_,?_,?_,?_,?_,?_⟩⟩
  · have ct := (counts B h i _ (marked_sub B i) (marked_six B i)).2
    change J.card+_=37 at ct
    omega
  · intro x
    rw [visits]
    have hx := companion_visits B h i _ (lab x).property
    have large := degree_companion B h i _ (lab x).property
    change (appearances B J (emb x)).card+1=degree B (emb x) at hx
    change 7 ≤ degree B (emb x) at large
    change _ = 6+(degree B (emb x)-7)
    omega
  · intro x
    rw [visits]; simp only [size]
    have old := companion_repeat B h i _ (lab x).property
    have large := degree_companion B h i _ (lab x).property
    have eq : degree B (lab x).val-6=1+(degree B (lab x).val-7) := by omega
    simpa [J,emb,eq] using old
  · simp only [size]
    have cap := local_capacity B h i
    have hc := companion_card B h i
    have seven : (companions B i).card=7 := by omega
    simpa only [seven] using cap
  · intro y hy
    obtain ⟨_,_,small,eq⟩ := hp y hy
    refine ⟨(endpt y hy).1,(endpt y hy).2.1,(size _).trans_le small,?_⟩
    ext x
    have eqx := Finset.ext_iff.mp eq (emb x)
    have xh : emb x ∈ H := (lab x).property
    simpa [C,xh] using eqx
  · intro T sub L M mem
    apply pair_capacity B h width T L M u v (sub.trans low)
    intro y hy
    obtain ⟨_,_,yu,yv⟩ := endpt y (sub hy)
    exact ⟨(mem y hy).1,(mem y hy).2,(hp y (sub hy)).1,yu,yv⟩
  · intro w p k target round enough
    let weight (z : Point) := if hz : z ∈ H then w (lab.symm ⟨z,hz⟩) else 0
    have we (x : Fin 7) : weight (emb x)=w x := by
      have hz : emb x ∈ H := (lab x).property
      change (if h : emb x ∈ H then w (lab.symm ⟨emb x,h⟩) else 0)=w x
      rw [dif_pos hz]
      exact congrArg w (lab.symm_apply_apply x)
    have rt (j : Photo) (_ : j ∈ J) : (∑ z ∈ H ∩ B j, weight z) ≤ k*p (C j) := by
      rw [← cm,Finset.sum_map]; simpa only [we] using round (C j)
    have ce : k*(target-1)<∑ z ∈ H,weight z := by
      rw [← full,Finset.sum_map]; simpa only [we] using enough
    simp only [size]
    exact remaining_weighted_capacity B h i S outside u v (fun y hy => ⟨(hp y hy).1,(hp y hy).2.1⟩)
      weight (fun j => p (C j)) k target rt ce

end Cover61.LocalRows
