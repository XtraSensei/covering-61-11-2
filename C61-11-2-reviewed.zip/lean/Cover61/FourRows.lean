import Cover61.FiveRows

namespace Cover61.LocalRows

theorem weighted_visits (B : Family 38) (O : Finset Point) (J : Finset Photo)
    (w : Photo → Nat) :
    ∑ y ∈ O, ∑ j ∈ appearances B J y, w j = ∑ j ∈ J, (O ∩ B j).card * w j := by
  simp only [appearances,Finset.sum_filter]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  rw [← Finset.sum_filter]
  have eq : O.filter (fun y => y ∈ B j) = O ∩ B j := by ext y; simp
  simp [eq]

/-- Rounding each contribution to an even number costs at most one seat per
odd intersection. Every outsider needs to see all seven companions. -/
theorem parity_capacity (B : Family 38) (h : IsCover B) (i : Photo)
    (seven : (companions B i).card=7) :
    400 ≤ ∑ j ∈ clear B i (marked B i), (amount B i j + amount B i j % 2)*(11-amount B i j) := by
  let H := companions B i
  let J := clear B i (marked B i)
  let O := (Finset.univ : Finset Point) \ B i
  let s := amount B i
  let w (j) := s j + s j % 2
  have person (y : Point) (hy : y ∈ O) : 8 ≤ ∑ j ∈ appearances B J y, w j := by
    let T := appearances B J y
    have out := (Finset.mem_sdiff.mp hy).2
    have incl : H ⊆ T.biUnion (fun j => H ∩ B j) := by
      intro z hz
      have yz : y ≠ z := fun e => out (e ▸ (Finset.mem_sdiff.mp hz).1)
      obtain ⟨j,yj,zj⟩ := h.2 y z yz
      have jc := companion_only_clear B h (marked B i) (marked_sub B i) (marked_six B i)
        (companion_eq B i ▸ hz) zj (fun e => out (e ▸ yj))
      exact Finset.mem_biUnion.mpr ⟨j,Finset.mem_filter.mpr ⟨jc,yj⟩,Finset.mem_inter.mpr ⟨hz,zj⟩⟩
    have total : H.card ≤ ∑ j ∈ T, s j := (Finset.card_le_card incl).trans Finset.card_biUnion_le
    have up : (∑ j ∈ T, s j) ≤ ∑ j ∈ T, w j := Finset.sum_le_sum (fun j _ => Nat.le_add_right ..)
    have even : 2 ∣ ∑ j ∈ T, w j := Finset.dvd_sum (fun j _ => ⟨(s j+1)/2,by dsimp [w]; omega⟩)
    obtain ⟨k,hk⟩ := even
    change H.card=7 at seven
    change 8 ≤ ∑ j ∈ T, w j
    omega
  have all := Finset.sum_le_sum person
  rw [weighted_visits] at all
  have os : O.card = 50 := by simp [O,Finset.card_sdiff_of_subset,h.1]
  simp [os] at all
  have row (j : Photo) : (O ∩ B j).card*w j ≤ w j*(11-s j) := by
    have dis : Disjoint (H ∩ B j) (O ∩ B j) := by
      apply Finset.disjoint_left.mpr
      intro z x y
      exact (Finset.mem_sdiff.mp (Finset.mem_inter.mp y).1).2 (Finset.mem_sdiff.mp (Finset.mem_inter.mp x).1).1
    have cap := Finset.card_le_card (show (H ∩ B j) ∪ (O ∩ B j) ⊆ B j from
      Finset.union_subset Finset.inter_subset_right Finset.inter_subset_right)
    rw [Finset.card_union_of_disjoint dis,h.1] at cap
    change s j + (O ∩ B j).card ≤ 11 at cap
    rw [Nat.mul_comm]
    exact Nat.mul_le_mul_left _ (by omega)
  exact all.trans (Finset.sum_le_sum (fun j _ => row j))

def large (B : Family 38) (i : Photo) :=
  (clear B i (marked B i)).filter (fun j => 4 ≤ amount B i j)

theorem outside_low_large (B : Family 38) (h : IsCover B) (i : Photo) (four : (marked B i).card=4)
    (y : Point) (yl : y ∈ lows B) (out : y ∉ B i) :
    ∃ j ∈ large B i, y ∈ B j := by
  obtain ⟨j,k,_,both,op⟩ := four_forces_complements B h i (marked B i) (marked_sub B i)
    (marked_six B i) four y out (Finset.mem_filter.mp yl).2
  have atrow {r : Photo} (hr : r ∈ ({j,k} : Finset Photo)) :=
    Finset.mem_filter.mp (both ▸ hr : r ∈ appearances B (clear B i (marked B i)) y)
  have eq : companions B i ∩ B k = companions B i \ (companions B i ∩ B j) := by
    ext z
    by_cases hz : z ∈ companions B i
    · simpa [hz] using op z (companion_eq B i ▸ hz)
    · simp [hz]
  have inc : companions B i ∩ B j ⊆ companions B i := Finset.inter_subset_left
  have add : amount B i k + amount B i j = (companions B i).card := by
    unfold amount
    rw [eq,Finset.card_sdiff_of_subset inc,Nat.sub_add_cancel (Finset.card_le_card inc)]
  have := companion_card B h i
  by_cases big : 4 ≤ amount B i j
  · exact ⟨j,Finset.mem_filter.mpr ⟨(atrow (by simp)).1,big⟩,(atrow (by simp)).2⟩
  · exact ⟨k,Finset.mem_filter.mpr ⟨(atrow (by simp)).1,by omega⟩,(atrow (by simp)).2⟩

theorem two_large (B : Family 38) (h : IsCover B) (i : Photo) (four : (marked B i).card=4)
    (width : ∀ j, (marked B j).card ≤ 4) : 2 ≤ (large B i).card := by
  let O := lows B \ B i
  have outside : O = lows B \ marked B i := by ext x; simp [O,marked]
  have inc : marked B i ⊆ lows B := Finset.inter_subset_left
  have sz : O.card+4 = (lows B).card := by
    rw [outside,Finset.card_sdiff_of_subset inc,← four,Nat.sub_add_cancel (Finset.card_le_card inc)]
  have sub : O ⊆ (large B i).biUnion (fun j => marked B j) := by
    intro y hy
    obtain ⟨yl,out⟩ := Finset.mem_sdiff.mp hy
    obtain ⟨j,jh,yj⟩ := outside_low_large B h i four y yl out
    exact Finset.mem_biUnion.mpr ⟨j,jh,Finset.mem_inter.mpr ⟨yl,yj⟩⟩
  have upper := (Finset.card_le_card sub).trans Finset.card_biUnion_le
  have each := Finset.sum_le_sum (s := large B i) (fun j _ => width j)
  simp at each
  have nine : 9 ≤ (lows B).card := nine_six_people B h
  omega

/-- Integer prices combine the ordinary and parity-rounded cuts. -/
theorem four_needs_excess (B : Family 38) (h : IsCover B) (i : Photo) (four : (marked B i).card=4)
    (width : ∀ j, (marked B j).card ≤ 4) : 0 < excess B (companions B i) := by
  let J := clear B i (marked B i)
  let s := amount B i
  have hc := companion_card B h i
  have seven : (companions B i).card=7 := by omega
  have table : ∀ k : Fin 8, 8*room k.val + (k.val+k.val%2)*(11-k.val) +
      (if 4≤k.val then 34 else 0) ≤ 62*k.val+38 := by decide
  have row (j : Photo) (_ : j ∈ J) : 8*room (s j) + (s j+s j%2)*(11-s j) +
      (if 4≤s j then 34 else 0) ≤ 62*s j+38 := by
    have le : s j ≤ 7 := (Finset.card_le_card Finset.inter_subset_left).trans_eq seven
    exact table ⟨s j,by omega⟩
  have sum := Finset.sum_le_sum row
  simp only [Finset.sum_add_distrib,← Finset.mul_sum,← Finset.sum_filter,Finset.sum_const,nsmul_eq_mul,
    Nat.cast_id] at sum
  have two := two_large B h i four width
  have parity := parity_capacity B h i seven
  have cap := local_capacity B h i
  have total := total_companion_visits B h i
  have count := (counts B h i (marked B i) (marked_sub B i) (marked_six B i)).2
  change 2 ≤ (J.filter (fun j => 4 ≤ s j)).card at two
  rw [seven] at cap total
  change 350 ≤ ∑ j ∈ J, room (s j) at cap
  change 400 ≤ ∑ j ∈ J, (s j+s j%2)*(11-s j) at parity
  change (∑ j ∈ J, s j) = 6*7 + _ at total
  change J.card + 5*(marked B i).card=37 at count
  omega

theorem nine_width (B : Family 38) (h : IsCover B) (nine : (lows B).card=9) :
    ∀ i, (marked B i).card ≤ 3 := by
  have small := no_five_of_le_fourteen B h (by omega)
  intro i
  by_contra! no
  have le := small i
  have pos := four_needs_excess B h i (by omega) small
  have := local_excess_le B h i
  omega

end Cover61.LocalRows
