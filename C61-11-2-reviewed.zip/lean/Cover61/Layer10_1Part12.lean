import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced10_1_144 : Balanced (rows10_1 144) := by decide +kernel

theorem balanced10_1_145 : Balanced (rows10_1 145) := by decide +kernel

theorem balanced10_1_146 : Balanced (rows10_1 146) := by decide +kernel

theorem balanced10_1_147 : Balanced (rows10_1 147) := by decide +kernel

theorem balanced10_1_148 : Balanced (rows10_1 148) := by decide +kernel

theorem balanced10_1_149 : Balanced (rows10_1 149) := by decide +kernel

theorem balanced10_1_150 : Balanced (rows10_1 150) := by decide +kernel

theorem balanced10_1_151 : Balanced (rows10_1 151) := by decide +kernel

end Cover61.Layers
