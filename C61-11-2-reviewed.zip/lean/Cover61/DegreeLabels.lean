import Cover61.FourColors

namespace Cover61.LocalRows

def multiplicity (f : Fin 7→Nat) (t : Nat) := FourView.countBy Finset.univ f t

theorem arrange_degrees (f g : Fin 7→Nat) (eq : ∀ k,multiplicity f k=multiplicity g k) :
    ∃ p : Equiv.Perm (Fin 7), ∀ i, f (p i)=g i := by
  classical
  have cards (k : Nat) : Fintype.card {i // g i=k}=Fintype.card {i // f i=k} := by
    simpa [Fintype.card_subtype,multiplicity,FourView.countBy] using (eq k).symm
  let E (k : Nat) : {i // g i=k} ≃ {i // f i=k} := Fintype.equivOfCardEq (cards k)
  exact ⟨Equiv.ofFiberEquiv E,Equiv.ofFiberEquiv_map E⟩

theorem small_degrees (f : Fin 7→Nat) (le : (∑ x,f x) ≤ 3) :
    multiplicity f 0+multiplicity f 1+multiplicity f 2+multiplicity f 3=7 ∧
    multiplicity f 1+2*multiplicity f 2+3*multiplicity f 3=∑ x,f x ∧
    ∀ t,3<t → multiplicity f t=0 := by
  have small (x : Fin 7) : f x ≤ 3 := (Finset.single_le_sum (f := f)
    (fun _ _ => Nat.zero_le _) (Finset.mem_univ x)).trans le
  let idx (x : Fin 7) : Fin 4 := ⟨f x,by have := small x; omega⟩
  have eq (t : Fin 4) : FourView.countBy Finset.univ idx t=multiplicity f t.val := by
    unfold multiplicity FourView.countBy
    congr 1
  have all : (Finset.univ : Finset (Fin 4))={0,1,2,3} := by decide
  have num := FourView.weighted_count (Finset.univ : Finset (Fin 7)) idx (fun _ => 1)
  have mass := FourView.weighted_count (Finset.univ : Finset (Fin 7)) idx (fun t => t.val)
  rw [all] at num mass
  simp [eq,idx,add_comm,add_left_comm,add_assoc,Nat.mul_comm] at num mass
  refine ⟨by omega,by omega,?_⟩
  intro t ht
  unfold multiplicity FourView.countBy
  apply Finset.card_eq_zero.mpr
  apply Finset.eq_empty_iff_forall_notMem.mpr
  intro x hx
  have := (Finset.mem_filter.mp hx).2
  have := small x
  omega

noncomputable def companionLabels (B : Family 38) (h : IsCover B) (i : Photo)
    (four : (marked B i).card=4) : Fin 7 ≃ ↥(companions B i) :=
  (Fintype.equivFinOfCardEq (by have := companion_card B h i; simp; omega)).symm

theorem sum_label_degree (B : Family 38) (i : Photo) (lab : Fin 7 ≃ ↥(companions B i)) :
    (∑ x, (degree B (lab x).val-7))=excess B (companions B i) := by
  let f (x : ↥(companions B i)) := degree B x.val-7
  have eq := Equiv.sum_comp lab f
  exact eq.trans (Finset.sum_attach (companions B i) (fun x => degree B x-7))

/-- Any prescribed number of outside low points can be kept in the local view. -/
theorem view_of_degrees (B : Family 38) (h : IsCover B) (i : Photo) (four : (marked B i).card=4)
    (width : ∀ j,(marked B j).card≤4) (R : Nat) (enough : R+4≤(lows B).card)
    (g : Fin 7→Nat) (lab : Fin 7 ≃ ↥(companions B i))
    (freq : ∀ t,multiplicity (fun x => degree B (lab x).val-7) t=multiplicity g t) :
    Nonempty (FourView R g) := by
  classical
  obtain ⟨p,hp⟩ := arrange_degrees _ g freq
  let outside := lows B \ B i
  have eq : outside=lows B \ marked B i := by ext y; simp [outside,marked]
  have size : R≤outside.card := by
    rw [eq,Finset.card_sdiff_of_subset (show marked B i ⊆ lows B from Finset.inter_subset_left),four]
    omega
  obtain ⟨S,sub,sz⟩ := Finset.exists_subset_card_eq size
  have view := four_view B h i four width S (fun x hx => (Finset.mem_sdiff.mp (sub hx)).1)
    (fun x hx => (Finset.mem_sdiff.mp (sub hx)).2) (p.trans lab)
  rw [sz] at view
  have same : (fun x => degree B ((p.trans lab) x).val-7)=g := funext hp
  rwa [same] at view

end Cover61.LocalRows
