import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes10_0_48 : List (Branch 9 65) := [
  
]

theorem checked10_0_48 : ∃ cert, Checked (rows9_0 48) rows10_0 0 cert :=
  ⟨routes10_0_48, by decide +kernel⟩

private def routes10_0_49 : List (Branch 9 65) := [
  
]

theorem checked10_0_49 : ∃ cert, Checked (rows9_0 49) rows10_0 0 cert :=
  ⟨routes10_0_49, by decide +kernel⟩

theorem balanced10_0_48 : Balanced (rows10_0 48) := by decide +kernel

theorem balanced10_0_49 : Balanced (rows10_0 49) := by decide +kernel

theorem balanced10_0_50 : Balanced (rows10_0 50) := by decide +kernel

theorem balanced10_0_51 : Balanced (rows10_0 51) := by decide +kernel

theorem balanced10_0_52 : Balanced (rows10_0 52) := by decide +kernel

theorem balanced10_0_53 : Balanced (rows10_0 53) := by decide +kernel

theorem balanced10_0_54 : Balanced (rows10_0 54) := by decide +kernel

theorem balanced10_0_55 : Balanced (rows10_0 55) := by decide +kernel

theorem balanced10_0_56 : Balanced (rows10_0 56) := by decide +kernel

theorem balanced10_0_57 : Balanced (rows10_0 57) := by decide +kernel

theorem balanced10_0_58 : Balanced (rows10_0 58) := by decide +kernel

theorem balanced10_0_59 : Balanced (rows10_0 59) := by decide +kernel

end Cover61.Layers
