import Cover61.Block

namespace Cover61

def lows (B : Family 38) : Finset Point :=
  Finset.univ.filter (fun x => degree B x = 6)

theorem total_excess (B : Family 38) (h : IsCover B) :
    (∑ x, (degree B x - 7)) + 9 = (lows B).card := by
  have exactAt (x : Point) :
      degree B x + (if degree B x = 6 then 1 else 0) = 7 + (degree B x - 7) := by
    have := degree_ge_six B h x
    split <;> omega
  have eq : (∑ x, (degree B x + if degree B x = 6 then 1 else 0)) =
      ∑ x, (7 + (degree B x - 7)) := Finset.sum_congr rfl (fun x _ => exactAt x)
  simp only [Finset.sum_add_distrib,Finset.sum_boole,seats B h] at eq
  simp [lows] at eq ⊢
  omega

theorem nine_rest_seven (B : Family 38) (h : IsCover B) (nine : (lows B).card = 9)
    (x : Point) (hx : x ∉ lows B) : degree B x = 7 := by
  have ex := total_excess B h
  rw [nine] at ex
  have le := Finset.single_le_sum (f := fun y => degree B y - 7)
    (fun y _ => Nat.zero_le _) (Finset.mem_univ x)
  have lo := degree_ge_six B h x
  simp [lows] at hx
  omega

theorem at_most_twenty_five (B : Family 38) (h : IsCover B) : (lows B).card ≤ 25 := by
  classical
  have ne : (lows B).Nonempty := by
    apply Finset.card_pos.mp
    have := nine_six_people B h
    change 9 ≤ (lows B).card at this
    omega
  obtain ⟨x,hx⟩ := ne
  have six : degree B x = 6 := (Finset.mem_filter.mp hx).2
  have sums := cross_sum B {x} ((lows B).erase x)
  simp only [Finset.sum_singleton] at sums
  have ones : ∀ y ∈ (lows B).erase x, partners B x y = 1 := fun y hy =>
    six_meets_once B h x y six (Finset.mem_erase.mp hy).1.symm
  rw [Finset.sum_congr rfl ones] at sums
  have each (j : Fin 38) :
      (({x} : Finset Point) ∩ B j).card * (((lows B).erase x) ∩ B j).card ≤
      4 * (if x ∈ B j then 1 else 0) := by
    by_cases xj : x ∈ B j
    · have lrow : lows B ∩ B j = (B j).filter (fun y => degree B y = 6) := by
        ext y; simp [lows,and_comm]
      have inter : ((lows B).erase x) ∩ B j = (lows B ∩ B j).erase x := by
        ext y; simp [and_assoc]
      have xc := Finset.mem_inter.mpr ⟨hx,xj⟩
      have hi := at_most_five B h j
      rw [inter,Finset.card_erase_of_mem xc,lrow]
      simp [xj]; omega
    · simp [xj]
  have cap := Finset.sum_le_sum (s := Finset.univ) (fun j _ => each j)
  rw [← sums,← Finset.mul_sum] at cap
  simp [Finset.card_erase_of_mem hx] at cap
  change (Finset.univ.filter (fun j => x ∈ B j)).card = 6 at six
  omega

end Cover61
