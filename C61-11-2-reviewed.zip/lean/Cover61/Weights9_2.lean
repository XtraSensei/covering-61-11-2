import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w9_15Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {0,7,8}, {1,3,5}, {1,4,6}, {2,3,7}, {2,5,8}, {1,7}, {1,8}, {2,4}, {2,6}, {3,6}, {3,8}, {4,5}, {4,7}, {4,8}, {5,7}, {6,7}, {6,8}, {0}, {0}, {1}, {2}, {3}, {5}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_15Cost : Cost := fun i =>
  ([0, 0, 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_15_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_15Rows :=
  Weighted.exclude _ w9_15Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_17Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {0,7,8}, {1,3,5}, {1,4,6}, {2,3,7}, {3,6,8}, {1,7}, {1,8}, {2,4}, {2,5}, {2,6}, {2,8}, {4,5}, {4,7}, {4,8}, {5,7}, {5,8}, {6,7}, {0}, {0}, {1}, {3}, {3}, {6}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_17Cost : Cost := fun i =>
  ([0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_17_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_17Rows :=
  Weighted.exclude _ w9_17Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_18Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {0,7,8}, {1,3,5}, {1,4,6}, {2,3,7}, {4,5,8}, {1,7}, {1,8}, {2,4}, {2,5}, {2,6}, {2,8}, {3,6}, {3,8}, {4,7}, {5,7}, {6,7}, {6,8}, {0}, {0}, {1}, {3}, {4}, {5}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_18Cost : Cost := fun i =>
  ([-1, 0, 0, 0, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_18_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_18Rows :=
  Weighted.exclude _ w9_18Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_19Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {0,7,8}, {1,3,5}, {1,4,7}, {1,6,8}, {2,3,8}, {2,4}, {2,5}, {2,6}, {2,7}, {3,6}, {3,7}, {4,5}, {4,6}, {4,8}, {5,7}, {5,8}, {6,7}, {0}, {0}, {1}, {1}, {3}, {8}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_19Cost : Cost := fun i =>
  ([1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_19_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_19Rows :=
  Weighted.exclude _ w9_19Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
