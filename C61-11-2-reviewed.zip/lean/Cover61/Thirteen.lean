import Cover61.StructuralReduction
import Cover61.FourColors

namespace Cover61.LocalRows

private def visitsOf (B : Family 38) (x : Point) (k : Nat) := (appearances B (fullRows B k) x).card

private theorem size_counts (B : Family 38) (width : ∀ j, (marked B j).card≤4) (J : Finset Photo)
    (w : Nat→Nat) :
    ∑ j ∈ J,w (marked B j).card =
      ∑ k : Fin 5,(J.filter (fun j => (marked B j).card=k.val)).card*w k.val := by
  let f (j : Photo) : Fin 5 := ⟨(marked B j).card,Nat.lt_succ_of_le (width j)⟩
  have count := FourView.weighted_count J f (fun k => w k.val)
  convert count.symm using 1
  apply Finset.sum_congr rfl
  intro k _
  congr 2

private theorem four_sizes (B : Family 38) (width : ∀ j, (marked B j).card≤4) (x : Point) (w : Nat→Nat) :
    ∑ j ∈ appearances B Finset.univ x,w (marked B j).card =
    visitsOf B x 0*w 0+visitsOf B x 1*w 1+visitsOf B x 2*w 2+visitsOf B x 3*w 3+visitsOf B x 4*w 4 := by
  have each (k : Nat) : ((appearances B Finset.univ x).filter (fun j => (marked B j).card=k)).card=visitsOf B x k := by
    unfold visitsOf appearances fullRows
    congr 1
    ext j
    simp [and_comm]
  have eq := size_counts B width (appearances B Finset.univ x) w
  have un : (Finset.univ : Finset (Fin 5))={0,1,2,3,4} := by decide
  rw [un] at eq
  simpa [each,add_assoc,add_comm,add_left_comm] using eq

private theorem attendance_mass (B : Family 38) (h : IsCover B) (x : Point) :
    (∑ j ∈ appearances B Finset.univ x,(marked B j).card) = (lows B).card + (if x ∈ lows B then 5 else 0) := by
  have total := cross_sum B (lows B) {x}
  simp only [Finset.sum_singleton] at total
  have right : ∑ j,(lows B ∩ B j).card*(({x}:Finset Point) ∩ B j).card =
      ∑ j ∈ appearances B Finset.univ x,(marked B j).card := by
    rw [appearances,Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro j _
    by_cases hx : x ∈ B j <;> simp [hx,marked]
  rw [←right,←total]
  have each (y : Point) (hy : y ∈ lows B) : partners B y x=1+(if y=x then 5 else 0) := by
    have six := (Finset.mem_filter.mp hy).2
    by_cases eq : y=x
    · subst y; simpa [partners,degree] using six
    · simpa [eq] using six_meets_once B h y x six eq
  rw [Finset.sum_congr rfl each,Finset.sum_add_distrib]
  simp

theorem thirteen_impossible (B : Family 38) (h : IsCover B) (a : (lows B).card=13)
    (individual : ∀ i,(marked B i).card=4 → 3≤excess B (companions B i)) : False := by
  have width := no_five_of_le_fourteen B h (by omega)
  have global := total_excess B h
  have dis (i : Photo) (hi : i ∈ fullRows B 4) (j : Photo) (hj : j ∈ fullRows B 4) (ne : i≠j) :=
    disjoint_costly B h i j ne (by
      have := individual i (Finset.mem_filter.mp hi).2
      have := individual j (Finset.mem_filter.mp hj).2
      omega)
  have quads := disjoint_low_seats B 4 dis
  have mass (x : Point) := (four_sizes B width x id).symm.trans (attendance_mass B h x)
  simp only [id_eq,mul_zero,zero_add,mul_one] at mass
  have lowInfo (x : Point) (hx : x ∈ lows B) : visitsOf B x 1=0 ∧ visitsOf B x 2=visitsOf B x 4 := by
    have v4 : visitsOf B x 4≤1 := by
      apply Finset.card_le_one.mpr
      intro i hi j hj
      by_contra ne
      obtain ⟨qi,xi⟩ := Finset.mem_filter.mp hi
      obtain ⟨qj,xj⟩ := Finset.mem_filter.mp hj
      exact Finset.disjoint_left.mp (dis i qi j qj ne) (Finset.mem_inter.mpr ⟨hx,xi⟩) (Finset.mem_inter.mpr ⟨hx,xj⟩)
    have v0 : visitsOf B x 0=0 := by
      unfold visitsOf
      apply Finset.card_eq_zero.mpr
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro j hj
      obtain ⟨z,xj⟩ := Finset.mem_filter.mp hj
      have empty := Finset.card_eq_zero.mp (Finset.mem_filter.mp z).2
      exact Finset.notMem_empty x (empty ▸ (show x ∈ marked B j from Finset.mem_inter.mpr ⟨hx,xj⟩))
    have total := four_sizes B width x (fun _ => 1)
    have r : (appearances B Finset.univ x).card=6 := (Finset.mem_filter.mp hx).2
    simp [r] at total
    have m := mass x
    simp [hx,a] at m
    omega
  have summation (k : Nat) : (∑ x ∈ lows B,visitsOf B x k)=(fullRows B k).card*k := by
    rw [show (∑ x ∈ lows B,visitsOf B x k)=∑ j ∈ fullRows B k,(marked B j).card from (block_sum ..).symm]
    have atrow (j : Photo) (hj : j ∈ fullRows B k) : (marked B j).card=k := (Finset.mem_filter.mp hj).2
    rw [Finset.sum_congr rfl atrow]
    simp
  have n1 := summation 1
  rw [Finset.sum_congr rfl (g := fun _ => 0) (fun x hx => (lowInfo x hx).1)] at n1
  simp at n1
  have counts := Finset.sum_congr rfl (fun x hx => (lowInfo x hx).2)
  rw [summation,summation] at counts
  have sizes := size_counts B width Finset.univ id
  have un : (Finset.univ : Finset (Fin 5))={0,1,2,3,4} := by decide
  rw [un] at sizes
  change (∑ j,lowCount B j)=_ at sizes
  rw [low_seat_identity,a] at sizes
  have bySize (s : Nat) : (Finset.univ.filter (fun j => (marked B j).card=s)).card=(fullRows B s).card := rfl
  simp [bySize] at sizes
  have noneOr : (fullRows B 4).card=0 ∨ (fullRows B 4).card=3 := by omega
  have noSingle (x : Point) : visitsOf B x 1=0 := by
    have le := Finset.card_le_card (Finset.filter_subset (fun j => x ∈ B j) (fullRows B 1))
    change visitsOf B x 1≤_ at le
    omega
  rcases noneOr with zero | three
  · obtain ⟨x,hx⟩ := Finset.card_pos.mp (show (Finset.univ \ lows B).card>0 by simp [Finset.card_sdiff_of_subset,a])
    have never (k : Nat) (eq : (fullRows B k).card=0) : visitsOf B x k=0 := by
      have le := Finset.card_le_card (Finset.filter_subset (fun j => x ∈ B j) (fullRows B k))
      change visitsOf B x k≤_ at le
      omega
    have m := mass x
    rw [if_neg (Finset.mem_sdiff.mp hx).2,a] at m
    have := never 2 (by omega)
    have := never 4 zero
    have := noSingle x
    omega
  · let w (x : Point) := degree B x-7
    have bound (x : Point) (hx : x ∉ lows B) : visitsOf B x 4≤2 := by
      have m := mass x
      rw [if_neg hx,a] at m
      have := noSingle x
      omega
    have lb := Finset.sum_le_sum (s := fullRows B 4) (fun j hj => individual j (Finset.mem_filter.mp hj).2)
    rw [Finset.sum_const,Nat.nsmul_eq_mul,three] at lb
    have ub : ∑ j ∈ fullRows B 4,excess B (companions B j)≤2*∑ x,w x := by
      change (∑ j ∈ fullRows B 4,∑ x ∈ B j \ lows B,w x) ≤ _
      have inner (j : Photo) : (∑ x ∈ B j \ lows B,w x)=∑ x : Point, if x ∈ B j \ lows B then w x else 0 := by
        rw [← Finset.sum_filter]
        have filter : Finset.univ.filter (fun x => x ∈ B j \ lows B) = B j \ lows B := by ext x; simp
        rw [filter]
      simp_rw [inner]
      rw [Finset.sum_comm,Finset.mul_sum]
      apply Finset.sum_le_sum
      intro x _
      by_cases hx : x ∈ lows B
      · simp [hx,w,(Finset.mem_filter.mp hx).2]
      · simp only [Finset.mem_sdiff,hx,not_false_eq_true,and_true,←Finset.sum_filter,Finset.sum_const,Nat.nsmul_eq_mul]
        exact Nat.mul_le_mul_right _ (bound x hx)
    change _+9=_ at global
    change _≤2*(∑ x,(degree B x-7)) at ub
    omega

end Cover61.LocalRows
