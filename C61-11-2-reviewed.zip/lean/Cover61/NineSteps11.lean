import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext132 : ∀ t, GoodStep 132 t := by decide +kernel

theorem ext133 : ∀ t, GoodStep 133 t := by decide +kernel

theorem ext134 : ∀ t, GoodStep 134 t := by decide +kernel

theorem ext135 : ∀ t, GoodStep 135 t := by decide +kernel

theorem ext136 : ∀ t, GoodStep 136 t := by decide +kernel

theorem ext137 : ∀ t, GoodStep 137 t := by decide +kernel

theorem ext138 : ∀ t, GoodStep 138 t := by decide +kernel

theorem ext139 : ∀ t, GoodStep 139 t := by decide +kernel

theorem ext140 : ∀ t, GoodStep 140 t := by decide +kernel

theorem ext141 : ∀ t, GoodStep 141 t := by decide +kernel

theorem ext142 : ∀ t, GoodStep 142 t := by decide +kernel

theorem ext143 : ∀ t, GoodStep 143 t := by decide +kernel

end Cover61.Nine
