import Cover61.TripleOrbit
import Cover61.Weighted

namespace Cover61.Skeleton

abbrev Rows (n : Nat) := Fin 38 → Row n
def fibers {n : Nat} (r : Rows n) (s : Row n) := Finset.univ.filter (fun i => r i = s)
def containing {n : Nat} (r : Rows n) (s : Row n) := Finset.univ.filter (fun i => s ⊆ r i)
def tally {n : Nat} (r : Rows n) (s : Row n) := (containing r s).card
def diagram {n : Nat} (r : Rows n) : Sys n := (Finset.univ.image r).filter (fun s => s.card = 3)

def Regular {n : Nat} (r : Rows n) : Prop :=
  (∀ i, (r i).card ≤ 3) ∧ (∀ x, tally r {x} = 6) ∧ ∀ x y : Fin n, x ≠ y → tally r {x,y} = 1
instance {n : Nat} (r : Rows n) : Decidable (Regular r) := by unfold Regular; infer_instance

theorem regular_projection {n : Nat} (B : Family 38) (h : IsCover B) (p : Fin n ↪ Point)
    (six : ∀ j, degree B (p j)=6) (width : ∀ i, (Partitions.lowRow B p i).card ≤ 3) :
    Regular (Partitions.lowRow B p) := by
  refine ⟨width,?_,?_⟩
  · intro x; simpa [tally,containing,Partitions.lowRow,degree] using six x
  · intro x y ne
    have meet := six_meets_once B h _ _ (six x) (p.injective.ne ne)
    simpa [tally,containing,Partitions.lowRow,partners,Finset.insert_subset_iff] using meet

theorem mem_diagram {n : Nat} (r : Rows n) (s : Row n) :
    s ∈ diagram r ↔ (∃ i, r i=s) ∧ s.card=3 := by simp [diagram]

theorem tally_le_one {n : Nat} (r : Rows n) (reg : Regular r) (s : Row n) (two : 1<s.card) :
    tally r s ≤ 1 := by
  obtain ⟨x,y,hx,hy,ne⟩ := Finset.one_lt_card_iff.mp two
  have sub : containing r s ⊆ containing r {x,y} := by
    intro i hi
    have inside := (Finset.mem_filter.mp hi).2
    simp [containing,Finset.insert_subset_iff,inside hx,inside hy]
  exact (Finset.card_le_card sub).trans_eq (reg.2.2 x y ne)

theorem packing {n : Nat} (r : Rows n) (reg : Regular r) : Packing (diagram r) := by
  refine ⟨fun s hs => ((mem_diagram r s).mp hs).2,?_⟩
  intro s hs t ht ne
  obtain ⟨⟨i,rfl⟩,_⟩ := (mem_diagram r s).mp hs
  obtain ⟨⟨j,rfl⟩,_⟩ := (mem_diagram r t).mp ht
  by_contra! two
  have bound := tally_le_one r reg _ two
  have sub : ({i,j} : Finset _) ⊆ containing r (r i ∩ r j) := by
    intro k hk
    rcases Finset.mem_insert.mp hk with rfl | hk
    · simp [containing]
    · rw [Finset.mem_singleton] at hk
      subst k; simp [containing]
  have le := (Finset.card_le_card sub).trans bound
  have diff : i ≠ j := fun eq => ne (congrArg r eq)
  simp [diff] at le

theorem tallies {n : Nat} (r t : Rows n) (hr : Regular r) (ht : Regular t) (same : diagram r = diagram t) :
    ∀ s, tally r s = tally t s := by
  intro s
  by_cases zero : s.card=0
  · have eq := Finset.card_eq_zero.mp zero; subst s; simp [tally,containing]
  by_cases one : s.card=1
  · obtain ⟨x,rfl⟩ := Finset.card_eq_one.mp one
    rw [hr.2.1,ht.2.1]
  by_cases two : s.card=2
  · obtain ⟨x,y,ne,rfl⟩ := Finset.card_eq_two.mp two
    rw [hr.2.2 _ _ ne,ht.2.2 _ _ ne]
  have large : 3 ≤ s.card := by omega
  have tag (v : Rows n) (hv : Regular v) : tally v s = if s ∈ diagram v then 1 else 0 := by
    have small := tally_le_one v hv s (by omega)
    split
    next h =>
      obtain ⟨⟨i,hi⟩,_⟩ := (mem_diagram v s).mp h
      have pos := Finset.card_pos.mpr (show (containing v s).Nonempty from ⟨i,by simp [containing,hi]⟩)
      change 0 < tally v s at pos
      omega
    next h =>
      apply Finset.card_eq_zero.mpr
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro i hi
      have sub := (Finset.mem_filter.mp hi).2
      have size := hv.1 i
      have lower := Finset.card_le_card sub
      have eq := Finset.eq_of_subset_of_card_le sub (by omega)
      exact h ((mem_diagram v s).mpr ⟨⟨i,eq.symm⟩,by rw [eq]; omega⟩)
  rw [tag r hr,tag t ht,same]

/-- Knowing the number of rows containing each subset determines each exact multiplicity. -/
theorem fiber_sizes {n : Nat} (r t : Rows n) (same : ∀ s, tally r s = tally t s) :
    ∀ s, (fibers r s).card = (fibers t s).card := by
  classical
  have count (v : Rows n) (s : Row n) :
      ∑ w ∈ Finset.univ.filter (fun w => s ⊆ w), (fibers v w).card = tally v s := by
    calc
      _ = ∑ w ∈ Finset.univ.filter (fun w => s ⊆ w), ∑ i : Fin 38, if v i=w then 1 else 0 := by simp [fibers]
      _ = ∑ i : Fin 38, ∑ w ∈ Finset.univ.filter (fun w => s ⊆ w), if v i=w then 1 else 0 := Finset.sum_comm
      _ = _ := by simp [tally,containing]
  intro s
  apply Finset.strongDownwardInductionOn (n := n) (p := fun s => (fibers r s).card = (fibers t s).card) s _ (by
    simpa using Finset.card_le_univ s)
  intro a ih _
  let up := Finset.univ.filter (fun b : Row n => a ⊆ b)
  have mem : a ∈ up := by simp [up]
  have off : ∑ k ∈ up.erase a, (fibers r k).card = ∑ k ∈ up.erase a, (fibers t k).card := by
    apply Finset.sum_congr rfl
    intro k hk
    obtain ⟨ne,hk⟩ := Finset.mem_erase.mp hk
    apply ih (by simpa using Finset.card_le_univ k)
    exact Finset.ssubset_iff_subset_ne.mpr ⟨(Finset.mem_filter.mp hk).2,ne.symm⟩
  have e1 := Finset.sum_erase_add up (fun k => (fibers r k).card) mem
  have e2 := Finset.sum_erase_add up (fun k => (fibers t k).card) mem
  rw [off] at e1
  change _ = ∑ k ∈ Finset.univ.filter (fun k => a ⊆ k), (fibers r k).card at e1
  change _ = ∑ k ∈ Finset.univ.filter (fun k => a ⊆ k), (fibers t k).card at e2
  rw [count,same] at e1
  rw [count] at e2
  omega

theorem arrange {n : Nat} (r t : Rows n) (sizes : ∀ s, (fibers r s).card = (fibers t s).card) :
    ∃ e : Equiv.Perm (Fin 38), ∀ i, r (e i) = t i := by
  classical
  have eq (s : Row n) : Fintype.card {i // t i = s} = Fintype.card {i // r i = s} := by
    simpa [Fintype.card_subtype, fibers] using (sizes s).symm
  let e (s : Row n) : {i // t i = s} ≃ {i // r i = s} := Fintype.equivOfCardEq (eq s)
  exact ⟨Equiv.ofFiberEquiv e,Equiv.ofFiberEquiv_map e⟩

end Cover61.Skeleton
