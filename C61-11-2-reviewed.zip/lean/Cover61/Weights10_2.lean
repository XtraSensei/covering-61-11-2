import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w10_004_01Rows : Rows 10 := fun i =>
  ([{0,2}, {0,3}, {1,3}, {2,3}, {4}, {0,4}, {5}, {1,5}, {3,4,5}, {6}, {1,6}, {2,4,6}, {7}, {0,1,7}, {2,7}, {5,6,7}, {8}, {1,2,8}, {0,5,8}, {3,6,8}, {4,7,8}, {9}, {1,4,9}, {2,5,9}, {0,6,9}, {3,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_004_01Cost : Cost := fun i =>
  ([0, 0, 1, 0, 2, 0, 1, 0, -3, 1, 0, -1, 4, -1, 0, -2, -1, 0, -4, 0, 1, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_004_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_004_01Rows :=
  Weighted.exclude _ w10_004_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_004_02Rows : Rows 10 := fun i =>
  ([{0,2}, {0,3}, {1,3}, {2,3}, {4}, {0,4}, {5}, {1,5}, {6}, {1,6}, {2,4,6}, {3,5,6}, {7}, {0,1,7}, {2,7}, {4,5,7}, {8}, {1,2,8}, {3,4,8}, {0,5,8}, {6,7,8}, {9}, {1,4,9}, {2,5,9}, {0,6,9}, {3,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_004_02Cost : Cost := fun i =>
  ([1, 0, 1, -1, 0, 0, 1, 1, 1, 0, -2, -2, 2, 0, 0, -1, 0, 0, 0, -1, 0, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_004_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_004_02Rows :=
  Weighted.exclude _ w10_004_02Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_004_03Rows : Rows 10 := fun i =>
  ([{0,2}, {0,3}, {1,3}, {2,3}, {4}, {0,4}, {5}, {1,5}, {2,4,5}, {6}, {1,6}, {0,5,6}, {7}, {2,7}, {1,4,7}, {3,6,7}, {8}, {0,1,8}, {3,4,8}, {2,6,8}, {5,7,8}, {9}, {1,2,9}, {3,5,9}, {4,6,9}, {0,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_004_03Cost : Cost := fun i =>
  ([0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, -1, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_004_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_004_03Rows :=
  Weighted.exclude _ w10_004_03Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_005_01Rows : Rows 10 := fun i =>
  ([{0,2}, {1,2}, {0,3}, {1,3}, {4}, {0,4}, {5}, {1,5}, {3,4,5}, {6}, {0,1,6}, {2,6}, {7}, {3,7}, {2,4,7}, {5,6,7}, {8}, {2,3,8}, {0,5,8}, {4,6,8}, {1,7,8}, {9}, {1,4,9}, {2,5,9}, {3,6,9}, {0,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_005_01Cost : Cost := fun i =>
  ([0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_005_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_005_01Rows :=
  Weighted.exclude _ w10_005_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
