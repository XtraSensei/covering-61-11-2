import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end140 : EndOK 140 := by decide +kernel

theorem end141 : EndOK 141 := by decide +kernel

theorem end142 : EndOK 142 := by decide +kernel

theorem end143 : EndOK 143 := by decide +kernel

theorem end144 : EndOK 144 := by decide +kernel

theorem end145 : EndOK 145 := by decide +kernel

theorem end146 : EndOK 146 := by decide +kernel

theorem end147 : EndOK 147 := by decide +kernel

theorem end148 : EndOK 148 := by decide +kernel

theorem end149 : EndOK 149 := by decide +kernel

theorem end150 : EndOK 150 := by decide +kernel

theorem end151 : EndOK 151 := by decide +kernel

theorem end152 : EndOK 152 := by decide +kernel

theorem end153 : EndOK 153 := by decide +kernel

end Cover61.Nine
