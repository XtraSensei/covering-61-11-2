import Cover61.Partitions

namespace Cover61.Catalog

open Partitions

set_option maxRecDepth 50000

set_option maxHeartbeats 3000000

def s10_018_01Head : Finset (Fin 10) := {2,3,7}

def s10_018_01Rest : List (Finset (Fin 10)) := [
  {0,1,2}, {0,3}, {0,4}, {1,4}, {0,5}, {2,5}, {1,3,5}, {4,5}, {1,6}, {2,6}, {3,6}, {7}, {1,7}, {4,6,7}, {8}, {2,8}, {3,4,8}, {0,6,8}, {5,7,8}, {9}, {3,9}, {2,4,9}, {5,6,9}, {0,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_018_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_018_01Head s10_018_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_018_02Head : Finset (Fin 10) := {2,3,7}

def s10_018_02Rest : List (Finset (Fin 10)) := [
  {0,1,2}, {0,3}, {0,4}, {1,4}, {0,5}, {2,5}, {1,3,5}, {4,5}, {1,6}, {2,6}, {3,6}, {7}, {1,7}, {4,6,7}, {8}, {2,8}, {3,4,8}, {5,6,8}, {0,7,8}, {9}, {3,9}, {2,4,9}, {0,6,9}, {5,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_018_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_018_02Head s10_018_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_018_03Head : Finset (Fin 10) := {7,8,9}

def s10_018_03Rest : List (Finset (Fin 10)) := [
  {0,3}, {1,2,3}, {0,4}, {1,4}, {0,5}, {2,5}, {4,5}, {1,6}, {2,6}, {3,6}, {7}, {1,7}, {0,2,7}, {3,4,7}, {5,6,7}, {8}, {0,1,8}, {2,8}, {3,5,8}, {4,6,8}, {9}, {3,9}, {2,4,9}, {1,5,9}, {0,6,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_018_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_018_03Head s10_018_03Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_018_04Head : Finset (Fin 10) := {7,8,9}

def s10_018_04Rest : List (Finset (Fin 10)) := [
  {0,3}, {1,2,3}, {0,4}, {1,4}, {0,5}, {2,5}, {4,5}, {1,6}, {2,6}, {3,6}, {7}, {1,7}, {0,2,7}, {3,5,7}, {4,6,7}, {8}, {0,1,8}, {2,8}, {3,4,8}, {5,6,8}, {9}, {3,9}, {2,4,9}, {1,5,9}, {0,6,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_018_04_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_018_04Head s10_018_04Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_019_01Head : Finset (Fin 10) := {4,5,6}

def s10_019_01Rest : List (Finset (Fin 10)) := [
  {0,1,2}, {0,3}, {0,4}, {1,4}, {1,5}, {2,5}, {3,5}, {1,6}, {2,6}, {3,6}, {7}, {0,7}, {1,3,7}, {2,4,7}, {8}, {2,8}, {3,4,8}, {0,5,8}, {6,7,8}, {9}, {2,3,9}, {4,9}, {0,6,9}, {5,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_019_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_019_01Head s10_019_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_020_02Head : Finset (Fin 10) := {0,2,9}

def s10_020_02Rest : List (Finset (Fin 10)) := [
  {0,3}, {0,4}, {1,2,4}, {3,4}, {0,5}, {1,5}, {2,5}, {1,6}, {2,6}, {3,6}, {7}, {1,7}, {2,3,7}, {4,5,7}, {0,6,7}, {8}, {0,1,8}, {2,8}, {3,5,8}, {4,6,8}, {9}, {1,3,9}, {4,9}, {5,6,9}, {7,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_020_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_020_02Head s10_020_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_025_01Head : Finset (Fin 10) := {4,5,7}

def s10_025_01Rest : List (Finset (Fin 10)) := [
  {0,3}, {1,2,3}, {0,4}, {1,4}, {2,4}, {0,5}, {1,5}, {2,5}, {1,6}, {2,6}, {3,6}, {7}, {3,7}, {0,6,7}, {8}, {0,1,8}, {3,4,8}, {5,6,8}, {2,7,8}, {9}, {0,2,9}, {3,5,9}, {4,6,9}, {1,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_025_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_025_01Head s10_025_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_026_01Head : Finset (Fin 10) := {3,4,7}

def s10_026_01Rest : List (Finset (Fin 10)) := [
  {0,1,2}, {0,3}, {1,3}, {0,4}, {1,4}, {0,5}, {2,5}, {3,5}, {1,6}, {2,6}, {4,6}, {7}, {2,7}, {5,6,7}, {8}, {2,3,8}, {4,5,8}, {0,6,8}, {1,7,8}, {9}, {2,4,9}, {1,5,9}, {3,6,9}, {0,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_026_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_026_01Head s10_026_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_027_01Head : Finset (Fin 10) := {3,4,7}

def s10_027_01Rest : List (Finset (Fin 10)) := [
  {0,1,2}, {0,3}, {0,4}, {1,4}, {2,4}, {0,5}, {1,5}, {3,5}, {1,6}, {2,6}, {3,6}, {7}, {2,7}, {5,6,7}, {8}, {1,3,8}, {2,5,8}, {4,6,8}, {0,7,8}, {9}, {2,3,9}, {4,5,9}, {0,6,9}, {1,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_027_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_027_01Head s10_027_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_029_01Head : Finset (Fin 10) := {0,1,7}

def s10_029_01Rest : List (Finset (Fin 10)) := [
  {0,2}, {1,3}, {0,4}, {2,4}, {0,5}, {1,5}, {3,5}, {1,6}, {2,6}, {3,6}, {4,5,6}, {7}, {2,3,7}, {4,7}, {8}, {0,3,8}, {1,4,8}, {2,5,8}, {6,7,8}, {9}, {1,2,9}, {3,4,9}, {0,6,9}, {5,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_029_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_029_01Head s10_029_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
