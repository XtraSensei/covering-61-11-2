import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_2_12 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,4,8}, {2,9}, {5}, {6,10}, {7}},21,⟨3758181022882,4477548629554⟩⟩,
  ⟨{{0,8,9}, {1,7}, {2,3}, {4}, {5}, {6,10}},3,⟨2544051149090,3189442540724⟩⟩
]

theorem checked12_2_12 : ∃ cert, Checked (rows11_1 12) rows12_2 2 cert :=
  ⟨routes12_2_12, by decide +kernel⟩

private def routes12_2_13 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,8}, {4,7,9}, {5}, {10}},4,⟨1008759263171,78497015179⟩⟩,
  ⟨{{0,5}, {1,6}, {2,3}, {4,7,9}, {8}, {10}},6,⟨1003167032241,1549423331995⟩⟩
]

theorem checked12_2_13 : ∃ cert, Checked (rows11_1 13) rows12_2 2 cert :=
  ⟨routes12_2_13, by decide +kernel⟩

private def routes12_2_14 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,4,8}, {2,9}, {5,10}, {6}, {7}},2,⟨3960567017330,7013302835407⟩⟩,
  ⟨{{0,5}, {1,4,8}, {2,3}, {6}, {7}, {9,10}},3,⟨3950247707186,3948393306319⟩⟩
]

theorem checked12_2_14 : ∃ cert, Checked (rows11_1 14) rows12_2 2 cert :=
  ⟨routes12_2_14, by decide +kernel⟩

private def routes12_2_15 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,5,9}, {2,3}, {6}, {7}, {8,10}},22,⟨329963835190,5962278145703⟩⟩,
  ⟨{{0,6,8}, {1,3}, {2,9}, {4}, {5,10}, {7}},22,⟨3758135403726,3796526295826⟩⟩
]

theorem checked12_2_15 : ∃ cert, Checked (rows11_1 15) rows12_2 2 cert :=
  ⟨routes12_2_15, by decide +kernel⟩

private def routes12_2_16 : List (Branch 11 23) := [
  ⟨{{0,5}, {1,3}, {2,8}, {4,6,9}, {7}, {10}},5,⟨1009353681358,759651225256⟩⟩,
  ⟨{{0,5}, {1,7}, {2,3}, {4,6,9}, {8}, {10}},5,⟨1003408587610,1502194026520⟩⟩
]

theorem checked12_2_16 : ∃ cert, Checked (rows11_1 16) rows12_2 2 cert :=
  ⟨routes12_2_16, by decide +kernel⟩

private def routes12_2_17 : List (Branch 11 23) := [
  ⟨{{0,5}, {1,7}, {2,3}, {4,6,9}, {8,10}},4,⟨1743837067258,5960242757920⟩⟩
]

theorem checked12_2_17 : ∃ cert, Checked (rows11_1 17) rows12_2 2 cert :=
  ⟨routes12_2_17, by decide +kernel⟩

private def routes12_2_18 : List (Branch 11 23) := [
  
]

theorem checked12_2_18 : ∃ cert, Checked (rows11_1 18) rows12_2 2 cert :=
  ⟨routes12_2_18, by decide +kernel⟩

private def routes12_2_19 : List (Branch 11 23) := [
  ⟨{{0,5}, {1,7}, {2,8}, {3,6,9}, {4,10}},5,⟨1805754602432,6026891745567⟩⟩
]

theorem checked12_2_19 : ∃ cert, Checked (rows11_1 19) rows12_2 2 cert :=
  ⟨routes12_2_19, by decide +kernel⟩

private def routes12_2_20 : List (Branch 11 23) := [
  ⟨{{0,5}, {1,7}, {2,3}, {4,8,9}, {6,10}},0,⟨1796283201152,4535649528729⟩⟩
]

theorem checked12_2_20 : ∃ cert, Checked (rows11_1 20) rows12_2 2 cert :=
  ⟨routes12_2_20, by decide +kernel⟩

private def routes12_2_21 : List (Branch 11 23) := [
  
]

theorem checked12_2_21 : ∃ cert, Checked (rows11_1 21) rows12_2 2 cert :=
  ⟨routes12_2_21, by decide +kernel⟩

private def routes12_2_22 : List (Branch 11 23) := [
  
]

theorem checked12_2_22 : ∃ cert, Checked (rows11_1 22) rows12_2 2 cert :=
  ⟨routes12_2_22, by decide +kernel⟩

private def routes12_2_23 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,5,9}, {2,3}, {6}, {7}, {8,10}},0,⟨3874569869720,6083589834223⟩⟩
]

theorem checked12_2_23 : ∃ cert, Checked (rows11_1 23) rows12_2 2 cert :=
  ⟨routes12_2_23, by decide +kernel⟩

theorem balanced12_2_12 : Balanced (rows12_2 12) := by decide +kernel

theorem balanced12_2_13 : Balanced (rows12_2 13) := by decide +kernel

theorem balanced12_2_14 : Balanced (rows12_2 14) := by decide +kernel

theorem balanced12_2_15 : Balanced (rows12_2 15) := by decide +kernel

theorem balanced12_2_16 : Balanced (rows12_2 16) := by decide +kernel

theorem balanced12_2_17 : Balanced (rows12_2 17) := by decide +kernel

theorem balanced12_2_18 : Balanced (rows12_2 18) := by decide +kernel

theorem balanced12_2_19 : Balanced (rows12_2 19) := by decide +kernel

theorem balanced12_2_20 : Balanced (rows12_2 20) := by decide +kernel

theorem balanced12_2_21 : Balanced (rows12_2 21) := by decide +kernel

theorem balanced12_2_22 : Balanced (rows12_2 22) := by decide +kernel

end Cover61.Layers
