import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced10_1_84 : Balanced (rows10_1 84) := by decide +kernel

theorem balanced10_1_85 : Balanced (rows10_1 85) := by decide +kernel

theorem balanced10_1_86 : Balanced (rows10_1 86) := by decide +kernel

theorem balanced10_1_87 : Balanced (rows10_1 87) := by decide +kernel

theorem balanced10_1_88 : Balanced (rows10_1 88) := by decide +kernel

theorem balanced10_1_89 : Balanced (rows10_1 89) := by decide +kernel

theorem balanced10_1_90 : Balanced (rows10_1 90) := by decide +kernel

theorem balanced10_1_91 : Balanced (rows10_1 91) := by decide +kernel

theorem balanced10_1_92 : Balanced (rows10_1 92) := by decide +kernel

theorem balanced10_1_93 : Balanced (rows10_1 93) := by decide +kernel

theorem balanced10_1_94 : Balanced (rows10_1 94) := by decide +kernel

theorem balanced10_1_95 : Balanced (rows10_1 95) := by decide +kernel

end Cover61.Layers
