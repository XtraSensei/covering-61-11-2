import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end98 : EndOK 98 := by decide +kernel

theorem end99 : EndOK 99 := by decide +kernel

theorem end100 : EndOK 100 := by decide +kernel

theorem end101 : EndOK 101 := by decide +kernel

theorem end102 : EndOK 102 := by decide +kernel

theorem end103 : EndOK 103 := by decide +kernel

theorem end104 : EndOK 104 := by decide +kernel

theorem end105 : EndOK 105 := by decide +kernel

theorem end106 : EndOK 106 := by decide +kernel

theorem end107 : EndOK 107 := by decide +kernel

theorem end108 : EndOK 108 := by decide +kernel

theorem end109 : EndOK 109 := by decide +kernel

theorem end110 : EndOK 110 := by decide +kernel

theorem end111 : EndOK 111 := by decide +kernel

theorem reg35 : Regular (candidates 35) := by decide +kernel

theorem reg36 : Regular (candidates 36) := by decide +kernel

theorem reg37 : Regular (candidates 37) := by decide +kernel

theorem reg38 : Regular (candidates 38) := by decide +kernel

theorem reg39 : Regular (candidates 39) := by decide +kernel

end Cover61.Nine
