import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced10_1_96 : Balanced (rows10_1 96) := by decide +kernel

theorem balanced10_1_97 : Balanced (rows10_1 97) := by decide +kernel

theorem balanced10_1_98 : Balanced (rows10_1 98) := by decide +kernel

theorem balanced10_1_99 : Balanced (rows10_1 99) := by decide +kernel

theorem balanced10_1_100 : Balanced (rows10_1 100) := by decide +kernel

theorem balanced10_1_101 : Balanced (rows10_1 101) := by decide +kernel

theorem balanced10_1_102 : Balanced (rows10_1 102) := by decide +kernel

theorem balanced10_1_103 : Balanced (rows10_1 103) := by decide +kernel

theorem balanced10_1_104 : Balanced (rows10_1 104) := by decide +kernel

theorem balanced10_1_105 : Balanced (rows10_1 105) := by decide +kernel

theorem balanced10_1_106 : Balanced (rows10_1 106) := by decide +kernel

theorem balanced10_1_107 : Balanced (rows10_1 107) := by decide +kernel

end Cover61.Layers
