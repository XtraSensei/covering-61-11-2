import Mathlib.Data.Fintype.Fin
import Mathlib.Tactic.FinCases

namespace Cover61.Affine

/-- A row of three entries in the coordinate model of AG(2,3). -/
abbrev Row := Fin 3 → Bool

private theorem xorThree {a b₀ b₁ b₂ c₀ c₁ c₂ : Bool}
    (h₀ : (a ^^ b₀ ^^ c₀) = true) (h₁ : (a ^^ b₁ ^^ c₁) = true)
    (h₂ : (a ^^ b₂ ^^ c₂) = true) :
    a = (true ^^ b₀ ^^ b₁ ^^ b₂ ^^ c₀ ^^ c₁ ^^ c₂) := by
  revert h₀ h₁ h₂
  decide +revert

/-- Each transversal has odd parity. Summing those through a fixed point
over the binary field forces the representative differences on its row to be constant. -/
theorem row_constant (a b c : Row)
    (lines : ∀ i j : Fin 3, (a i ^^ b j ^^ c (i + j)) = true) :
    ∀ i, a i = a 0 := by
  have h (i : Fin 3) := xorThree (lines i 0) (lines i 1) (lines i 2)
  intro i
  rw [h i, h 0]
  have cycle (u v w z : Bool) :
      ((u ^^ w ^^ z ^^ v) = (u ^^ v ^^ w ^^ z)) ∧
      ((u ^^ z ^^ v ^^ w) = (u ^^ v ^^ w ^^ z)) := by decide +revert
  fin_cases i
  · rfl
  · exact (cycle _ (c 0) (c 1) (c 2)).1
  · exact (cycle _ (c 0) (c 1) (c 2)).2

/-- If the other two rows can each choose the representative or its complement,
one pair of choices has no matching bit in the common row. -/
theorem incompatible_choices (p q b c : Row)
    (lines : ∀ i j : Fin 3, ((p i ^^ q i) ^^ b j ^^ c (i + j)) = true) :
    ∃ flip : Bool, ∀ i, (p i ^^ flip) ≠ q i := by
  have h := row_constant (fun i => p i ^^ q i) b c lines
  refine ⟨!(p 0 ^^ q 0), ?_⟩
  intro i
  have hx := h i
  change (p i ^^ q i) = (p 0 ^^ q 0) at hx
  rw [← hx]
  cases p i <;> cases q i <;> decide

end Cover61.Affine
