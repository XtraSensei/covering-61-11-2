import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes11_2_48 : List (Branch 10 54) := [
  ⟨{{0,7}, {1,4}, {2,5}, {3,6,8}, {9}},29,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_48 : ∃ cert, Checked (rows10_1 48) rows11_2 2 cert :=
  ⟨routes11_2_48, by decide +kernel⟩

private def routes11_2_49 : List (Branch 10 54) := [
  ⟨{{0,8}, {1,6}, {2,4,7}, {3,5}, {9}},30,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,5}, {4,6}, {9}},28,⟨258142310165,258390576665⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9}},29,⟨258142310165,258390576665⟩⟩
]

theorem checked11_2_49 : ∃ cert, Checked (rows10_1 49) rows11_2 2 cert :=
  ⟨routes11_2_49, by decide +kernel⟩

private def routes11_2_50 : List (Branch 10 54) := [
  ⟨{{0,5,6}, {1,4}, {2,3}, {7,8}, {9}},30,⟨258879076995,258879076995⟩⟩,
  ⟨{{0,7}, {1,4}, {2,5}, {3,6,8}, {9}},30,⟨258390576665,258142310165⟩⟩,
  ⟨{{0,7}, {1,5,8}, {2,3}, {4,6}, {9}},30,⟨258395484755,258395484755⟩⟩
]

theorem checked11_2_50 : ∃ cert, Checked (rows10_1 50) rows11_2 2 cert :=
  ⟨routes11_2_50, by decide +kernel⟩

private def routes11_2_51 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,6,8}, {5,7}, {9}},25,⟨47850019355,125459399455⟩⟩
]

theorem checked11_2_51 : ∃ cert, Checked (rows10_1 51) rows11_2 2 cert :=
  ⟨routes11_2_51, by decide +kernel⟩

private def routes11_2_52 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,6,8}, {5,7}, {9}},26,⟨35857356695,106595772795⟩⟩
]

theorem checked11_2_52 : ∃ cert, Checked (rows10_1 52) rows11_2 2 cert :=
  ⟨routes11_2_52, by decide +kernel⟩

private def routes11_2_53 : List (Branch 10 54) := [
  ⟨{{0,8}, {1,6}, {2,4,7}, {3,5}, {9}},31,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9}},31,⟨282456898295,282456898295⟩⟩
]

theorem checked11_2_53 : ∃ cert, Checked (rows10_1 53) rows11_2 2 cert :=
  ⟨routes11_2_53, by decide +kernel⟩

private def routes11_2_54 : List (Branch 10 54) := [
  ⟨{{0}, {1,5,8}, {2,3}, {4}, {6,7}, {9}},27,⟨47841880235,47841880235⟩⟩,
  ⟨{{0,5,6}, {1}, {2,3}, {4}, {7,8}, {9}},14,⟨64699290765,17019184165⟩⟩,
  ⟨{{0,5,6}, {1,4}, {2,3}, {7,8}, {9}},31,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_54 : ∃ cert, Checked (rows10_1 54) rows11_2 2 cert :=
  ⟨routes11_2_54, by decide +kernel⟩

private def routes11_2_55 : List (Branch 10 54) := [
  ⟨{{0,5,6}, {1,4}, {2,3}, {7,8}, {9}},21,⟨59976023355,117157163455⟩⟩,
  ⟨{{0,5,6}, {1,4}, {2,7}, {3,8}, {9}},32,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,5,6}, {1,9}, {2,3}, {4}, {7,8}},21,⟨75487235635,234205875835⟩⟩,
  ⟨{{0,5,6}, {1,9}, {2,7}, {3,8}, {4}},32,⟨269303987485,269303987485⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9}},33,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,9}, {1,3,7}, {2,5}, {4}, {6,8}},33,⟨269303987485,269303987485⟩⟩
]

theorem checked11_2_55 : ∃ cert, Checked (rows10_1 55) rows11_2 2 cert :=
  ⟨routes11_2_55, by decide +kernel⟩

private def routes11_2_56 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,5}, {3,8}, {4,6,7}, {9}},25,⟨127924561275,244438365275⟩⟩
]

theorem checked11_2_56 : ∃ cert, Checked (rows10_1 56) rows11_2 2 cert :=
  ⟨routes11_2_56, by decide +kernel⟩

private def routes11_2_57 : List (Branch 10 54) := [
  ⟨{{0}, {1,3,7}, {2,5}, {4,9}, {6,8}},32,⟨128012218845,236485835845⟩⟩,
  ⟨{{0}, {1,9}, {2,4,8}, {3,6}, {5,7}},32,⟨127827126025,243366577525⟩⟩,
  ⟨{{0,7}, {1,6}, {2,4,8}, {3,5}, {9}},32,⟨117489159875,19361216375⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9}},32,⟨115939865095,17199915595⟩⟩
]

theorem checked11_2_57 : ∃ cert, Checked (rows10_1 57) rows11_2 2 cert :=
  ⟨routes11_2_57, by decide +kernel⟩

private def routes11_2_58 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,4,8}, {3,6}, {5,7}, {9}},21,⟨83555500265,117157164665⟩⟩,
  ⟨{{0}, {1,3,7}, {2,5}, {4}, {6,8}, {9}},21,⟨84338133765,41898178765⟩⟩,
  ⟨{{0,7}, {1,6}, {2,4,8}, {3,5}, {9}},34,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9}},34,⟨282262026585,282262026585⟩⟩
]

theorem checked11_2_58 : ∃ cert, Checked (rows10_1 58) rows11_2 2 cert :=
  ⟨routes11_2_58, by decide +kernel⟩

private def routes11_2_59 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,4,8}, {3,6}, {5,7}, {9}},32,⟨258879076995,258879076995⟩⟩,
  ⟨{{0}, {1,3,7}, {2,5}, {4}, {6,8}, {9}},32,⟨258682549675,258682549675⟩⟩,
  ⟨{{0,7}, {1,6}, {2,4,8}, {3,5}, {9}},35,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,3,7}, {2,6}, {4,5}, {9}},35,⟨282262026585,282262026585⟩⟩
]

theorem checked11_2_59 : ∃ cert, Checked (rows10_1 59) rows11_2 2 cert :=
  ⟨routes11_2_59, by decide +kernel⟩

theorem balanced11_2_48 : Balanced (rows11_2 48) := by decide +kernel

theorem balanced11_2_49 : Balanced (rows11_2 49) := by decide +kernel

theorem balanced11_2_50 : Balanced (rows11_2 50) := by decide +kernel

theorem balanced11_2_51 : Balanced (rows11_2 51) := by decide +kernel

theorem balanced11_2_52 : Balanced (rows11_2 52) := by decide +kernel

theorem balanced11_2_53 : Balanced (rows11_2 53) := by decide +kernel

end Cover61.Layers
