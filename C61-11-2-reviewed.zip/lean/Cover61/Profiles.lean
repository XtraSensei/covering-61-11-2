import Cover61.StructuralCover

namespace Cover61
open LocalRows

def frequency (B : Family 38) (r : Nat) := (Finset.univ.filter (fun x => degree B x=r)).card

theorem twelve_companion_cost (B : Family 38) (h : IsCover B) (a : (lows B).card=12)
    (i : Fin 38) (four : (marked B i).card=4) : excess B (companions B i)=3 := by
  have hi := local_excess_le B h i
  have lo := four_cost_three B h i four (no_five_of_le_fourteen B h (by omega)) (by omega)
  omega

theorem twelve_eights_in_quad (B : Family 38) (h : IsCover B) (a : (lows B).card=12)
    (i : Fin 38) (four : (marked B i).card=4) (x : Point) (dx : degree B x=8) : x ∈ companions B i := by
  by_contra no
  have sum := Finset.sum_le_univ_sum_of_nonneg (s := insert x (companions B i))
    (f := fun y => degree B y-7) (fun _ => Nat.zero_le _)
  rw [Finset.sum_insert no,dx] at sum
  change 1+excess B (companions B i)≤_ at sum
  rw [twelve_companion_cost B h a i four] at sum
  have := total_excess B h
  omega

theorem twelve_three_eights (B : Family 38) (h : IsCover B) (a : (lows B).card=12) : 3≤frequency B 8 := by
  have width := no_five_of_le_fourteen B h (by omega)
  obtain ⟨i,low⟩ := Layers.twelve_has_quad B h a
  have four : (marked B i).card=4 := Nat.le_antisymm (width i) low
  let lab := companionLabels B h i four
  let V := Finset.univ.filter (fun t : Fin 7 => degree B (lab t).val-7=1)
  have three : V.card=3 := four_cost_spread B h i four width (by omega) (twelve_companion_cost B h a i four) lab
  rw [←three]
  apply Finset.card_le_card_of_injOn (fun t => (lab t).val)
  · intro t ht
    have dx := (Finset.mem_filter.mp ht).2
    change degree B (lab t).val-7=1 at dx
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_univ _,?_⟩
    change degree B (lab t).val=8;omega
  · exact fun _ _ _ _ eq => lab.injective (Subtype.ext eq)

theorem frequency_totals (B : Family 38) (h : IsCover B) (small : (lows B).card≤12) :
    frequency B 6+frequency B 7+frequency B 8+frequency B 9+frequency B 10=61 ∧
    frequency B 8+2*frequency B 9+3*frequency B 10+9=(lows B).card ∧
    ∀ x,6≤degree B x ∧ degree B x≤10 := by
  have total := total_excess B h
  have bound (x : Point) : 6≤degree B x ∧ degree B x≤10 := by
    have le := Finset.single_le_sum (s := Finset.univ) (f := fun y => degree B y-7)
      (fun _ _ => Nat.zero_le _) (Finset.mem_univ x)
    exact ⟨degree_ge_six B h x,by omega⟩
  let idx (x : Point) : Fin 5 := ⟨degree B x-6,by have := bound x;omega⟩
  have freq (k : Fin 5) : FourView.countBy Finset.univ idx k=frequency B (k.val+6) := by
    unfold FourView.countBy frequency
    congr 1;ext x
    simp only [Finset.mem_filter,Finset.mem_univ,true_and]
    rw [Fin.ext_iff];change degree B x-6=k.val ↔ _
    have := bound x;omega
  let univ : Finset (Fin 5) := {0,1,2,3,4}
  have all : (Finset.univ : Finset (Fin 5))=univ := by decide
  have seats := FourView.weighted_count (Finset.univ : Finset Point) idx (fun _ => 1)
  have mass := FourView.weighted_count (Finset.univ : Finset Point) idx (fun k => k.val-1)
  rw [all] at seats mass
  have rel (x : Point) : (idx x).val-1=degree B x-7 := by simp [idx,Nat.sub_sub]
  simp [univ,freq,rel,add_comm,add_left_comm,add_assoc,Nat.mul_comm] at seats mass
  exact ⟨by omega,by omega,bound⟩

theorem allowed_profiles (B : Family 38) (h : IsCover B) (small : (lows B).card≤12) :
    let freq := fun s t u v w => frequency B 6=s ∧ frequency B 7=t ∧ frequency B 8=u ∧ frequency B 9=v ∧ frequency B 10=w
    freq 9 52 0 0 0 ∨ freq 10 50 1 0 0 ∨ freq 11 48 2 0 0 ∨ freq 11 49 0 1 0 ∨ freq 12 46 3 0 0 := by
  obtain ⟨count,extras,_⟩ := frequency_totals B h small
  have six : frequency B 6=(lows B).card := rfl
  have twelve := twelve_three_eights B h
  have min := nine_six_people B h
  dsimp only
  have cases : (lows B).card=9 ∨ (lows B).card=10 ∨ (lows B).card=11 ∨ (lows B).card=12 := by omega
  rcases cases with n|n|n|n
  · left;omega
  · right;left;omega
  · right;right
    by_cases nine : frequency B 9=0
    · left;omega
    · right;left;omega
  · have spread := twelve n
    right;right;right;right;omega

end Cover61
