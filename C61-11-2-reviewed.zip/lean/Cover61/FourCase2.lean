import Cover61.FourTariffs
import Mathlib.Tactic.FinCases

namespace Cover61.LocalRows.FourCase2
open FourView
set_option maxRecDepth 100000
set_option maxHeartbeats 6000000

def extra (i : Fin 7) : Nat := (#[1,1,0,0,0,0,0] : Array Nat)[i.val]!
private def classify (C : SevenSet) : Fin 18 := (#[0,1,1,2,3,4,4,5,3,4,4,5,6,7,7,8,3,4,4,5,6,7,7,8,6,7,7,8,9,10,10,11,3,4,4,5,6,7,7,8,6,7,7,8,9,10,10,11,6,7,7,8,9,10,10,11,9,10,10,11,12,13,13,14,3,4,4,5,6,7,7,8,6,7,7,8,9,10,10,11,6,7,7,8,9,10,10,11,9,10,10,11,12,13,13,14,6,7,7,8,9,10,10,11,9,10,10,11,12,13,13,14,9,10,10,11,12,13,13,14,12,13,13,14,15,16,16,17] : Array (Fin 18))[(mask C)%128]!
private def widths (i : Fin 18) : Nat := (#[0,1,2,1,2,3,2,3,4,3,4,5,4,5,6,5,6,7] : Array (Nat))[i.val]!
private def opposite (i : Fin 18) : Fin 18 := (#[17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0] : Array (Fin 18))[i.val]!
private def colors : Colors 18 where
  cls := classify
  size := widths
  other := opposite
  card := by decide +kernel
  complement := by decide +kernel
  otherSize := by decide +kernel

private def groups (i : Fin 2) : SevenSet := (#[{2,3,4,5,6},{0,1}] : Array (SevenSet))[i.val]!
private def units (j : Fin 2) (i : Fin 18) : Nat :=
  ((#[#[0,0,0,1,1,1,2,2,2,3,3,3,4,4,4,5,5,5],#[0,1,2,0,1,2,0,1,2,0,1,2,0,1,2,0,1,2]] : Array (Array Nat))[j.val]!)[i.val]!
private theorem units_ok : ∀ j C, units j (classify C)=(groups j ∩ C).card := by decide +kernel

private def words0 : List Nat := [1093]
private def pay0 (i : Fin 18) : Nat := (#[0,1,1,1,1,1,1,1,2,1,2,2,2,2,2,2,2,3] : Array (Nat))[i.val]!
private theorem costs0 : ∀ C : SevenSet, tariffs 3 words0 C=pay0 (classify C) := by decide +kernel
private theorem need0 : tariffs 3 words0 Finset.univ=3 := by decide +kernel
private theorem valid0 (v : FourView 7 extra) : v.ValidPrice (fun C => pay0 (classify C)) 3 := by
  have a := many_tariffs v 3 words0 (by decide)
  rw [need0,funext costs0] at a
  exact a

private def words1 : List Nat := [2177,2159,2105,1943,1457]
private def pay1 (i : Fin 18) : Nat := (#[0,5,5,5,5,5,5,5,10,5,10,10,10,10,10,10,10,15] : Array (Nat))[i.val]!
private theorem costs1 : ∀ C : SevenSet, tariffs 6 words1 C=pay1 (classify C) := by decide +kernel
private theorem need1 : tariffs 6 words1 Finset.univ=15 := by decide +kernel
private theorem valid1 (v : FourView 7 extra) : v.ValidPrice (fun C => pay1 (classify C)) 15 := by
  have a := many_tariffs v 6 words1 (by decide)
  rw [need1,funext costs1] at a
  exact a

private def words2 : List Nat := [2149,2095,1933,1447,2077,1915,1429,1861,1375,1213,2147,2093,1931,1445,2075,1913,1427,1859,1373,1211]
private def pay2 (i : Fin 18) : Nat := (#[0,30,60,32,62,92,64,94,124,96,126,156,128,158,188,160,190,220] : Array (Nat))[i.val]!
private theorem costs2 : ∀ C : SevenSet, tariffs 1 words2 C=pay2 (classify C) := by decide +kernel
private theorem need2 : tariffs 1 words2 Finset.univ=220 := by decide +kernel
private theorem valid2 (v : FourView 7 extra) : v.ValidPrice (fun C => pay2 (classify C)) 220 := by
  have a := many_tariffs v 1 words2 (by decide)
  rw [need2,funext costs2] at a
  exact a

private def words3 : List Nat := [2177,2159,2105,1943,1457]
private def pay3 (i : Fin 18) : Nat := (#[0,5,5,5,5,10,5,10,10,10,10,15,10,15,15,15,15,20] : Array (Nat))[i.val]!
private theorem costs3 : ∀ C : SevenSet, tariffs 4 words3 C=pay3 (classify C) := by decide +kernel
private theorem need3 : tariffs 4 words3 Finset.univ=20 := by decide +kernel
private theorem valid3 (v : FourView 7 extra) : v.ValidPrice (fun C => pay3 (classify C)) 20 := by
  have a := many_tariffs v 4 words3 (by decide)
  rw [need3,funext costs3] at a
  exact a

private def words4 : List Nat := [2052,1890,1404,1836,1350,1188,2034,1872,1386,1980,1656,684,1764,1278,1602,630,954,468,1800,1314,1152,1746,1260,1584,612,936,450,1044,882,396]
private def pay4 (i : Fin 18) : Nat := (#[0,0,0,36,36,36,72,72,72,108,108,108,144,144,144,180,180,180] : Array (Nat))[i.val]!
private theorem costs4 : ∀ C : SevenSet, tariffs 1 words4 C=pay4 (classify C) := by decide +kernel
private theorem need4 : tariffs 1 words4 Finset.univ=180 := by decide +kernel
private theorem valid4 (v : FourView 7 extra) : v.ValidPrice (fun C => pay4 (classify C)) 180 := by
  have a := many_tariffs v 1 words4 (by decide)
  rw [need4,funext costs4] at a
  exact a

private def pay (i : Fin 5) : Fin 18 → Nat := (#[pay0,pay1,pay2,pay3,pay4] : Array (Fin 18 → Nat))[i.val]!
private def need (i : Fin 5) : Nat := (#[3,15,220,20,180] : Array (Nat))[i.val]!
private def T : Table 7 18 2 5 extra where
  colors := colors
  group := groups
  units := units
  counts := units_ok
  price := pay
  target := need
  prices := by
    intro v j
    fin_cases j
    · exact valid0 v
    · exact valid1 v
    · exact valid2 v
    · exact valid3 v
    · exact valid4 v

private def document0 : List (Int × Rule 18 2 5) := [(10,.visits 0),(10,.visits 1),(-22,.size 3),(-26,.size 4),(1,.price 0)]
private def batch0 : List (List Nat) := [[0,0,0,1,13,0,1,2]]
private theorem checked0 : batch0.all (fun h => valid T (decodeHist h) document0)=true := by decide +kernel

private def document1 : List (Int × Rule 18 2 5) := [(45,.visits 0),(45,.visits 1),(-30,.chosen),(-55,.size 3),(-40,.size 4),(2,.price 1)]
private def batch1 : List (List Nat) := [[0,0,0,2,10,3,0,2],[0,0,0,1,12,2,0,2],[0,0,0,0,14,1,0,2],[0,0,0,0,14,0,2,1],[0,0,0,1,11,3,1,1],[0,0,0,0,13,2,1,1],[0,0,1,0,9,6,0,1],[0,0,0,2,8,6,0,1],[0,0,0,1,10,5,0,1],[0,0,0,0,12,4,0,1],[0,0,0,0,11,5,1,0],[0,0,0,0,10,7,0,0]]
private theorem checked1 : batch1.all (fun h => valid T (decodeHist h) document1)=true := by decide +kernel

private def document2 : List (Int × Rule 18 2 5) := [(22,.visits 1),(-66,.size 3),(-110,.size 4),(11,.budget 0),(2,.endpoint 5 true true)]
private def batch2 : List (List Nat) := [[0,0,0,2,11,0,3,1],[0,0,0,2,10,2,2,1],[0,0,0,1,12,1,2,1],[0,0,0,3,9,0,5,0],[0,0,0,2,10,1,4,0],[0,0,0,1,12,0,4,0]]
private theorem checked2 : batch2.all (fun h => valid T (decodeHist h) document2)=true := by decide +kernel

private def document3 : List (Int × Rule 18 2 5) := [(560,.visits 1),(-220,.chosen),(320,.size 1),(-960,.size 3),(-1980,.size 4),(1,.price 2),(145,.endpoint 5 true false),(288,.budget 0)]
private def batch3 : List (List Nat) := [[0,0,0,3,8,3,2,1],[0,0,0,4,5,6,1,1],[0,0,0,3,7,5,1,1],[0,0,0,2,9,4,1,1],[0,0,0,5,2,9,0,1],[0,0,0,4,4,8,0,1],[0,0,0,3,6,7,0,1],[0,0,0,4,6,3,4,0],[0,0,0,3,8,2,4,0],[0,0,0,5,3,6,3,0],[0,0,0,4,5,5,3,0],[0,0,0,3,7,4,3,0],[0,0,0,2,9,3,3,0],[0,0,0,1,11,2,3,0],[0,0,0,0,13,1,3,0]]
private theorem checked3 : batch3.all (fun h => valid T (decodeHist h) document3)=true := by decide +kernel

private def document4 : List (Int × Rule 18 2 5) := [(-1,.chosen),(1,.mass 2)]
private def batch4 : List (List Nat) := [[0,0,1,0,11,2,2,1],[0,0,1,0,10,4,1,1],[0,0,1,0,11,1,4,0],[0,0,1,0,10,3,3,0],[0,0,0,6,0,9,2,0],[0,1,0,0,8,6,2,0],[0,0,1,0,9,5,2,0],[0,0,0,0,12,3,2,0],[0,0,1,4,0,11,1,0],[0,1,0,0,7,8,1,0],[0,0,1,0,8,7,1,0],[0,0,0,5,0,12,0,0],[0,1,0,0,6,10,0,0],[0,0,1,0,7,9,0,0]]
private theorem checked4 : batch4.all (fun h => valid T (decodeHist h) document4)=true := by decide +kernel

private def document5 : List (Int × Rule 18 2 5) := [(-4,.visits 0),(4,.size 1),(4,.size 2),(-4,.size 4),(-12,.size 5),(1,.endpoint 2 false false),(1,.endpoint 5 true false),(2,.endpoint 2 true false),(2,.budget 0)]
private def batch5 : List (List Nat) := [[0,0,1,1,8,5,1,1],[0,0,1,2,5,8,0,1],[0,0,1,1,7,7,0,1],[0,0,1,1,9,2,4,0],[0,0,1,2,6,5,3,0],[0,0,1,1,8,4,3,0],[0,0,1,3,3,8,2,0],[0,0,2,0,6,7,2,0],[0,0,1,2,5,7,2,0],[0,0,1,1,7,6,2,0],[0,0,2,1,3,10,1,0],[0,0,2,0,5,9,1,0]]
private theorem checked5 : batch5.all (fun h => valid T (decodeHist h) document5)=true := by decide +kernel

private def document6 : List (Int × Rule 18 2 5) := [(-5,.visits 0),(-2,.chosen),(5,.size 1),(-5,.size 3),(-20,.size 4),(5,.endpoint 5 true false),(5,.budget 0),(1,.endpoint 7 false true),(1,.endpoint 7 true true),(2,.endpoint 9 false true)]
private def batch6 : List (List Nat) := [[0,0,0,5,2,8,2,0],[0,0,0,4,4,7,2,0],[0,0,0,5,1,10,1,0],[0,0,0,4,3,9,1,0],[0,0,0,4,2,11,0,0]]
private theorem checked6 : batch6.all (fun h => valid T (decodeHist h) document6)=true := by decide +kernel

private def document7 : List (Int × Rule 18 2 5) := [(-3,.visits 0),(-2,.chosen),(3,.size 1),(-3,.size 3),(-12,.size 4),(1,.endpoint 7 true false),(3,.budget 0),(2,.endpoint 5 true true),(1,.endpoint 7 false true),(2,.endpoint 9 false true)]
private def batch7 : List (List Nat) := [[0,0,0,3,6,6,2,0],[0,0,0,3,5,8,1,0],[0,0,0,3,4,10,0,0]]
private theorem checked7 : batch7.all (fun h => valid T (decodeHist h) document7)=true := by decide +kernel

private def document8 : List (Int × Rule 18 2 5) := [(-2,.visits 0),(-2,.chosen),(2,.size 1),(-2,.size 3),(-8,.size 4),(1,.endpoint 7 true false),(2,.endpoint 5 true false),(2,.budget 0),(1,.endpoint 7 false true),(2,.endpoint 9 false true)]
private def batch8 : List (List Nat) := [[0,0,0,2,8,5,2,0],[0,0,0,2,7,7,1,0],[0,0,0,2,6,9,0,0]]
private theorem checked8 : batch8.all (fun h => valid T (decodeHist h) document8)=true := by decide +kernel

private def document9 : List (Int × Rule 18 2 5) := [(-1,.chosen),(1,.mass 3)]
private def batch9 : List (List Nat) := [[0,0,0,1,10,4,2,0],[0,1,0,1,5,9,1,0],[0,0,0,1,9,6,1,0],[0,1,0,2,2,12,0,0],[0,1,0,1,4,11,0,0],[0,0,0,1,8,8,0,0]]
private theorem checked9 : batch9.all (fun h => valid T (decodeHist h) document9)=true := by decide +kernel

private def document10 : List (Int × Rule 18 2 5) := [(-20,.chosen),(50,.size 1),(45,.size 2),(80,.size 3),(70,.size 4),(90,.size 5),(1,.price 3)]
private def batch10 : List (List Nat) := [[0,0,1,3,2,10,1,0],[0,0,2,2,0,13,0,0],[0,0,2,1,2,12,0,0],[0,0,1,3,1,12,0,0],[0,0,2,0,4,11,0,0],[0,0,1,2,3,11,0,0]]
private theorem checked10 : batch10.all (fun h => valid T (decodeHist h) document10)=true := by decide +kernel

private def document11 : List (Int × Rule 18 2 5) := [(-540,.chosen),(360,.size 1),(-360,.size 3),(-1440,.size 4),(-3240,.size 5),(1,.price 4),(180,.endpoint 7 true false),(360,.endpoint 5 true false),(324,.budget 0),(240,.endpoint 2 true true),(180,.endpoint 7 false true),(360,.endpoint 9 false true),(360,.mass 2)]
private def batch11 : List (List Nat) := [[0,0,1,2,4,9,1,0],[0,0,1,1,6,8,1,0],[0,0,1,1,5,10,0,0]]
private theorem checked11 : batch11.all (fun h => valid T (decodeHist h) document11)=true := by decide +kernel

private def documents (i : Fin 12) : List (Int × Rule 18 2 5) := (#[document0,document1,document2,document3,document4,document5,document6,document7,document8,document9,document10,document11] : Array (List (Int × Rule 18 2 5)))[i.val]!
private def batches (i : Fin 12) : List (List Nat) := (#[batch0,batch1,batch2,batch3,batch4,batch5,batch6,batch7,batch8,batch9,batch10,batch11] : Array (List (List Nat)))[i.val]!
private theorem checked (j : Fin 12) : (batches j).all (fun h => valid T (decodeHist h) (documents j))=true := by
  fin_cases j
  · exact checked0
  · exact checked1
  · exact checked2
  · exact checked3
  · exact checked4
  · exact checked5
  · exact checked6
  · exact checked7
  · exact checked8
  · exact checked9
  · exact checked10
  · exact checked11

private def containsHistogram (h : List Nat) := (List.finRange 12).any (fun j => (batches j).contains h)
private theorem present : (Histogram.enumerate 7 17 44 350).all containsHistogram=true := by decide +kernel
theorem excluded (v : FourView 7 extra) : False := by
  have seats : 42+(∑ x,extra x)=44 := by decide +kernel
  have hs := v.possible_histogram
  rw [seats] at hs
  obtain ⟨j,_,ok⟩ := List.any_eq_true.mp (List.all_eq_true.mp present _ hs)
  have inside : Histogram.data v.hist 7 ∈ batches j := by simpa using ok
  have price := List.all_eq_true.mp (checked j) _ inside
  rw [read_hist] at price
  exact rejected T v (documents j) price

end Cover61.LocalRows.FourCase2
