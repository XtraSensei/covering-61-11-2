import Cover61.Moments

namespace Cover61.LocalRows

abbrev Photo := Fin 38

def through (B : Family 38) (i : Photo) (G : Finset Point) : Finset Photo :=
  (Finset.univ.erase i).filter (fun j => (G ∩ B j).Nonempty)

def clear (B : Family 38) (i : Photo) (G : Finset Point) : Finset Photo :=
  (Finset.univ.erase i) \ through B i G

def appearances (B : Family 38) (J : Finset Photo) (x : Point) : Finset Photo :=
  J.filter (fun j => x ∈ B j)

theorem through_other {B : Family 38} {i j : Photo} {G : Finset Point}
    (hj : j ∈ through B i G) : j ≠ i :=
  (Finset.mem_erase.mp (Finset.mem_filter.mp hj).1).1

/-- A second row through a marked point meets the pivot in that point alone. -/
theorem single_intersection (B : Family 38) (h : IsCover B) {i j : Photo}
    (G : Finset Point) (sub : G ⊆ B i) (six : ∀ x ∈ G, degree B x = 6)
    (hj : j ∈ through B i G) :
    ∃ x ∈ G, B i ∩ B j = {x} ∧ G ∩ B j = {x} := by
  obtain ⟨x,hx⟩ := (Finset.mem_filter.mp hj).2
  obtain ⟨xG,xj⟩ := Finset.mem_inter.mp hx
  have uniq (y : Point) (yi : y ∈ B i) (yj : y ∈ B j) : y = x :=
    (intersection_single B h x y (six x xG) i j (through_other hj).symm (sub xG) xj yi yj).symm
  refine ⟨x,xG,?_,?_⟩
  · ext y
    simp only [Finset.mem_inter,Finset.mem_singleton]
    exact ⟨fun z => uniq y z.1 z.2, fun e => e ▸ ⟨sub xG,xj⟩⟩
  · ext y
    simp only [Finset.mem_inter,Finset.mem_singleton]
    exact ⟨fun z => uniq y (sub z.1) z.2, fun e => e ▸ ⟨xG,xj⟩⟩

theorem block_sum (B : Family 38) (J : Finset Photo) (G : Finset Point) :
    ∑ j ∈ J, (G ∩ B j).card = ∑ x ∈ G, (appearances B J x).card := by
  calc
    _ = ∑ j ∈ J, ∑ x ∈ G, if x ∈ B j then 1 else 0 := by simp
    _ = ∑ x ∈ G, ∑ j ∈ J, if x ∈ B j then 1 else 0 := Finset.sum_comm
    _ = _ := by simp [appearances]

theorem counts (B : Family 38) (h : IsCover B) (i : Photo) (G : Finset Point)
    (sub : G ⊆ B i) (six : ∀ x ∈ G, degree B x = 6) :
    (through B i G).card = 5*G.card ∧ (clear B i G).card + 5*G.card = 37 := by
  have all := block_sum B Finset.univ G
  change ∑ j, (G ∩ B j).card = ∑ x ∈ G, degree B x at all
  rw [Finset.sum_congr rfl (g := fun _ => 6) six] at all
  have at_i : G ∩ B i = G := Finset.inter_eq_left.mpr sub
  have erase := Finset.sum_erase_add Finset.univ (fun j => (G ∩ B j).card) (Finset.mem_univ i)
  rw [at_i,all] at erase
  have indicator (j : Photo) (hj : j ∈ Finset.univ.erase i) :
      (G ∩ B j).card = if (G ∩ B j).Nonempty then 1 else 0 := by
    split
    next non =>
      obtain ⟨_,_,_,eq⟩ := single_intersection B h G sub six (Finset.mem_filter.mpr ⟨hj,non⟩)
      simp [eq]
    next no => simp [Finset.not_nonempty_iff_eq_empty.mp no]
  rw [Finset.sum_congr rfl indicator] at erase
  simp only [Finset.sum_boole,Finset.sum_const,nsmul_eq_mul] at erase
  have tally : (through B i G).card + G.card = G.card * 6 := by simpa [through] using erase
  have main : (through B i G).card = 5*G.card := by omega
  refine ⟨main,?_⟩
  have inc : through B i G ⊆ Finset.univ.erase i := Finset.filter_subset .. 
  rw [clear,Finset.card_sdiff_of_subset inc,← main,Nat.sub_add_cancel (Finset.card_le_card inc)]
  simp

theorem outside_counts (B : Family 38) (h : IsCover B) (i : Photo) (G : Finset Point)
    (sub : G ⊆ B i) (six : ∀ x ∈ G, degree B x = 6) (y : Point) (out : y ∉ B i) :
    (appearances B (through B i G) y).card = G.card ∧
    (appearances B (clear B i G) y).card + G.card = degree B y := by
  have meet (x : Point) (hx : x ∈ G) : partners B x y=1 :=
    six_meets_once B h x y (six x hx) (fun e => out (e ▸ sub hx))
  have eq := cross_sum B G {y}
  simp only [Finset.sum_singleton] at eq
  rw [Finset.sum_congr rfl meet] at eq
  have row (j : Photo) : (G ∩ B j).card * (({y} : Finset Point) ∩ B j).card =
      if j ∈ appearances B (through B i G) y then 1 else 0 := by
    by_cases jy : y ∈ B j
    · have ji : j ≠ i := fun e => out (e ▸ jy)
      by_cases non : (G ∩ B j).Nonempty
      · have tj : j ∈ through B i G := Finset.mem_filter.mpr ⟨Finset.mem_erase.mpr ⟨ji,Finset.mem_univ _⟩,non⟩
        obtain ⟨_,_,_,one⟩ := single_intersection B h G sub six tj
        simp [appearances,jy,tj,one]
      · simp [appearances,through,jy,Finset.not_nonempty_iff_eq_empty.mp non]
    · simp [appearances,jy]
  rw [Finset.sum_congr rfl (fun j _ => row j)] at eq
  simp at eq
  refine ⟨eq.symm,?_⟩
  let A := appearances B (Finset.univ.erase i) y
  have sz : A.card = degree B y := by
    unfold A appearances degree
    congr 1
    ext j
    simp only [Finset.mem_filter,Finset.mem_erase,Finset.mem_univ,and_true,true_and]
    exact ⟨And.right,fun jy => ⟨fun e => out (e ▸ jy),jy⟩⟩
  have inc : appearances B (through B i G) y ⊆ A := fun j hj =>
    Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp (Finset.mem_filter.mp hj).1).1,(Finset.mem_filter.mp hj).2⟩
  have diff : appearances B (clear B i G) y = A \ appearances B (through B i G) y := by
    ext j; simp [appearances,clear,A]; tauto
  rw [diff,Finset.card_sdiff_of_subset inc,← eq]
  have := Finset.card_le_card inc
  omega

theorem companion_only_clear (B : Family 38) (h : IsCover B) {i j : Photo}
    (G : Finset Point) (sub : G ⊆ B i) (six : ∀ x ∈ G, degree B x = 6)
    {z : Point} (comp : z ∈ B i \ G) (jz : z ∈ B j) (ji : j ≠ i) : j ∈ clear B i G := by
  apply Finset.mem_sdiff.mpr
  refine ⟨Finset.mem_erase.mpr ⟨ji,Finset.mem_univ _⟩,fun hj => ?_⟩
  obtain ⟨x,xg,one,_⟩ := single_intersection B h G sub six hj
  obtain ⟨zi,ng⟩ := Finset.mem_sdiff.mp comp
  have mem := Finset.mem_inter.mpr ⟨zi,jz⟩
  rw [one,Finset.mem_singleton] at mem
  exact ng (mem ▸ xg)

theorem five_forces_group (B : Family 38) (h : IsCover B) (i : Photo) (G : Finset Point)
    (sub : G ⊆ B i) (six : ∀ x ∈ G, degree B x=6) (five : G.card=5)
    (y : Point) (out : y ∉ B i) (low : degree B y=6) :
    ∃ j, appearances B (clear B i G) y = {j} ∧ B i \ G ⊆ B j := by
  have cnt := (outside_counts B h i G sub six y out).2
  rw [five,low] at cnt
  obtain ⟨j,unique⟩ := Finset.card_eq_one.mp (show (appearances B (clear B i G) y).card=1 by omega)
  refine ⟨j,unique,?_⟩
  intro z hz
  have ne : y ≠ z := fun e => out (e ▸ (Finset.mem_sdiff.mp hz).1)
  obtain ⟨k,yk,zk⟩ := h.2 y z ne
  have kc := companion_only_clear B h G sub six hz zk (fun e => out (e ▸ yk))
  have mem : k ∈ appearances B (clear B i G) y := Finset.mem_filter.mpr ⟨kc,yk⟩
  rw [unique,Finset.mem_singleton] at mem
  exact mem ▸ zk

theorem four_forces_complements (B : Family 38) (h : IsCover B) (i : Photo) (G : Finset Point)
    (sub : G ⊆ B i) (six : ∀ x ∈ G, degree B x=6) (four : G.card=4)
    (y : Point) (out : y ∉ B i) (low : degree B y=6) :
    ∃ j k, j ≠ k ∧ appearances B (clear B i G) y = {j,k} ∧
      ∀ z ∈ B i \ G, z ∈ B k ↔ z ∉ B j := by
  have cnt := (outside_counts B h i G sub six y out).2
  rw [four,low] at cnt
  obtain ⟨j,k,ne,both⟩ := Finset.card_eq_two.mp (show (appearances B (clear B i G) y).card=2 by omega)
  refine ⟨j,k,ne,both,?_⟩
  have atrow {t} (ht : t ∈ ({j,k} : Finset Photo)) := (Finset.mem_filter.mp (both ▸ ht :
    t ∈ appearances B (clear B i G) y)).2
  intro z hz
  have yz : y ≠ z := fun e => out (e ▸ (Finset.mem_sdiff.mp hz).1)
  constructor
  · intro zk zj
    exact yz (intersection_single B h y z low j k ne (atrow (by simp)) (atrow (by simp)) zj zk)
  · intro zj
    obtain ⟨t,yt,zt⟩ := h.2 y z yz
    have tc := companion_only_clear B h G sub six hz zt (fun e => out (e ▸ yt))
    have mem : t ∈ appearances B (clear B i G) y := Finset.mem_filter.mpr ⟨tc,yt⟩
    rw [both,Finset.mem_insert,Finset.mem_singleton] at mem
    rcases mem with rfl | rfl
    · contradiction
    · exact zt

end Cover61.LocalRows
