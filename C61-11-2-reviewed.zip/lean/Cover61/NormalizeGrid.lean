import Cover61.GridCoordinates
import Cover61.LatinMeaning

namespace Cover61.Grid
variable {α : Type} [DecidableEq α] {U : Finset α}

def Along (D : Axis U) (L : Finset α) := ∀ i,(L ∩ D.row i).card=1

def Axis.relabel (X : Axis U) (e : Equiv.Perm Five) : Axis U where
  row i := X.row (e i)
  sub i := X.sub _
  size i := X.size _
  cover x hx := by
    obtain ⟨i,mem,one⟩ := X.cover x hx
    refine ⟨e.symm i,by simpa using mem,fun j hj => ?_⟩
    exact e.injective (by simpa using one (e j) hj)

theorem Axis.relabel_coord (X : Axis U) (e : Equiv.Perm Five) (x : α) (hx : x ∈ U) :
    (X.relabel e).coord x=e.symm (X.coord x) := by
  apply (X.relabel e).coord_eq
  change x ∈ X.row (e (e.symm _));simpa using X.coord_mem x hx

namespace Chart
variable (D : Chart U)

def reindex (r c s : Equiv.Perm Five) : Chart U where
  R := D.R.relabel r
  C := D.C.relabel c
  S := D.S.relabel s
  rc i j := D.rc _ _
  rs i j := D.rs _ _
  cs i j := D.cs _ _

theorem reindex_cell (r c s : Equiv.Perm Five) (i j : Five) :
    (D.reindex r c s).cell i j=D.cell (r i) (c j) := by
  have both := (D.reindex r c s).cell_mem i j
  exact D.cell_of_mem both.1 both.2

theorem reindex_symbol (r c s : Equiv.Perm Five) (i j : Five) :
    (D.reindex r c s).symbol i j=s.symm (D.symbol (r i) (c j)) := by
  change (D.S.relabel s).coord _ = _
  rw [reindex_cell]
  exact D.S.relabel_coord _ _ (D.R.sub _ (D.cell_mem _ _).1)

theorem normalize : ∃ r s : Equiv.Perm Five,
    (∀ j,(D.reindex r (Equiv.refl _) s).symbol 0 j=j) ∧ (∀ i,(D.reindex r (Equiv.refl _) s).symbol i 0=i) := by
  classical
  let s : Equiv.Perm Five := Equiv.ofBijective (D.symbol 0) (Finite.injective_iff_bijective.mp (D.row_inj 0))
  let t : Equiv.Perm Five := Equiv.ofBijective (fun i => s.symm (D.symbol i 0))
    (Finite.injective_iff_bijective.mp (s.symm.injective.comp (D.col_inj 0)))
  have z : t 0=0 := s.symm_apply_apply 0
  have zero : t.symm 0=0 := t.injective (by simp [z])
  refine ⟨t.symm,s,?_,?_⟩
  · intro j;rw [reindex_symbol,zero];exact s.symm_apply_apply j
  · intro i;rw [reindex_symbol];exact t.apply_symm_apply i

def Reduced := (∀ j,D.symbol 0 j=j) ∧ ∀ i,D.symbol i 0=i
noncomputable def word (k : Nat) := LatinFive.pack (D.symbol ⟨k%5,Nat.mod_lt _ (by decide)⟩)

theorem word_at (i : Five) : D.word i.val=LatinFive.pack (D.symbol i) := by simp [word,Nat.mod_eq_of_lt i.isLt]

theorem latin_complete (red : D.Reduced) : LatinFive.rowPrefix D.word 5 ∈ LatinFive.squares := by
  apply LatinFive.complete
  · exact (D.word_at 0).trans (LatinFive.first_code _ red.1)
  · intro i hi
    rw [show D.word i=_ from D.word_at ⟨i,hi⟩]
    exact LatinFive.permutation_code _ (D.row_inj _)
  · intro i hi
    let k : Five := ⟨i,hi⟩
    change LatinFive.digit (D.word k.val) 0=k.val
    rw [word_at];exact (LatinFive.unpack _ 0).trans (congrArg Fin.val (red.2 k))
  · intro i hi j hj
    rw [show D.word i=_ from D.word_at ⟨i,hi⟩,show D.word j=_ from D.word_at ⟨j,by omega⟩]
    apply LatinFive.columns_apart
    intro k eq
    have same := D.col_inj k eq
    exact (Nat.ne_of_gt hj) (show i=j from congrArg Fin.val same)

end Chart
end Cover61.Grid
