import Mathlib.Tactic.FinCases
import Cover61.Layer12_2Part0
import Cover61.Layer12_2Part1
import Cover61.Layer12_2Part2
import Cover61.Layer12_2Part3
import Cover61.Layer12_2Part4
import Cover61.Layer12_2Part5
import Cover61.Layer12_2Part6
import Cover61.Layer12_2Part7
import Cover61.Layer12_2Part8
import Cover61.Layer12_2Part9
namespace Cover61.Layers
open Skeleton Growth
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
theorem steps12_2 (j : Fin 118) : ∃ cert, Checked (rows11_1 j) rows12_2 2 cert := by
  fin_cases j
  · exact checked12_2_0
  · exact checked12_2_1
  · exact checked12_2_2
  · exact checked12_2_3
  · exact checked12_2_4
  · exact checked12_2_5
  · exact checked12_2_6
  · exact checked12_2_7
  · exact checked12_2_8
  · exact checked12_2_9
  · exact checked12_2_10
  · exact checked12_2_11
  · exact checked12_2_12
  · exact checked12_2_13
  · exact checked12_2_14
  · exact checked12_2_15
  · exact checked12_2_16
  · exact checked12_2_17
  · exact checked12_2_18
  · exact checked12_2_19
  · exact checked12_2_20
  · exact checked12_2_21
  · exact checked12_2_22
  · exact checked12_2_23
  · exact checked12_2_24
  · exact checked12_2_25
  · exact checked12_2_26
  · exact checked12_2_27
  · exact checked12_2_28
  · exact checked12_2_29
  · exact checked12_2_30
  · exact checked12_2_31
  · exact checked12_2_32
  · exact checked12_2_33
  · exact checked12_2_34
  · exact checked12_2_35
  · exact checked12_2_36
  · exact checked12_2_37
  · exact checked12_2_38
  · exact checked12_2_39
  · exact checked12_2_40
  · exact checked12_2_41
  · exact checked12_2_42
  · exact checked12_2_43
  · exact checked12_2_44
  · exact checked12_2_45
  · exact checked12_2_46
  · exact checked12_2_47
  · exact checked12_2_48
  · exact checked12_2_49
  · exact checked12_2_50
  · exact checked12_2_51
  · exact checked12_2_52
  · exact checked12_2_53
  · exact checked12_2_54
  · exact checked12_2_55
  · exact checked12_2_56
  · exact checked12_2_57
  · exact checked12_2_58
  · exact checked12_2_59
  · exact checked12_2_60
  · exact checked12_2_61
  · exact checked12_2_62
  · exact checked12_2_63
  · exact checked12_2_64
  · exact checked12_2_65
  · exact checked12_2_66
  · exact checked12_2_67
  · exact checked12_2_68
  · exact checked12_2_69
  · exact checked12_2_70
  · exact checked12_2_71
  · exact checked12_2_72
  · exact checked12_2_73
  · exact checked12_2_74
  · exact checked12_2_75
  · exact checked12_2_76
  · exact checked12_2_77
  · exact checked12_2_78
  · exact checked12_2_79
  · exact checked12_2_80
  · exact checked12_2_81
  · exact checked12_2_82
  · exact checked12_2_83
  · exact checked12_2_84
  · exact checked12_2_85
  · exact checked12_2_86
  · exact checked12_2_87
  · exact checked12_2_88
  · exact checked12_2_89
  · exact checked12_2_90
  · exact checked12_2_91
  · exact checked12_2_92
  · exact checked12_2_93
  · exact checked12_2_94
  · exact checked12_2_95
  · exact checked12_2_96
  · exact checked12_2_97
  · exact checked12_2_98
  · exact checked12_2_99
  · exact checked12_2_100
  · exact checked12_2_101
  · exact checked12_2_102
  · exact checked12_2_103
  · exact checked12_2_104
  · exact checked12_2_105
  · exact checked12_2_106
  · exact checked12_2_107
  · exact checked12_2_108
  · exact checked12_2_109
  · exact checked12_2_110
  · exact checked12_2_111
  · exact checked12_2_112
  · exact checked12_2_113
  · exact checked12_2_114
  · exact checked12_2_115
  · exact checked12_2_116
  · exact checked12_2_117
theorem balanced12_2 (j : Fin 23) : Balanced (rows12_2 j) := by
  fin_cases j
  · exact balanced12_2_0
  · exact balanced12_2_1
  · exact balanced12_2_2
  · exact balanced12_2_3
  · exact balanced12_2_4
  · exact balanced12_2_5
  · exact balanced12_2_6
  · exact balanced12_2_7
  · exact balanced12_2_8
  · exact balanced12_2_9
  · exact balanced12_2_10
  · exact balanced12_2_11
  · exact balanced12_2_12
  · exact balanced12_2_13
  · exact balanced12_2_14
  · exact balanced12_2_15
  · exact balanced12_2_16
  · exact balanced12_2_17
  · exact balanced12_2_18
  · exact balanced12_2_19
  · exact balanced12_2_20
  · exact balanced12_2_21
  · exact balanced12_2_22
end Cover61.Layers
