import Cover61.FiveGrid

namespace Cover61.LocalRows

def groupPeople (B : Family 38) (i : Photo) := (groups B i).biUnion B
def exceptional (B : Family 38) (i : Photo) := groupPeople B i \ (companions B i ∪ lows B)
def ordinary (B : Family 38) (i : Photo) := (Finset.univ : Finset Point) \ groupPeople B i

theorem low_in_groups (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    lows B ⊆ groupPeople B i := by
  intro x hx;obtain ⟨hg,hx⟩ := groupOf_mem B h i five x hx
  exact Finset.mem_biUnion.mpr ⟨_,hg,hx⟩

theorem pivot_in_groups (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    B i ⊆ groupPeople B i := fun x hx => Finset.mem_biUnion.mpr ⟨i,(five_group_cover B h i five).1,hx⟩

theorem ordinary_away (B : Family 38) (i : Photo) {x : Point} (hx : x ∈ ordinary B i) {j : Photo}
    (jg : j ∈ groups B i) : x ∉ B j := fun mem => (Finset.mem_sdiff.mp hx).2 (Finset.mem_biUnion.mpr ⟨j,jg,mem⟩)

theorem exc_away (B : Family 38) (i : Photo) {x : Point} (hx : x ∈ exceptional B i) : x ∉ B i := by
  intro xi
  have no := Finset.mem_sdiff.mp hx
  by_cases low : x ∈ lows B
  · exact no.2 (Finset.mem_union_right _ low)
  · exact no.2 (Finset.mem_union_left _ (Finset.mem_sdiff.mpr ⟨xi,low⟩))

theorem exception_bound (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    (exceptional B i).card + (lows B).card ≤ 5*(groups B i).card := by
  let H := companions B i
  let G := groups B i
  let W := exceptional B i
  have sz := companion_card B h i
  have six : H.card=6 := by change (companions B i).card=6;omega
  have inside : W ∪ lows B ⊆ G.biUnion (fun j => B j \ H) := by
    intro x hx
    obtain ⟨allg,notH⟩ : x ∈ groupPeople B i ∧ x ∉ H := by
      rcases Finset.mem_union.mp hx with w|low
      · have mem := Finset.mem_sdiff.mp w
        exact ⟨mem.1,fun m => mem.2 (Finset.mem_union_left _ m)⟩
      · exact ⟨low_in_groups B h i five low,fun m => (Finset.mem_sdiff.mp m).2 low⟩
    obtain ⟨j,jg,xj⟩ := Finset.mem_biUnion.mp allg
    exact Finset.mem_biUnion.mpr ⟨j,jg,Finset.mem_sdiff.mpr ⟨xj,notH⟩⟩
  have pay := (Finset.card_le_card inside).trans Finset.card_biUnion_le
  have row (j : Photo) (jg : j ∈ G) : (B j \ H).card=5 := by
    rw [Finset.card_sdiff_of_subset (Finset.mem_filter.mp jg).2.1,h.1,six]
  have dis : Disjoint W (lows B) := Finset.disjoint_left.mpr (fun x hx low =>
    (Finset.mem_sdiff.mp hx).2 (Finset.mem_union_right _ low))
  rw [Finset.card_union_of_disjoint dis,Finset.sum_congr rfl row] at pay
  simpa [Nat.mul_comm] using pay

theorem cell_low_bound (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (j : Photo) (jc : j ∈ cells B i) : (marked B j).card≤(groups B i).card := by
  let V := marked B j
  have inj : Set.InjOn (groupOf B i) (V : Set Point) := by
    intro x xl y yl eq
    by_contra ne
    obtain ⟨low,xj⟩ := Finset.mem_inter.mp xl;obtain ⟨other,yj⟩ := Finset.mem_inter.mp yl
    exact Finset.disjoint_left.mp (same_group_disjoint B h i five x y low other ne eq)
      (Finset.mem_filter.mpr ⟨jc,xj⟩) (Finset.mem_filter.mpr ⟨jc,yj⟩)
  have sub : V.image (groupOf B i) ⊆ groups B i := by
    intro k hk;obtain ⟨x,xv,rfl⟩ := Finset.mem_image.mp hk
    exact (groupOf_mem B h i five x (Finset.mem_inter.mp xv).1).1
  have le := Finset.card_le_card sub
  rwa [Finset.card_image_of_injOn inj] at le

theorem cell_seats (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (j : Photo) (jc : j ∈ cells B i) :
    11≤(marked B j).card+(exceptional B i ∩ B j).card+(ordinary B i ∩ B j).card := by
  have noH (x : Point) (xh : x ∈ companions B i) (xj : x ∈ B j) : False := by
    obtain ⟨y,ym,one,_⟩ := single_intersection B h (marked B i) (marked_sub ..) (marked_six B i) jc
    have mem : x ∈ B i ∩ B j := Finset.mem_inter.mpr ⟨(Finset.mem_sdiff.mp xh).1,xj⟩
    rw [one,Finset.mem_singleton] at mem
    exact (Finset.mem_sdiff.mp xh).2 (mem ▸ (Finset.mem_inter.mp ym).1)
  have sub : B j ⊆ (marked B j ∪ (exceptional B i ∩ B j)) ∪ (ordinary B i ∩ B j) := by
    intro x hx
    by_cases low : x ∈ lows B
    · exact Finset.mem_union_left _ (Finset.mem_union_left _ (Finset.mem_inter.mpr ⟨low,hx⟩))
    · by_cases inG : x ∈ groupPeople B i
      · have ex : x ∈ exceptional B i := Finset.mem_sdiff.mpr ⟨inG,fun hm => (Finset.mem_union.mp hm).elim (fun m => noH x m hx) low⟩
        exact Finset.mem_union_left _ (Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨ex,hx⟩))
      · exact Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,inG⟩,hx⟩)
  have bound := (Finset.card_le_card sub).trans (Finset.card_union_le _ _)
  rw [h.1] at bound
  exact bound.trans (Nat.add_le_add_right (Finset.card_union_le _ _) _)

theorem three_per_line (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (cash : (∑ x,(degree B x-7)) ≤ excess B (companions B i)+3) (J : Finset Photo) (jfive : J.card=5)
    (S : Finset Point) (outside : S ⊆ ordinary B i) (all : ∀ x ∈ S,line B i x=J) : S.card≤3 := by
  by_contra! bad
  have visits (j : Photo) (hj : j ∈ J) : S ⊆ B j := by
    intro x hx;have mem : j ∈ line B i x := all x hx ▸ hj;exact (Finset.mem_filter.mp mem).2
  have each (x : Point) (hx : x ∈ S) : 1≤degree B x-7 := by
    have cost := shared_rows_budget B h S J visits x hx
    rw [jfive] at cost;omega
  have dis : Disjoint S (companions B i) := Finset.disjoint_left.mpr (fun x hx hc =>
    ordinary_away B i (outside hx) (five_group_cover B h i five).1 (Finset.mem_sdiff.mp hc).1)
  have limit := Finset.sum_le_univ_sum_of_nonneg (s := S ∪ companions B i) (f := fun x => degree B x-7) (fun _ => Nat.zero_le _)
  rw [Finset.sum_union dis] at limit
  change _ + excess B (companions B i) ≤ _ at limit
  have seats := Finset.sum_le_sum each
  simp at seats
  omega

end Cover61.LocalRows
