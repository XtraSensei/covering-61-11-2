import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_3_0 : List (Branch 11 19) := [
  
]

theorem checked12_3_0 : ∃ cert, Checked (rows11_2 0) rows12_3 3 cert :=
  ⟨routes12_3_0, by decide +kernel⟩

private def routes12_3_1 : List (Branch 11 19) := [
  ⟨{{0,6}, {1,8}, {2,4}, {3,5,7}, {9}, {10}},11,⟨3472309940869,6227119318761⟩⟩,
  ⟨{{0,6}, {1,8}, {2,4}, {3,5,7}, {9,10}},17,⟨8624091486252,8633979885036⟩⟩,
  ⟨{{0,8}, {1,4}, {2,6}, {3,5,7}, {9}, {10}},8,⟨5901667701996,7722021284076⟩⟩,
  ⟨{{0,8}, {1,4}, {2,6}, {3,5,7}, {9,10}},7,⟨8624873817384,8388036285288⟩⟩
]

theorem checked12_3_1 : ∃ cert, Checked (rows11_2 1) rows12_3 3 cert :=
  ⟨routes12_3_1, by decide +kernel⟩

private def routes12_3_2 : List (Branch 11 19) := [
  ⟨{{0,5}, {1,7}, {2,3}, {4,6,8}, {9}, {10}},11,⟨6196673966725,6227549279721⟩⟩,
  ⟨{{0,5}, {1,7}, {2,3}, {4,6,8}, {9,10}},17,⟨5899727460396,7891007346156⟩⟩,
  ⟨{{0,7}, {1,3}, {2,5}, {4,6,8}, {9}, {10}},11,⟨516777593981,2692620227627⟩⟩,
  ⟨{{0,7}, {1,3}, {2,5}, {4,6,8}, {9,10}},17,⟨5445378131732,6816483090351⟩⟩
]

theorem checked12_3_2 : ∃ cert, Checked (rows11_2 2) rows12_3 3 cert :=
  ⟨routes12_3_2, by decide +kernel⟩

private def routes12_3_3 : List (Branch 11 19) := [
  
]

theorem checked12_3_3 : ∃ cert, Checked (rows11_2 3) rows12_3 3 cert :=
  ⟨routes12_3_3, by decide +kernel⟩

private def routes12_3_4 : List (Branch 11 19) := [
  ⟨{{0,8}, {1,4,7}, {2,5}, {3,6}, {9,10}},10,⟨8617207602498,8613753255536⟩⟩,
  ⟨{{0,9}, {1,4,7}, {2,6}, {3}, {5,8}, {10}},15,⟨5442427998216,2828817890844⟩⟩
]

theorem checked12_3_4 : ∃ cert, Checked (rows11_2 4) rows12_3 3 cert :=
  ⟨routes12_3_4, by decide +kernel⟩

private def routes12_3_5 : List (Branch 11 19) := [
  ⟨{{0}, {1,4,7}, {2,6}, {3}, {5,8}, {9,10}},10,⟨2207541989994,7942086011431⟩⟩,
  ⟨{{0,8}, {1,4,7}, {2,5}, {3,6}, {9}, {10}},10,⟨3471460830519,2398495858209⟩⟩,
  ⟨{{0,8}, {1,4,7}, {2,5}, {3,6}, {9,10}},12,⟨5153080154343,7629665717586⟩⟩
]

theorem checked12_3_5 : ∃ cert, Checked (rows11_2 5) rows12_3 3 cert :=
  ⟨routes12_3_5, by decide +kernel⟩

private def routes12_3_6 : List (Branch 11 19) := [
  
]

theorem checked12_3_6 : ∃ cert, Checked (rows11_2 6) rows12_3 3 cert :=
  ⟨routes12_3_6, by decide +kernel⟩

private def routes12_3_7 : List (Branch 11 19) := [
  
]

theorem checked12_3_7 : ∃ cert, Checked (rows11_2 7) rows12_3 3 cert :=
  ⟨routes12_3_7, by decide +kernel⟩

private def routes12_3_8 : List (Branch 11 19) := [
  
]

theorem checked12_3_8 : ∃ cert, Checked (rows11_2 8) rows12_3 3 cert :=
  ⟨routes12_3_8, by decide +kernel⟩

private def routes12_3_9 : List (Branch 11 19) := [
  
]

theorem checked12_3_9 : ∃ cert, Checked (rows11_2 9) rows12_3 3 cert :=
  ⟨routes12_3_9, by decide +kernel⟩

private def routes12_3_10 : List (Branch 11 19) := [
  
]

theorem checked12_3_10 : ∃ cert, Checked (rows11_2 10) rows12_3 3 cert :=
  ⟨routes12_3_10, by decide +kernel⟩

private def routes12_3_11 : List (Branch 11 19) := [
  
]

theorem checked12_3_11 : ∃ cert, Checked (rows11_2 11) rows12_3 3 cert :=
  ⟨routes12_3_11, by decide +kernel⟩

theorem balanced12_3_0 : Balanced (rows12_3 0) := by decide +kernel

theorem balanced12_3_1 : Balanced (rows12_3 1) := by decide +kernel

theorem balanced12_3_2 : Balanced (rows12_3 2) := by decide +kernel

theorem balanced12_3_3 : Balanced (rows12_3 3) := by decide +kernel

theorem balanced12_3_4 : Balanced (rows12_3 4) := by decide +kernel

theorem balanced12_3_5 : Balanced (rows12_3 5) := by decide +kernel

theorem balanced12_3_6 : Balanced (rows12_3 6) := by decide +kernel

theorem balanced12_3_7 : Balanced (rows12_3 7) := by decide +kernel

theorem balanced12_3_8 : Balanced (rows12_3 8) := by decide +kernel

theorem balanced12_3_9 : Balanced (rows12_3 9) := by decide +kernel

theorem balanced12_3_10 : Balanced (rows12_3 10) := by decide +kernel

theorem balanced12_3_11 : Balanced (rows12_3 11) := by decide +kernel

end Cover61.Layers
