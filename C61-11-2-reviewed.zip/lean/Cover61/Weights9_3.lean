import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w9_21Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {0,7,8}, {1,3,5}, {1,4,7}, {2,5,7}, {3,6,8}, {1,6}, {1,8}, {2,3}, {2,4}, {2,6}, {2,8}, {3,7}, {4,5}, {4,6}, {4,8}, {5,8}, {6,7}, {0}, {0}, {1}, {3}, {5}, {7}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_21Cost : Cost := fun i =>
  ([0, 0, 0, 0, -1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_21_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_21Rows :=
  Weighted.exclude _ w9_21Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_24Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,5}, {1,4,6}, {2,3,7}, {2,6,8}, {4,7,8}, {0,7}, {0,8}, {1,7}, {1,8}, {2,4}, {2,5}, {3,6}, {3,8}, {4,5}, {5,7}, {5,8}, {6,7}, {0}, {1}, {2}, {3}, {4}, {6}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_24Cost : Cost := fun i =>
  ([-1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_24_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_24Rows :=
  Weighted.exclude _ w9_24Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_25Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,5}, {1,4,6}, {2,3,7}, {4,5,8}, {6,7,8}, {0,7}, {0,8}, {1,7}, {1,8}, {2,4}, {2,5}, {2,6}, {2,8}, {3,6}, {3,8}, {4,7}, {5,7}, {0}, {1}, {3}, {4}, {5}, {6}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_25Cost : Cost := fun i =>
  ([-1, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_25_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_25Rows :=
  Weighted.exclude _ w9_25Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_29Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,5}, {1,4,7}, {2,4,6}, {2,5,8}, {3,7,8}, {0,7}, {0,8}, {1,6}, {1,8}, {2,3}, {2,7}, {3,6}, {4,5}, {4,8}, {5,7}, {6,7}, {6,8}, {0}, {1}, {2}, {3}, {4}, {5}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_29Cost : Cost := fun i =>
  ([0, -1, -4, -2, 0, -2, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 2, 1, 3, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_29_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_29Rows :=
  Weighted.exclude _ w9_29Cost (2) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
