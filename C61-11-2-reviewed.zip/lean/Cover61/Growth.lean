import Cover61.BigRows

namespace Cover61.Growth
open Skeleton

def branches {n : Nat} (r : Rows n) : Nat → Row n → Finset (Sys n)
  | 0, U => if U=∅ then {∅} else ∅
  | k+1, U => if hu : U.Nonempty then
      (Finset.univ.filter (fun i => U.min' hu ∈ r i ∧ r i ⊆ U)).biUnion
        (fun i => (branches r k (U \ r i)).image (insert (r i)))
    else {∅}

def picks {n} (r : Rows n) (T : Finset (Fin 38)) := (T.image r).erase ∅

private theorem none {n} (r : Rows n) (T : Finset (Fin 38)) (U : Row n)
    (fits : Weighted.Fits r T U) (em : U=∅) : picks r T = ∅ := by
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro s hs
    obtain ⟨non,hm⟩ := Finset.mem_erase.mp hs
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hm
    obtain ⟨x,hx⟩ := Finset.nonempty_iff_ne_empty.mpr non
    have pos := Finset.card_pos.mpr (show (T.filter (fun j => x ∈ r j)).Nonempty from
      ⟨i,Finset.mem_filter.mpr ⟨hi,hx⟩⟩)
    simpa [fits x,em] using pos

theorem branches_complete {n : Nat} (r : Rows n) (fuel : Nat) (T : Finset (Fin 38))
    (U : Row n) (fits : Weighted.Fits r T U) (small : T.card ≤ fuel) :
    picks r T ∈ branches r fuel U := by
  induction fuel generalizing U T with
  | zero =>
    have he : T=∅ := Finset.card_eq_zero.mp (by omega)
    have hu : U=∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro x hx
      simpa [he,hx] using fits x
    simp [branches,hu,none r T U fits hu]
  | succ fuel ih =>
    by_cases hu : U.Nonempty
    · have hx := fits (U.min' hu)
      simp only [Finset.min'_mem,ite_true] at hx
      obtain ⟨i,hi⟩ := Finset.card_pos.mp (show 0 < (T.filter (fun j => U.min' hu ∈ r j)).card by omega)
      obtain ⟨hiT,px⟩ := Finset.mem_filter.mp hi
      have sub : r i ⊆ U := by
        intro x hxr
        by_contra no
        have pos := Finset.card_pos.mpr (show (T.filter (fun j => x ∈ r j)).Nonempty from
          ⟨i,Finset.mem_filter.mpr ⟨hiT,hxr⟩⟩)
        simpa [fits x,no] using pos
      have rest : Weighted.Fits r (T.erase i) (U \ r i) := by
        intro x
        have eq : (T.erase i).filter (fun j => x ∈ r j) = (T.filter (fun j => x ∈ r j)).erase i := by ext j; simp [and_assoc]
        rw [eq]
        by_cases hr : x ∈ r i
        · rw [Finset.card_erase_of_mem (Finset.mem_filter.mpr ⟨hiT,hr⟩),fits x]
          simp [hr,sub hr]
        · have hn : i ∉ T.filter (fun j => x ∈ r j) := by simp [hr]
          rw [Finset.erase_eq_of_notMem hn,fits x]
          simp [hr]
      have lt : (T.erase i).card ≤ fuel := by rw [Finset.card_erase_of_mem hiT]; omega
      have smaller :=  ih _ _ rest lt
      have ne := Finset.nonempty_iff_ne_empty.mp (show (r i).Nonempty from ⟨_,px⟩)
      have eq : picks r T = insert (r i) (picks r (T.erase i)) := by
        unfold picks
        conv_lhs => rw [← Finset.insert_erase hiT]
        rw [Finset.image_insert,Finset.erase_insert_of_ne ne]
      rw [branches,dif_pos hu,eq]
      exact Finset.mem_biUnion.mpr ⟨i,Finset.mem_filter.mpr ⟨Finset.mem_univ _,px,sub⟩,
        Finset.mem_image.mpr ⟨_,smaller,rfl⟩⟩
    · have em := Finset.not_nonempty_iff_eq_empty.mp hu
      simp [branches,hu,none r T U fits em]

def lift {n : Nat} (s : Row n) : Row (n+1) := s.map Fin.castSuccEmb
def plus {n : Nat} (s : Row n) : Row (n+1) := insert (Fin.last n) (lift s)
def extension {n} (r : Rows n) (T : Finset (Fin 38)) : Rows (n+1) :=
  fun i => if i ∈ T then plus (r i) else lift (r i)
def highAfter {n} (r : Rows n) (P : Sys n) : Sys (n+1) :=
  ((big r \ P).image lift) ∪ ((P.filter (fun s => 2 ≤ s.card)).image plus)

theorem last_not_lift {n} (s : Row n) : Fin.last n ∉ lift s := by
  intro h
  obtain ⟨x,_,eq⟩ := Finset.mem_map.mp h
  exact Fin.castSucc_ne_last x eq

@[simp] theorem card_lift {n} (s : Row n) : (lift s).card = s.card := Finset.card_map _
@[simp] theorem card_plus {n} (s : Row n) : (plus s).card = s.card+1 := by simp [plus,last_not_lift]

theorem uniqRow {n} (r : Rows n) (bal : Balanced r) {i j} (same : r i = r j) (two : 2 ≤ (r i).card) : i=j := by
  by_contra ne
  have le := uniqueIndex r bal (r i) two
  have sub : ({i,j} : Finset _) ⊆ containing r (r i) := by
    intro k hk
    simp only [Finset.mem_insert,Finset.mem_singleton] at hk
    rcases hk with rfl | rfl <;> simp [containing,same]
  have bad := (Finset.card_le_card sub).trans le
  simp [ne] at bad

theorem high_extension {n} (r : Rows n) (bal : Balanced r) (T : Finset (Fin 38)) :
    big (extension r T) = highAfter r (picks r T) := by
  ext w
  rw [big_mem]
  constructor
  · rintro ⟨⟨i,rfl⟩,sz⟩
    by_cases hi : i ∈ T
    · simp [extension,hi] at sz ⊢
      apply Finset.mem_union_right
      apply Finset.mem_image.mpr
      refine ⟨r i,Finset.mem_filter.mpr ⟨Finset.mem_erase.mpr ⟨?_,Finset.mem_image_of_mem _ hi⟩,by omega⟩,rfl⟩
      intro he; simp [he] at sz
    · simp only [extension,if_neg hi,card_lift] at sz ⊢
      apply Finset.mem_union_left
      apply Finset.mem_image.mpr
      refine ⟨r i,Finset.mem_sdiff.mpr ⟨(big_mem _ _).mpr ⟨⟨i,rfl⟩,sz⟩,?_⟩,rfl⟩
      intro pick
      obtain ⟨j,hj,eq⟩ := Finset.mem_image.mp (Finset.mem_erase.mp pick).2
      have ji := uniqRow r bal eq.symm (by omega)
      exact hi (ji ▸ hj)
  · intro hw
    rcases Finset.mem_union.mp hw with left | right
    · obtain ⟨s,hs,rfl⟩ := Finset.mem_image.mp left
      obtain ⟨inB,no⟩ := Finset.mem_sdiff.mp hs
      obtain ⟨⟨i,rfl⟩,sz⟩ := (big_mem _ _).mp inB
      have hi : i ∉ T := by
        intro hi
        apply no
        apply Finset.mem_erase.mpr
        exact ⟨fun eq => by simp [eq] at sz, Finset.mem_image_of_mem _ hi⟩
      exact ⟨⟨i,by simp [extension,hi]⟩,by simpa⟩
    · obtain ⟨s,hs,rfl⟩ := Finset.mem_image.mp right
      obtain ⟨ins,sz⟩ := Finset.mem_filter.mp hs
      obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp (Finset.mem_erase.mp ins).2
      exact ⟨⟨i,by simp [extension,hi]⟩,by rw [card_plus]; omega⟩

end Cover61.Growth
