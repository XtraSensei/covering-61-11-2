import Cover61.FourView

namespace Cover61.LocalRows
namespace FourView

def countBy {α β : Type} [DecidableEq β] (X : Finset α) (f : α → β) (b : β) :=
  (X.filter (fun x => f x=b)).card

theorem weighted_count {α β : Type} [Fintype β] [DecidableEq β] (X : Finset α) (f : α→β) (w : β→Nat) :
    ∑ b, countBy X f b*w b = ∑ x ∈ X,w (f x) := by
  calc
    _ = ∑ b : β, ∑ x ∈ X, if f x=b then w b else 0 := by
      apply Finset.sum_congr rfl
      intro b _
      rw [← Finset.sum_filter]
      simp [countBy]
    _ = _ := by rw [Finset.sum_comm]; simp

structure Colors (n : Nat) where
  cls : SevenSet → Fin n
  size : Fin n → Nat
  other : Fin n → Fin n
  card : ∀ c, size (cls c)=c.card
  complement : ∀ c, cls cᶜ=other (cls c)
  otherSize : ∀ i, size (other i) = 7-size i

variable {R n : Nat} {e : Fin 7→Nat} (v : FourView R e) (colors : Colors n)

def rowCount := countBy v.J (fun j => colors.cls (v.C j))
def lowCount := countBy v.S (fun y => colors.cls (v.C (v.left y)))
def hist := countBy v.J (fun j => (v.C j).card)

theorem hist_eq (s : Nat) :
    ∑ a, v.rowCount colors a*(if colors.size a=s then 1 else 0)=v.hist s := by
  rw [rowCount,weighted_count]
  simp [Colors.card,hist,countBy]

theorem low_total : ∑ a, v.lowCount colors a=R := by
  have total := weighted_count v.S (fun y => colors.cls (v.C (v.left y))) (fun _ => 1)
  simpa [lowCount,v.chosen] using total

theorem row_le_hist (a : Fin n) : v.rowCount colors a ≤ v.hist (colors.size a) := by
  apply Finset.card_le_card
  intro j hj
  obtain ⟨jj,eq⟩ := Finset.mem_filter.mp hj
  exact Finset.mem_filter.mpr ⟨jj,(colors.card _).symm.trans (congrArg colors.size eq)⟩

theorem low_slots (a : Fin n) :
    v.lowCount colors a ≤ min (v.rowCount colors a*v.rowCount colors (colors.other a))
      (min (4*v.rowCount colors a) (4*v.rowCount colors (colors.other a))) := by
  apply v.slots _ (Finset.filter_subset ..)
  intro y hy
  obtain ⟨ys,eq⟩ := Finset.mem_filter.mp hy
  obtain ⟨l,r,_,comp⟩ := v.endpoints y ys
  exact ⟨Finset.mem_filter.mpr ⟨l,eq⟩,Finset.mem_filter.mpr ⟨r,by
    change colors.cls (v.C (v.right y))=colors.other a
    change colors.cls (v.C (v.left y))=a at eq
    rw [comp,colors.complement,eq]⟩⟩

def cap (h : Nat → Nat) (s : Nat) := min (h s*h (7-s)) (min (4*h s) (4*h (7-s)))

theorem size_slots (s : Nat) :
    ∑ a, v.lowCount colors a*(if colors.size a=s then 1 else 0) ≤ cap v.hist s := by
  rw [lowCount,weighted_count]
  simp only [Colors.card,Finset.sum_boole,Nat.cast_id]
  apply v.slots _ (Finset.filter_subset ..)
  intro y hy
  obtain ⟨ys,eq⟩ := Finset.mem_filter.mp hy
  obtain ⟨l,r,_,comp⟩ := v.endpoints y ys
  exact ⟨Finset.mem_filter.mpr ⟨l,eq⟩,Finset.mem_filter.mpr ⟨r,by
    change (v.C (v.right y)).card = 7-s
    rw [comp,Finset.card_compl,eq,Fintype.card_fin]⟩⟩

theorem visits_group (P : SevenSet) (units : Fin n→Nat)
    (correct : ∀ C, units (colors.cls C)=(P ∩ C).card) :
    ∑ a, v.rowCount colors a*units a=∑ x ∈ P,(6+e x) := by
  rw [rowCount,weighted_count]
  simp only [correct]
  calc
    _ = ∑ j ∈ v.J, ∑ x ∈ P, if x ∈ v.C j then 1 else 0 := by
      apply Finset.sum_congr rfl
      intro j _
      simp only [Finset.sum_boole,Nat.cast_id]
      congr 1
    _ = _ := by rw [Finset.sum_comm]; simp [v.people]

theorem budget_group (P : SevenSet) (units : Fin n→Nat)
    (correct : ∀ C, units (colors.cls C)=(P ∩ C).card) :
    ∑ a, v.rowCount colors a*(units a*(colors.size a-1))≤∑ x ∈ P,10*(1+e x) := by
  rw [rowCount,weighted_count]
  simp only [correct,Colors.card]
  have eq (j : Photo) : (P ∩ v.C j).card*((v.C j).card-1) =
      ∑ x ∈ P, if x ∈ v.C j then (v.C j).card-1 else 0 := by
    rw [← Finset.sum_filter]
    have same : P.filter (fun x => x ∈ v.C j)=P ∩ v.C j := by ext x; simp
    simp [same]
  simp only [eq]; rw [Finset.sum_comm]
  exact Finset.sum_le_sum (fun x _ => by simpa [Finset.sum_filter] using v.budget x)

/-- Any price on colors whose pullback has a valid outsider inequality can
be used without assuming that any two underlying points are interchangeable. -/
def ValidPrice (p : SevenSet → Nat) (t : Nat) : Prop :=
  (50-R)*t+(∑ y ∈ v.S,(p (v.C (v.left y))+p (v.C (v.right y)))) ≤
    ∑ j ∈ v.J,(11-(v.C j).card)*p (v.C j)

theorem add_price {p q : SevenSet → Nat} {s t : Nat} (a : v.ValidPrice p s) (b : v.ValidPrice q t) :
    v.ValidPrice (fun C => p C+q C) (s+t) := by
  unfold ValidPrice at *
  have eq (y : Point) : p (v.C (v.left y))+q (v.C (v.left y))+(p (v.C (v.right y))+q (v.C (v.right y))) =
      (p (v.C (v.left y))+p (v.C (v.right y)))+(q (v.C (v.left y))+q (v.C (v.right y))) := by omega
  simp only [eq,Nat.mul_add,Finset.sum_add_distrib] at *
  omega

theorem grouped_price (p : Fin n→Nat) (target : Nat)
    (valid : v.ValidPrice (fun C => p (colors.cls C)) target) :
    (50-R)*target + (∑ a, v.lowCount colors a*(p a+p (colors.other a))) ≤
      ∑ a,v.rowCount colors a*((11-colors.size a)*p a) := by
  rw [lowCount,weighted_count,rowCount,weighted_count]
  have right (y : Point) (hy : y ∈ v.S) :
      p (colors.other (colors.cls (v.C (v.left y))))=p (colors.cls (v.C (v.right y))) := by
    rw [(v.endpoints y hy).2.2.2,colors.complement]
  simpa [ValidPrice,Colors.card,Finset.sum_add_distrib,Finset.sum_congr rfl right] using valid

end FourView
end Cover61.LocalRows
