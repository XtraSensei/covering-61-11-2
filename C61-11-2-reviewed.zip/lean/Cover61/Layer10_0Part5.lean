import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced10_0_60 : Balanced (rows10_0 60) := by decide +kernel

theorem balanced10_0_61 : Balanced (rows10_0 61) := by decide +kernel

theorem balanced10_0_62 : Balanced (rows10_0 62) := by decide +kernel

theorem balanced10_0_63 : Balanced (rows10_0 63) := by decide +kernel

theorem balanced10_0_64 : Balanced (rows10_0 64) := by decide +kernel

end Cover61.Layers
