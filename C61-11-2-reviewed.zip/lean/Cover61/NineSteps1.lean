import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext12 : ∀ t, GoodStep 12 t := by decide +kernel

theorem ext13 : ∀ t, GoodStep 13 t := by decide +kernel

theorem ext14 : ∀ t, GoodStep 14 t := by decide +kernel

theorem ext15 : ∀ t, GoodStep 15 t := by decide +kernel

theorem ext16 : ∀ t, GoodStep 16 t := by decide +kernel

theorem ext17 : ∀ t, GoodStep 17 t := by decide +kernel

theorem ext18 : ∀ t, GoodStep 18 t := by decide +kernel

theorem ext19 : ∀ t, GoodStep 19 t := by decide +kernel

theorem ext20 : ∀ t, GoodStep 20 t := by decide +kernel

theorem ext21 : ∀ t, GoodStep 21 t := by decide +kernel

theorem ext22 : ∀ t, GoodStep 22 t := by decide +kernel

theorem ext23 : ∀ t, GoodStep 23 t := by decide +kernel

end Cover61.Nine
