import Cover61.FourRows
import Cover61.RepeatBudget

namespace Cover61.LocalRows

/-- A weighted set cover of the pivot companions gives a lower price for
every outsider, including when only a prescribed subset of outsiders is counted. -/
theorem weighted_companion_cut (B : Family 38) (h : IsCover B) (i : Photo)
    (A : Finset Point) (outside : ∀ y ∈ A, y ∉ B i)
    (w : Point → Nat) (price : Photo → Nat) (divisor target : Nat)
    (rounds : ∀ j ∈ clear B i (marked B i),
      (∑ z ∈ companions B i ∩ B j, w z) ≤ divisor * price j)
    (need : divisor * (target-1) < ∑ z ∈ companions B i, w z) :
    A.card * target ≤ ∑ j ∈ clear B i (marked B i), (A ∩ B j).card * price j := by
  let H := companions B i
  let J := clear B i (marked B i)
  have person (y : Point) (hy : y ∈ A) : target ≤ ∑ j ∈ appearances B J y, price j := by
    let T := appearances B J y
    have once (z : Point) (hz : z ∈ H) : w z ≤ ∑ j ∈ T, if z ∈ B j then w z else 0 := by
      have out := outside y hy
      have ne : y ≠ z := fun e => out (e ▸ (Finset.mem_sdiff.mp hz).1)
      obtain ⟨j,yj,zj⟩ := h.2 y z ne
      have inJ := companion_only_clear B h _ (marked_sub B i) (marked_six B i)
        (companion_eq B i ▸ hz) zj (fun e => out (e ▸ yj))
      have inT : j ∈ T := Finset.mem_filter.mpr ⟨inJ,yj⟩
      simpa only [if_pos zj] using (Finset.single_le_sum
        (f := fun k => if z ∈ B k then w z else 0) (fun _ _ => Nat.zero_le _) inT)
    have le := Finset.sum_le_sum once
    rw [Finset.sum_comm] at le
    have row (j : Photo) (hj : j ∈ T) :
        (∑ z ∈ H, if z ∈ B j then w z else 0) ≤ divisor * price j := by
      have eq : H.filter (fun z => z ∈ B j) = H ∩ B j := by ext z; simp
      rw [← Finset.sum_filter,eq]
      exact rounds j (Finset.mem_filter.mp hj).1
    have bound := le.trans (Finset.sum_le_sum row)
    rw [← Finset.mul_sum] at bound
    by_contra! short
    change (∑ j ∈ T, price j) < target at short
    have cap := Nat.mul_le_mul_left divisor (show (∑ j ∈ T, price j) ≤ target-1 by omega)
    exact (not_le_of_gt need) (bound.trans cap)
  have total := Finset.sum_le_sum person
  rw [weighted_visits] at total
  simpa using total

/-- The other members of the pivot have already met there. Each subsequent
meeting with one of them is charged to the same person's repeat budget. -/
theorem companion_repeat (B : Family 38) (h : IsCover B) (i : Photo)
    (x : Point) (hx : x ∈ companions B i) :
    ∑ j ∈ appearances B (clear B i (marked B i)) x, (amount B i j-1) ≤
      10*(degree B x-6) := by
  let H := companions B i
  let T := appearances B (clear B i (marked B i)) x
  have xi := (Finset.mem_sdiff.mp hx).1
  have members (j : Photo) (hj : j ∈ T) : x ∈ H ∩ B j :=
    Finset.mem_inter.mpr ⟨hx,(Finset.mem_filter.mp hj).2⟩
  have row (j : Photo) (hj : j ∈ T) : amount B i j-1 = ((H.erase x) ∩ B j).card := by
    have eq : (H.erase x) ∩ B j = (H ∩ B j).erase x := by ext y; simp [and_assoc]
    rw [eq,Finset.card_erase_of_mem (members j hj)]
    rfl
  have person (y : Point) (hy : y ∈ H.erase x) :
      (appearances B T y).card ≤ partners B x y-1 := by
    let P := Finset.univ.filter (fun j => x ∈ B j ∧ y ∈ B j)
    have yp := (Finset.mem_sdiff.mp (Finset.mem_erase.mp hy).2).1
    have ip : i ∈ P := Finset.mem_filter.mpr ⟨Finset.mem_univ _,xi,yp⟩
    have sub : appearances B T y ⊆ P.erase i := by
      intro j hj
      obtain ⟨jt,yj⟩ := Finset.mem_filter.mp hj
      obtain ⟨jc,xj⟩ := Finset.mem_filter.mp jt
      exact Finset.mem_erase.mpr ⟨(Finset.mem_erase.mp (Finset.mem_sdiff.mp jc).1).1,
        Finset.mem_filter.mpr ⟨Finset.mem_univ _,xj,yj⟩⟩
    have le := Finset.card_le_card sub
    rw [Finset.card_erase_of_mem ip] at le
    simpa [P,partners] using le
  change (∑ j ∈ T, _) ≤ _
  rw [Finset.sum_congr rfl row,block_sum]
  have sub : H.erase x ⊆ (Finset.univ : Finset Point).erase x :=
    Finset.erase_subset_erase _ (Finset.subset_univ _)
  exact (Finset.sum_le_sum person).trans ((Finset.sum_le_sum_of_subset_of_nonneg
    (f := fun y => partners B x y-1) sub (fun _ _ _ => Nat.zero_le _)).trans_eq (repeat_sum B h x))

end Cover61.LocalRows
