import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_3_12 : List (Branch 11 19) := [
  
]

theorem checked12_3_12 : ∃ cert, Checked (rows11_2 12) rows12_3 3 cert :=
  ⟨routes12_3_12, by decide +kernel⟩

private def routes12_3_13 : List (Branch 11 19) := [
  
]

theorem checked12_3_13 : ∃ cert, Checked (rows11_2 13) rows12_3 3 cert :=
  ⟨routes12_3_13, by decide +kernel⟩

private def routes12_3_14 : List (Branch 11 19) := [
  
]

theorem checked12_3_14 : ∃ cert, Checked (rows11_2 14) rows12_3 3 cert :=
  ⟨routes12_3_14, by decide +kernel⟩

private def routes12_3_15 : List (Branch 11 19) := [
  
]

theorem checked12_3_15 : ∃ cert, Checked (rows11_2 15) rows12_3 3 cert :=
  ⟨routes12_3_15, by decide +kernel⟩

private def routes12_3_16 : List (Branch 11 19) := [
  
]

theorem checked12_3_16 : ∃ cert, Checked (rows11_2 16) rows12_3 3 cert :=
  ⟨routes12_3_16, by decide +kernel⟩

private def routes12_3_17 : List (Branch 11 19) := [
  
]

theorem checked12_3_17 : ∃ cert, Checked (rows11_2 17) rows12_3 3 cert :=
  ⟨routes12_3_17, by decide +kernel⟩

private def routes12_3_18 : List (Branch 11 19) := [
  
]

theorem checked12_3_18 : ∃ cert, Checked (rows11_2 18) rows12_3 3 cert :=
  ⟨routes12_3_18, by decide +kernel⟩

private def routes12_3_19 : List (Branch 11 19) := [
  
]

theorem checked12_3_19 : ∃ cert, Checked (rows11_2 19) rows12_3 3 cert :=
  ⟨routes12_3_19, by decide +kernel⟩

private def routes12_3_20 : List (Branch 11 19) := [
  
]

theorem checked12_3_20 : ∃ cert, Checked (rows11_2 20) rows12_3 3 cert :=
  ⟨routes12_3_20, by decide +kernel⟩

private def routes12_3_21 : List (Branch 11 19) := [
  ⟨{{0,7}, {1,5,8}, {2,3}, {4,6}, {9,10}},16,⟨5436146132846,1907387229363⟩⟩,
  ⟨{{0,9}, {1,5,8}, {2}, {3,6}, {4,7}, {10}},18,⟨3031724612246,7095619146286⟩⟩
]

theorem checked12_3_21 : ∃ cert, Checked (rows11_2 21) rows12_3 3 cert :=
  ⟨routes12_3_21, by decide +kernel⟩

private def routes12_3_22 : List (Branch 11 19) := [
  ⟨{{0,7}, {1,5,8}, {2,3}, {4,6}, {9}, {10}},18,⟨3826369353686,4938832327803⟩⟩,
  ⟨{{0,9}, {1,5,8}, {2,10}, {3,6}, {4,7}},6,⟨8625906729341,8278807933814⟩⟩
]

theorem checked12_3_22 : ∃ cert, Checked (rows11_2 22) rows12_3 3 cert :=
  ⟨routes12_3_22, by decide +kernel⟩

private def routes12_3_23 : List (Branch 11 19) := [
  ⟨{{0}, {1}, {2,6,7}, {3,8}, {4,5}, {9,10}},16,⟨7138873649006,1917670956531⟩⟩,
  ⟨{{0,8}, {1,4}, {2,6,7}, {3,5}, {9}, {10}},7,⟨7813975020423,2205873203523⟩⟩,
  ⟨{{0,8}, {1,4}, {2,6,7}, {3,5}, {9,10}},5,⟨8562540039350,8330963161576⟩⟩
]

theorem checked12_3_23 : ∃ cert, Checked (rows11_2 23) rows12_3 3 cert :=
  ⟨routes12_3_23, by decide +kernel⟩

theorem balanced12_3_12 : Balanced (rows12_3 12) := by decide +kernel

theorem balanced12_3_13 : Balanced (rows12_3 13) := by decide +kernel

theorem balanced12_3_14 : Balanced (rows12_3 14) := by decide +kernel

theorem balanced12_3_15 : Balanced (rows12_3 15) := by decide +kernel

theorem balanced12_3_16 : Balanced (rows12_3 16) := by decide +kernel

theorem balanced12_3_17 : Balanced (rows12_3 17) := by decide +kernel

theorem balanced12_3_18 : Balanced (rows12_3 18) := by decide +kernel

end Cover61.Layers
