import Cover61.PhysicalGrid

namespace Cover61.LocalRows
open Grid

theorem four_groups_impossible (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (four : (groups B i).card=4) (a : 17≤(lows B).card) : False := by
  classical
  obtain ⟨k,kg,ks,width⟩ := choose_four_axes B h i five four a
  let T := (groups B i).erase k
  have tg : T ⊆ groups B i := Finset.erase_subset ..
  have size : T.card=3 := by change ((groups B i).erase k).card=3;rw [Finset.card_erase_of_mem kg,four]
  obtain ⟨D,red,real⟩ := physical_chart B h i five T tg size width
  obtain ⟨y,ym,z,zm,ne⟩ := Finset.one_lt_card.mp ks
  have path (v : Point) (vlow : v ∈ marked B k) := real _ (line_sub B i v)
    (low_line_count B h i five v (Finset.mem_inter.mp vlow).1)
    (fourth_crosses B h i five tg kg (Finset.notMem_erase k (groups B i)) v vlow)
  obtain ⟨P,py⟩ := path y ym;obtain ⟨Q,qz⟩ := path z zm
  have apart : Disjoint P.cells Q.cells := by
    rw [py,qz]
    apply same_group_disjoint B h i five y z (Finset.mem_inter.mp ym).1 (Finset.mem_inter.mp zm).1 ne
    rw [groupOf_eq B h i five kg ym,groupOf_eq B h i five kg zm]
  have cash : (∑ x,(degree B x-7)) ≤ excess B (companions B i)+3 := by
    have := total_excess B h;have := (five_group_excess B h i five).1;have := at_most_twenty B h
    omega
  let W := exceptional B i
  let C := cells B i
  let q (x : Point) := D.stamp (line B i x)
  have required (j : Photo) (jc : j ∈ C) : 1≤(W ∩ B j).card := by
    let S := ordinary B i ∩ B j
    have os : S ⊆ ordinary B i := Finset.inter_subset_left
    have per (c : Nat) (_ : c ∈ S.image q) := stamp_fibers B h i five T tg D real cash S os c
    have cap := Chart.counts_of_fibers S q 3 per
    have kinds : (S.image q).card≤2 := by
      apply D.at_most_two_through red P Q apart j S q
      intro x hx
      have away {r : Photo} (rg : r ∈ groups B i) : x ∉ B r := ordinary_away B i (os hx) rg
      have many := outside_line_count B h i five x (away (five_group_cover B h i five).1)
      obtain ⟨L,hl⟩ := real _ (line_sub B i x) many (ordinary_crosses B h i five tg x (os hx))
      have meet (v : Point) (vl : v ∈ marked B k) : (line B i x ∩ line B i v).card=1 := by
        rw [Finset.inter_comm]
        apply line_meeting B h i five v x (Finset.mem_inter.mp vl).1 (fun e => away kg (e ▸ (Finset.mem_inter.mp vl).2))
        rw [groupOf_eq B h i five kg vl]
        exact away kg
      refine ⟨L,?_,hl ▸ Finset.mem_filter.mpr ⟨jc,(Finset.mem_inter.mp hx).2⟩,?_,?_⟩
      · change L.mask=D.stamp (line B i x);rw [←hl,D.stamp_path]
      · rw [hl,py];exact meet y ym
      · rw [hl,qz];exact meet z zm
    have seats := cell_seats B h i five j jc
    have low := cell_low_bound B h i five j jc
    change 11≤(marked B j).card+(W ∩ B j).card+S.card at seats
    omega
  have all := Finset.sum_le_sum required
  have sum := block_sum B C W
  have visits (x : Point) (wx : x ∈ W) : (appearances B C x).card=5 := outside_line_count B h i five x (exc_away B i wx)
  rw [Finset.sum_congr rfl visits] at sum
  have cnt : C.card=25 := cells_count B h i five
  simp [cnt] at all
  simp at sum
  have lim := exception_bound B h i five
  change W.card+(lows B).card≤5*(groups B i).card at lim
  omega

end Cover61.LocalRows
