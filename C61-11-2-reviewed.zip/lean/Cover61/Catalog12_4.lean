import Cover61.Partitions

namespace Cover61.Catalog

open Partitions

set_option maxRecDepth 50000

set_option maxHeartbeats 3000000

def s12_072_03Head : Finset (Fin 12) := {0,1,2,3}

def s12_072_03Rest : List (Finset (Fin 12)) := [
  {0,4}, {1,4}, {2,5}, {3,5}, {3,6}, {7}, {4,5,6,7}, {0,8}, {1,5,8}, {2,6,8}, {3,7,8}, {1,9}, {3,4,9}, {0,6,9}, {2,7,9}, {2,10}, {1,6,10}, {0,7,10}, {4,8,10}, {5,9,10}, {2,4,11}, {0,5,11}, {6,11}, {1,7,11}, {8,9,11}, {3,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s12_072_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s12_072_03Head s12_072_03Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s12_072_04Head : Finset (Fin 12) := {0,1,2,3}

def s12_072_04Rest : List (Finset (Fin 12)) := [
  {0,4}, {1,4}, {2,5}, {3,5}, {3,6}, {7}, {4,5,6,7}, {0,8}, {1,5,8}, {2,6,8}, {3,7,8}, {1,9}, {0,6,9}, {2,7,9}, {4,8,9}, {2,10}, {3,4,10}, {1,6,10}, {0,7,10}, {5,9,10}, {2,4,11}, {0,5,11}, {6,11}, {1,7,11}, {3,9,11}, {8,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s12_072_04_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s12_072_04Head s12_072_04Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s12_125_01Head : Finset (Fin 12) := {3,7,10}

def s12_125_01Rest : List (Finset (Fin 12)) := [
  {3}, {0,1,2,3}, {0,4}, {1,5}, {2,6}, {7}, {4,5,6,7}, {0,8}, {4,8}, {2,5,8}, {3,6,8}, {1,7,8}, {1,9}, {3,4,9}, {5,9}, {0,6,9}, {2,7,9}, {2,10}, {1,4,10}, {0,5,10}, {6,10}, {11}, {2,4,11}, {3,5,11}, {1,6,11}, {0,7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s12_125_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s12_125_01Head s12_125_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s12_128_01Head : Finset (Fin 12) := {3,6,8}

def s12_128_01Rest : List (Finset (Fin 12)) := [
  {3}, {0,1,2,3}, {0,4}, {1,5}, {2,6}, {7}, {4,5,6,7}, {0,8}, {4,8}, {2,5,8}, {1,7,8}, {2,9}, {1,4,9}, {5,9}, {0,6,9}, {3,7,9}, {1,10}, {3,4,10}, {0,5,10}, {6,10}, {2,7,10}, {11}, {2,4,11}, {3,5,11}, {1,6,11}, {0,7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s12_128_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s12_128_01Head s12_128_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s12_129_01Head : Finset (Fin 12) := {3,5,8}

def s12_129_01Rest : List (Finset (Fin 12)) := [
  {0,1,2,3}, {0,4}, {1,5}, {2,6}, {3,7}, {4,5,6,7}, {0,8}, {4,8}, {1,6,8}, {2,7,8}, {2,9}, {1,4,9}, {5,9}, {3,6,9}, {0,7,9}, {3,10}, {2,4,10}, {0,5,10}, {6,10}, {1,7,10}, {1,11}, {3,4,11}, {2,5,11}, {0,6,11}, {7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s12_129_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s12_129_01Head s12_129_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s12_132_01Head : Finset (Fin 12) := {2,7,8}

def s12_132_01Rest : List (Finset (Fin 12)) := [
  {3}, {0,1,2,3}, {0,4}, {1,5}, {2,6}, {7}, {4,5,6,7}, {1,8}, {4,8}, {0,5,8}, {3,6,8}, {2,9}, {1,4,9}, {5,9}, {0,6,9}, {3,7,9}, {0,10}, {2,4,10}, {3,5,10}, {6,10}, {1,7,10}, {11}, {3,4,11}, {2,5,11}, {1,6,11}, {0,7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s12_132_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s12_132_01Head s12_132_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s12_133_01Head : Finset (Fin 12) := {0,5,8}

def s12_133_01Rest : List (Finset (Fin 12)) := [
  {0,1,2,3}, {0,4}, {1,5}, {2,6}, {3,7}, {4,5,6,7}, {1,8}, {4,8}, {3,6,8}, {2,7,8}, {2,9}, {3,4,9}, {5,9}, {0,6,9}, {1,7,9}, {3,10}, {1,4,10}, {2,5,10}, {6,10}, {0,7,10}, {0,11}, {2,4,11}, {3,5,11}, {1,6,11}, {7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s12_133_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s12_133_01Head s12_133_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
