import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.Fin

namespace Cover61

abbrev Point := Fin 61
abbrev Family (b : Nat) := Fin b → Finset Point

def IsCover {b : Nat} (B : Family b) : Prop :=
  (∀ i, (B i).card = 11) ∧
  ∀ x y : Point, x ≠ y → ∃ i, x ∈ B i ∧ y ∈ B i

def degree {b : Nat} (B : Family b) (x : Point) : Nat :=
  (Finset.univ.filter (fun i => x ∈ B i)).card

def partners {b : Nat} (B : Family b) (x y : Point) : Nat :=
  (Finset.univ.filter (fun i => x ∈ B i ∧ y ∈ B i)).card

private theorem count_univ {α : Type} [Fintype α] [DecidableEq α] (s : Finset α) :
    (∑ x : α, if x ∈ s then 1 else 0 : Nat) = s.card := by simp

theorem seats {b : Nat} (B : Family b) (h : IsCover B) :
    ∑ x, degree B x = b * 11 := by
  calc
    _ = ∑ x : Point, ∑ i, if x ∈ B i then 1 else 0 := by simp [degree]
    _ = ∑ i, ∑ x : Point, if x ∈ B i then 1 else 0 := Finset.sum_comm
    _ = _ := by simp [count_univ, h.1]

theorem partnerSum {b : Nat} (B : Family b) (h : IsCover B) (x : Point) :
    ∑ y ∈ Finset.univ.erase x, partners B x y = 10 * degree B x := by
  calc
    _ = ∑ y ∈ Finset.univ.erase x, ∑ i, if x ∈ B i ∧ y ∈ B i then 1 else 0 := by
      simp [partners]
    _ = ∑ i, ∑ y ∈ Finset.univ.erase x, if x ∈ B i ∧ y ∈ B i then 1 else 0 :=
      Finset.sum_comm
    _ = ∑ i, 10 * (if x ∈ B i then 1 else 0) := by
      apply Finset.sum_congr rfl
      intro i _
      by_cases hx : x ∈ B i
      · have heq : ((Finset.univ.erase x).filter (fun y => y ∈ B i)) = (B i).erase x := by
          ext y; simp [and_comm]
        simp [hx, heq, Finset.card_erase_of_mem hx, h.1 i]
      · simp [hx]
    _ = _ := by rw [← Finset.mul_sum]; simp [degree]

theorem partners_pos {b : Nat} (B : Family b) (h : IsCover B)
    (x y : Point) (hxy : x ≠ y) : 1 ≤ partners B x y := by
  obtain ⟨i,hi⟩ := h.2 x y hxy
  exact Finset.card_pos.mpr ⟨i, Finset.mem_filter.mpr ⟨Finset.mem_univ _,hi⟩⟩

theorem degree_ge_six {b : Nat} (B : Family b) (h : IsCover B) (x : Point) :
    6 ≤ degree B x := by
  have hl := Finset.sum_le_sum (s := Finset.univ.erase x) (f := fun _ : Point => 1)
    (g := partners B x) fun y hy => partners_pos B h x y (Finset.mem_erase.mp hy).1.symm
  rw [partnerSum B h x] at hl
  simp at hl
  omega

theorem six_meets_once {b : Nat} (B : Family b) (h : IsCover B)
    (x y : Point) (hx : degree B x = 6) (hxy : x ≠ y) : partners B x y = 1 := by
  by_contra hn
  have hgt : 1 < partners B x y := by
    have := partners_pos B h x y hxy
    omega
  have hl := Finset.sum_lt_sum (s := Finset.univ.erase x) (f := fun _ : Point => 1)
    (g := partners B x) (fun z hz => partners_pos B h x z (Finset.mem_erase.mp hz).1.symm)
    ⟨y,Finset.mem_erase.mpr ⟨hxy.symm,Finset.mem_univ _⟩,hgt⟩
  rw [partnerSum B h x, hx] at hl
  simpa using hl

theorem nine_six_people (B : Family 38) (h : IsCover B) :
    9 ≤ (Finset.univ.filter (fun x => degree B x = 6)).card := by
  have hl : (∑ x : Point, 7) ≤
      ∑ x : Point, (degree B x + if degree B x = 6 then 1 else 0) := by
    apply Finset.sum_le_sum
    intro x _
    have := degree_ge_six B h x
    split <;> omega
  rw [Finset.sum_add_distrib, seats B h] at hl
  simp at hl
  omega

end Cover61
