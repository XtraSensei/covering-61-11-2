import Cover61.Partitions

namespace Cover61.Catalog

open Partitions

set_option maxRecDepth 50000

set_option maxHeartbeats 3000000

def s10_011_01Head : Finset (Fin 10) := {1,2,3}

def s10_011_01Rest : List (Finset (Fin 10)) := [
  {0,4}, {1,4}, {2,4}, {0,5}, {1,5}, {3,5}, {0,6}, {2,6}, {3,6}, {4,5,6}, {7}, {1,7}, {0,2,7}, {3,4,7}, {8}, {2,8}, {0,3,8}, {1,6,8}, {5,7,8}, {9}, {0,1,9}, {3,9}, {2,5,9}, {6,7,9}, {4,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_011_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_011_01Head s10_011_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_011_02Head : Finset (Fin 10) := {0,2,7}

def s10_011_02Rest : List (Finset (Fin 10)) := [
  {1,2,3}, {0,4}, {1,4}, {2,4}, {0,5}, {1,5}, {3,5}, {0,6}, {2,6}, {3,6}, {7}, {1,7}, {3,4,7}, {5,6,7}, {8}, {2,8}, {0,3,8}, {4,5,8}, {1,6,8}, {9}, {0,1,9}, {3,9}, {2,5,9}, {4,6,9}, {7,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_011_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_011_02Head s10_011_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_012_01Head : Finset (Fin 10) := {1,3,9}

def s10_012_01Rest : List (Finset (Fin 10)) := [
  {0,1,2}, {0,3}, {0,4}, {1,4}, {2,3,4}, {0,5}, {1,5}, {2,5}, {1,6}, {2,6}, {3,6}, {7}, {2,7}, {3,5,7}, {4,6,7}, {8}, {3,8}, {4,5,8}, {0,6,8}, {1,7,8}, {9}, {4,9}, {5,6,9}, {0,7,9}, {2,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_012_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_012_01Head s10_012_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_012_02Head : Finset (Fin 10) := {3,5,7}

def s10_012_02Rest : List (Finset (Fin 10)) := [
  {0,3}, {0,4}, {1,4}, {2,3,4}, {0,5}, {1,5}, {2,5}, {1,6}, {2,6}, {3,6}, {7}, {0,1,7}, {2,7}, {4,6,7}, {8}, {1,2,8}, {3,8}, {4,5,8}, {0,6,8}, {9}, {0,2,9}, {1,3,9}, {4,9}, {5,6,9}, {7,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_012_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_012_02Head s10_012_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_012_03Head : Finset (Fin 10) := {3,4,5}

def s10_012_03Rest : List (Finset (Fin 10)) := [
  {0,1,2}, {0,3}, {0,4}, {1,4}, {0,5}, {1,5}, {2,5}, {1,6}, {2,6}, {3,6}, {7}, {2,7}, {1,3,7}, {4,6,7}, {8}, {3,8}, {2,4,8}, {0,6,8}, {5,7,8}, {9}, {2,3,9}, {4,9}, {5,6,9}, {0,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_012_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_012_03Head s10_012_03Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_012_04Head : Finset (Fin 10) := {0,1,2}

def s10_012_04Rest : List (Finset (Fin 10)) := [
  {0,3}, {0,4}, {1,4}, {0,5}, {1,5}, {2,5}, {3,4,5}, {1,6}, {2,6}, {3,6}, {7}, {2,7}, {1,3,7}, {4,6,7}, {8}, {3,8}, {2,4,8}, {5,6,8}, {0,7,8}, {9}, {2,3,9}, {4,9}, {0,6,9}, {5,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_012_04_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_012_04Head s10_012_04Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_014_03Head : Finset (Fin 10) := {3,4,7}

def s10_014_03Rest : List (Finset (Fin 10)) := [
  {0,3}, {1,2,3}, {0,4}, {1,4}, {0,5}, {1,5}, {2,5}, {1,6}, {2,6}, {4,6}, {3,5,6}, {7}, {2,7}, {0,6,7}, {8}, {0,2,8}, {3,8}, {4,5,8}, {1,7,8}, {9}, {0,1,9}, {3,9}, {2,4,9}, {5,7,9}, {6,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_014_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_014_03Head s10_014_03Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_015_01Head : Finset (Fin 10) := {2,5,9}

def s10_015_01Rest : List (Finset (Fin 10)) := [
  {0,1,2}, {0,3}, {0,4}, {1,4}, {2,3,4}, {0,5}, {1,5}, {3,5}, {1,6}, {2,6}, {4,6}, {7}, {2,7}, {1,3,7}, {5,6,7}, {8}, {2,8}, {4,5,8}, {3,6,8}, {0,7,8}, {9}, {3,9}, {0,6,9}, {4,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_015_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_015_01Head s10_015_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_017_01Head : Finset (Fin 10) := {1,3,9}

def s10_017_01Rest : List (Finset (Fin 10)) := [
  {0,1,2}, {0,3}, {0,4}, {1,4}, {2,3,4}, {0,5}, {2,5}, {3,5}, {1,6}, {2,6}, {3,6}, {7}, {1,7}, {4,5,7}, {0,6,7}, {8}, {2,8}, {1,5,8}, {4,6,8}, {3,7,8}, {9}, {4,9}, {5,6,9}, {2,7,9}, {0,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_017_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_017_01Head s10_017_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s10_017_02Head : Finset (Fin 10) := {1,2,3}

def s10_017_02Rest : List (Finset (Fin 10)) := [
  {0,3}, {0,4}, {1,4}, {0,5}, {2,5}, {3,5}, {1,6}, {2,6}, {3,6}, {4,5,6}, {7}, {1,7}, {2,4,7}, {0,6,7}, {8}, {0,1,8}, {2,8}, {3,4,8}, {5,7,8}, {9}, {0,2,9}, {4,9}, {1,5,9}, {3,7,9}, {6,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s10_017_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s10_017_02Head s10_017_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
