import Cover61.Incidence

namespace Cover61.Cuts

/-- The oriented missing pairs in a cut have to be covered in the remaining blocks. -/
theorem capacity {b : Nat} (B : Family b) (size : ∀ i, (B i).card=11)
    (J : Finset (Fin b)) (X : Finset Point) (M : Finset (Point × Point))
    (cross : ∀ t ∈ M, t.1 ∈ X ∧ t.2 ∉ X)
    (cover : ∀ t ∈ M, ∃ j ∈ J, t.1 ∈ B j ∧ t.2 ∈ B j) :
    M.card ≤ ∑ i ∈ J, (B i ∩ X).card * (11-(B i ∩ X).card) := by
  let P (i : Fin b) := (B i ∩ X) ×ˢ (B i \ X)
  have sub : M ⊆ J.biUnion P := by
    intro t ht
    obtain ⟨j,hj,a,b'⟩ := cover t ht
    obtain ⟨u,v⟩ := cross t ht
    exact Finset.mem_biUnion.mpr ⟨j,hj,Finset.mem_product.mpr
      ⟨Finset.mem_inter.mpr ⟨a,u⟩,Finset.mem_sdiff.mpr ⟨b',v⟩⟩⟩
  have room (i : Fin b) : (P i).card = (B i ∩ X).card * (11-(B i ∩ X).card) := by
    have diff : B i \ X = B i \ (B i ∩ X) := by ext x; simp
    simp only [P,Finset.card_product,diff,Finset.card_sdiff_of_subset Finset.inter_subset_left,size]
  exact (Finset.card_le_card sub).trans (Finset.card_biUnion_le.trans_eq
    (Finset.sum_congr rfl (fun i _ => room i)))

/-- The slice used in the two-type cut of the 9-37 relaxation: 18 appearances
spread over 11 blocks can account for at most 166 distinct cross-pairs. -/
theorem eighteen_in_eleven {b : Nat} (B : Family b) (size : ∀ i, (B i).card=11)
    (J : Finset (Fin b)) (X : Finset Point) (M : Finset (Point × Point))
    (cross : ∀ t ∈ M, t.1 ∈ X ∧ t.2 ∉ X)
    (cover : ∀ t ∈ M, ∃ j ∈ J, t.1 ∈ B j ∧ t.2 ∈ B j)
    (count : J.card = 11) (mass : (∑ i ∈ J, (B i ∩ X).card) = 18) : M.card ≤ 166 := by
  have tab : ∀ j : Fin 12, j.val*(11-j.val) ≤ 8*j.val+2 := by decide
  have row (i : Fin b) :
      (B i ∩ X).card * (11-(B i ∩ X).card) ≤ 8*(B i ∩ X).card+2 := by
    have hi := Finset.card_le_card (Finset.inter_subset_left (s₁:=B i) (s₂:=X))
    rw [size] at hi
    exact tab ⟨(B i ∩ X).card,Nat.lt_succ_of_le hi⟩
  have sum := Finset.sum_le_sum (s:=J) (fun i _ => row i)
  rw [Finset.sum_add_distrib, ← Finset.mul_sum,mass] at sum
  have bound := capacity B size J X M cross cover
  simp [count] at sum
  omega

end Cover61.Cuts
