import Cover61.Prices

namespace Cover61.Replay

open Cover61.Prices

/-- A signed equality may use any integer multiplier. A lower-bound row
must use a nonnegative multiplier to give a valid weighted lower bound. -/
structure Constraint (n : Nat) extends Row n where
  equality : Bool

def Satisfies {n : Nat} (r : Constraint n) (x : Fin n → Int) : Prop :=
  if r.equality then r.rhs = eval r.coeff x else r.rhs ≤ eval r.coeff x

inductive Tree (m n : Nat) where
  | leaf (weights : Fin m → Int)
  | split (j : Fin n) (v : Int) (left right : Tree m n)

def above {n : Nat} (a l u : Fin n → Int) : Int :=
  ∑ j, if 0 ≤ a j then a j * u j else a j * l j

def verify {m n : Nat} (rows : Fin m → Constraint n)
    (l u : Fin n → Int) : Tree m n → Bool
  | .leaf w =>
    decide (∀ i, (rows i).equality = true ∨ 0 ≤ w i) &&
    decide (above (total (fun i => (rows i).toRow) w) l u < ∑ i, w i * (rows i).rhs)
  | .split j v left right =>
    verify rows l (Function.update u j (min (u j) v)) left &&
    verify rows (Function.update l j (max (l j) (v+1))) u right

theorem sound {m n : Nat} (rows : Fin m → Constraint n)
    (x : Fin n → Int) (ok : ∀ i, Satisfies (rows i) x) (t : Tree m n)
    (l u : Fin n → Int) (hl : ∀ j, l j ≤ x j) (hu : ∀ j, x j ≤ u j)
    (certificate : verify rows l u t = true) : False := by
  induction t generalizing l u with
  | leaf w =>
    obtain ⟨sign, gap⟩ := Bool.and_eq_true_iff.mp certificate
    have sign' := of_decide_eq_true sign
    have gap' := of_decide_eq_true gap
    have weight (i : Fin m) : w i * (rows i).rhs ≤ w i * eval (rows i).coeff x := by
      have hi := ok i
      by_cases e : (rows i).equality = true
      · simp [Satisfies,e] at hi
        rw [hi]
      · simp [Satisfies,e] at hi
        exact mul_le_mul_of_nonneg_left hi ((sign' i).resolve_left e)
    have bound : (∑ i, w i * (rows i).rhs) ≤ above (total (fun i => (rows i).toRow) w) l u := by
      calc
        _ ≤ ∑ i, w i * eval (rows i).coeff x := Finset.sum_le_sum (fun i _ => weight i)
        _ = eval (total (fun i => (rows i).toRow) w) x := by
          simp only [eval, total, Finset.mul_sum, Finset.sum_mul, mul_assoc]
          exact Finset.sum_comm
        _ ≤ _ := by
          apply Finset.sum_le_sum
          intro j _
          split
          next hp => exact mul_le_mul_of_nonneg_left (hu j) hp
          next hp => exact mul_le_mul_of_nonpos_left (hl j) (le_of_not_ge hp)
    exact (not_lt_of_ge bound) gap'
  | split j v left right il ir =>
    obtain ⟨a,b⟩ := Bool.and_eq_true_iff.mp certificate
    by_cases h : x j ≤ v
    · apply il _ _ hl _ a
      intro k
      by_cases e : k = j
      · subst k; simpa using le_min (hu j) h
      · simpa [Function.update_of_ne e] using hu k
    · apply ir _ _ _ hu b
      intro k
      by_cases e : k = j
      · subst k; simp only [Function.update_self]; exact max_le (hl j) (by omega)
      · simpa [Function.update_of_ne e] using hl k

end Cover61.Replay
