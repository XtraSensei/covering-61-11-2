import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_2_96 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,4,9}, {3,7}, {5}, {6}, {8,10}},20,⟨2485994186192,1713317286208⟩⟩,
  ⟨{{0,4}, {1,5}, {2,3,8}, {6}, {7}, {9,10}},18,⟨1775163446771,86625350108⟩⟩
]

theorem checked12_2_96 : ∃ cert, Checked (rows11_1 96) rows12_2 2 cert :=
  ⟨routes12_2_96, by decide +kernel⟩

private def routes12_2_97 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,3}, {2,5,9}, {6}, {7,10}, {8}},12,⟨1127317361038,780592090454⟩⟩,
  ⟨{{0,7,9}, {1,3}, {2,6}, {4}, {5,10}, {8}},10,⟨1741019171859,1698226852003⟩⟩
]

theorem checked12_2_97 : ∃ cert, Checked (rows11_1 97) rows12_2 2 cert :=
  ⟨routes12_2_97, by decide +kernel⟩

private def routes12_2_98 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,2}, {4,6,8}, {5}, {7,10}, {9}},12,⟨4532772393358,780595076426⟩⟩
]

theorem checked12_2_98 : ∃ cert, Checked (rows11_1 98) rows12_2 2 cert :=
  ⟨routes12_2_98, by decide +kernel⟩

private def routes12_2_99 : List (Branch 11 23) := [
  
]

theorem checked12_2_99 : ∃ cert, Checked (rows11_1 99) rows12_2 2 cert :=
  ⟨routes12_2_99, by decide +kernel⟩

private def routes12_2_100 : List (Branch 11 23) := [
  
]

theorem checked12_2_100 : ∃ cert, Checked (rows11_1 100) rows12_2 2 cert :=
  ⟨routes12_2_100, by decide +kernel⟩

private def routes12_2_101 : List (Branch 11 23) := [
  
]

theorem checked12_2_101 : ∃ cert, Checked (rows11_1 101) rows12_2 2 cert :=
  ⟨routes12_2_101, by decide +kernel⟩

private def routes12_2_102 : List (Branch 11 23) := [
  
]

theorem checked12_2_102 : ∃ cert, Checked (rows11_1 102) rows12_2 2 cert :=
  ⟨routes12_2_102, by decide +kernel⟩

private def routes12_2_103 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,3}, {2,5,7}, {6}, {8,10}, {9}},11,⟨4478517377444,6207500049718⟩⟩
]

theorem checked12_2_103 : ∃ cert, Checked (rows11_1 103) rows12_2 2 cert :=
  ⟨routes12_2_103, by decide +kernel⟩

private def routes12_2_104 : List (Branch 11 23) := [
  
]

theorem checked12_2_104 : ∃ cert, Checked (rows11_1 104) rows12_2 2 cert :=
  ⟨routes12_2_104, by decide +kernel⟩

private def routes12_2_105 : List (Branch 11 23) := [
  
]

theorem checked12_2_105 : ∃ cert, Checked (rows11_1 105) rows12_2 2 cert :=
  ⟨routes12_2_105, by decide +kernel⟩

private def routes12_2_106 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,6,9}, {4,10}, {7}, {8}},12,⟨1741212792429,868765291746⟩⟩,
  ⟨{{0,2}, {1,4,9}, {3,7}, {5}, {6,10}, {8}},12,⟨1741272110974,2242192516960⟩⟩
]

theorem checked12_2_106 : ∃ cert, Checked (rows11_1 106) rows12_2 2 cert :=
  ⟨routes12_2_106, by decide +kernel⟩

private def routes12_2_107 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,3}, {2,5,9}, {6}, {7,10}, {8}},11,⟨1127317361038,780592090454⟩⟩,
  ⟨{{0,7,9}, {1,3}, {2,6}, {4}, {5,10}, {8}},11,⟨1127112765504,2379335661780⟩⟩
]

theorem checked12_2_107 : ∃ cert, Checked (rows11_1 107) rows12_2 2 cert :=
  ⟨routes12_2_107, by decide +kernel⟩

end Cover61.Layers
