import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_2_0 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,4,9}, {2,10}, {5}, {6,7}, {8}},4,⟨329650675233,4954511489675⟩⟩
]

theorem checked12_2_0 : ∃ cert, Checked (rows11_1 0) rows12_2 2 cert :=
  ⟨routes12_2_0, by decide +kernel⟩

private def routes12_2_1 : List (Branch 11 23) := [
  
]

theorem checked12_2_1 : ∃ cert, Checked (rows11_1 1) rows12_2 2 cert :=
  ⟨routes12_2_1, by decide +kernel⟩

private def routes12_2_2 : List (Branch 11 23) := [
  
]

theorem checked12_2_2 : ∃ cert, Checked (rows11_1 2) rows12_2 2 cert :=
  ⟨routes12_2_2, by decide +kernel⟩

private def routes12_2_3 : List (Branch 11 23) := [
  
]

theorem checked12_2_3 : ∃ cert, Checked (rows11_1 3) rows12_2 2 cert :=
  ⟨routes12_2_3, by decide +kernel⟩

private def routes12_2_4 : List (Branch 11 23) := [
  
]

theorem checked12_2_4 : ∃ cert, Checked (rows11_1 4) rows12_2 2 cert :=
  ⟨routes12_2_4, by decide +kernel⟩

private def routes12_2_5 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,4,9}, {3,10}, {5}, {6,7}, {8}},4,⟨3736481129073,4149902595850⟩⟩
]

theorem checked12_2_5 : ∃ cert, Checked (rows11_1 5) rows12_2 2 cert :=
  ⟨routes12_2_5, by decide +kernel⟩

private def routes12_2_6 : List (Branch 11 23) := [
  
]

theorem checked12_2_6 : ∃ cert, Checked (rows11_1 6) rows12_2 2 cert :=
  ⟨routes12_2_6, by decide +kernel⟩

private def routes12_2_7 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,4,9}, {2,10}, {5}, {6,7}, {8}},5,⟨329650675233,4954511489675⟩⟩
]

theorem checked12_2_7 : ∃ cert, Checked (rows11_1 7) rows12_2 2 cert :=
  ⟨routes12_2_7, by decide +kernel⟩

private def routes12_2_8 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,5,6}, {2,10}, {4}, {7}, {8,9}},6,⟨369721896225,7121655043415⟩⟩
]

theorem checked12_2_8 : ∃ cert, Checked (rows11_1 8) rows12_2 2 cert :=
  ⟨routes12_2_8, by decide +kernel⟩

private def routes12_2_9 : List (Branch 11 23) := [
  
]

theorem checked12_2_9 : ∃ cert, Checked (rows11_1 9) rows12_2 2 cert :=
  ⟨routes12_2_9, by decide +kernel⟩

private def routes12_2_10 : List (Branch 11 23) := [
  ⟨{{0,5}, {1,7}, {2,8}, {3,6,9}, {4,10}},6,⟨1805754602432,6026891745567⟩⟩,
  ⟨{{0,5}, {1,4,8}, {2,3}, {6}, {7}, {9,10}},21,⟨367803364918,6705322346327⟩⟩,
  ⟨{{0,8,9}, {1,7}, {2,3}, {4,10}, {5}, {6}},2,⟨2544057098594,4721897305268⟩⟩
]

theorem checked12_2_10 : ∃ cert, Checked (rows11_1 10) rows12_2 2 cert :=
  ⟨routes12_2_10, by decide +kernel⟩

private def routes12_2_11 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,3}, {2,9}, {5,6,8}, {7}, {10}},4,⟨3052032282563,78497035903⟩⟩,
  ⟨{{0,4}, {1,7}, {2,3}, {5,6,8}, {9}, {10}},4,⟨3037087432907,140050106625⟩⟩
]

theorem checked12_2_11 : ∃ cert, Checked (rows11_1 11) rows12_2 2 cert :=
  ⟨routes12_2_11, by decide +kernel⟩

theorem balanced12_2_0 : Balanced (rows12_2 0) := by decide +kernel

theorem balanced12_2_1 : Balanced (rows12_2 1) := by decide +kernel

theorem balanced12_2_2 : Balanced (rows12_2 2) := by decide +kernel

theorem balanced12_2_3 : Balanced (rows12_2 3) := by decide +kernel

theorem balanced12_2_4 : Balanced (rows12_2 4) := by decide +kernel

theorem balanced12_2_5 : Balanced (rows12_2 5) := by decide +kernel

theorem balanced12_2_6 : Balanced (rows12_2 6) := by decide +kernel

theorem balanced12_2_7 : Balanced (rows12_2 7) := by decide +kernel

theorem balanced12_2_8 : Balanced (rows12_2 8) := by decide +kernel

theorem balanced12_2_9 : Balanced (rows12_2 9) := by decide +kernel

theorem balanced12_2_10 : Balanced (rows12_2 10) := by decide +kernel

theorem balanced12_2_11 : Balanced (rows12_2 11) := by decide +kernel

end Cover61.Layers
