import Cover61.FourTariffs
import Mathlib.Tactic.FinCases

namespace Cover61.LocalRows.FourCase3
open FourView
set_option maxRecDepth 100000
set_option maxHeartbeats 6000000

def extra (i : Fin 7) : Nat := (#[3,0,0,0,0,0,0] : Array Nat)[i.val]!
private def classify (C : SevenSet) : Fin 14 := (#[0,1,2,3,2,3,4,5,2,3,4,5,4,5,6,7,2,3,4,5,4,5,6,7,4,5,6,7,6,7,8,9,2,3,4,5,4,5,6,7,4,5,6,7,6,7,8,9,4,5,6,7,6,7,8,9,6,7,8,9,8,9,10,11,2,3,4,5,4,5,6,7,4,5,6,7,6,7,8,9,4,5,6,7,6,7,8,9,6,7,8,9,8,9,10,11,4,5,6,7,6,7,8,9,6,7,8,9,8,9,10,11,6,7,8,9,8,9,10,11,8,9,10,11,10,11,12,13] : Array (Fin 14))[(mask C)%128]!
private def widths (i : Fin 14) : Nat := (#[0,1,1,2,2,3,3,4,4,5,5,6,6,7] : Array (Nat))[i.val]!
private def opposite (i : Fin 14) : Fin 14 := (#[13,12,11,10,9,8,7,6,5,4,3,2,1,0] : Array (Fin 14))[i.val]!
private def colors : Colors 14 where
  cls := classify
  size := widths
  other := opposite
  card := by decide +kernel
  complement := by decide +kernel
  otherSize := by decide +kernel

private def groups (i : Fin 2) : SevenSet := (#[{1,2,3,4,5,6},{0}] : Array (SevenSet))[i.val]!
private def units (j : Fin 2) (i : Fin 14) : Nat :=
  ((#[#[0,0,1,1,2,2,3,3,4,4,5,5,6,6],#[0,1,0,1,0,1,0,1,0,1,0,1,0,1]] : Array (Array Nat))[j.val]!)[i.val]!
private theorem units_ok : ∀ j C, units j (classify C)=(groups j ∩ C).card := by decide +kernel

private def words0 : List Nat := [1094]
private def pay0 (i : Fin 14) : Nat := (#[0,1,1,1,1,2,1,2,2,2,2,3,2,3] : Array (Nat))[i.val]!
private theorem costs0 : ∀ C : SevenSet, tariffs 3 words0 C=pay0 (classify C) := by decide +kernel
private theorem need0 : tariffs 3 words0 Finset.univ=3 := by decide +kernel
private theorem valid0 (v : FourView 8 extra) : v.ValidPrice (fun C => pay0 (classify C)) 3 := by
  have a := many_tariffs v 3 words0 (by decide)
  rw [need0,funext costs0] at a
  exact a

private def words1 : List Nat := [2181,2175,2157,2103,1941,1455]
private def pay1 (i : Fin 14) : Nat := (#[0,0,6,6,10,10,12,12,18,18,19,19,24,24] : Array (Nat))[i.val]!
private theorem costs1 : ∀ C : SevenSet, tariffs 3 words1 C=pay1 (classify C) := by decide +kernel
private theorem need1 : tariffs 3 words1 Finset.univ=24 := by decide +kernel
private theorem valid1 (v : FourView 8 extra) : v.ValidPrice (fun C => pay1 (classify C)) 24 := by
  have a := many_tariffs v 3 words1 (by decide)
  rw [need1,funext costs1] at a
  exact a

private def pay (i : Fin 2) : Fin 14 → Nat := (#[pay0,pay1] : Array (Fin 14 → Nat))[i.val]!
private def need (i : Fin 2) : Nat := (#[3,24] : Array (Nat))[i.val]!
private def T : Table 8 14 2 2 extra where
  colors := colors
  group := groups
  units := units
  counts := units_ok
  price := pay
  target := need
  prices := by
    intro v j
    fin_cases j
    · exact valid0 v
    · exact valid1 v

private def document0 : List (Int × Rule 14 2 2) := [(1164,.visits 1),(-282,.chosen),(800,.size 1),(-1940,.size 3),(-4418,.size 4),(38,.price 0),(7,.price 1),(486,.budget 0)]
private def batch0 : List (List Nat) := [[0,0,0,4,8,2,1,2],[0,0,0,3,10,1,1,2],[0,0,0,2,12,0,1,2],[0,0,0,5,5,5,0,2],[0,0,0,4,7,4,0,2],[0,0,0,3,9,3,0,2],[0,0,0,2,11,2,0,2],[0,0,0,1,13,1,0,2],[0,0,0,0,15,0,0,2],[0,0,0,5,6,2,3,1],[0,0,0,4,8,1,3,1],[0,0,0,3,10,0,3,1],[0,0,0,6,3,5,2,1],[0,0,0,5,5,4,2,1],[0,0,0,4,7,3,2,1],[0,0,0,3,9,2,2,1],[0,0,0,2,11,1,2,1],[0,0,0,1,13,0,2,1],[0,0,0,7,0,8,1,1],[0,0,0,6,2,7,1,1],[0,0,0,5,4,6,1,1],[0,0,0,4,6,5,1,1],[0,0,0,3,8,4,1,1],[0,0,0,2,10,3,1,1],[0,0,0,1,12,2,1,1],[0,0,0,0,14,1,1,1],[0,0,0,6,1,9,0,1],[0,0,0,5,3,8,0,1],[0,0,0,4,5,7,0,1],[0,0,0,3,7,6,0,1],[0,0,0,2,9,5,0,1],[0,0,0,1,11,4,0,1],[0,0,0,6,4,2,5,0],[0,0,0,5,6,1,5,0],[0,0,0,4,8,0,5,0],[0,0,0,7,1,5,4,0],[0,0,0,6,3,4,4,0],[0,0,0,5,5,3,4,0],[0,0,0,4,7,2,4,0],[0,0,0,3,9,1,4,0],[0,0,0,2,11,0,4,0],[0,0,0,7,0,7,3,0],[0,0,0,6,2,6,3,0],[0,0,0,5,4,5,3,0],[0,0,0,4,6,4,3,0],[0,0,0,3,8,3,3,0],[0,0,0,2,10,2,3,0],[0,0,0,6,1,8,2,0],[0,0,0,5,3,7,2,0],[0,0,0,4,5,6,2,0],[0,0,0,6,0,10,1,0]]
private theorem checked0 : batch0.all (fun h => valid T (decodeHist h) document0)=true := by decide +kernel

private def document1 : List (Int × Rule 14 2 2) := [(44,.visits 1),(-44,.size 2),(-132,.size 3),(-242,.size 4),(-396,.size 5),(11,.endpoint 3 true false),(22,.budget 0),(2,.endpoint 5 true true)]
private def batch1 : List (List Nat) := [[0,0,1,1,11,1,1,2],[0,0,1,0,13,0,1,2],[0,0,1,2,8,4,0,2],[0,0,1,1,10,3,0,2],[0,0,1,0,12,2,0,2],[0,0,1,2,9,1,3,1],[0,0,1,1,11,0,3,1],[0,0,1,3,6,4,2,1],[0,0,2,0,9,3,2,1],[0,0,1,2,8,3,2,1],[0,0,1,1,10,2,2,1],[0,0,1,0,12,1,2,1],[0,0,1,4,3,7,1,1],[0,0,2,1,6,6,1,1],[0,0,1,3,5,6,1,1],[0,0,2,0,8,5,1,1],[0,0,1,2,7,5,1,1],[0,0,1,1,9,4,1,1],[0,0,1,0,11,3,1,1],[0,0,1,5,0,10,0,1],[0,0,2,2,3,9,0,1],[0,0,1,4,2,9,0,1],[0,0,2,1,5,8,0,1],[0,0,1,3,4,8,0,1],[0,0,2,0,7,7,0,1],[0,0,1,2,6,7,0,1],[0,0,1,1,8,6,0,1],[0,0,1,0,10,5,0,1],[0,0,0,0,13,3,0,1],[0,0,1,3,7,1,5,0],[0,0,2,0,10,0,5,0],[0,0,1,2,9,0,5,0],[0,0,1,4,4,4,4,0],[0,0,2,1,7,3,4,0],[0,0,1,3,6,3,4,0],[0,0,2,0,9,2,4,0],[0,0,1,2,8,2,4,0],[0,0,1,1,10,1,4,0],[0,0,1,0,12,0,4,0],[0,0,1,5,1,7,3,0],[0,0,2,2,4,6,3,0],[0,0,1,4,3,6,3,0],[0,0,2,1,6,5,3,0],[0,0,1,3,5,5,3,0],[0,0,2,0,8,4,3,0],[0,0,1,2,7,4,3,0],[0,0,1,1,9,3,3,0],[0,0,1,0,11,2,3,0],[0,0,0,1,12,1,3,0],[0,0,0,0,14,0,3,0],[0,0,2,3,1,9,2,0],[0,0,1,5,0,9,2,0],[0,0,3,0,4,8,2,0],[0,0,2,2,3,8,2,0],[0,0,1,4,2,8,2,0],[0,0,2,1,5,7,2,0],[0,0,1,3,4,7,2,0],[0,0,2,0,7,6,2,0],[0,0,1,2,6,6,2,0],[0,0,1,1,8,5,2,0],[0,0,0,3,7,5,2,0],[0,0,1,0,10,4,2,0],[0,0,0,2,9,4,2,0],[0,0,0,1,11,3,2,0],[0,0,0,0,13,2,2,0],[0,0,3,1,1,11,1,0],[0,0,2,3,0,11,1,0],[0,0,3,0,3,10,1,0],[0,0,2,2,2,10,1,0],[0,0,1,4,1,10,1,0],[0,0,2,1,4,9,1,0],[0,0,1,3,3,9,1,0],[0,0,0,5,2,9,1,0],[0,0,2,0,6,8,1,0],[0,0,1,2,5,8,1,0],[0,0,0,4,4,8,1,0],[0,0,1,1,7,7,1,0],[0,0,0,3,6,7,1,0],[0,0,1,0,9,6,1,0],[0,0,0,2,8,6,1,0],[0,0,0,1,10,5,1,0],[0,0,0,0,12,4,1,0],[0,0,3,1,0,13,0,0],[0,0,3,0,2,12,0,0],[0,0,2,2,1,12,0,0],[0,0,1,4,0,12,0,0],[0,0,2,1,3,11,0,0],[0,0,1,3,2,11,0,0],[0,0,0,5,1,11,0,0],[0,0,2,0,5,10,0,0],[0,0,1,2,4,10,0,0],[0,0,0,4,3,10,0,0],[0,0,1,1,6,9,0,0],[0,0,0,3,5,9,0,0],[0,0,1,0,8,8,0,0],[0,0,0,2,7,8,0,0],[0,0,0,1,9,7,0,0]]
private theorem checked1 : batch1.all (fun h => valid T (decodeHist h) document1)=true := by decide +kernel

private def document2 : List (Int × Rule 14 2 2) := [(-1,.chosen),(1,.mass 1)]
private def batch2 : List (List Nat) := [[0,1,0,0,11,2,2,1],[0,1,0,0,10,4,1,1],[0,1,0,0,9,6,0,1],[0,1,0,0,11,1,4,0],[0,1,0,0,10,3,3,0],[0,1,0,0,9,5,2,0],[0,1,0,4,0,11,1,0],[1,0,0,0,7,8,1,0],[0,1,0,0,8,7,1,0],[0,1,0,3,1,12,0,0],[1,0,0,0,6,10,0,0],[0,1,0,0,7,9,0,0],[0,0,0,0,11,6,0,0]]
private theorem checked2 : batch2.all (fun h => valid T (decodeHist h) document2)=true := by decide +kernel

private def document3 : List (Int × Rule 14 2 2) := [(-3,.visits 0),(3,.size 1),(4,.size 2),(3,.size 3),(-10,.size 6),(1,.budget 0),(3,.endpoint 1 false true),(2,.endpoint 1 true true)]
private def batch3 : List (List Nat) := [[0,1,0,1,8,5,1,1],[0,1,0,2,5,8,0,1],[0,1,0,1,7,7,0,1],[0,1,0,1,9,2,4,0],[0,1,0,2,6,5,3,0],[0,1,0,1,8,4,3,0],[0,1,0,3,3,8,2,0],[0,1,1,0,6,7,2,0],[0,1,0,2,5,7,2,0],[0,1,0,1,7,6,2,0],[0,1,1,1,3,10,1,0],[0,1,0,3,2,10,1,0],[0,1,1,0,5,9,1,0],[0,1,0,2,4,9,1,0],[0,1,0,1,6,8,1,0],[0,1,1,2,0,13,0,0],[0,1,1,1,2,12,0,0],[0,1,1,0,4,11,0,0],[0,1,0,2,3,11,0,0],[0,1,0,1,5,10,0,0]]
private theorem checked3 : batch3.all (fun h => valid T (decodeHist h) document3)=true := by decide +kernel

private def document4 : List (Int × Rule 14 2 2) := [(-1,.chosen),(1,.mass 3)]
private def batch4 : List (List Nat) := [[1,0,0,1,4,11,0,0]]
private theorem checked4 : batch4.all (fun h => valid T (decodeHist h) document4)=true := by decide +kernel

private def documents (i : Fin 5) : List (Int × Rule 14 2 2) := (#[document0,document1,document2,document3,document4] : Array (List (Int × Rule 14 2 2)))[i.val]!
private def batches (i : Fin 5) : List (List Nat) := (#[batch0,batch1,batch2,batch3,batch4] : Array (List (List Nat)))[i.val]!
private theorem checked (j : Fin 5) : (batches j).all (fun h => valid T (decodeHist h) (documents j))=true := by
  fin_cases j
  · exact checked0
  · exact checked1
  · exact checked2
  · exact checked3
  · exact checked4

private def containsHistogram (h : List Nat) := (List.finRange 5).any (fun j => (batches j).contains h)
private theorem present : (Histogram.enumerate 7 17 45 350).all containsHistogram=true := by decide +kernel
theorem excluded (v : FourView 8 extra) : False := by
  have seats : 42+(∑ x,extra x)=45 := by decide +kernel
  have hs := v.possible_histogram
  rw [seats] at hs
  obtain ⟨j,_,ok⟩ := List.any_eq_true.mp (List.all_eq_true.mp present _ hs)
  have inside : Histogram.data v.hist 7 ∈ batches j := by simpa using ok
  have price := List.all_eq_true.mp (checked j) _ inside
  rw [read_hist] at price
  exact rejected T v (documents j) price

end Cover61.LocalRows.FourCase3
