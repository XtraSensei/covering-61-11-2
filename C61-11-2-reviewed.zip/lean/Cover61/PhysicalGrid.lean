import Cover61.GroupBundles
import Cover61.PathBounds

namespace Cover61.LocalRows
open Grid

variable (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)

def crossesGroups (B : Family 38) (i : Photo) (T : Finset Photo) (L : Finset Photo) :=
  ∀ j ∈ T, ∀ x ∈ marked B j,(L ∩ line B i x).card=1

include h five

theorem ordinary_crosses {T : Finset Photo} (sub : T ⊆ groups B i) (x : Point) (hx : x ∈ ordinary B i) :
    crossesGroups B i T (line B i x) := by
  intro j hj y hy
  obtain ⟨yl,yj⟩ := Finset.mem_inter.mp hy
  have away := ordinary_away B i hx (sub hj)
  rw [Finset.inter_comm]
  apply line_meeting B h i five y x yl (fun e => away (e ▸ yj))
  rwa [groupOf_eq B h i five (sub hj) hy]

theorem fourth_crosses {T : Finset Photo} (sub : T ⊆ groups B i) {j : Photo}
    (jg : j ∈ groups B i) (out : j ∉ T) (x : Point) (hx : x ∈ marked B j) :
    crossesGroups B i T (line B i x) := by
  intro k hk y hy
  apply other_group_cross B h i five x y (Finset.mem_inter.mp hx).1 (Finset.mem_inter.mp hy).1
  rw [groupOf_eq B h i five jg hx,groupOf_eq B h i five (sub hk) hy]
  exact fun e => out (e ▸ hk)

theorem physical_chart (T : Finset Photo) (sub : T ⊆ groups B i) (n : T.card=3)
    (width : ∀ j ∈ T,4≤(marked B j).card) :
    ∃ D : Chart (cells B i), D.Reduced ∧ ∀ L : Finset Photo, L ⊆ cells B i → L.card=5 →
    crossesGroups B i T L → ∃ P : D.Path,P.cells=L := by
  classical
  let e : Fin 3 ≃ ↥T := (Fintype.equivFinOfCardEq (by simpa using n)).symm
  let bundles (k : Fin 3) := groupBundle B h i five (e k).val (sub (e k).property)
  have domain (k : Fin 3) : (bundles k).lines.card=4 ∨ (bundles k).lines.card=5 := by
    simp only [bundles,bundle_count]
    have lo := width _ (e k).property;have hi := marked_width_five B h (e k).val
    omega
  have total := cells_count B h i five
  let finished (k : Fin 3) := (bundles k).finish total (domain k)
  let A (k : Fin 3) := (finished k).axis total ((bundles k).finish_count total (domain k))
  have orth (k l : Fin 3) (ne : k≠l) (u v : Grid.Five) : ((A k).row u ∩ (A l).row v).card=1 := by
    have raw := group_cross B h i five (e k).val (e l).val (sub (e k).property) (sub (e l).property)
      (fun eq => ne (e.injective (Subtype.ext eq)))
    exact (bundles k).finish_cross (bundles l) total (domain k) (domain l) raw
      _ ((finished k).axis_member ..) _ ((finished l).axis_member ..)
  let D : Chart (cells B i) := ⟨A 0,A 1,A 2,orth 0 1 (by decide),orth 0 2 (by decide),orth 1 2 (by decide)⟩
  obtain ⟨r,s,red⟩ := D.normalize
  refine ⟨D.reindex r (Equiv.refl _) s,red,?_⟩
  intro L inside sz hits
  have conn (k : Fin 3) : Along (A k) L := by
    intro j
    apply (bundles k).finish_hits total (domain k) L inside sz _ _ ((finished k).axis_member ..)
    intro M hm
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hm
    exact hits _ (e k).property x hx
  exact ⟨⟨L,inside,(fun t => conn 0 (r t)),(fun t => conn 1 t),(fun t => conn 2 (s t))⟩,rfl⟩

theorem stamp_fibers (T : Finset Photo) (sub : T ⊆ groups B i) (D : Grid.Chart (cells B i))
    (real : ∀ L : Finset Photo,L ⊆ cells B i → L.card=5 → crossesGroups B i T L → ∃ P : D.Path,P.cells=L)
    (cash : (∑ x,(degree B x-7)) ≤ excess B (companions B i)+3)
    (S : Finset Point) (os : S ⊆ ordinary B i) (c : Nat) :
    (S.filter (fun x => D.stamp (line B i x)=c)).card≤3 := by
  classical
  let F := S.filter (fun x => D.stamp (line B i x)=c)
  by_cases non : F.Nonempty
  · obtain ⟨x,hx⟩ := non
    let valid (y : Point) (hy : y ∈ F) := os (Finset.mem_filter.mp hy).1
    have len (y : Point) (hy : y ∈ F) := outside_line_count B h i five y
      (ordinary_away B i (valid y hy) (five_group_cover B h i five).1)
    have existsPath (y : Point) (hy : y ∈ F) := real _ (line_sub B i y) (len y hy)
      (ordinary_crosses B h i five sub y (valid y hy))
    obtain ⟨P,px⟩ := existsPath x hx
    have sameLine (y : Point) (hy : y ∈ F) : line B i y=line B i x := by
      obtain ⟨Q,qy⟩ := existsPath y hy
      have eq : D.stamp (line B i y)=D.stamp (line B i x) :=
        (Finset.mem_filter.mp hy).2.trans (Finset.mem_filter.mp hx).2.symm
      rw [←qy,←px,D.stamp_path Q,D.stamp_path P] at eq
      exact qy.symm.trans ((Q.same_mask P eq).trans px)
    exact three_per_line B h i five cash (line B i x) (len x hx) F (fun _ hy => valid _ hy) sameLine
  · change F.card≤3;rw [Finset.not_nonempty_iff_eq_empty.mp non];decide

end Cover61.LocalRows
