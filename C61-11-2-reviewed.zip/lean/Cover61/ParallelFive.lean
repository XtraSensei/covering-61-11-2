import Cover61.FiveGrid

namespace Cover61.Grid

variable {α : Type} [DecidableEq α]

def Cross (P Q : Finset (Finset α)) := ∀ x ∈ P, ∀ y ∈ Q, (x ∩ y).card=1

structure Bundle (U : Finset α) where
  lines : Finset (Finset α)
  sub : ∀ l ∈ lines, l ⊆ U
  size : ∀ l ∈ lines, l.card=5
  separate : ∀ l ∈ lines, ∀ k ∈ lines, l≠k → Disjoint l k

namespace Bundle
variable {U : Finset α} (P : Bundle U)

def occupied := P.lines.biUnion id
def leftover := U \ P.occupied

theorem occupied_sub : P.occupied ⊆ U := by
  intro x hx
  obtain ⟨l,hl,hx⟩ := Finset.mem_biUnion.mp hx
  exact P.sub l hl hx

theorem occupied_size : P.occupied.card=P.lines.card*5 := by
  change (P.lines.biUnion (fun x => x)).card=_
  rw [Finset.card_biUnion P.separate,Finset.sum_congr rfl P.size]
  simp

theorem line_left_disjoint (l : Finset α) (hl : l ∈ P.lines) : Disjoint l P.leftover := by
  apply Finset.disjoint_left.mpr
  intro x hx h
  exact (Finset.mem_sdiff.mp h).2 (Finset.mem_biUnion.mpr ⟨l,hl,hx⟩)

theorem leftover_size (tot : U.card=25) (four : P.lines.card=4) : P.leftover.card=5 := by
  rw [leftover,Finset.card_sdiff_of_subset P.occupied_sub,tot,P.occupied_size,four]

theorem meets_leftover (tot : U.card=25) (four : P.lines.card=4)
    (l : Finset α) (ls : l ⊆ U) (five : l.card=5) (hits : ∀ t ∈ P.lines,(l ∩ t).card=1) :
    (l ∩ P.leftover).card=1 := by
  have pieces : l ∩ P.occupied=P.lines.biUnion (fun t => l ∩ t) := by
    ext x
    simp only [occupied,Finset.mem_inter,Finset.mem_biUnion,id_eq]
    grind
  have seen : (l ∩ P.occupied).card=4 := by
    rw [pieces,Finset.card_biUnion (fun t ht s hs ne => (P.separate t ht s hs ne).mono Finset.inter_subset_right Finset.inter_subset_right),
      Finset.sum_congr rfl hits]
    simp [four]
  have diff : l ∩ P.leftover=l \ (l ∩ P.occupied) := by
    ext x
    simp only [leftover,Finset.mem_sdiff,Finset.mem_inter]
    constructor
    · rintro ⟨xl,_,xo⟩; exact ⟨xl,fun k => xo k.2⟩
    · rintro ⟨xl,no⟩; exact ⟨xl,ls xl,fun xo => no ⟨xl,xo⟩⟩
  rw [diff,Finset.card_sdiff_of_subset Finset.inter_subset_left,five,seen]

def finish (tot : U.card=25) (range : P.lines.card=4 ∨ P.lines.card=5) : Bundle U where
  lines := if P.lines.card=4 then insert P.leftover P.lines else P.lines
  sub l hl := by
    split at hl
    · rcases Finset.mem_insert.mp hl with rfl|hl
      · exact Finset.sdiff_subset
      · exact P.sub l hl
    · exact P.sub l hl
  size l hl := by
    split at hl
    next four =>
      rcases Finset.mem_insert.mp hl with rfl|hl
      · exact P.leftover_size tot four
      · exact P.size l hl
    next => exact P.size l hl
  separate l hl k hk ne := by
    split at hl
    next four =>
      rw [if_pos four] at hk
      rcases Finset.mem_insert.mp hl with rfl|hl <;> rcases Finset.mem_insert.mp hk with rfl|hk
      · exact (ne rfl).elim
      · exact (P.line_left_disjoint k hk).symm
      · exact P.line_left_disjoint l hl
      · exact P.separate l hl k hk ne
    next no => rw [if_neg no] at hk; exact P.separate l hl k hk ne

theorem finish_count (tot : U.card=25) (range : P.lines.card=4 ∨ P.lines.card=5) :
    (P.finish tot range).lines.card=5 := by
  change (if P.lines.card=4 then insert P.leftover P.lines else P.lines).card=5
  split
  next four =>
    have missing : P.leftover ∉ P.lines := by
      intro mem
      have empty : P.leftover=∅ := disjoint_self.mp (P.line_left_disjoint P.leftover mem)
      have := P.leftover_size tot four
      simp [empty] at this
    rw [Finset.card_insert_of_notMem missing,four]
  next no => exact range.resolve_left no

theorem finish_contains (tot : U.card=25) (range : P.lines.card=4 ∨ P.lines.card=5) : P.lines ⊆ (P.finish tot range).lines := by
  intro l hl
  change l ∈ (if P.lines.card=4 then insert P.leftover P.lines else P.lines)
  split <;> simp [hl]

theorem finish_hits (tot : U.card=25) (range : P.lines.card=4 ∨ P.lines.card=5)
    (l : Finset α) (ls : l ⊆ U) (five : l.card=5) (hits : ∀ t ∈ P.lines,(l ∩ t).card=1) :
    ∀ t ∈ (P.finish tot range).lines,(l ∩ t).card=1 := by
  intro t ht
  change t ∈ (if P.lines.card=4 then insert P.leftover P.lines else P.lines) at ht
  split at ht
  next four =>
    rcases Finset.mem_insert.mp ht with rfl|ht
    · exact P.meets_leftover tot four l ls five hits
    · exact hits t ht
  next => exact hits t ht

theorem finish_cross (Q : Bundle U) (tot : U.card=25) (p : P.lines.card=4 ∨ P.lines.card=5)
    (q : Q.lines.card=4 ∨ Q.lines.card=5) (orth : Cross P.lines Q.lines) :
    Cross (P.finish tot p).lines (Q.finish tot q).lines := by
  intro l hl
  apply Q.finish_hits tot q l ((P.finish tot p).sub l hl) ((P.finish tot p).size l hl)
  intro t ht
  rw [Finset.inter_comm]
  exact P.finish_hits tot p t (Q.sub t ht) (Q.size t ht) (fun v hv => by rw [Finset.inter_comm]; exact orth v hv t ht) l hl

end Bundle
end Cover61.Grid
