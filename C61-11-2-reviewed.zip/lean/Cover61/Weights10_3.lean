import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w10_005_04Rows : Rows 10 := fun i =>
  ([{0,2}, {1,2}, {0,3}, {1,3}, {4}, {0,4}, {5}, {1,5}, {3,4,5}, {6}, {2,6}, {0,5,6}, {7}, {3,7}, {2,4,7}, {1,6,7}, {8}, {0,1,8}, {2,3,8}, {4,6,8}, {5,7,8}, {9}, {1,4,9}, {2,5,9}, {3,6,9}, {0,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_005_04Cost : Cost := fun i =>
  ([0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, -2, 0, -2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_005_04_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_005_04Rows :=
  Weighted.exclude _ w10_005_04Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_006_01Rows : Rows 10 := fun i =>
  ([{0,2}, {1,2}, {0,3}, {1,3}, {2,3}, {4}, {0,4}, {5}, {1,5}, {6}, {0,1,6}, {4,5,6}, {7}, {2,4,7}, {3,5,7}, {6,7}, {8}, {3,4,8}, {0,5,8}, {2,6,8}, {1,7,8}, {9}, {1,4,9}, {2,5,9}, {3,6,9}, {0,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_006_01Cost : Cost := fun i =>
  ([0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_006_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_006_01Rows :=
  Weighted.exclude _ w10_006_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_010_01Rows : Rows 10 := fun i =>
  ([{0,2,3}, {0,4}, {1,4}, {2,4}, {0,5}, {1,5}, {2,5}, {3,4,5}, {0,6}, {1,6}, {3,6}, {7}, {2,7}, {1,3,7}, {4,6,7}, {8}, {0,1,8}, {3,8}, {2,6,8}, {5,7,8}, {9}, {1,2,9}, {3,9}, {5,6,9}, {0,7,9}, {4,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_010_01Cost : Cost := fun i =>
  ([0, 0, 0, 0, 0, 0, 1, -2, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_010_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_010_01Rows :=
  Weighted.exclude _ w10_010_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_012_05Rows : Rows 10 := fun i =>
  ([{0,3}, {1,2,3}, {0,4}, {1,4}, {0,5}, {1,5}, {2,5}, {3,4,5}, {1,6}, {2,6}, {3,6}, {7}, {0,1,7}, {2,7}, {4,6,7}, {8}, {3,8}, {2,4,8}, {0,6,8}, {5,7,8}, {9}, {0,2,9}, {4,9}, {5,6,9}, {3,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_012_05Cost : Cost := fun i =>
  ([0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, -2, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_012_05_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_012_05Rows :=
  Weighted.exclude _ w10_012_05Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
