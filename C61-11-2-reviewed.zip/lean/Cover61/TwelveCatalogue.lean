import Cover61.StructuralCover
import Cover61.Layer10_1
import Cover61.Layer11_1
import Cover61.Layer11_2
import Cover61.Layer12_1
import Cover61.Layer12_2
import Cover61.Layer12_3

namespace Cover61
open Skeleton Growth Layers

theorem twelve_catalogue (B : Family 38) (h : IsCover B) (a : (lows B).card=12) :
    (∃ j : Fin 22,Weighted.Realizes B (rows12_1 j)) ∨
    (∃ j : Fin 23,Weighted.Realizes B (rows12_2 j)) ∨
    (∃ j : Fin 19,Weighted.Realizes B (rows12_3 j)) := by
  have e10 : Exhausts rows10_1 1 :=
    induction_step Nine.candidates rows10_1 1 startNine steps10_1 balanced10_1
  have e11a : Exhausts rows11_1 1 := induction_step rows10_0 rows11_1 1 ten_exhausts steps11_1 balanced11_1
  have e11b : Exhausts rows11_2 2 := induction_step rows10_1 rows11_2 2 e10 steps11_2 balanced11_2
  have one : Exhausts rows12_1 1 := induction_step rows11_0 rows12_1 1 eleven_exhausts steps12_1 balanced12_1
  have two : Exhausts rows12_2 2 := induction_step rows11_1 rows12_2 2 e11a steps12_2 balanced12_2
  have three : Exhausts rows12_3 3 := induction_step rows11_2 rows12_3 3 e11b steps12_3 balanced12_3
  obtain ⟨p,six,eq⟩ := label_lows B a
  obtain ⟨balanced,k,alternatives,shape⟩ := twelve_shape B h a p six eq
  rcases alternatives with rfl|rfl|rfl
  · obtain ⟨j,sim⟩ := one _ balanced shape
    exact Or.inl ⟨j,realizes_similar B p six sim⟩
  · obtain ⟨j,sim⟩ := two _ balanced shape
    exact Or.inr (Or.inl ⟨j,realizes_similar B p six sim⟩)
  · obtain ⟨j,sim⟩ := three _ balanced shape
    exact Or.inr (Or.inr ⟨j,realizes_similar B p six sim⟩)

end Cover61
