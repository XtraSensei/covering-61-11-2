import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext24 : ∀ t, GoodStep 24 t := by decide +kernel

theorem ext25 : ∀ t, GoodStep 25 t := by decide +kernel

theorem ext26 : ∀ t, GoodStep 26 t := by decide +kernel

theorem ext27 : ∀ t, GoodStep 27 t := by decide +kernel

theorem ext28 : ∀ t, GoodStep 28 t := by decide +kernel

theorem ext29 : ∀ t, GoodStep 29 t := by decide +kernel

theorem ext30 : ∀ t, GoodStep 30 t := by decide +kernel

theorem ext31 : ∀ t, GoodStep 31 t := by decide +kernel

theorem ext32 : ∀ t, GoodStep 32 t := by decide +kernel

theorem ext33 : ∀ t, GoodStep 33 t := by decide +kernel

theorem ext34 : ∀ t, GoodStep 34 t := by decide +kernel

theorem ext35 : ∀ t, GoodStep 35 t := by decide +kernel

end Cover61.Nine
