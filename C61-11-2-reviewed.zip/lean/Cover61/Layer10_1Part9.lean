import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced10_1_108 : Balanced (rows10_1 108) := by decide +kernel

theorem balanced10_1_109 : Balanced (rows10_1 109) := by decide +kernel

theorem balanced10_1_110 : Balanced (rows10_1 110) := by decide +kernel

theorem balanced10_1_111 : Balanced (rows10_1 111) := by decide +kernel

theorem balanced10_1_112 : Balanced (rows10_1 112) := by decide +kernel

theorem balanced10_1_113 : Balanced (rows10_1 113) := by decide +kernel

theorem balanced10_1_114 : Balanced (rows10_1 114) := by decide +kernel

theorem balanced10_1_115 : Balanced (rows10_1 115) := by decide +kernel

theorem balanced10_1_116 : Balanced (rows10_1 116) := by decide +kernel

theorem balanced10_1_117 : Balanced (rows10_1 117) := by decide +kernel

theorem balanced10_1_118 : Balanced (rows10_1 118) := by decide +kernel

theorem balanced10_1_119 : Balanced (rows10_1 119) := by decide +kernel

end Cover61.Layers
