import Mathlib.Tactic.FinCases
import Cover61.Layer12_3Part0
import Cover61.Layer12_3Part1
import Cover61.Layer12_3Part2
import Cover61.Layer12_3Part3
import Cover61.Layer12_3Part4
namespace Cover61.Layers
open Skeleton Growth
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
theorem steps12_3 (j : Fin 54) : ∃ cert, Checked (rows11_2 j) rows12_3 3 cert := by
  fin_cases j
  · exact checked12_3_0
  · exact checked12_3_1
  · exact checked12_3_2
  · exact checked12_3_3
  · exact checked12_3_4
  · exact checked12_3_5
  · exact checked12_3_6
  · exact checked12_3_7
  · exact checked12_3_8
  · exact checked12_3_9
  · exact checked12_3_10
  · exact checked12_3_11
  · exact checked12_3_12
  · exact checked12_3_13
  · exact checked12_3_14
  · exact checked12_3_15
  · exact checked12_3_16
  · exact checked12_3_17
  · exact checked12_3_18
  · exact checked12_3_19
  · exact checked12_3_20
  · exact checked12_3_21
  · exact checked12_3_22
  · exact checked12_3_23
  · exact checked12_3_24
  · exact checked12_3_25
  · exact checked12_3_26
  · exact checked12_3_27
  · exact checked12_3_28
  · exact checked12_3_29
  · exact checked12_3_30
  · exact checked12_3_31
  · exact checked12_3_32
  · exact checked12_3_33
  · exact checked12_3_34
  · exact checked12_3_35
  · exact checked12_3_36
  · exact checked12_3_37
  · exact checked12_3_38
  · exact checked12_3_39
  · exact checked12_3_40
  · exact checked12_3_41
  · exact checked12_3_42
  · exact checked12_3_43
  · exact checked12_3_44
  · exact checked12_3_45
  · exact checked12_3_46
  · exact checked12_3_47
  · exact checked12_3_48
  · exact checked12_3_49
  · exact checked12_3_50
  · exact checked12_3_51
  · exact checked12_3_52
  · exact checked12_3_53
theorem balanced12_3 (j : Fin 19) : Balanced (rows12_3 j) := by
  fin_cases j
  · exact balanced12_3_0
  · exact balanced12_3_1
  · exact balanced12_3_2
  · exact balanced12_3_3
  · exact balanced12_3_4
  · exact balanced12_3_5
  · exact balanced12_3_6
  · exact balanced12_3_7
  · exact balanced12_3_8
  · exact balanced12_3_9
  · exact balanced12_3_10
  · exact balanced12_3_11
  · exact balanced12_3_12
  · exact balanced12_3_13
  · exact balanced12_3_14
  · exact balanced12_3_15
  · exact balanced12_3_16
  · exact balanced12_3_17
  · exact balanced12_3_18
end Cover61.Layers
