import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end14 : EndOK 14 := by decide +kernel

theorem end15 : EndOK 15 := by decide +kernel

theorem end16 : EndOK 16 := by decide +kernel

theorem end17 : EndOK 17 := by decide +kernel

theorem end18 : EndOK 18 := by decide +kernel

theorem end19 : EndOK 19 := by decide +kernel

theorem end20 : EndOK 20 := by decide +kernel

theorem end21 : EndOK 21 := by decide +kernel

theorem end22 : EndOK 22 := by decide +kernel

theorem end23 : EndOK 23 := by decide +kernel

theorem end24 : EndOK 24 := by decide +kernel

theorem end25 : EndOK 25 := by decide +kernel

theorem end26 : EndOK 26 := by decide +kernel

theorem end27 : EndOK 27 := by decide +kernel

theorem reg5 : Regular (candidates 5) := by decide +kernel

theorem reg6 : Regular (candidates 6) := by decide +kernel

theorem reg7 : Regular (candidates 7) := by decide +kernel

theorem reg8 : Regular (candidates 8) := by decide +kernel

theorem reg9 : Regular (candidates 9) := by decide +kernel

end Cover61.Nine
