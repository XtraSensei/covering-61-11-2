import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext144 : ∀ t, GoodStep 144 t := by decide +kernel

theorem ext145 : ∀ t, GoodStep 145 t := by decide +kernel

theorem ext146 : ∀ t, GoodStep 146 t := by decide +kernel

theorem ext147 : ∀ t, GoodStep 147 t := by decide +kernel

theorem ext148 : ∀ t, GoodStep 148 t := by decide +kernel

theorem ext149 : ∀ t, GoodStep 149 t := by decide +kernel

theorem ext150 : ∀ t, GoodStep 150 t := by decide +kernel

theorem ext151 : ∀ t, GoodStep 151 t := by decide +kernel

theorem ext152 : ∀ t, GoodStep 152 t := by decide +kernel

theorem ext153 : ∀ t, GoodStep 153 t := by decide +kernel

theorem ext154 : ∀ t, GoodStep 154 t := by decide +kernel

theorem ext155 : ∀ t, GoodStep 155 t := by decide +kernel

end Cover61.Nine
