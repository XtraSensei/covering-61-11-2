import Cover61.AGGeometry

namespace Cover61.Affine
set_option maxHeartbeats 4000000
set_option maxRecDepth 50000

def coord (d : Dir) (r i : Loc) : Labels :=
  ([0,1,2,3,4,5,6,8,7,0,3,6,1,4,7,2,8,5,0,4,8,1,5,6,2,7,3,0,5,7,1,3,8,2,6,4] : List Labels)[9*d.val+3*r.val+i.val]'(by simp; omega)
def cuttingDir (d : Dir) (i j : Loc) : Dir :=
  ([1,2,3,3,1,2,2,3,1,0,2,3,3,0,2,2,3,0,0,3,1,1,0,3,3,1,0,0,1,2,2,0,1,1,2,0] : List Dir)[9*d.val+3*i.val+j.val]'(by simp; omega)
def omitted (d : Dir) (i j : Loc) : Loc :=
  ([0,0,0,1,1,1,2,2,2,0,0,0,1,1,2,1,2,2,0,0,0,1,1,2,1,2,2,0,0,0,1,1,2,1,2,2] : List Loc)[9*d.val+3*i.val+j.val]'(by simp; omega)

def otherA (r : Loc) : Loc := if r=0 then 1 else 0
def otherB (r : Loc) : Loc := if r=2 then 1 else 2
def transversal (d : Dir) (i j r : Loc) : Labels :=
  coord d r (if r=0 then i else if r=1 then j else i+j)
def omittedRole (d : Dir) (i j : Loc) := D (cuttingDir d i j) (omitted d i j)
def photoOf (k : Photo) (a : Labels) := k = onePhoto a false ∨ k = onePhoto a true
instance (k : Photo) (a : Labels) : Decidable (photoOf k a) := by unfold photoOf; infer_instance

theorem cutDifferent : ∀ d i j, cuttingDir d i j ≠ d := by decide +kernel
theorem transversalFacts : ∀ (d : Dir) (r i j : Loc),
    let a := transversal d i j (otherA r)
    let b := transversal d i j (otherB r)
    let s := S d r
    let t := omittedRole d i j
    a ≠ b ∧ onLine s a = false ∧ onLine t a = false ∧
    onLine s b = false ∧ onLine t b = false ∧ ∀ k, allowed s k = true → allowed t k = true →
      photoOf k a ∨ photoOf k b := by decide +kernel

theorem rowsMeetOnFirst : ∀ d k, allowed (S d 1) k = true → allowed (S d 2) k = true →
    ∃ i, photoOf k (coord d 0 i) := by decide +kernel
theorem offOther : ∀ d i, onLine (S d 1) (coord d 0 i) = false ∧
    onLine (S d 2) (coord d 0 i) = false ∧ onLine (S d 2) (coord d 1 i) = false := by decide +kernel
theorem thirdSupport : ∀ d k, allowed (S d 2) k = true →
    k = line d 2 ∨ (∃ i, photoOf k (coord d 0 i)) ∨ ∃ i, photoOf k (coord d 1 i) := by decide +kernel
theorem thirdOn : ∀ d, line d 2 ∈ lines (S d 2) ∧ (line d 2).val < 12 := by decide +kernel

namespace Profile

theorem readCommon (p q : Profile) {k a} (hp : k ∈ p.U) (hq : k ∈ q.U)
    (pk : photoOf k a) (poff : onLine p.r a = false) (qoff : onLine q.r a = false) :
    p.bit a = q.bit a := by
  rcases pk with rfl | rfl
  · exact ((p.bitMem a poff false).mp hp).trans ((q.bitMem a qoff false).mp hq).symm
  · exact ((p.bitMem a poff true).mp hp).trans ((q.bitMem a qoff true).mp hq).symm

theorem writeCommon (p q : Profile) {a} (eq : p.bit a = q.bit a)
    (poff : onLine p.r a = false) (qoff : onLine q.r a = false) :
    onePhoto a (p.bit a) ∈ p.U ∩ q.U := Finset.mem_inter.mpr
      ⟨(p.bitMem a poff _).mpr rfl,(q.bitMem a qoff _).mpr eq.symm⟩

theorem comparison (p q : Profile) (d : Dir) (r i j : Loc) (pr : p.r = S d r)
    (qr : q.r = omittedRole d i j) (one : (p.U ∩ q.U).card = 1) :
    let a := transversal d i j (otherA r)
    let b := transversal d i j (otherB r)
    (p.bit a == q.bit a) ≠ (p.bit b == q.bit b) := by
  dsimp only
  let a := transversal d i j (otherA r)
  let b := transversal d i j (otherB r)
  obtain ⟨ne,ap,aq,bp,bq,only⟩ := transversalFacts d r i j
  rw [← pr] at ap bp only
  rw [← qr] at aq bq only
  change a ≠ b at ne
  have either : p.bit a = q.bit a ∨ p.bit b = q.bit b := by
    obtain ⟨k,hk⟩ := Finset.card_pos.mp (show 0 < (p.U ∩ q.U).card by omega)
    obtain ⟨hp,hq⟩ := Finset.mem_inter.mp hk
    rcases only k (p.support hp) (q.support hq) with kp | kp
    · exact Or.inl (p.readCommon q hp hq kp ap aq)
    · exact Or.inr (p.readCommon q hp hq kp bp bq)
  have excl (ha : p.bit a = q.bit a) (hb : p.bit b = q.bit b) : False := by
    have h1 := p.writeCommon q ha ap aq
    have h2 := p.writeCommon q hb bp bq
    have sub : ({onePhoto a (p.bit a), onePhoto b (p.bit b)} : Finset Photo) ⊆ p.U ∩ q.U := by
      intro k hk
      simp only [Finset.mem_insert,Finset.mem_singleton] at hk
      rcases hk with rfl | rfl <;> assumption
    have distinct : onePhoto a (p.bit a) ≠ onePhoto b (p.bit b) := fun e => ne (uniquePhoto _ _ _ _ e).1
    have small := Finset.card_le_card sub
    simp [distinct,one] at small
  change (p.bit a == q.bit a) ≠ (p.bit b == q.bit b)
  rcases either with ha | hb
  · have hn := excl ha
    simpa [ha] using hn
  · have hn : p.bit a ≠ q.bit a := fun h => excl h hb
    simp [hb,hn]

theorem transfer (p q : Profile) {k a} (hk : k ∈ p.U) (w : photoOf k a)
    (poff : onLine p.r a=false) (qoff : onLine q.r a=false) (eq : p.bit a=q.bit a) : k ∈ q.U := by
  rcases w with rfl | rfl
  · exact (q.bitMem a qoff false).mpr (eq ▸ (p.bitMem a poff false).mp hk)
  · exact (q.bitMem a qoff true).mpr (eq ▸ (p.bitMem a poff true).mp hk)

theorem agreeThird (p q : Profile) (d : Dir) (pr : p.r = S d 2) (qr : q.r = S d 2)
    (bitsA : ∀ i, p.bit (coord d 0 i) = q.bit (coord d 0 i))
    (bitsB : ∀ i, p.bit (coord d 1 i) = q.bit (coord d 1 i)) : p.U = q.U := by
  apply Finset.eq_of_subset_of_card_le _ (by rw [p.count,q.count])
  intro k hk
  have supp := p.support hk
  rw [pr] at supp
  rcases thirdSupport d k supp with he | ⟨i,ha⟩ | ⟨i,hb⟩
  · subst k; apply (q.lineMem (thirdOn d).2).mpr
    rw [qr]; exact (thirdOn d).1
  · exact p.transfer q hk ha (pr ▸ (offOther d i).2.1) (qr ▸ (offOther d i).2.1) (bitsA i)
  · exact p.transfer q hk hb (pr ▸ (offOther d i).2.2) (qr ▸ (offOther d i).2.2) (bitsB i)

end Profile
end Cover61.Affine
