import Cover61.DeletePoint
import Cover61.NineComplete

namespace Cover61.Growth
open Skeleton
set_option maxHeartbeats 1500000
set_option maxRecDepth 10000

def Exhausts {n m} (v : Fin m → Rows n) (q : Nat) :=
  ∀ r : Rows n, Balanced r → Shape (big r) q → ∃ k, Similar r (v k)

theorem chooseLast {n} (r : Rows (n+1)) (bal : Balanced r) (q : Nat) (sh : Shape (big r) q) :
    ∃ v, Similar r v ∧ Balanced v ∧ Shape (big v) q ∧
      (0 < q → ∃ s ∈ quads (big v), Fin.last n ∈ s) := by
  classical
  by_cases z : q=0
  · exact ⟨r,similar_refl r,bal,sh,by omega⟩
  have pos : 0 < (quads (big r)).card := by rw [sh.2.1]; omega
  obtain ⟨s,hs⟩ := Finset.card_pos.mp pos
  obtain ⟨_,hsz⟩ := Finset.mem_filter.mp hs
  obtain ⟨x,hx⟩ := Finset.card_pos.mp (show 0 < s.card by omega)
  let p := Equiv.swap x (Fin.last n)
  let v := move p (Equiv.refl _) r
  refine ⟨v,⟨p,Equiv.refl _,rfl⟩,move_balanced _ bal _ _,shape_move _ _ _ _ sh,fun _ => ?_⟩
  refine ⟨s.image p,?_,?_⟩
  · change _ ∈ quads (big (move p _ r))
    rw [move_big,quads_rename]
    exact Finset.mem_image_of_mem _ hs
  · exact Finset.mem_image.mpr ⟨x,hx,Equiv.swap_apply_left _ _⟩

theorem induction_step {n m m'} (parent : Fin m → Rows n) (dest : Fin m' → Rows (n+1)) (q : Nat)
    (prev : Exhausts parent (q-1))
    (steps : ∀ j, ∃ cert, Checked (parent j) dest q cert)
    (out : ∀ k, Balanced (dest k)) : Exhausts dest q := by
  intro r bal sh
  obtain ⟨u,ru,ub,ush,uLast⟩ := chooseLast r bal q sh
  obtain ⟨j,p,e,pre⟩ := prev (before u) (before_bal u ub) (before_shape u q ush uLast)
  let v := move (prolong p) e u
  have vs : Shape (big v) q := shape_move _ _ _ _ ush
  have vb : Balanced v := move_balanced _ ub _ _
  have par : before v = parent j := (before_move u p e).trans pre
  have eq : extension (parent j) (taken v) = v := by rw [← par,reconstruct]
  obtain ⟨cert,ok⟩ := steps j
  obtain ⟨k,sim⟩ := checked_sound (parent j) dest q cert ok (taken v) (taken_count v vb)
    (by rw [← par]; exact taken_fits v vb) (by rw [← par]; exact before_bal v vb) (by rwa [eq]) out (by rwa [eq])
  rw [eq] at sim
  exact ⟨k,similar_trans (similar_trans ru ⟨prolong p,e,rfl⟩) sim⟩

theorem small_diagram {n} (r : Rows n) (le : ∀ i, (r i).card ≤ 3) : big r = diagram r := by
  ext s
  rw [big_mem,mem_diagram]
  constructor
  · rintro ⟨⟨i,rfl⟩,h⟩
    exact ⟨⟨i,rfl⟩,Nat.le_antisymm (le i) h⟩
  · rintro ⟨w,eq⟩; exact ⟨w,eq.ge⟩

theorem startNine : Exhausts Nine.candidates 0 := by
  intro r bal sh
  have reg : Regular r := ⟨fun i => width r 0 sh i,bal⟩
  obtain ⟨k,q,hq⟩ := Nine.orbit (diagram r) (packing r reg)
  have eq : diagram (push q r) = Nine.state k := (push_diagram q r).trans hq
  have ok := Nine.endOK k (eq ▸ feasible_of_regular _ (push_regular q r reg))
  let j := (Nine.terminal k).1
  have iso : Iso (diagram r) (diagram (Nine.candidates j)) :=
    compose ⟨q,hq⟩ ⟨permutation _ ok.1,ok.2⟩
  refine ⟨j,similar_of_big bal (Nine.regOK j).2 ?_⟩
  rw [small_diagram r reg.1,small_diagram _ (Nine.regOK j).1]
  exact iso

end Cover61.Growth
