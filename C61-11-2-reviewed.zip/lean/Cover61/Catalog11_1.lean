import Cover61.Partitions

namespace Cover61.Catalog

open Partitions

set_option maxRecDepth 50000

set_option maxHeartbeats 3000000

def s11_055_02Head : Finset (Fin 11) := {3,4}

def s11_055_02Rest : List (Finset (Fin 11)) := [
  {0,1}, {0,2}, {1,2}, {0,3,5}, {4,5}, {1,3,6}, {5,6}, {0,4,7}, {2,5,7}, {6,7}, {2,3,8}, {1,5,8}, {4,6,8}, {7,8}, {3,9}, {2,4,9}, {0,6,9}, {1,7,9}, {8,9}, {10}, {1,4,10}, {2,6,10}, {3,7,10}, {0,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_055_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_055_02Head s11_055_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_055_03Head : Finset (Fin 11) := {5,7,10}

def s11_055_03Rest : List (Finset (Fin 11)) := [
  {0,1}, {0,2}, {1,2}, {3,4}, {0,3,5}, {4,5}, {0,4,6}, {5,6}, {1,3,7}, {2,4,7}, {6,7}, {1,4,8}, {2,5,8}, {3,6,8}, {7,8}, {3,9}, {1,5,9}, {2,6,9}, {0,7,9}, {8,9}, {10}, {2,3,10}, {1,6,10}, {0,8,10}, {4,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_055_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_055_03Head s11_055_03Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_056_01Head : Finset (Fin 11) := {0,2,4}

def s11_056_01Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {0,3}, {2,3}, {4,5}, {1,3,6}, {5,6}, {1,4,7}, {2,5,7}, {6,7}, {3,4,8}, {1,5,8}, {0,6,8}, {7,8}, {4,9}, {0,5,9}, {2,6,9}, {3,7,9}, {8,9}, {10}, {3,5,10}, {4,6,10}, {0,7,10}, {2,8,10}, {1,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_056_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_056_01Head s11_056_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_056_02Head : Finset (Fin 11) := {0,2,4}

def s11_056_02Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {0,3}, {2,3}, {4,5}, {1,3,6}, {5,6}, {3,4,7}, {2,5,7}, {6,7}, {1,4,8}, {3,5,8}, {0,6,8}, {7,8}, {4,9}, {1,5,9}, {2,6,9}, {0,7,9}, {8,9}, {10}, {0,5,10}, {4,6,10}, {1,7,10}, {2,8,10}, {3,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_056_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_056_02Head s11_056_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_056_03Head : Finset (Fin 11) := {0,5,10}

def s11_056_03Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {0,3}, {2,3}, {0,2,4}, {4,5}, {3,4,6}, {5,6}, {1,3,7}, {2,5,7}, {6,7}, {1,4,8}, {3,5,8}, {0,6,8}, {7,8}, {4,9}, {1,5,9}, {2,6,9}, {0,7,9}, {8,9}, {10}, {1,6,10}, {4,7,10}, {2,8,10}, {3,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_056_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_056_03Head s11_056_03Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_057_01Head : Finset (Fin 11) := {0,2,5}

def s11_057_01Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {0,4}, {3,4}, {1,4,6}, {5,6}, {0,3,7}, {1,5,7}, {6,7}, {2,4,8}, {3,5,8}, {0,6,8}, {7,8}, {1,3,9}, {5,9}, {2,6,9}, {4,7,9}, {8,9}, {10}, {4,5,10}, {3,6,10}, {2,7,10}, {1,8,10}, {0,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_057_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_057_01Head s11_057_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_057_02Head : Finset (Fin 11) := {0,2,5}

def s11_057_02Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {0,4}, {3,4}, {2,4,6}, {5,6}, {0,3,7}, {1,5,7}, {6,7}, {1,3,8}, {4,5,8}, {0,6,8}, {7,8}, {1,4,9}, {5,9}, {3,6,9}, {2,7,9}, {8,9}, {10}, {3,5,10}, {1,6,10}, {4,7,10}, {2,8,10}, {0,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_057_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_057_02Head s11_057_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_01Head : Finset (Fin 11) := {0,3,5}

def s11_058_01Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {0,4,6}, {5,6}, {0,2,7}, {1,3,7}, {6,7}, {1,4,8}, {2,5,8}, {3,6,8}, {7,8}, {0,9}, {2,4,9}, {1,6,9}, {5,7,9}, {8,9}, {10}, {1,5,10}, {2,6,10}, {4,7,10}, {0,8,10}, {3,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_01Head s11_058_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_02Head : Finset (Fin 11) := {0,3,5}

def s11_058_02Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {0,4,6}, {5,6}, {0,2,7}, {1,3,7}, {6,7}, {2,4,8}, {1,5,8}, {3,6,8}, {7,8}, {0,9}, {2,5,9}, {1,6,9}, {4,7,9}, {8,9}, {10}, {1,4,10}, {2,6,10}, {5,7,10}, {0,8,10}, {3,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_02Head s11_058_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_058_03Head : Finset (Fin 11) := {0,2,7}

def s11_058_03Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {0,3,5}, {4,5}, {0,4,6}, {5,6}, {1,4,7}, {6,7}, {2,4,8}, {1,5,8}, {3,6,8}, {7,8}, {0,9}, {2,5,9}, {1,6,9}, {3,7,9}, {8,9}, {10}, {1,3,10}, {2,6,10}, {5,7,10}, {0,8,10}, {4,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_058_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_058_03Head s11_058_03Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
