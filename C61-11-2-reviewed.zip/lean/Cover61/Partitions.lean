import Cover61.Incidence

namespace Cover61.Partitions

variable {α : Type} [DecidableEq α]

/-- Test if some sublist partitions precisely the requested points. -/
def check (target : Finset α) : List (Finset α) → Bool
  | [] => decide (target = ∅)
  | row :: rows =>
    check target rows || (decide (row.Nonempty ∧ row ⊆ target) && check (target \ row) rows)

/-- Number of selected rows containing a particular point. -/
def visits (x : α) : List (Finset α × Bool) → Nat
  | [] => 0
  | (s, yes) :: rest => (if yes = true ∧ x ∈ s then 1 else 0) + visits x rest

theorem accepts (rows : List (Finset α × Bool)) (target : Finset α)
    (h : ∀ x, visits x rows = if x ∈ target then 1 else 0) :
    check target (rows.map Prod.fst) = true := by
  induction rows generalizing target with
  | nil =>
    have he : target = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro x hx
      simpa [visits,hx] using h x
    simp [check,he]
  | cons head tail ih =>
    obtain ⟨s,b⟩ := head
    cases b with
    | false =>
      have ht := ih target (fun x => by simpa [visits] using h x)
      simp [check,ht]
    | true =>
      have hs : s ⊆ target := by
        intro x hx
        by_contra hn
        simpa [visits,hx,hn] using h x
      have ht := ih (target \ s) (by
        intro x
        have hh := h x
        by_cases hx : x ∈ s
        · have hy := hs hx
          simp [visits,hx,hy] at hh ⊢
          omega
        · simpa [visits,hx] using hh)
      by_cases empty : s = ∅
      · subst s; simp at ht; simp [check,ht]
      · simp [check,hs,ht,Finset.nonempty_iff_ne_empty.mpr empty]

def lowRow {b n : Nat} (B : Family b) (p : Fin n → Point) (i : Fin b) : Finset (Fin n) :=
  Finset.univ.filter (fun j => p j ∈ B i)

private theorem visits_as_sum {b n : Nat} (B : Family b) (p : Fin n → Point)
    (z : Point) (idx : List (Fin b)) (j : Fin n) :
    visits j (idx.map (fun i => (lowRow B p i,decide (z ∈ B i)))) =
    (idx.map (fun i => if p j ∈ B i ∧ z ∈ B i then 1 else 0)).sum := by
  induction idx with
  | nil => rfl
  | cons i is ih =>
    simp only [List.map_cons, visits, List.sum_cons, ih]
    simp [lowRow,and_comm]

/-- Connects the executable exact-cover test to an arbitrary covering. Each
designated point occurs six times. Fix an outsider on row i and delete i:
the selected remaining rows must partition the as-yet-unseen designated points. -/
theorem required {b n : Nat} (B : Family b) (h : IsCover B) (p : Fin n → Point)
    (six : ∀ j, degree B (p j) = 6) (z : Point) (ext : ∀ j, p j ≠ z)
    (i : Fin b) (zi : z ∈ B i) (idx : List (Fin b))
    (order : idx.Perm (Finset.univ.erase i).toList) :
    check (Finset.univ \ lowRow B p i) (idx.map (lowRow B p)) = true := by
  classical
  let t : Finset (Fin b) := Finset.univ.erase i
  have hh := accepts (idx.map (fun k => (lowRow B p k,decide (z ∈ B k))))
    (Finset.univ \ lowRow B p i) (by
      intro j
      rw [visits_as_sum, (order.map _).sum_eq, Finset.sum_map_toList]
      let f (k : Fin b) : Nat := if p j ∈ B k ∧ z ∈ B k then 1 else 0
      have hp : ∑ k, f k = 1 := by
        simpa [f,partners] using six_meets_once B h (p j) z (six j) (ext j)
      have he := Finset.sum_erase_add Finset.univ f (Finset.mem_univ i)
      rw [hp] at he
      change (∑ k ∈ Finset.univ.erase i, f k) = _
      by_cases hi : p j ∈ B i
      · have hf : f i = 1 := by simp [f,hi,zi]
        rw [hf] at he
        have hz : (∑ k ∈ Finset.univ.erase i, f k) = 0 := by omega
        simpa only [Finset.mem_sdiff,Finset.mem_univ,lowRow,Finset.mem_filter,hi,
          and_self,not_true_eq_false,and_false,if_false] using hz
      · have hf : f i = 0 := by simp [f,hi]
        rw [hf,Nat.add_zero] at he
        simpa [lowRow,hi] using he)
  simpa [t,List.map_map,Function.comp_def] using hh

/-- The first row is distinguished. All other rows, including empty ones, can
be listed in any order. The labels designate points of replication six. -/
def Realizes {n : Nat} (B : Family 38) (first : Finset (Fin n))
    (rest : List (Finset (Fin n))) : Prop :=
  ∃ (p : Fin n → Point) (i : Fin 38) (idx : List (Fin 38)),
    (∀ j, degree B (p j) = 6) ∧ idx.Perm (Finset.univ.erase i).toList ∧
    lowRow B p i = first ∧ idx.map (lowRow B p) = rest

theorem exclude {n : Nat} (first : Finset (Fin n)) (rest : List (Finset (Fin n)))
    (space : first.card < 11) (reject : check (Finset.univ \ first) rest = false) :
    ∀ B : Family 38, IsCover B → ¬ Realizes B first rest := by
  intro B h ⟨p,i,idx,six,order,head,tail⟩
  have existsOutside : ∃ z ∈ B i, ∀ j, p j ≠ z := by
    by_contra! hn
    have sub : B i ⊆ first.image p := by
      intro z hz
      obtain ⟨j,rfl⟩ := hn z hz
      exact Finset.mem_image.mpr ⟨j,by simpa [← head,lowRow] using hz,rfl⟩
    have size := (Finset.card_le_card sub).trans Finset.card_image_le
    rw [h.1 i] at size
    omega
  obtain ⟨z,zi,ext⟩ := existsOutside
  have hh := required B h p six z ext i zi idx order
  rw [head,tail,reject] at hh
  contradiction

end Cover61.Partitions
