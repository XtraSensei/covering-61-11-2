import Cover61.SecondMoment
import Cover61.LocalWeighted
import Mathlib.Data.Nat.Choose.Basic

namespace Cover61.Photos
open LocalRows

theorem diagonal_people (u : Nat) : (u:Int)*(u:Int)=(u:Int)+2*(u.choose 2:Int) := by
  induction u with
  | zero => decide
  | succ u ih =>
    rw [Nat.choose_succ_succ u 1,Nat.choose_one_right,Nat.cast_add,Nat.cast_succ]
    grind only

theorem square_weighted {α : Type} [DecidableEq α] (I : Finset α) (w z : α→Int) :
    (∑ i ∈ I,w i*z i)*(∑ i ∈ I,w i*z i)=∑ i ∈ I,∑ k ∈ I,(w i*w k)*(z i*z k) := by
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k _;grind only

theorem block_moment_expansion {α β : Type} [DecidableEq α] [DecidableEq β]
    (I : Finset α) (J : Finset β) (w : α→Int) (z : α→β→Int) :
    (∑ j ∈ J,(∑ i ∈ I,w i*z i j)*(∑ i ∈ I,w i*z i j))=
      ∑ i ∈ I,∑ k ∈ I,(w i*w k)*(∑ j ∈ J,z i j*z k j) := by
  let f (j : β) (i k : α) := (w i*w k)*(z i j*z k j)
  calc
    _ = ∑ j ∈ J,∑ i ∈ I,∑ k ∈ I,f j i k := Finset.sum_congr rfl (fun j _ => square_weighted I w (fun i => z i j))
    _ = ∑ i ∈ I,∑ j ∈ J,∑ k ∈ I,f j i k := Finset.sum_comm
    _ = ∑ i ∈ I,∑ k ∈ I,∑ j ∈ J,f j i k := Finset.sum_congr rfl (fun _ _ => Finset.sum_comm)
    _ = _ := by simp only [f,Finset.mul_sum]

theorem intersection_range {α : Type} [DecidableEq α] (U A B : Finset α) (a : A ⊆ U) (b : B ⊆ U) :
    A.card+B.card-U.card≤(A ∩ B).card ∧ (A ∩ B).card≤min A.card B.card := by
  have union := Finset.card_le_card (Finset.union_subset a b)
  have sum := Finset.card_union_add_card_inter A B
  exact ⟨by omega,le_min (Finset.card_le_card Finset.inter_subset_left) (Finset.card_le_card Finset.inter_subset_right)⟩

def within (B : Family 38) (J : Finset (Fin 38)) (x y : Point) := (J.filter (fun j => x ∈ B j ∧ y ∈ B j)).card

theorem class_other_visits (B : Family 38) (J : Finset (Fin 38)) (O : Finset Point) (c : Nat)
    (capacity : ∀ j ∈ J,(O ∩ B j).card=c) (x : Point) (xo : x ∈ O) :
    (∑ y ∈ O.erase x,(appearances B J y).card)+(appearances B J x).card=J.card*c := by
  rw [Finset.sum_erase_add _ _ xo,←block_sum B J O,Finset.sum_congr rfl capacity]
  simp

theorem class_partner_seats (B : Family 38) (J : Finset (Fin 38)) (O : Finset Point) (c : Nat)
    (capacity : ∀ j ∈ J,(O ∩ B j).card=c) (x : Point) (xo : x ∈ O) :
    ∑ y ∈ O.erase x,within B J x y=(appearances B J x).card*(c-1) := by
  have unit (j : Fin 38) (jg : j ∈ J) (xj : x ∈ B j) :
      ((O ∩ B j).erase x).card=c-1 := by
    rw [Finset.card_erase_of_mem (Finset.mem_inter.mpr ⟨xo,xj⟩),capacity j jg]
  calc
    _ = ∑ y ∈ O.erase x, ∑ j ∈ J,if x ∈ B j ∧ y ∈ B j then 1 else 0 := by simp [within]
    _ = ∑ j ∈ J, ∑ y ∈ O.erase x,if x ∈ B j ∧ y ∈ B j then 1 else 0 := Finset.sum_comm
    _ = ∑ j ∈ J,if x ∈ B j then c-1 else 0 := by
      apply Finset.sum_congr rfl;intro j hj
      by_cases xj : x ∈ B j
      · simpa [xj] using unit j hj xj
      · simp [xj]
    _ = _ := by rw [←Finset.sum_filter];simp [appearances]

theorem rounded_core_budget (B : Family 38) (h : IsCover B) (core : Point→Finset (Fin 38))
    (attends : ∀ x,∀ j ∈ core x,x ∈ B j) (x : Point) (S : Finset Point) (d : Nat) (pos : 0<d) :
    (∑ y ∈ S.erase x,(((core x ∩ core y).card-1)/d))≤10*(degree B x-6)/d := by
  apply (Nat.le_div_iff_mul_le pos).mpr
  rw [Finset.sum_mul]
  have each (y : Point) (_ : y ∈ S.erase x) : ((core x ∩ core y).card-1)/d*d≤partners B x y-1 := by
    have sub : core x ∩ core y ⊆ Finset.univ.filter (fun j => x ∈ B j ∧ y ∈ B j) := by
      intro j hj
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,attends x j (Finset.mem_inter.mp hj).1,attends y j (Finset.mem_inter.mp hj).2⟩
    exact (Nat.div_mul_le_self _ _).trans (Nat.sub_le_sub_right (Finset.card_le_card sub) 1)
  have upper := Finset.sum_le_sum_of_subset_of_nonneg (f := fun y => partners B x y-1)
    (Finset.erase_subset_erase x (Finset.subset_univ S)) (fun _ _ _ => Nat.zero_le _)
  rw [repeat_sum B h] at upper
  exact (Finset.sum_le_sum each).trans upper

end Cover61.Photos
