import Cover61.NineOrbits

import Cover61.NineEnds0

import Cover61.NineEnds1

import Cover61.NineEnds2

import Cover61.NineEnds3

import Cover61.NineEnds4

import Cover61.NineEnds5

import Cover61.NineEnds6

import Cover61.NineEnds7

import Cover61.NineEnds8

import Cover61.NineEnds9

import Cover61.NineEnds10

import Cover61.NineEnds11

namespace Cover61.Nine

open Skeleton

set_option maxRecDepth 50000

set_option maxHeartbeats 4000000

theorem endOK (j : Fin 163) : EndOK j := by
  fin_cases j
  · exact end0
  · exact end1
  · exact end2
  · exact end3
  · exact end4
  · exact end5
  · exact end6
  · exact end7
  · exact end8
  · exact end9
  · exact end10
  · exact end11
  · exact end12
  · exact end13
  · exact end14
  · exact end15
  · exact end16
  · exact end17
  · exact end18
  · exact end19
  · exact end20
  · exact end21
  · exact end22
  · exact end23
  · exact end24
  · exact end25
  · exact end26
  · exact end27
  · exact end28
  · exact end29
  · exact end30
  · exact end31
  · exact end32
  · exact end33
  · exact end34
  · exact end35
  · exact end36
  · exact end37
  · exact end38
  · exact end39
  · exact end40
  · exact end41
  · exact end42
  · exact end43
  · exact end44
  · exact end45
  · exact end46
  · exact end47
  · exact end48
  · exact end49
  · exact end50
  · exact end51
  · exact end52
  · exact end53
  · exact end54
  · exact end55
  · exact end56
  · exact end57
  · exact end58
  · exact end59
  · exact end60
  · exact end61
  · exact end62
  · exact end63
  · exact end64
  · exact end65
  · exact end66
  · exact end67
  · exact end68
  · exact end69
  · exact end70
  · exact end71
  · exact end72
  · exact end73
  · exact end74
  · exact end75
  · exact end76
  · exact end77
  · exact end78
  · exact end79
  · exact end80
  · exact end81
  · exact end82
  · exact end83
  · exact end84
  · exact end85
  · exact end86
  · exact end87
  · exact end88
  · exact end89
  · exact end90
  · exact end91
  · exact end92
  · exact end93
  · exact end94
  · exact end95
  · exact end96
  · exact end97
  · exact end98
  · exact end99
  · exact end100
  · exact end101
  · exact end102
  · exact end103
  · exact end104
  · exact end105
  · exact end106
  · exact end107
  · exact end108
  · exact end109
  · exact end110
  · exact end111
  · exact end112
  · exact end113
  · exact end114
  · exact end115
  · exact end116
  · exact end117
  · exact end118
  · exact end119
  · exact end120
  · exact end121
  · exact end122
  · exact end123
  · exact end124
  · exact end125
  · exact end126
  · exact end127
  · exact end128
  · exact end129
  · exact end130
  · exact end131
  · exact end132
  · exact end133
  · exact end134
  · exact end135
  · exact end136
  · exact end137
  · exact end138
  · exact end139
  · exact end140
  · exact end141
  · exact end142
  · exact end143
  · exact end144
  · exact end145
  · exact end146
  · exact end147
  · exact end148
  · exact end149
  · exact end150
  · exact end151
  · exact end152
  · exact end153
  · exact end154
  · exact end155
  · exact end156
  · exact end157
  · exact end158
  · exact end159
  · exact end160
  · exact end161
  · exact end162

theorem regOK (j : Fin 50) : Regular (candidates j) := by
  fin_cases j
  · exact reg0
  · exact reg1
  · exact reg2
  · exact reg3
  · exact reg4
  · exact reg5
  · exact reg6
  · exact reg7
  · exact reg8
  · exact reg9
  · exact reg10
  · exact reg11
  · exact reg12
  · exact reg13
  · exact reg14
  · exact reg15
  · exact reg16
  · exact reg17
  · exact reg18
  · exact reg19
  · exact reg20
  · exact reg21
  · exact reg22
  · exact reg23
  · exact reg24
  · exact reg25
  · exact reg26
  · exact reg27
  · exact reg28
  · exact reg29
  · exact reg30
  · exact reg31
  · exact reg32
  · exact reg33
  · exact reg34
  · exact reg35
  · exact reg36
  · exact reg37
  · exact reg38
  · exact reg39
  · exact reg40
  · exact reg41
  · exact reg42
  · exact reg43
  · exact reg44
  · exact reg45
  · exact reg46
  · exact reg47
  · exact reg48
  · exact reg49

/-- Every coverage with nine designated six-fold points and at most three
of them per row realizes one of the fifty recorded nine-point skeletons. -/
theorem exhaustive (B : Family 38) (h : IsCover B) (p : Fin 9 ↪ Point)
    (six : ∀ j, degree B (p j) = 6)
    (width : ∀ i, (Partitions.lowRow B p i).card ≤ 3) :
    ∃ j : Fin 50, Weighted.Realizes B (candidates j) := by
  let r := Partitions.lowRow B p
  have reg := regular_projection B h p six width
  obtain ⟨k,iso⟩ := orbit (diagram r) (packing r reg)
  obtain ⟨q,hq⟩ := iso
  have eq : diagram (push q r) = state k := (push_diagram q r).trans hq
  have ok := endOK k (eq ▸ feasible_of_regular _ (push_regular q r reg))
  let j := (terminal k).1
  have iso2 : Iso (state k) (diagram (candidates j)) := ⟨permutation _ ok.1,ok.2⟩
  exact ⟨j,realizes_of_iso B h p six width _ (regOK j) (compose ⟨q,hq⟩ iso2)⟩

end Cover61.Nine
