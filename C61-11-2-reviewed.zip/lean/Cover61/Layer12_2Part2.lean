import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_2_24 : List (Branch 11 23) := [
  ⟨{{0,5}, {1,7}, {2,3}, {4,10}, {6,8,9}},1,⟨2539264825856,2311784208393⟩⟩
]

theorem checked12_2_24 : ∃ cert, Checked (rows11_1 24) rows12_2 2 cert :=
  ⟨routes12_2_24, by decide +kernel⟩

private def routes12_2_25 : List (Branch 11 23) := [
  
]

theorem checked12_2_25 : ∃ cert, Checked (rows11_1 25) rows12_2 2 cert :=
  ⟨routes12_2_25, by decide +kernel⟩

private def routes12_2_26 : List (Branch 11 23) := [
  ⟨{{0,7,9}, {1,3}, {2,8}, {4}, {5}, {6,10}},1,⟨3932890329412,2384528956469⟩⟩
]

theorem checked12_2_26 : ∃ cert, Checked (rows11_1 26) rows12_2 2 cert :=
  ⟨routes12_2_26, by decide +kernel⟩

private def routes12_2_27 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,8,9}, {2,7}, {4,10}, {5}, {6}},2,⟨1131118794729,2354862063301⟩⟩
]

theorem checked12_2_27 : ∃ cert, Checked (rows11_1 27) rows12_2 2 cert :=
  ⟨routes12_2_27, by decide +kernel⟩

private def routes12_2_28 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,5}, {2,6,9}, {4}, {7,10}, {8}},22,⟨2484364458059,449524192722⟩⟩,
  ⟨{{0,1,7}, {2,8}, {3,9}, {4}, {5}, {6,10}},14,⟨1783168554277,4691403093751⟩⟩
]

theorem checked12_2_28 : ∃ cert, Checked (rows11_1 28) rows12_2 2 cert :=
  ⟨routes12_2_28, by decide +kernel⟩

private def routes12_2_29 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,6}, {2,3,5}, {7}, {8,10}, {9}},16,⟨1764456910810,5975622310361⟩⟩
]

theorem checked12_2_29 : ∃ cert, Checked (rows11_1 29) rows12_2 2 cert :=
  ⟨routes12_2_29, by decide +kernel⟩

private def routes12_2_30 : List (Branch 11 23) := [
  ⟨{{0,5,9}, {1,3}, {2,7}, {4}, {6}, {8,10}},8,⟨3192580028429,5276941652070⟩⟩,
  ⟨{{0,5,9}, {1,3}, {2,8}, {4}, {6}, {7,10}},9,⟨4483322393033,1275537912814⟩⟩
]

theorem checked12_2_30 : ∃ cert, Checked (rows11_1 30) rows12_2 2 cert :=
  ⟨routes12_2_30, by decide +kernel⟩

private def routes12_2_31 : List (Branch 11 23) := [
  
]

theorem checked12_2_31 : ∃ cert, Checked (rows11_1 31) rows12_2 2 cert :=
  ⟨routes12_2_31, by decide +kernel⟩

private def routes12_2_32 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,5}, {2,6,9}, {4,10}, {7}, {8}},2,⟨3126886287261,1054557715772⟩⟩,
  ⟨{{0,4}, {1,3}, {2,6,9}, {5,10}, {7}, {8}},2,⟨3189197612986,2998504974487⟩⟩,
  ⟨{{0,5,9}, {1,3}, {2,7}, {4,10}, {6}, {8}},13,⟨383819347285,1003858883291⟩⟩,
  ⟨{{0,5,9}, {1,3}, {2,8}, {4,10}, {6}, {7}},13,⟨323083957515,3047148545111⟩⟩
]

theorem checked12_2_32 : ∃ cert, Checked (rows11_1 32) rows12_2 2 cert :=
  ⟨routes12_2_32, by decide +kernel⟩

private def routes12_2_33 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,3}, {4,5,8}, {6}, {7,10}, {9}},22,⟨3165455464523,449524211730⟩⟩,
  ⟨{{0,2}, {1,6}, {3,7,8}, {4,10}, {5}, {9}},2,⟨1764704274333,1054557695180⟩⟩,
  ⟨{{0,2}, {1,6}, {3,9}, {4,5,8}, {7,10}},4,⟨5280541129259,449741129882⟩⟩,
  ⟨{{0,1,7}, {2,8}, {3,9}, {4,10}, {5}, {6}},20,⟨1155482717906,6219178249669⟩⟩
]

theorem checked12_2_33 : ∃ cert, Checked (rows11_1 33) rows12_2 2 cert :=
  ⟨routes12_2_33, by decide +kernel⟩

private def routes12_2_34 : List (Branch 11 23) := [
  
]

theorem checked12_2_34 : ∃ cert, Checked (rows11_1 34) rows12_2 2 cert :=
  ⟨routes12_2_34, by decide +kernel⟩

private def routes12_2_35 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,3}, {4,10}, {5,6,7}, {8}, {9}},2,⟨4536573827049,2354865049273⟩⟩
]

theorem checked12_2_35 : ∃ cert, Checked (rows11_1 35) rows12_2 2 cert :=
  ⟨routes12_2_35, by decide +kernel⟩

end Cover61.Layers
