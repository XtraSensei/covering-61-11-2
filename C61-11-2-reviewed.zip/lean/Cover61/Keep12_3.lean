import Cover61.CatalogueBridge
import Cover61.Catalog
import Cover61.Weights
import Cover61.NineCover
import Cover61.LayerData
namespace Cover61.Remainder
set_option maxRecDepth 60000
set_option maxHeartbeats 4000000
def live12_3 : Finset (Fin 19) := {1,5,10,15}
theorem keep12_3 (B : Family 38) (h : IsCover B) (j : Fin 19)
    (real : Weighted.Realizes B (Layers.rows12_3 j)) : j ∈ live12_3 := by
  fin_cases j
  · exact False.elim (Catalog.w12_073_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.w12_123_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w12_123_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w12_124_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.s12_125_01_excluded B h (pointed_of_realizes real 21
      [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w12_125_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w12_126_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s12_128_01_excluded B h (pointed_of_realizes real 10
      [0,1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.s12_129_01_excluded B h (pointed_of_realizes real 8
      [0,1,2,3,4,5,6,7,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w12_130_01_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w12_130_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.w12_130_03_excluded B h (rows_of_realizes real (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.s12_132_01_excluded B h (pointed_of_realizes real 11
      [0,1,2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.w12_132_02_excluded B h (rows_of_realizes real (by decide +kernel)))
  · exact False.elim (Catalog.s12_133_01_excluded B h (pointed_of_realizes real 8
      [0,1,2,3,4,5,6,7,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
end Cover61.Remainder
