import Cover61.Weighted
import Cover61.Frequencies

namespace Cover61.Affine

abbrev Photo := Fin 38
abbrev Labels := Fin 9

def planeRows : Weighted.Rows 9 := fun i =>
  ([{0,1,2},{3,4,5},{6,7,8},
    {0,3,6},{1,4,7},{2,5,8},
    {0,4,8},{1,5,6},{2,3,7},
    {0,5,7},{1,3,8},{2,4,6},
    {0},{0},{1},{1},{2},{2},{3},{3},{4},{4},{5},{5},
    {6},{6},{7},{7},{8},{8},∅,∅,∅,∅,∅,∅,∅,∅] : List (Finset Labels))[i.val]'(i.isLt)

def triples (U : Finset Photo) := U.filter (fun i => i.val < 12)
def singles (U : Finset Photo) := U.filter (fun i => 12 ≤ i.val ∧ i.val < 30)
def blanks (U : Finset Photo) := U.filter (fun i => 30 ≤ i.val)

private theorem line_inter : ∀ i j : Photo, i.val < 12 → j.val < 12 →
    i.val/3 ≠ j.val/3 → (planeRows i ∩ planeRows j).Nonempty := by decide +kernel

private theorem row_sizes : ∀ i : Photo, (planeRows i).card =
    3*(if i.val < 12 then 1 else 0) + (if 12 ≤ i.val ∧ i.val < 30 then 1 else 0) := by decide +kernel

theorem shape (U : Finset Photo) (size : U.card=7)
    (fits : Weighted.Fits planeRows U Finset.univ) :
    1 ≤ (triples U).card ∧ (triples U).card ≤ 3 ∧
    3*(triples U).card + (singles U).card = 9 ∧
    (blanks U).card + 2 = 2*(triples U).card ∧
    ∃ d : Nat, d < 4 ∧ ∀ i ∈ triples U, i.val/3 = d := by
  have meet (x : Labels) : (U.filter (fun i => x ∈ planeRows i)).card = 1 := by
    simpa using fits x
  have labelSum : ∑ i ∈ U, (planeRows i).card = 9 := by
    calc
      _ = ∑ i ∈ U, ∑ x : Labels, if x ∈ planeRows i then 1 else 0 := by simp
      _ = ∑ x : Labels, ∑ i ∈ U, if x ∈ planeRows i then 1 else 0 := Finset.sum_comm
      _ = _ := by simp [meet]
  simp only [row_sizes,Finset.sum_add_distrib, ← Finset.mul_sum,Finset.sum_boole,Nat.cast_id] at labelSum
  change 3*(triples U).card + (singles U).card = 9 at labelSum
  have unit (i : Photo) :
      (if i.val < 12 then 1 else 0) + (if 12 ≤ i.val ∧ i.val < 30 then 1 else 0) +
      (if 30 ≤ i.val then 1 else 0) = (1 : Nat) := by split <;> split <;> split <;> omega
  have count := Finset.sum_congr (s₁ := U) rfl (fun i _ => unit i)
  simp only [Finset.sum_add_distrib,Finset.sum_boole,Nat.cast_id,Finset.sum_const,Nat.nsmul_eq_mul,Nat.mul_one,size] at count
  change (triples U).card + (singles U).card + (blanks U).card = 7 at count
  have start : 0 < (triples U).card := by omega
  refine ⟨start,by omega,labelSum,by omega,?_⟩
  obtain ⟨i,hi⟩ := Finset.card_pos.mp start
  obtain ⟨hiU,hiL⟩ := Finset.mem_filter.mp hi
  refine ⟨i.val/3,by omega,?_⟩
  intro j hj
  obtain ⟨hjU,hjL⟩ := Finset.mem_filter.mp hj
  by_contra ne
  obtain ⟨x,hx⟩ := line_inter j i hjL hiL ne
  have ji : j ≠ i := by intro eq; exact ne (congrArg (fun k : Photo => k.val/3) eq)
  have subset : ({j,i} : Finset Photo) ⊆ U.filter (fun k => x ∈ planeRows k) := by
    intro k hk
    simp only [Finset.mem_insert,Finset.mem_singleton] at hk
    obtain ⟨a,b⟩ := Finset.mem_inter.mp hx
    rcases hk with rfl | rfl <;> simp [*]
  have le := Finset.card_le_card subset
  simp [ji,meet] at le

/-- Every outsider in a hypothesized covering with this affine skeleton and
exactly nine low points attends one, two or three parallel triple blocks. -/
theorem outsider_shape (B : Family 38) (h : IsCover B) (nine : (lows B).card = 9)
    (p : Labels ↪ Point) (e : Equiv.Perm Photo)
    (six : ∀ j, degree B (p j) = 6)
    (rows : ∀ i, Partitions.lowRow B p (e i) = planeRows i)
    (z : Point) (out : ∀ j, p j ≠ z) :
    let U := Finset.univ.filter (fun i => z ∈ B (e i))
    1 ≤ (triples U).card ∧ (triples U).card ≤ 3 ∧
    3*(triples U).card + (singles U).card = 9 ∧
    (blanks U).card + 2 = 2*(triples U).card ∧
    ∃ d : Nat, d < 4 ∧ ∀ i ∈ triples U, i.val/3 = d := by
  classical
  let U := Finset.univ.filter (fun i => z ∈ B (e i))
  apply shape U
  · have sub : Finset.univ.map p ⊆ lows B := by
      intro x hx
      obtain ⟨j,_,rfl⟩ := Finset.mem_map.mp hx
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,six j⟩
    have eq : Finset.univ.map p = lows B := Finset.eq_of_subset_of_card_le sub (by simp [nine])
    have hz : z ∉ lows B := by
      rw [← eq]
      intro hz
      obtain ⟨j,_,he⟩ := Finset.mem_map.mp hz
      exact out j he
    have remap := Equiv.sum_comp e (fun j => if z ∈ B j then (1:Nat) else 0)
    simp only [Finset.sum_boole,Nat.cast_id] at remap
    exact remap.trans (nine_rest_seven B h nine z hz)
  · intro x
    have remap := Equiv.sum_comp e (fun j => if p x ∈ B j ∧ z ∈ B j then (1:Nat) else 0)
    have meet := six_meets_once B h (p x) z (six x) (out x)
    simp only [Finset.sum_boole] at remap
    rw [← meet]
    simp [U,← rows,Partitions.lowRow,partners,Finset.filter_filter,and_comm] at remap ⊢
    exact remap

end Cover61.Affine
