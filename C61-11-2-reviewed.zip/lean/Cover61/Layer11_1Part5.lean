import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes11_1_60 : List (Branch 10 118) := [
  
]

theorem checked11_1_60 : ∃ cert, Checked (rows10_0 60) rows11_1 1 cert :=
  ⟨routes11_1_60, by decide +kernel⟩

private def routes11_1_61 : List (Branch 10 118) := [
  
]

theorem checked11_1_61 : ∃ cert, Checked (rows10_0 61) rows11_1 1 cert :=
  ⟨routes11_1_61, by decide +kernel⟩

private def routes11_1_62 : List (Branch 10 118) := [
  
]

theorem checked11_1_62 : ∃ cert, Checked (rows10_0 62) rows11_1 1 cert :=
  ⟨routes11_1_62, by decide +kernel⟩

private def routes11_1_63 : List (Branch 10 118) := [
  
]

theorem checked11_1_63 : ∃ cert, Checked (rows10_0 63) rows11_1 1 cert :=
  ⟨routes11_1_63, by decide +kernel⟩

private def routes11_1_64 : List (Branch 10 118) := [
  
]

theorem checked11_1_64 : ∃ cert, Checked (rows10_0 64) rows11_1 1 cert :=
  ⟨routes11_1_64, by decide +kernel⟩

theorem balanced11_1_60 : Balanced (rows11_1 60) := by decide +kernel

theorem balanced11_1_61 : Balanced (rows11_1 61) := by decide +kernel

theorem balanced11_1_62 : Balanced (rows11_1 62) := by decide +kernel

theorem balanced11_1_63 : Balanced (rows11_1 63) := by decide +kernel

theorem balanced11_1_64 : Balanced (rows11_1 64) := by decide +kernel

theorem balanced11_1_65 : Balanced (rows11_1 65) := by decide +kernel

theorem balanced11_1_66 : Balanced (rows11_1 66) := by decide +kernel

theorem balanced11_1_67 : Balanced (rows11_1 67) := by decide +kernel

theorem balanced11_1_68 : Balanced (rows11_1 68) := by decide +kernel

theorem balanced11_1_69 : Balanced (rows11_1 69) := by decide +kernel

theorem balanced11_1_70 : Balanced (rows11_1 70) := by decide +kernel

theorem balanced11_1_71 : Balanced (rows11_1 71) := by decide +kernel

end Cover61.Layers
