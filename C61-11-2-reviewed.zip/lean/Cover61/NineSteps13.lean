import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext156 : ∀ t, GoodStep 156 t := by decide +kernel

theorem ext157 : ∀ t, GoodStep 157 t := by decide +kernel

theorem ext158 : ∀ t, GoodStep 158 t := by decide +kernel

theorem ext159 : ∀ t, GoodStep 159 t := by decide +kernel

theorem ext160 : ∀ t, GoodStep 160 t := by decide +kernel

theorem ext161 : ∀ t, GoodStep 161 t := by decide +kernel

theorem ext162 : ∀ t, GoodStep 162 t := by decide +kernel

end Cover61.Nine
