import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes11_2_36 : List (Branch 10 54) := [
  ⟨{{0,3,4}, {1,6}, {2,5}, {7,8}, {9}},21,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,3,4}, {1,9}, {2}, {5,7}, {6,8}},22,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,7}, {1,5,8}, {2,3}, {4,6}, {9}},21,⟨281583141885,281583141885⟩⟩,
  ⟨{{0,9}, {1,5,8}, {2}, {3,6}, {4,7}},22,⟨281583141885,281583141885⟩⟩
]

theorem checked11_2_36 : ∃ cert, Checked (rows10_1 36) rows11_2 2 cert :=
  ⟨routes11_2_36, by decide +kernel⟩

private def routes11_2_37 : List (Branch 10 54) := [
  
]

theorem checked11_2_37 : ∃ cert, Checked (rows10_1 37) rows11_2 2 cert :=
  ⟨routes11_2_37, by decide +kernel⟩

private def routes11_2_38 : List (Branch 10 54) := [
  
]

theorem checked11_2_38 : ∃ cert, Checked (rows10_1 38) rows11_2 2 cert :=
  ⟨routes11_2_38, by decide +kernel⟩

private def routes11_2_39 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,6,7}, {3,8}, {4,5}, {9}},21,⟨258879076995,258879076995⟩⟩,
  ⟨{{0}, {1,5,8}, {2}, {3,6}, {4,7}, {9}},21,⟨258682581355,258682581355⟩⟩,
  ⟨{{0,7}, {1,5,8}, {2,3}, {4,6}, {9}},23,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,4}, {2,6,7}, {3,5}, {9}},23,⟨282262058265,282262058265⟩⟩
]

theorem checked11_2_39 : ∃ cert, Checked (rows10_1 39) rows11_2 2 cert :=
  ⟨routes11_2_39, by decide +kernel⟩

private def routes11_2_40 : List (Branch 10 54) := [
  ⟨{{0,1,2}, {3,8}, {4,5}, {6,7}, {9}},24,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,9}, {1,3,5}, {2,8}, {4}, {6,7}},25,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_40 : ∃ cert, Checked (rows10_1 40) rows11_2 2 cert :=
  ⟨routes11_2_40, by decide +kernel⟩

private def routes11_2_41 : List (Branch 10 54) := [
  ⟨{{0,1,2}, {3,8}, {4,5}, {6,7}, {9}},26,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,9}, {1,3,5}, {2,8}, {4}, {6,7}},26,⟨270668082195,270668082195⟩⟩
]

theorem checked11_2_41 : ∃ cert, Checked (rows10_1 41) rows11_2 2 cert :=
  ⟨routes11_2_41, by decide +kernel⟩

private def routes11_2_42 : List (Branch 10 54) := [
  ⟨{{0,5,6}, {1,4}, {2,8}, {3,7}, {9}},12,⟨135061871545,116832541745⟩⟩,
  ⟨{{0,5,6}, {1,9}, {2,8}, {3,7}, {4}},13,⟨153494715075,234632525475⟩⟩,
  ⟨{{0,9}, {1,3,5}, {2,8}, {4}, {6,7}},27,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_42 : ∃ cert, Checked (rows10_1 42) rows11_2 2 cert :=
  ⟨routes11_2_42, by decide +kernel⟩

private def routes11_2_43 : List (Branch 10 54) := [
  ⟨{{0,9}, {1}, {2,3}, {4,6,8}, {5,7}},25,⟨258879076995,258879076995⟩⟩,
  ⟨{{0,9}, {1}, {2,5}, {3,7}, {4,6,8}},26,⟨129191220735,244730672235⟩⟩,
  ⟨{{0,9}, {1}, {2,4,7}, {3,6}, {5,8}},27,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_43 : ∃ cert, Checked (rows10_1 43) rows11_2 2 cert :=
  ⟨routes11_2_43, by decide +kernel⟩

private def routes11_2_44 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3}, {4,6,8}, {5,7}, {9}},24,⟨258879076995,258879076995⟩⟩,
  ⟨{{0}, {1}, {2,5}, {3,7}, {4,6,8}, {9}},26,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_44 : ∃ cert, Checked (rows10_1 44) rows11_2 2 cert :=
  ⟨routes11_2_44, by decide +kernel⟩

private def routes11_2_45 : List (Branch 10 54) := [
  ⟨{{0}, {1,7,8}, {2,5}, {3,6}, {4}, {9}},27,⟨127895289285,236368906285⟩⟩
]

theorem checked11_2_45 : ∃ cert, Checked (rows10_1 45) rows11_2 2 cert :=
  ⟨routes11_2_45, by decide +kernel⟩

private def routes11_2_46 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,4,7}, {3,6}, {5,8}, {9}},12,⟨64323440815,116832380815⟩⟩,
  ⟨{{0}, {1,7,8}, {2,5}, {3,6}, {4}, {9}},13,⟨116199622415,40189468315⟩⟩
]

theorem checked11_2_46 : ∃ cert, Checked (rows10_1 46) rows11_2 2 cert :=
  ⟨routes11_2_46, by decide +kernel⟩

private def routes11_2_47 : List (Branch 10 54) := [
  ⟨{{0,7}, {1,4}, {2,5}, {3,6,8}, {9}},28,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_47 : ∃ cert, Checked (rows10_1 47) rows11_2 2 cert :=
  ⟨routes11_2_47, by decide +kernel⟩

theorem balanced11_2_36 : Balanced (rows11_2 36) := by decide +kernel

theorem balanced11_2_37 : Balanced (rows11_2 37) := by decide +kernel

theorem balanced11_2_38 : Balanced (rows11_2 38) := by decide +kernel

theorem balanced11_2_39 : Balanced (rows11_2 39) := by decide +kernel

theorem balanced11_2_40 : Balanced (rows11_2 40) := by decide +kernel

theorem balanced11_2_41 : Balanced (rows11_2 41) := by decide +kernel

theorem balanced11_2_42 : Balanced (rows11_2 42) := by decide +kernel

theorem balanced11_2_43 : Balanced (rows11_2 43) := by decide +kernel

theorem balanced11_2_44 : Balanced (rows11_2 44) := by decide +kernel

theorem balanced11_2_45 : Balanced (rows11_2 45) := by decide +kernel

theorem balanced11_2_46 : Balanced (rows11_2 46) := by decide +kernel

theorem balanced11_2_47 : Balanced (rows11_2 47) := by decide +kernel

end Cover61.Layers
