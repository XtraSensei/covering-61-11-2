import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w10_002_01Rows : Rows 10 := fun i =>
  ([{0,2}, {0,3}, {1,3}, {4}, {0,4}, {1,2,4}, {5}, {1,5}, {2,3,5}, {6}, {1,6}, {3,4,6}, {7}, {0,1,7}, {2,7}, {5,6,7}, {8}, {2,8}, {4,5,8}, {0,6,8}, {3,7,8}, {9}, {3,9}, {0,5,9}, {2,6,9}, {4,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_002_01Cost : Cost := fun i =>
  ([0, 0, 0, 0, 0, 0, 1, 2, -1, 2, 1, 0, 1, -1, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_002_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_002_01Rows :=
  Weighted.exclude _ w10_002_01Cost (2) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_002_02Rows : Rows 10 := fun i =>
  ([{0,2}, {0,3}, {1,3}, {4}, {0,4}, {1,2,4}, {5}, {1,5}, {2,3,5}, {6}, {1,6}, {4,5,6}, {7}, {0,1,7}, {2,7}, {3,6,7}, {8}, {2,8}, {3,4,8}, {0,6,8}, {5,7,8}, {9}, {3,9}, {0,5,9}, {2,6,9}, {4,7,9}, {1,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_002_02Cost : Cost := fun i =>
  ([0, 0, 0, 0, 1, 0, 1, 0, -1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_002_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_002_02Rows :=
  Weighted.exclude _ w10_002_02Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_002_03Rows : Rows 10 := fun i =>
  ([{0,2}, {0,3}, {1,3}, {4}, {0,4}, {1,2,4}, {5}, {1,5}, {2,3,5}, {6}, {1,6}, {4,5,6}, {7}, {2,7}, {0,5,7}, {3,6,7}, {8}, {2,8}, {3,4,8}, {0,6,8}, {1,7,8}, {9}, {0,1,9}, {3,9}, {2,6,9}, {4,7,9}, {5,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_002_03Cost : Cost := fun i =>
  ([0, 1, 0, 1, 1, 0, 1, 0, -1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, -1, 0, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_002_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_002_03Rows :=
  Weighted.exclude _ w10_002_03Cost (2) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_003_01Rows : Rows 10 := fun i =>
  ([{0,2}, {0,3}, {2,3}, {4}, {0,4}, {1,3,4}, {5}, {1,5}, {2,4,5}, {6}, {1,6}, {0,5,6}, {7}, {1,7}, {3,5,7}, {2,6,7}, {8}, {0,1,8}, {2,8}, {3,6,8}, {4,7,8}, {9}, {1,2,9}, {3,9}, {4,6,9}, {0,7,9}, {5,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_003_01Cost : Cost := fun i =>
  ([0, 0, 0, 1, 1, -1, 2, 0, -1, 2, 0, 0, 2, 0, 0, 0, 1, -1, 1, -1, 0, 1, -1, 1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_003_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_003_01Rows :=
  Weighted.exclude _ w10_003_01Cost (3) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
