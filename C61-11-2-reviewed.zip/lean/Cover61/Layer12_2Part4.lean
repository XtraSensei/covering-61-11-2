import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_2_48 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,5}, {2,6,9}, {4,10}, {7}, {8}},0,⟨1127136256268,949610751254⟩⟩
]

theorem checked12_2_48 : ∃ cert, Checked (rows11_1 48) rows12_2 2 cert :=
  ⟨routes12_2_48, by decide +kernel⟩

private def routes12_2_49 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,3}, {4,10}, {5,7,8}, {6}, {9}},3,⟨4475436570704,2311795526722⟩⟩,
  ⟨{{0,2}, {1,6}, {3,4,8}, {5}, {7,10}, {9}},19,⟨1074941592010,5227511130567⟩⟩,
  ⟨{{0,2}, {1,6}, {3,9}, {4,10}, {5,7,8}},0,⟨4532591288588,949613737226⟩⟩,
  ⟨{{0,1,7}, {2,8}, {3,9}, {4,10}, {5}, {6}},19,⟨1155482717906,6219178249669⟩⟩
]

theorem checked12_2_49 : ∃ cert, Checked (rows11_1 49) rows12_2 2 cert :=
  ⟨routes12_2_49, by decide +kernel⟩

private def routes12_2_50 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,6,7}, {4,10}, {8}, {9}},7,⟨4469925181700,1816527238438⟩⟩
]

theorem checked12_2_50 : ∃ cert, Checked (rows11_1 50) rows12_2 2 cert :=
  ⟨routes12_2_50, by decide +kernel⟩

private def routes12_2_51 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,3}, {4,7,9}, {5}, {6}, {8,10}},15,⟨3126638923738,5975622330953⟩⟩,
  ⟨{{0,6,8}, {1,3}, {2,7}, {4}, {5}, {9,10}},15,⟨3212378509637,5779623100361⟩⟩
]

theorem checked12_2_51 : ∃ cert, Checked (rows11_1 51) rows12_2 2 cert :=
  ⟨routes12_2_51, by decide +kernel⟩

private def routes12_2_52 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,4,8}, {6,10}, {7}, {9}},18,⟨3207266201678,4134143615635⟩⟩,
  ⟨{{0,2}, {1,6}, {3,4,8}, {5,10}, {7}, {9}},17,⟨3207268938830,4815234622099⟩⟩,
  ⟨{{0,3}, {1,5}, {2,6,9}, {4,10}, {7}, {8}},19,⟨4560937750226,6219181235641⟩⟩,
  ⟨{{0,4}, {1,3}, {2,6,9}, {5,10}, {7}, {8}},22,⟨4499020347998,6157693853014⟩⟩
]

theorem checked12_2_52 : ∃ cert, Checked (rows11_1 52) rows12_2 2 cert :=
  ⟨routes12_2_52, by decide +kernel⟩

private def routes12_2_53 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,8}, {4,7,9}, {5,10}},5,⟨5289860867148,2360586915192⟩⟩,
  ⟨{{0,4}, {1,6}, {2,3,5}, {7}, {8}, {9,10}},15,⟨2531287503173,5779623081353⟩⟩
]

theorem checked12_2_53 : ∃ cert, Checked (rows11_1 53) rows12_2 2 cert :=
  ⟨routes12_2_53, by decide +kernel⟩

private def routes12_2_54 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,4,8}, {6,10}, {7}, {9}},9,⟨2508073056401,5332839253544⟩⟩
]

theorem checked12_2_54 : ∃ cert, Checked (rows11_1 54) rows12_2 2 cert :=
  ⟨routes12_2_54, by decide +kernel⟩

private def routes12_2_55 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,6,7}, {4,10}, {8}, {9}},21,⟨1763789879346,3473573753023⟩⟩,
  ⟨{{0,2}, {1,6}, {3,4,8}, {5}, {7,10}, {9}},12,⟨3166310694074,4557245604593⟩⟩
]

theorem checked12_2_55 : ∃ cert, Checked (rows11_1 55) rows12_2 2 cert :=
  ⟨routes12_2_55, by decide +kernel⟩

private def routes12_2_56 : List (Branch 11 23) := [
  
]

theorem checked12_2_56 : ∃ cert, Checked (rows11_1 56) rows12_2 2 cert :=
  ⟨routes12_2_56, by decide +kernel⟩

private def routes12_2_57 : List (Branch 11 23) := [
  
]

theorem checked12_2_57 : ∃ cert, Checked (rows11_1 57) rows12_2 2 cert :=
  ⟨routes12_2_57, by decide +kernel⟩

private def routes12_2_58 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,6}, {2,3,5}, {7}, {8,10}, {9}},13,⟨1764456910810,5975622310361⟩⟩
]

theorem checked12_2_58 : ∃ cert, Checked (rows11_1 58) rows12_2 2 cert :=
  ⟨routes12_2_58, by decide +kernel⟩

private def routes12_2_59 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,7}, {4,10}, {5,8,9}},4,⟨4542871995057,1549868227611⟩⟩
]

theorem checked12_2_59 : ∃ cert, Checked (rows11_1 59) rows12_2 2 cert :=
  ⟨routes12_2_59, by decide +kernel⟩

end Cover61.Layers
