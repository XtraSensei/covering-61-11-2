import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_1_24 : List (Branch 11 22) := [
  ⟨{{0,9}, {1,4,10}, {2,3}, {5,6}, {7,8}},13,⟨1694795764343,141702066880⟩⟩
]

theorem checked12_1_24 : ∃ cert, Checked (rows11_0 24) rows12_1 1 cert :=
  ⟨routes12_1_24, by decide +kernel⟩

private def routes12_1_25 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,9,10}, {5,6}, {7,8}},15,⟨2356570961481,2542321064217⟩⟩
]

theorem checked12_1_25 : ∃ cert, Checked (rows11_0 25) rows12_1 1 cert :=
  ⟨routes12_1_25, by decide +kernel⟩

private def routes12_1_26 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,7,10}, {5,6}, {8,9}},17,⟨1701463987960,2582514128359⟩⟩,
  ⟨{{0,1}, {2,5,10}, {3,4}, {6,7}, {8,9}},10,⟨2391304856358,4721953646366⟩⟩,
  ⟨{{0,9}, {1,6,10}, {2,3}, {4,5}, {7,8}},17,⟨2376048632265,5511627016489⟩⟩
]

theorem checked12_1_26 : ∃ cert, Checked (rows11_0 26) rows12_1 1 cert :=
  ⟨routes12_1_26, by decide +kernel⟩

private def routes12_1_27 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,9,10}, {5,6}, {7,8}},21,⟨2356923307772,2579933866521⟩⟩,
  ⟨{{0,1}, {2,5,10}, {3,4}, {6,7}, {8,9}},11,⟨2391304856358,4721953646366⟩⟩,
  ⟨{{0,9}, {1,6,10}, {2,3}, {4,5}, {7,8}},12,⟨2387192547608,4159097570089⟩⟩
]

theorem checked12_1_27 : ∃ cert, Checked (rows11_0 27) rows12_1 1 cert :=
  ⟨routes12_1_27, by decide +kernel⟩

private def routes12_1_28 : List (Branch 11 22) := [
  ⟨{{0,9}, {1,6,10}, {2,3}, {4,5}, {7,8}},7,⟨1706101541144,4159097568505⟩⟩
]

theorem checked12_1_28 : ∃ cert, Checked (rows11_0 28) rows12_1 1 cert :=
  ⟨routes12_1_28, by decide +kernel⟩

private def routes12_1_29 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,7,10}, {5,6}, {8,9}},19,⟨1707525260551,6342687408904⟩⟩,
  ⟨{{0,1}, {2,9,10}, {3,4}, {5,6}, {7,8}},19,⟨2362589519147,511518322766⟩⟩,
  ⟨{{0,9}, {1,2}, {3,8,10}, {4,5}, {6,7}},16,⟨2405297888730,5779851406659⟩⟩
]

theorem checked12_1_29 : ∃ cert, Checked (rows11_0 29) rows12_1 1 cert :=
  ⟨routes12_1_29, by decide +kernel⟩

private def routes12_1_30 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,7,10}, {5,6}, {8,9}},10,⟨1711783795458,3944974874599⟩⟩,
  ⟨{{0,1}, {2,5,10}, {3,4}, {6,7}, {8,9}},14,⟨1705044845647,2314190516429⟩⟩,
  ⟨{{0,9}, {1,2}, {3,8,10}, {4,5}, {6,7}},14,⟨2405297888730,5779851406659⟩⟩
]

theorem checked12_1_30 : ∃ cert, Checked (rows11_0 30) rows12_1 1 cert :=
  ⟨routes12_1_30, by decide +kernel⟩

private def routes12_1_31 : List (Branch 11 22) := [
  ⟨{{0,9}, {1,2}, {3,8,10}, {4,5}, {6,7}},6,⟨1724210594117,5770551474963⟩⟩
]

theorem checked12_1_31 : ∃ cert, Checked (rows11_0 31) rows12_1 1 cert :=
  ⟨routes12_1_31, by decide +kernel⟩

private def routes12_1_32 : List (Branch 11 22) := [
  ⟨{{0,9}, {1,2}, {3,8,10}, {4,5}, {6,7}},3,⟨2405304337744,5770584550467⟩⟩
]

theorem checked12_1_32 : ∃ cert, Checked (rows11_0 32) rows12_1 1 cert :=
  ⟨routes12_1_32, by decide +kernel⟩

private def routes12_1_33 : List (Branch 11 22) := [
  ⟨{{0,9}, {1,6,10}, {2,3}, {4,5}, {7,8}},2,⟨2375973504454,1524439595250⟩⟩
]

theorem checked12_1_33 : ∃ cert, Checked (rows11_0 33) rows12_1 1 cert :=
  ⟨routes12_1_33, by decide +kernel⟩

private def routes12_1_34 : List (Branch 11 22) := [
  ⟨{{0,9}, {1,2}, {3,8,10}, {4,5}, {6,7}},4,⟨1729334563253,7142193085203⟩⟩
]

theorem checked12_1_34 : ∃ cert, Checked (rows11_0 34) rows12_1 1 cert :=
  ⟨routes12_1_34, by decide +kernel⟩

private def routes12_1_35 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,9,10}, {5,6}, {7,8}},13,⟨2362590183239,513237212752⟩⟩,
  ⟨{{0,9}, {1,2}, {3,8,10}, {4,5}, {6,7}},13,⟨2399604386608,1783331437580⟩⟩,
  ⟨{{0,9}, {1,6,10}, {2,3}, {4,5}, {7,8}},20,⟨2375973504454,1524439595250⟩⟩
]

theorem checked12_1_35 : ∃ cert, Checked (rows11_0 35) rows12_1 1 cert :=
  ⟨routes12_1_35, by decide +kernel⟩

end Cover61.Layers
