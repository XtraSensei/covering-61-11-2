import Cover61.AGInventory

namespace Cover61.Affine

def horizontal (d : Dir) (r : Role) : Bool := decide (∃ l, r = S d l)
def cells (d : Dir) : Finset Photo := Finset.univ.filter
  (fun i => (12 ≤ i.val ∧ i.val < 30) ∨ i ∈ lines (T d))

private theorem cellCount : ∀ d, (cells d).card = 21 := by decide +kernel
private theorem onlyCells : ∀ d r i, horizontal d r = true → allowed r i = true → i ∈ cells d := by decide +kernel
private theorem hcoeff : ∀ d r, (if horizontal d r then 1 else 0) = ∑ l, atom (S d l) r := by decide +kernel
theorem horizSingle : ∀ d l, horizontal d (S d l) = true := by decide +kernel
theorem notDouble : ∀ d e l, horizontal d (D e l) = false := by decide +kernel

namespace Scene

def focus (g : Scene) (d : Dir) : Finset Point :=
  (Finset.univ.filter (fun z : g.O => horizontal d (g.profile z).r)).map
    ⟨Subtype.val,Subtype.val_injective⟩

theorem inFocus (g : Scene) (d : Dir) (z : g.O) :
    z.val ∈ g.focus d ↔ horizontal d (g.profile z).r = true := by
  simp [focus]

theorem focusSize (g : Scene) (d : Dir) (four : ∀ l, g.n (S d l) = 4) :
    (g.focus d).card = 12 := by
  simp only [focus,Finset.card_map]
  calc
    _ = ∑ z : g.O, if horizontal d (g.profile z).r then 1 else 0 := by simp
    _ = ∑ z : g.O, ∑ l, atom (S d l) (g.profile z).r := by simp only [hcoeff]
    _ = ∑ l, ∑ z : g.O, atom (S d l) (g.profile z).r := Finset.sum_comm
    _ = ∑ l, g.n (S d l) := by simp [n,group,atom]
    _ = _ := by simp [four]

private theorem focus_props (g : Scene) (d : Dir) {x : Point} (hx : x ∈ g.focus d) :
    degree g.B x = 7 ∧ ∀ i, x ∈ g.B i → i ∈ cells d := by
  obtain ⟨z,hz,rfl⟩ := Finset.mem_map.mp hx
  refine ⟨g.degreeSeven z,fun i hi => onlyCells d _ i (Finset.mem_filter.mp hz).2 ?_⟩
  exact (g.profile z).support ((g.mem z i).mpr hi)

theorem once (g : Scene) (d : Dir) (four : ∀ l, g.n (S d l)=4)
    (z w : g.O) (sz : horizontal d (g.profile z).r = true)
    (dw : horizontal d (g.profile w).r = false) :
    ((g.profile z).U ∩ (g.profile w).U).card = 1 := by
  let H := g.focus d
  let s (i : Photo) := (H ∩ g.B i).card
  have hc : H.card=12 := g.focusSize d four
  have allSeven (x : Point) (hx : x ∈ H) : degree g.B x = 7 := (g.focus_props d hx).1
  have seats : ∑ i, s i = 84 := by
    calc
      _ = ∑ i, ∑ x ∈ H, if x ∈ g.B i then 1 else 0 := by simp [s]
      _ = ∑ x ∈ H, ∑ i, if x ∈ g.B i then 1 else 0 := Finset.sum_comm
      _ = ∑ _x ∈ H, 7 := by
        apply Finset.sum_congr rfl
        intro x hx
        simpa [degree] using allSeven x hx
      _ = _ := by simp [hc]
  have row (i : Photo) : 8*s i ≤ s i*s i + 16*(if i ∈ cells d then 1 else 0) := by
    by_cases hi : i ∈ cells d
    · have le := Finset.card_le_card (show H ∩ g.B i ⊆ g.B i from Finset.inter_subset_right)
      rw [g.cover.1] at le
      have tab : ∀ k : Fin 12, 8*k.val ≤ k.val*k.val + 16 := by decide
      simpa [hi] using tab ⟨s i,Nat.lt_succ_of_le le⟩
    · have em : H ∩ g.B i = ∅ := Finset.eq_empty_iff_forall_notMem.mpr (fun x hx =>
        hi ((g.focus_props d (Finset.mem_inter.mp hx).1).2 i (Finset.mem_inter.mp hx).2))
      simp [s,em]
  have lower := Finset.sum_le_sum (s := Finset.univ) (fun i _ => row i)
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum,seats,Finset.sum_boole,Nat.cast_id,
    Finset.filter_mem_eq_inter,Finset.univ_inter,cellCount] at lower
  rw [g.common]
  apply outside_meets_once_of_saturation g.B g.cover H allSeven
  · change H.card*(H.card+16) ≤ ∑ i, s i*s i
    rw [hc]
    omega
  · exact (g.inFocus d z).mpr sz
  · intro hw
    rw [(g.inFocus d w).mp hw] at dw
    contradiction

end Scene
end Cover61.Affine
