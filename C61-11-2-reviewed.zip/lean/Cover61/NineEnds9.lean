import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end126 : EndOK 126 := by decide +kernel

theorem end127 : EndOK 127 := by decide +kernel

theorem end128 : EndOK 128 := by decide +kernel

theorem end129 : EndOK 129 := by decide +kernel

theorem end130 : EndOK 130 := by decide +kernel

theorem end131 : EndOK 131 := by decide +kernel

theorem end132 : EndOK 132 := by decide +kernel

theorem end133 : EndOK 133 := by decide +kernel

theorem end134 : EndOK 134 := by decide +kernel

theorem end135 : EndOK 135 := by decide +kernel

theorem end136 : EndOK 136 := by decide +kernel

theorem end137 : EndOK 137 := by decide +kernel

theorem end138 : EndOK 138 := by decide +kernel

theorem end139 : EndOK 139 := by decide +kernel

theorem reg45 : Regular (candidates 45) := by decide +kernel

theorem reg46 : Regular (candidates 46) := by decide +kernel

theorem reg47 : Regular (candidates 47) := by decide +kernel

theorem reg48 : Regular (candidates 48) := by decide +kernel

theorem reg49 : Regular (candidates 49) := by decide +kernel

end Cover61.Nine
