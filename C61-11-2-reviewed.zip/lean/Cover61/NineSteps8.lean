import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext96 : ∀ t, GoodStep 96 t := by decide +kernel

theorem ext97 : ∀ t, GoodStep 97 t := by decide +kernel

theorem ext98 : ∀ t, GoodStep 98 t := by decide +kernel

theorem ext99 : ∀ t, GoodStep 99 t := by decide +kernel

theorem ext100 : ∀ t, GoodStep 100 t := by decide +kernel

theorem ext101 : ∀ t, GoodStep 101 t := by decide +kernel

theorem ext102 : ∀ t, GoodStep 102 t := by decide +kernel

theorem ext103 : ∀ t, GoodStep 103 t := by decide +kernel

theorem ext104 : ∀ t, GoodStep 104 t := by decide +kernel

theorem ext105 : ∀ t, GoodStep 105 t := by decide +kernel

theorem ext106 : ∀ t, GoodStep 106 t := by decide +kernel

theorem ext107 : ∀ t, GoodStep 107 t := by decide +kernel

end Cover61.Nine
