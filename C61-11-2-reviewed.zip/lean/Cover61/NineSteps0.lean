import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext0 : ∀ t, GoodStep 0 t := by decide +kernel

theorem ext1 : ∀ t, GoodStep 1 t := by decide +kernel

theorem ext2 : ∀ t, GoodStep 2 t := by decide +kernel

theorem ext3 : ∀ t, GoodStep 3 t := by decide +kernel

theorem ext4 : ∀ t, GoodStep 4 t := by decide +kernel

theorem ext5 : ∀ t, GoodStep 5 t := by decide +kernel

theorem ext6 : ∀ t, GoodStep 6 t := by decide +kernel

theorem ext7 : ∀ t, GoodStep 7 t := by decide +kernel

theorem ext8 : ∀ t, GoodStep 8 t := by decide +kernel

theorem ext9 : ∀ t, GoodStep 9 t := by decide +kernel

theorem ext10 : ∀ t, GoodStep 10 t := by decide +kernel

theorem ext11 : ∀ t, GoodStep 11 t := by decide +kernel

end Cover61.Nine
