import Cover61.RepeatBudget

namespace Cover61.LocalRows

/-- Two costly blocks cannot use the same low point: its two attendance
rows intersect in that point alone, so their companion budgets are disjoint. -/
theorem disjoint_costly (B : Family 38) (h : IsCover B) (i j : Photo) (ne : i ≠ j)
    (cost : (∑ x, (degree B x-7)) < excess B (companions B i)+excess B (companions B j)) :
    Disjoint (marked B i) (marked B j) := by
  rw [Finset.disjoint_left]
  intro x xi xj
  have hx := marked_six B i x xi
  have dis : Disjoint (companions B i) (companions B j) := by
    apply Finset.disjoint_left.mpr
    intro y yi yj
    have eq := intersection_single B h x y hx i j ne (marked_sub B i xi)
      (marked_sub B j xj) (Finset.mem_sdiff.mp yi).1 (Finset.mem_sdiff.mp yj).1
    exact (Finset.mem_sdiff.mp yi).2 (eq ▸ (Finset.mem_inter.mp xi).1)
  have lim := Finset.sum_le_univ_sum_of_nonneg (s := companions B i ∪ companions B j)
    (f := fun x => degree B x-7) (fun _ => Nat.zero_le _)
  rw [Finset.sum_union dis] at lim
  exact (not_le_of_gt cost) lim

theorem disjoint_low_seats (B : Family 38) (t : Nat)
    (dis : ∀ i ∈ fullRows B t, ∀ j ∈ fullRows B t, i ≠ j → Disjoint (marked B i) (marked B j)) :
    (fullRows B t).card*t ≤ (lows B).card := by
  let J := fullRows B t
  have left : (J.biUnion (marked B)).card=J.card*t := by
    have each (j : Photo) (hj : j ∈ J) : (marked B j).card=t := (Finset.mem_filter.mp hj).2
    rw [Finset.card_biUnion (by
      intro j hj k hk jk
      exact dis j hj k hk jk),Finset.sum_congr rfl each]
    simp
  have sub : J.biUnion (marked B) ⊆ lows B := by
    intro x hx
    obtain ⟨_,_,m⟩ := Finset.mem_biUnion.mp hx
    exact (Finset.mem_inter.mp m).1
  exact left ▸ Finset.card_le_card sub

theorem at_most_thirteen_of_local (B : Family 38) (h : IsCover B)
    (width : ∀ j,(marked B j).card ≤ 4)
    (cost : 11≤(lows B).card → ∀ j, (marked B j).card=4 → 3≤excess B (companions B j)) :
    (lows B).card ≤ 13 := by
  let a := (lows B).card
  let q := (fullRows B 4).card
  have top := at_most_twenty B h
  have moment := full_rows_needed B h 3 width
  change a*(a+5) ≤ 3*(a*6)+4*q at moment
  have global := total_excess B h
  change (∑ x, (degree B x-7))+9=a at global
  by_contra! bad
  change 13<a at bad
  change a≤20 at top
  have individual := cost (by change 11 ≤ a; omega)
  have price := Finset.sum_le_sum (s := fullRows B 4) (fun j hj =>
    individual j (Finset.mem_filter.mp hj).2)
  simp only [Finset.sum_const,Nat.nsmul_eq_mul] at price
  have cap (k : Nat) (hk : a<(k+1)*4) :
      q*3≤k*(∑ x,(degree B x-7)) := price.trans (sum_local_excess B h 4 k (by decide) hk)
  by_cases exact14 : a=14
  · have dis (i : Photo) (hi : i ∈ fullRows B 4) (j : Photo) (hj : j ∈ fullRows B 4) (ne : i≠j) :=
      disjoint_costly B h i j ne (by
        have ci := individual i (Finset.mem_filter.mp hi).2
        have cj := individual j (Finset.mem_filter.mp hj).2
        omega)
    have maximum := disjoint_low_seats B 4 dis
    change q*4≤a at maximum
    rw [exact14] at moment
    omega
  · have cases : a=15 ∨ a=16 ∨ a=17 ∨ a=18 ∨ a=19 ∨ a=20 := by omega
    rcases cases with z|z|z|z|z|z
    all_goals first
      | have upper := cap 3 (by omega); rw [z] at moment; omega
      | have upper := cap 4 (by omega); rw [z] at moment; omega
      | have upper := cap 5 (by omega); rw [z] at moment; omega

end Cover61.LocalRows
