import Cover61.AGGeometry
import Cover61.AffineCensus
import Cover61.Saturation

namespace Cover61.Affine

structure Scene where
  B : Family 38
  cover : IsCover B
  O : Finset Point
  population : O.card = 52
  profile : (z : O) → Profile
  mem : ∀ (z : O) i, i ∈ (profile z).U ↔ z.val ∈ B i
  room : ∀ d l, (O ∩ B (line d l)).card = 8

namespace Scene

def group (g : Scene) (r : Role) : Finset g.O :=
  Finset.univ.filter (fun z => (g.profile z).r = r)
def n (g : Scene) (r : Role) := (g.group r).card

theorem common (g : Scene) (z w : g.O) :
    ((g.profile z).U ∩ (g.profile w).U).card = partners g.B z.val w.val := by
  unfold partners
  congr 1
  ext i
  simp [g.mem]

theorem encounter (g : Scene) (z w : g.O) :
    ((g.profile z).U ∩ (g.profile w).U).Nonempty := by
  by_cases eq : z=w
  · subst w
    simp only [Finset.inter_self]
    apply Finset.card_pos.mp
    rw [(g.profile z).count]; decide
  · apply Finset.card_pos.mp
    rw [g.common]
    exact partners_pos _ g.cover _ _ (fun he => eq (Subtype.ext he))

theorem degreeSeven (g : Scene) (z : g.O) : degree g.B z.val = 7 := by
  have eq : (Finset.univ.filter (fun i => z.val ∈ g.B i)) = (g.profile z).U := by
    ext i; simp [g.mem]
  simpa only [degree,eq] using (g.profile z).count

theorem group_sum (g : Scene) (f : Role → Nat) :
    ∑ r, g.n r * f r = ∑ z : g.O, f (g.profile z).r := by
  calc
    _ = ∑ r, ∑ z : g.O, if (g.profile z).r = r then f r else 0 := by
      apply Finset.sum_congr rfl
      intro r _
      rw [← Finset.sum_filter]
      simp [n,group]
    _ = _ := by rw [Finset.sum_comm]; simp

theorem lineSeats (g : Scene) (d : Dir) (l : Loc) :
    ∑ r, g.n r * (if line d l ∈ lines r then 1 else 0) = 8 := by
  rw [g.group_sum]
  have hs (z : g.O) : line d l ∈ lines (g.profile z).r ↔ z.val ∈ g.B (line d l) := by
    have hl : (line d l).val < 12 := by unfold line; simp; omega
    exact ((g.profile z).lineMem hl).symm.trans (g.mem z _)
  simp only [hs,Finset.sum_boole,Nat.cast_id]
  let A := Finset.univ.filter (fun z : g.O => z.val ∈ g.B (line d l))
  let emb : g.O ↪ Point := ⟨Subtype.val,Subtype.val_injective⟩
  have eq : A.map emb = g.O ∩ g.B (line d l) := by
    ext x
    simp only [A,Finset.mem_map,Finset.mem_filter,Finset.mem_univ,true_and,Finset.mem_inter]
    constructor
    · rintro ⟨y,hy,hx⟩
      subst x; exact ⟨y.property,hy⟩
    · rintro ⟨xo,xb⟩
      exact ⟨⟨x,xo⟩,xb,rfl⟩
  exact (Finset.card_map emb).symm.trans ((congrArg Finset.card eq).trans (g.room d l))

end Scene

/-- Normalize the block order by the permutation realizing the skeleton. -/
theorem normalized {B : Family 38} (h : IsCover B) (nine : (lows B).card = 9)
    (p : Labels ↪ Point) (e : Equiv.Perm Photo) (six : ∀ j, degree B (p j) = 6)
    (rows : ∀ i, Partitions.lowRow B p (e i) = planeRows i) : Nonempty Scene := by
  classical
  let A : Family 38 := fun i => B (e i)
  let O := (Finset.univ : Finset Point) \ Finset.univ.map p
  have pop : O.card = 52 := by
    rw [Finset.card_sdiff_of_subset (Finset.subset_univ _)]; simp
  have cov : IsCover A := by
    refine ⟨fun i => h.1 (e i),?_⟩
    intro x y ne
    obtain ⟨i,hi⟩ := h.2 x y ne
    exact ⟨e.symm i,by simpa [A] using hi⟩
  let U (z : O) := Finset.univ.filter (fun i => z.val ∈ A i)
  have out (z : O) (j : Labels) : p j ≠ z.val := fun eq =>
    (Finset.mem_sdiff.mp z.property).2 (Finset.mem_map.mpr ⟨j,Finset.mem_univ _,eq⟩)
  have loweq : Finset.univ.map p = lows B := by
    apply Finset.eq_of_subset_of_card_le _ (by simp [nine])
    intro z hz
    obtain ⟨j,_,rfl⟩ := Finset.mem_map.mp hz
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,six j⟩
  have sz (z : O) : (U z).card = 7 := by
    have notLow : z.val ∉ lows B := loweq ▸ (Finset.mem_sdiff.mp z.property).2
    have remap := Equiv.sum_comp e (fun j => if z.val ∈ B j then (1:Nat) else 0)
    simp only [Finset.sum_boole,Nat.cast_id] at remap
    exact remap.trans (nine_rest_seven B h nine z.val notLow)
  have fits (z : O) : Weighted.Fits planeRows (U z) Finset.univ := by
    intro x
    have remap := Equiv.sum_comp e (fun j => if p x ∈ B j ∧ z.val ∈ B j then (1:Nat) else 0)
    have meet := six_meets_once B h (p x) z.val (six x) (out z x)
    simp only [Finset.sum_boole] at remap
    rw [← meet]
    simp [U,A,← rows,Partitions.lowRow,partners,Finset.filter_filter,and_comm] at remap ⊢
    exact remap
  let prof (z : O) : Profile := ⟨U z, Classical.choose (chooseRole (U z) (sz z) (fits z)),sz z,
    fits z,Classical.choose_spec (chooseRole (U z) (sz z) (fits z))⟩
  refine ⟨⟨A,cov,O,pop,prof,fun z i => by simp [prof,U],?_⟩⟩
  intro d l
  let i := line d l
  have sub : (planeRows i).map p ⊆ A i := by
    intro z hz
    obtain ⟨j,m,rfl⟩ := Finset.mem_map.mp hz
    rw [← rows] at m
    exact (Finset.mem_filter.mp m).2
  have eq : O ∩ A i = A i \ (planeRows i).map p := by
    ext z
    simp only [O,← rows,Partitions.lowRow,Finset.mem_filter,Finset.mem_sdiff,Finset.mem_map,
      Finset.mem_univ,true_and,Finset.mem_inter]
    constructor
    · rintro ⟨no,yes⟩
      exact ⟨yes,fun ⟨j,_,he⟩ => no ⟨j,he⟩⟩
    · rintro ⟨yes,no⟩
      exact ⟨fun ⟨j,he⟩ => no ⟨j,he.symm ▸ yes,he⟩,yes⟩
  change (O ∩ A i).card = 8
  rw [eq,Finset.card_sdiff_of_subset sub,Finset.card_map,cov.1,tripleSize]

end Cover61.Affine
