import Cover61.Tree

namespace Cover61.Replay
open Prices

def lowTerm (c l u : Int) := if 0≤c then c*l else c*u
def highTerm (c l u : Int) := if 0≤c then c*u else c*l

theorem coordinate_slack {n : Nat} (a l u x : Fin n→Int) (xl : ∀ j,l j≤x j) (xu : ∀ j,x j≤u j)
    (j : Fin n) :
    highTerm (a j) (l j) (u j)-a j*x j≤(∑ k,highTerm (a k) (l k) (u k))-eval a x ∧
    a j*x j-lowTerm (a j) (l j) (u j)≤eval a x-(∑ k,lowTerm (a k) (l k) (u k)) := by
  have low (k : Fin n) : lowTerm (a k) (l k) (u k)≤a k*x k := by
    unfold lowTerm;split
    next h => exact Int.mul_le_mul_of_nonneg_left (xl k) h
    next h => exact mul_le_mul_of_nonpos_left (xu k) (le_of_not_ge h)
  have high (k : Fin n) : a k*x k≤highTerm (a k) (l k) (u k) := by
    unfold highTerm;split
    next h => exact Int.mul_le_mul_of_nonneg_left (xu k) h
    next h => exact mul_le_mul_of_nonpos_left (xl k) (le_of_not_ge h)
  have left := Finset.single_le_sum (s := Finset.univ) (f := fun k => highTerm (a k) (l k) (u k)-a k*x k)
    (fun k _ => sub_nonneg.mpr (high k)) (Finset.mem_univ j)
  have right := Finset.single_le_sum (s := Finset.univ) (f := fun k => a k*x k-lowTerm (a k) (l k) (u k))
    (fun k _ => sub_nonneg.mpr (low k)) (Finset.mem_univ j)
  rw [Finset.sum_sub_distrib] at left right
  exact ⟨left,right⟩

/-- A lower-bound row with positive coefficient tightens the lower endpoint.
An upper-bound row tightens the upper endpoint with the same positive divisor. -/
theorem tighten_positive {n : Nat} (a l u x : Fin n→Int) (xl : ∀ j,l j≤x j) (xu : ∀ j,x j≤u j)
    (j : Fin n) (pos : 0<a j) (L R : Int) :
    (L≤eval a x → u j-((∑ k,highTerm (a k) (l k) (u k))-L)/a j≤x j) ∧
    (eval a x≤R → x j≤l j+(R-(∑ k,lowTerm (a k) (l k) (u k)))/a j) := by
  obtain ⟨above,below⟩ := coordinate_slack a l u x xl xu j
  simp only [highTerm,lowTerm,if_pos pos.le] at above below
  constructor
  · intro valid
    have prod : (u j-x j)*a j≤(∑ k,highTerm (a k) (l k) (u k))-L := by
      rw [Int.sub_mul,Int.mul_comm (u j),Int.mul_comm (x j)]
      exact above.trans (sub_le_sub_left valid _)
    have := Int.le_ediv_of_mul_le pos prod;omega
  · intro valid
    have prod : (x j-l j)*a j≤R-(∑ k,lowTerm (a k) (l k) (u k)) := by
      rw [Int.sub_mul,Int.mul_comm (x j),Int.mul_comm (l j)]
      exact below.trans (sub_le_sub_right valid _)
    have := Int.le_ediv_of_mul_le pos prod;omega

theorem tighten_negative {n : Nat} (a l u x : Fin n→Int) (xl : ∀ j,l j≤x j) (xu : ∀ j,x j≤u j)
    (j : Fin n) (neg : a j<0) (L R : Int) :
    (L≤eval a x → x j≤l j+((∑ k,highTerm (a k) (l k) (u k))-L)/(-a j)) ∧
    (eval a x≤R → u j-(R-(∑ k,lowTerm (a k) (l k) (u k)))/(-a j)≤x j) := by
  obtain ⟨above,below⟩ := coordinate_slack a l u x xl xu j
  simp only [highTerm,lowTerm,if_neg (not_le_of_gt neg)] at above below
  have pos : 0< -a j := by omega
  constructor
  · intro valid
    have eq : (x j-l j)*(-a j)=a j*l j-a j*x j := by grind only
    have prod := eq.trans_le (above.trans (sub_le_sub_left valid _))
    have rat : x j-l j≤((∑ k,highTerm (a k) (l k) (u k))-L)/(-a j) := Int.le_ediv_of_mul_le pos prod
    omega
  · intro valid
    have eq : (u j-x j)*(-a j)=a j*x j-a j*u j := by grind only
    have prod := eq.trans_le (below.trans (sub_le_sub_right valid _))
    have rat : u j-x j≤(R-(∑ k,lowTerm (a k) (l k) (u k)))/(-a j) := Int.le_ediv_of_mul_le pos prod
    omega

end Cover61.Replay
