import Mathlib.Tactic.FinCases
import Cover61.NineSteps0
import Cover61.NineSteps1
import Cover61.NineSteps2
import Cover61.NineSteps3
import Cover61.NineSteps4
import Cover61.NineSteps5
import Cover61.NineSteps6
import Cover61.NineSteps7
import Cover61.NineSteps8
import Cover61.NineSteps9
import Cover61.NineSteps10
import Cover61.NineSteps11
import Cover61.NineSteps12
import Cover61.NineSteps13
namespace Cover61.Nine
open Skeleton
set_option maxRecDepth 50000
set_option maxHeartbeats 4000000
theorem completeSteps : ∀ (j : Fin 163) t, GoodStep j t := by
  intro j
  fin_cases j
  · exact ext0
  · exact ext1
  · exact ext2
  · exact ext3
  · exact ext4
  · exact ext5
  · exact ext6
  · exact ext7
  · exact ext8
  · exact ext9
  · exact ext10
  · exact ext11
  · exact ext12
  · exact ext13
  · exact ext14
  · exact ext15
  · exact ext16
  · exact ext17
  · exact ext18
  · exact ext19
  · exact ext20
  · exact ext21
  · exact ext22
  · exact ext23
  · exact ext24
  · exact ext25
  · exact ext26
  · exact ext27
  · exact ext28
  · exact ext29
  · exact ext30
  · exact ext31
  · exact ext32
  · exact ext33
  · exact ext34
  · exact ext35
  · exact ext36
  · exact ext37
  · exact ext38
  · exact ext39
  · exact ext40
  · exact ext41
  · exact ext42
  · exact ext43
  · exact ext44
  · exact ext45
  · exact ext46
  · exact ext47
  · exact ext48
  · exact ext49
  · exact ext50
  · exact ext51
  · exact ext52
  · exact ext53
  · exact ext54
  · exact ext55
  · exact ext56
  · exact ext57
  · exact ext58
  · exact ext59
  · exact ext60
  · exact ext61
  · exact ext62
  · exact ext63
  · exact ext64
  · exact ext65
  · exact ext66
  · exact ext67
  · exact ext68
  · exact ext69
  · exact ext70
  · exact ext71
  · exact ext72
  · exact ext73
  · exact ext74
  · exact ext75
  · exact ext76
  · exact ext77
  · exact ext78
  · exact ext79
  · exact ext80
  · exact ext81
  · exact ext82
  · exact ext83
  · exact ext84
  · exact ext85
  · exact ext86
  · exact ext87
  · exact ext88
  · exact ext89
  · exact ext90
  · exact ext91
  · exact ext92
  · exact ext93
  · exact ext94
  · exact ext95
  · exact ext96
  · exact ext97
  · exact ext98
  · exact ext99
  · exact ext100
  · exact ext101
  · exact ext102
  · exact ext103
  · exact ext104
  · exact ext105
  · exact ext106
  · exact ext107
  · exact ext108
  · exact ext109
  · exact ext110
  · exact ext111
  · exact ext112
  · exact ext113
  · exact ext114
  · exact ext115
  · exact ext116
  · exact ext117
  · exact ext118
  · exact ext119
  · exact ext120
  · exact ext121
  · exact ext122
  · exact ext123
  · exact ext124
  · exact ext125
  · exact ext126
  · exact ext127
  · exact ext128
  · exact ext129
  · exact ext130
  · exact ext131
  · exact ext132
  · exact ext133
  · exact ext134
  · exact ext135
  · exact ext136
  · exact ext137
  · exact ext138
  · exact ext139
  · exact ext140
  · exact ext141
  · exact ext142
  · exact ext143
  · exact ext144
  · exact ext145
  · exact ext146
  · exact ext147
  · exact ext148
  · exact ext149
  · exact ext150
  · exact ext151
  · exact ext152
  · exact ext153
  · exact ext154
  · exact ext155
  · exact ext156
  · exact ext157
  · exact ext158
  · exact ext159
  · exact ext160
  · exact ext161
  · exact ext162

theorem triple_list : ∀ s : Row 9, s.card=3 → ∃ t, triangle t=s := by decide +kernel

theorem orbit (H : Sys 9) (valid : Packing H) : ∃ j, Iso H (state j) := by
  apply catalogue state 0 (by decide +kernel) _ H valid
  intro j s hs ok
  obtain ⟨t,rfl⟩ := triple_list s hs
  have step := completeSteps j t ok
  exact ⟨(transition j t).1,permutation _ step.1,step.2⟩

end Cover61.Nine
