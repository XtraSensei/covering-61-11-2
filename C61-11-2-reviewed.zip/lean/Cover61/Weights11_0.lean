import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w11_051_01Rows : Rows 11 := fun i =>
  ([{0,1}, {1,2}, {0,3}, {2,3}, {4}, {0,2,4}, {5}, {3,4,5}, {6}, {0,5,6}, {7}, {2,5,7}, {1,6,7}, {8}, {1,3,8}, {4,6,8}, {0,7,8}, {9}, {1,4,9}, {2,6,9}, {3,7,9}, {5,8,9}, {10}, {1,5,10}, {3,6,10}, {4,7,10}, {2,8,10}, {0,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 11)))[i.val]'(i.isLt)

private def w11_051_01Cost : Cost := fun i =>
  ([0, 0, 0, 0, 1, 0, 1, 0, 2, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w11_051_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w11_051_01Rows :=
  Weighted.exclude _ w11_051_01Cost (2) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w11_051_02Rows : Rows 11 := fun i =>
  ([{0,1}, {1,2}, {0,3}, {2,3}, {4}, {0,2,4}, {1,3,4}, {5}, {6}, {0,5,6}, {7}, {2,5,7}, {1,6,7}, {8}, {3,5,8}, {4,6,8}, {0,7,8}, {9}, {4,5,9}, {2,6,9}, {3,7,9}, {1,8,9}, {10}, {1,5,10}, {3,6,10}, {4,7,10}, {2,8,10}, {0,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 11)))[i.val]'(i.isLt)

private def w11_051_02Cost : Cost := fun i =>
  ([0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, -1, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w11_051_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w11_051_02Rows :=
  Weighted.exclude _ w11_051_02Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w11_052_01Rows : Rows 11 := fun i =>
  ([{0,1}, {0,2}, {1,2}, {3,4}, {0,3,5}, {4,5}, {3,6}, {1,4,6}, {5,6}, {7}, {1,3,7}, {2,4,7}, {8}, {1,5,8}, {2,6,8}, {0,7,8}, {9}, {2,3,9}, {0,6,9}, {5,7,9}, {4,8,9}, {10}, {0,4,10}, {2,5,10}, {6,7,10}, {3,8,10}, {1,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 11)))[i.val]'(i.isLt)

private def w11_052_01Cost : Cost := fun i =>
  ([1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w11_052_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w11_052_01Rows :=
  Weighted.exclude _ w11_052_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w11_052_02Rows : Rows 11 := fun i =>
  ([{0,1}, {0,2}, {1,2}, {3,4}, {0,3,5}, {4,5}, {3,6}, {0,4,6}, {5,6}, {7}, {1,3,7}, {2,6,7}, {8}, {2,3,8}, {1,5,8}, {4,7,8}, {9}, {1,4,9}, {2,5,9}, {0,7,9}, {6,8,9}, {10}, {2,4,10}, {1,6,10}, {5,7,10}, {0,8,10}, {3,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 11)))[i.val]'(i.isLt)

private def w11_052_02Cost : Cost := fun i =>
  ([0, 0, 0, 0, -1, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w11_052_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w11_052_02Rows :=
  Weighted.exclude _ w11_052_02Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
