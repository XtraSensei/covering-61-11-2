import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w12_124_01Rows : Rows 12 := fun i =>
  ([{2}, {3}, {0,1,2,3}, {0,4}, {1,5}, {6}, {7}, {4,5,6,7}, {0,8}, {4,8}, {3,5,8}, {2,6,8}, {1,7,8}, {1,9}, {2,4,9}, {5,9}, {0,6,9}, {3,7,9}, {10}, {1,4,10}, {0,5,10}, {3,6,10}, {2,7,10}, {11}, {3,4,11}, {2,5,11}, {1,6,11}, {0,7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 12)))[i.val]'(i.isLt)

private def w12_124_01Cost : Cost := fun i =>
  ([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, -1, 0, -1, 0, -1, 0, 0, -1, -1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w12_124_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w12_124_01Rows :=
  Weighted.exclude _ w12_124_01Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w12_125_02Rows : Rows 12 := fun i =>
  ([{3}, {0,1,2,3}, {0,4}, {1,5}, {2,6}, {7}, {4,5,6,7}, {0,8}, {4,8}, {3,5,8}, {1,6,8}, {2,7,8}, {1,9}, {2,4,9}, {5,9}, {3,6,9}, {0,7,9}, {2,10}, {3,4,10}, {0,5,10}, {6,10}, {1,7,10}, {11}, {1,4,11}, {2,5,11}, {0,6,11}, {3,7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 12)))[i.val]'(i.isLt)

private def w12_125_02Cost : Cost := fun i =>
  ([1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w12_125_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w12_125_02Rows :=
  Weighted.exclude _ w12_125_02Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w12_126_01Rows : Rows 12 := fun i =>
  ([{0,1,2,3}, {0,4}, {1,5}, {2,6}, {3,7}, {4,5,6,7}, {0,8}, {4,8}, {3,5,8}, {1,6,8}, {2,7,8}, {1,9}, {2,4,9}, {5,9}, {3,6,9}, {0,7,9}, {2,10}, {3,4,10}, {0,5,10}, {6,10}, {1,7,10}, {3,11}, {1,4,11}, {2,5,11}, {0,6,11}, {7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 12)))[i.val]'(i.isLt)

private def w12_126_01Cost : Cost := fun i =>
  ([0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w12_126_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w12_126_01Rows :=
  Weighted.exclude _ w12_126_01Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w12_130_01Rows : Rows 12 := fun i =>
  ([{2}, {3}, {0,1,2,3}, {0,4}, {1,5}, {6}, {7}, {4,5,6,7}, {1,8}, {4,8}, {0,5,8}, {3,6,8}, {2,7,8}, {0,9}, {2,4,9}, {5,9}, {1,6,9}, {3,7,9}, {10}, {3,4,10}, {2,5,10}, {0,6,10}, {1,7,10}, {11}, {1,4,11}, {3,5,11}, {2,6,11}, {0,7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 12)))[i.val]'(i.isLt)

private def w12_130_01Cost : Cost := fun i =>
  ([1, 2, 0, 0, 0, 1, 2, 0, 0, 0, -2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, -4, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w12_130_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w12_130_01Rows :=
  Weighted.exclude _ w12_130_01Cost (2) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
