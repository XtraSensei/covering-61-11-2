import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end56 : EndOK 56 := by decide +kernel

theorem end57 : EndOK 57 := by decide +kernel

theorem end58 : EndOK 58 := by decide +kernel

theorem end59 : EndOK 59 := by decide +kernel

theorem end60 : EndOK 60 := by decide +kernel

theorem end61 : EndOK 61 := by decide +kernel

theorem end62 : EndOK 62 := by decide +kernel

theorem end63 : EndOK 63 := by decide +kernel

theorem end64 : EndOK 64 := by decide +kernel

theorem end65 : EndOK 65 := by decide +kernel

theorem end66 : EndOK 66 := by decide +kernel

theorem end67 : EndOK 67 := by decide +kernel

theorem end68 : EndOK 68 := by decide +kernel

theorem end69 : EndOK 69 := by decide +kernel

theorem reg20 : Regular (candidates 20) := by decide +kernel

theorem reg21 : Regular (candidates 21) := by decide +kernel

theorem reg22 : Regular (candidates 22) := by decide +kernel

theorem reg23 : Regular (candidates 23) := by decide +kernel

theorem reg24 : Regular (candidates 24) := by decide +kernel

end Cover61.Nine
