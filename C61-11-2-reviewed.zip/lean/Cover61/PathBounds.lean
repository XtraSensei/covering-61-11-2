import Cover61.Footprints

namespace Cover61.Grid.Chart
open LatinFive
variable {α : Type} [DecidableEq α] {U : Finset α} (D : Chart U)

noncomputable def stamp (L : Finset α) : Nat := by
  classical
  exact if ok : ∃ P : Path D,P.cells=L then (Classical.choose ok).mask else 0

theorem stamp_path (P : Path D) : D.stamp P.cells=P.mask := by
  classical
  have ok : ∃ Q : Path D,Q.cells=P.cells := ⟨P,rfl⟩
  have same {V W : Path D} (e : V.cells=W.cells) : V=W := by
    cases V;cases W;cases e;rfl
  have eq : Classical.choose ok=P := same (Classical.choose_spec ok)
  simp [stamp,ok,eq]

theorem at_most_two_through {β : Type} [DecidableEq β] (red : D.Reduced) (A B : Path D)
    (apart : Disjoint A.cells B.cells) (x : α) (S : Finset β) (q : β→Nat)
    (good : ∀ t ∈ S,∃ P : Path D, P.mask=q t ∧ x ∈ P.cells ∧ (P.cells ∩ A.cells).card=1 ∧ (P.cells ∩ B.cells).card=1) :
    (S.image q).card≤2 := by
  let words := transversals (rowPrefix D.word 5)
  let k := 5*(D.R.coord x).val+(D.C.coord x).val
  have test := (Bool.and_eq_true_iff.mp (List.all_eq_true.mp certified _ (D.latin_complete red))).2
  change throughTest words=true at test
  have p := List.all_eq_true.mp (List.all_eq_true.mp test A.mask A.transversal) B.mask B.transversal
  have dis := (A.masks_disjoint B).mpr apart
  simp only [dis,Bool.not_true,Bool.false_or] at p
  have small : k<25 := by dsimp [k];have := (D.R.coord x).isLt;have := (D.C.coord x).isLt;omega
  let candidates := (words.filter (fun z => once z A.mask && once z B.mask)).filter (fun z => z.testBit k)
  have length : candidates.length≤2 := of_decide_eq_true (List.all_eq_true.mp p k (List.mem_range.mpr small))
  have sub : S.image q ⊆ candidates.toFinset := by
    intro z hz;obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hz
    obtain ⟨P,mask,mem,first,second⟩ := good t ht
    rw [←mask]
    apply List.mem_toFinset.mpr
    exact List.mem_filter.mpr ⟨List.mem_filter.mpr ⟨P.transversal,Bool.and_eq_true_iff.mpr ⟨P.masks_once A first,P.masks_once B second⟩⟩,
      (P.mask_at x (P.inside mem)).mpr mem⟩
  exact (Finset.card_le_card sub).trans (candidates.toFinset_card_le.trans length)

theorem counts_of_fibers {β γ : Type} [DecidableEq β] [DecidableEq γ] (S : Finset β) (f : β→γ)
    (m : Nat) (per : ∀ c ∈ S.image f,(S.filter (fun x => f x=c)).card≤m) : S.card≤(S.image f).card*m := by
  have union : (S.image f).biUnion (fun c => S.filter (fun x => f x=c))=S := by
    ext x;simp;intro hx;exact ⟨x,hx,rfl⟩
  have upper := Finset.card_biUnion_le (s := S.image f) (t := fun c => S.filter (fun x => f x=c))
  rw [union] at upper
  exact upper.trans (by simpa using Finset.sum_le_sum per)

theorem large_class {β : Type} [DecidableEq β] (red : D.Reduced) (S : Finset β) (q : β→Nat)
    (size : 40≤S.card) (all : ∀ t ∈ S, q t ∈ transversals (rowPrefix D.word 5))
    (per : ∀ c ∈ S.image q,(S.filter (fun x => q x=c)).card≤3) :
    ∃ T : Finset β, T ⊆ S ∧ 14≤T.card ∧ ∀ x ∈ T,∀ y ∈ T,q x≠q y → disjoint (q x) (q y)=true := by
  let words := transversals (rowPrefix D.word 5)
  have ok := (Bool.and_eq_true_iff.mp (List.all_eq_true.mp certified _ (D.latin_complete red))).1
  change classTest words=true at ok
  have inc : S.image q ⊆ words.toFinset := fun _ hz => by
    obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hz;exact List.mem_toFinset.mpr (all t ht)
  have count := (Finset.card_le_card inc).trans words.toFinset_card_le
  have mass := counts_of_fibers S q 3 per
  have long : words.length≠3 := by omega
  rw [classTest] at ok
  simp only [beq_eq_false_iff_ne.mpr long,Bool.false_or,Bool.and_eq_true,beq_iff_eq] at ok
  obtain ⟨⟨⟨_,three⟩,cls⟩,allClasses⟩ := ok
  let cs := classes words
  let people (c : List Nat) := S.filter (fun x => q x ∈ c)
  have sub : S ⊆ cs.toFinset.biUnion people := by
    intro x hx
    have present := List.all_eq_true.mp allClasses (q x) (all x hx)
    simp only [beq_iff_eq] at present
    have nz : (cs.filter (fun c => c.contains (q x))).length>0 := by change (cs.filter _).length=1 at present;omega
    obtain ⟨c,hc⟩ := List.length_pos_iff_exists_mem.mp nz
    obtain ⟨m,v⟩ := List.mem_filter.mp hc
    exact Finset.mem_biUnion.mpr ⟨c,List.mem_toFinset.mpr m,Finset.mem_filter.mpr ⟨hx,by simpa using v⟩⟩
  have bound := (Finset.card_le_card sub).trans Finset.card_biUnion_le
  have ncs := cs.toFinset_card_le
  change cs.length=3 at three
  have many : ∃ c ∈ cs.toFinset,14≤(people c).card := by
    by_contra! small
    have cap := Finset.sum_le_sum (s := cs.toFinset) (fun c hc => (show (people c).card≤13 by have := small c hc;omega))
    simp at cap;omega
  obtain ⟨c,hc,n⟩ := many
  refine ⟨people c,Finset.filter_subset ..,n,?_⟩
  intro x hx y hy ne
  have tests := (Bool.and_eq_true_iff.mp (List.all_eq_true.mp cls c (List.mem_toFinset.mp hc))).2
  have pair := List.all_eq_true.mp (List.all_eq_true.mp tests (q x) (Finset.mem_filter.mp hx).2) (q y) (Finset.mem_filter.mp hy).2
  simpa [ne] using pair

end Cover61.Grid.Chart
