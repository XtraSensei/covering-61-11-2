import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes11_2_96 : List (Branch 10 54) := [
  ⟨{{0,5,6}, {1}, {2,3}, {4,8}, {7}, {9}},8,⟨22455269385,22749984685⟩⟩,
  ⟨{{0,5,6}, {1,8}, {2,4}, {3,7}, {9}},40,⟨22129478535,21739749635⟩⟩,
  ⟨{{0,5,6}, {1,8}, {2,4}, {3,9}, {7}},29,⟨51138002925,234462923425⟩⟩,
  ⟨{{0,9}, {1}, {2,4}, {3,6,8}, {5}, {7}},10,⟨180738603665,241971076965⟩⟩
]

theorem checked11_2_96 : ∃ cert, Checked (rows10_1 96) rows11_2 2 cert :=
  ⟨routes11_2_96, by decide +kernel⟩

private def routes11_2_97 : List (Branch 10 54) := [
  ⟨{{0,3,4}, {1}, {2,6}, {5,8}, {7}, {9}},14,⟨47965849535,22763691635⟩⟩,
  ⟨{{0,3,4}, {1}, {2,8}, {5}, {6,7}, {9}},24,⟨159262013585,189629179885⟩⟩,
  ⟨{{0,3,4}, {1,6}, {2,8}, {5}, {7}, {9}},6,⟨22455694425,22824331925⟩⟩,
  ⟨{{0,9}, {1}, {2,4}, {3,6,8}, {5}, {7}},6,⟨180738603665,241971076965⟩⟩
]

theorem checked11_2_97 : ∃ cert, Checked (rows10_1 97) rows11_2 2 cert :=
  ⟨routes11_2_97, by decide +kernel⟩

private def routes11_2_98 : List (Branch 10 54) := [
  ⟨{{0}, {1,3,5}, {2,6}, {4,8}, {7}, {9}},40,⟨164772851465,149562848865⟩⟩,
  ⟨{{0}, {1,3,5}, {2,8}, {4,6}, {7}, {9}},40,⟨162413191735,45384421835⟩⟩
]

theorem checked11_2_98 : ∃ cert, Checked (rows10_1 98) rows11_2 2 cert :=
  ⟨routes11_2_98, by decide +kernel⟩

private def routes11_2_99 : List (Branch 10 54) := [
  ⟨{{0,5,6}, {1}, {2}, {3,8}, {4,7}, {9}},7,⟨210358525955,117800164055⟩⟩,
  ⟨{{0,5,6}, {1,8}, {2}, {3}, {4,7}, {9}},7,⟨207998808145,117694163145⟩⟩,
  ⟨{{0,7}, {1,3,5}, {2}, {4}, {6,8}, {9}},3,⟨124688362415,98749701315⟩⟩,
  ⟨{{0,8}, {1,3,5}, {2}, {4}, {6,7}, {9}},3,⟨110533577555,45373374555⟩⟩,
  ⟨{{0,8}, {1,3,5}, {2,6}, {4,7}, {9}},40,⟨148280664965,98362223565⟩⟩,
  ⟨{{0,9}, {1,3,5}, {2}, {4,7}, {6,8}},40,⟨138854176165,46351061265⟩⟩
]

theorem checked11_2_99 : ∃ cert, Checked (rows10_1 99) rows11_2 2 cert :=
  ⟨routes11_2_99, by decide +kernel⟩

private def routes11_2_100 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,6}, {3,9}, {4}, {5,7,8}},3,⟨231638386235,247499971435⟩⟩
]

theorem checked11_2_100 : ∃ cert, Checked (rows10_1 100) rows11_2 2 cert :=
  ⟨routes11_2_100, by decide +kernel⟩

private def routes11_2_101 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2}, {3,6}, {4,9}, {5,7,8}},16,⟨231638386235,247499971435⟩⟩,
  ⟨{{0}, {1}, {2,6}, {3}, {4,9}, {5,7,8}},3,⟨179798970905,246804217805⟩⟩
]

theorem checked11_2_101 : ∃ cert, Checked (rows10_1 101) rows11_2 2 cert :=
  ⟨routes11_2_101, by decide +kernel⟩

private def routes11_2_102 : List (Branch 10 54) := [
  
]

theorem checked11_2_102 : ∃ cert, Checked (rows10_1 102) rows11_2 2 cert :=
  ⟨routes11_2_102, by decide +kernel⟩

private def routes11_2_103 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,9}, {3,6}, {4}, {5,7,8}},8,⟨219006709295,98965815795⟩⟩
]

theorem checked11_2_103 : ∃ cert, Checked (rows10_1 103) rows11_2 2 cert :=
  ⟨routes11_2_103, by decide +kernel⟩

private def routes11_2_104 : List (Branch 10 54) := [
  
]

theorem checked11_2_104 : ∃ cert, Checked (rows10_1 104) rows11_2 2 cert :=
  ⟨routes11_2_104, by decide +kernel⟩

private def routes11_2_105 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,9}, {3,6}, {4}, {5,7,8}},17,⟨231638386235,247499971435⟩⟩
]

theorem checked11_2_105 : ∃ cert, Checked (rows10_1 105) rows11_2 2 cert :=
  ⟨routes11_2_105, by decide +kernel⟩

private def routes11_2_106 : List (Branch 10 54) := [
  
]

theorem checked11_2_106 : ∃ cert, Checked (rows10_1 106) rows11_2 2 cert :=
  ⟨routes11_2_106, by decide +kernel⟩

private def routes11_2_107 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3,7}, {4,5}, {6,8}, {9}},25,⟨220909994275,139074332475⟩⟩,
  ⟨{{0}, {1}, {2,3,7}, {4,9}, {5}, {6,8}},25,⟨99139334225,99063377025⟩⟩,
  ⟨{{0,7}, {1}, {2,4,8}, {3,6}, {5}, {9}},16,⟨167122498575,19447047175⟩⟩
]

theorem checked11_2_107 : ∃ cert, Checked (rows10_1 107) rows11_2 2 cert :=
  ⟨routes11_2_107, by decide +kernel⟩

end Cover61.Layers
