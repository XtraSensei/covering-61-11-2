import Cover61.NineCover
import Cover61.GrowClassification
import Cover61.Layer10_0

namespace Cover61
open Skeleton Growth

theorem width_three_shape {n} (r : Rows n) (width : ∀ i, (r i).card ≤ 3) :
    Shape (big r) 0 := by
  have small (s : Row n) (hs : s ∈ big r) : s.card ≤ 3 := by
    obtain ⟨⟨i,rfl⟩,_⟩ := (big_mem r s).mp hs
    exact width i
  have empty : quads (big r)=∅ := by
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro s hs
    obtain ⟨hb,sz⟩ := Finset.mem_filter.mp hs
    have := small s hb
    omega
  refine ⟨fun s hs => (small s hs).trans (by decide),?_,?_⟩
  · simp [empty]
  · simp [empty]

theorem catalogue_of_width_three {n m} (B : Family 38) (h : IsCover B) (count : (lows B).card=n)
    (width : ∀ i, (LocalRows.marked B i).card ≤ 3) (dest : Fin m → Rows n)
    (covers : Exhausts dest 0) : ∃ j, Weighted.Realizes B (dest j) := by
  obtain ⟨p,six,eq⟩ := label_lows B count
  have le (i : Fin 38) : (Partitions.lowRow B p i).card ≤ 3 := by
    have sizes := congrArg Finset.card (eq i)
    rw [Finset.card_map] at sizes
    exact sizes.trans_le (width i)
  obtain ⟨j,sim⟩ := covers (Partitions.lowRow B p) (regular_projection B h p six le).2
    (width_three_shape _ le)
  exact ⟨j,realizes_similar B p six sim⟩

theorem ten_exhausts : Exhausts Layers.rows10_0 0 :=
  induction_step Nine.candidates Layers.rows10_0 0 startNine Layers.steps10_0 Layers.balanced10_0

theorem ten_catalogue_of_width_three (B : Family 38) (h : IsCover B) (count : (lows B).card=10)
    (width : ∀ i, (LocalRows.marked B i).card ≤ 3) :
    ∃ j : Fin 65, Weighted.Realizes B (Layers.rows10_0 j) :=
  catalogue_of_width_three B h count width _ ten_exhausts

end Cover61
