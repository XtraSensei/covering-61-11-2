import Cover61.LocalRows

namespace Cover61.LocalRows

def companions (B : Family 38) (i : Photo) := B i \ lows B
def marked (B : Family 38) (i : Photo) := lows B ∩ B i
def room (s : Nat) := s * (11-s)
def amount (B : Family 38) (i j : Photo) := (companions B i ∩ B j).card
def excess (B : Family 38) (H : Finset Point) := ∑ x ∈ H, (degree B x-7)

theorem marked_sub (B : Family 38) (i : Photo) : marked B i ⊆ B i := Finset.inter_subset_right
theorem marked_six (B : Family 38) (i : Photo) (x : Point) (hx : x ∈ marked B i) :
    degree B x = 6 := (Finset.mem_filter.mp (Finset.mem_inter.mp hx).1).2
theorem companion_eq (B : Family 38) (i : Photo) : companions B i = B i \ marked B i := by
  ext x; simp [companions,marked]

theorem companion_card (B : Family 38) (h : IsCover B) (i : Photo) :
    (companions B i).card + (marked B i).card = 11 := by
  rw [companion_eq,Finset.card_sdiff_of_subset (marked_sub ..),
    Nat.sub_add_cancel (Finset.card_le_card (marked_sub ..)),h.1]

theorem degree_companion (B : Family 38) (h : IsCover B) (i : Photo)
    (x : Point) (hx : x ∈ companions B i) : 7 ≤ degree B x := by
  have hn := (Finset.mem_sdiff.mp hx).2
  have := degree_ge_six B h x
  simp [lows] at hn
  omega

theorem companion_visits (B : Family 38) (h : IsCover B) (i : Photo)
    (x : Point) (hx : x ∈ companions B i) :
    (appearances B (clear B i (marked B i)) x).card + 1 = degree B x := by
  have xi := (Finset.mem_sdiff.mp hx).1
  have hc : x ∈ B i \ marked B i := companion_eq B i ▸ hx
  have eq : appearances B (clear B i (marked B i)) x =
      (Finset.univ.filter (fun j => x ∈ B j)).erase i := by
    ext j
    constructor
    · intro mem
      obtain ⟨jc,xj⟩ := Finset.mem_filter.mp mem
      exact Finset.mem_erase.mpr ⟨(Finset.mem_erase.mp (Finset.mem_sdiff.mp jc).1).1,by simpa using xj⟩
    · intro mem
      obtain ⟨ji,xj⟩ := Finset.mem_erase.mp mem
      have inrow := (Finset.mem_filter.mp xj).2
      exact Finset.mem_filter.mpr
        ⟨companion_only_clear B h _ (marked_sub ..) (marked_six B i) hc inrow ji,inrow⟩
  rw [eq,Finset.card_erase_of_mem (by simpa using xi)]
  unfold degree
  have pos := Finset.card_pos.mpr (show (Finset.univ.filter (fun j => x ∈ B j)).Nonempty from
    ⟨i,by simpa using xi⟩)
  omega

theorem total_companion_visits (B : Family 38) (h : IsCover B) (i : Photo) :
    ∑ j ∈ clear B i (marked B i), amount B i j =
      6 * (companions B i).card + excess B (companions B i) := by
  unfold amount
  rw [block_sum]
  have term (x : Point) (hx : x ∈ companions B i) :
      (appearances B (clear B i (marked B i)) x).card = 6 + (degree B x-7) := by
    have := companion_visits B h i x hx
    have := degree_companion B h i x hx
    omega
  rw [Finset.sum_congr rfl term,Finset.sum_add_distrib]
  simp [excess,Nat.mul_comm]

theorem local_excess_le (B : Family 38) (h : IsCover B) (i : Photo) :
    excess B (companions B i) + 9 ≤ (lows B).card := by
  rw [← total_excess B h]
  unfold excess
  exact Nat.add_le_add_right (Finset.sum_le_univ_sum_of_nonneg (fun _ => Nat.zero_le _)) _

/-- All meetings across this cut must be supplied by the rows remaining clear. -/
theorem local_capacity (B : Family 38) (h : IsCover B) (i : Photo) :
    (companions B i).card * 50 ≤ ∑ j ∈ clear B i (marked B i), room (amount B i j) := by
  let H := companions B i
  let O := (Finset.univ : Finset Point) \ B i
  let J := clear B i (marked B i)
  have os : O.card=50 := by simp [O,Finset.card_sdiff_of_subset,h.1]
  have dis : Disjoint H O := by
    rw [Finset.disjoint_left]
    exact fun x hx ox => (Finset.mem_sdiff.mp ox).2 (Finset.mem_sdiff.mp hx).1
  have need := Finset.sum_le_sum (s := H) (fun x hx =>
    Finset.sum_le_sum (s := O) (fun y hy => partners_pos B h x y (fun e =>
      Finset.disjoint_left.mp dis hx (e ▸ hy))))
  simp only [Finset.sum_const,nsmul_eq_mul,mul_one,Nat.cast_id,os] at need
  rw [cross_sum] at need
  have row (j : Photo) : (H ∩ B j).card * (O ∩ B j).card ≤ if j ∈ J then room (amount B i j) else 0 := by
    split
    next hj =>
      have d : Disjoint (H ∩ B j) (O ∩ B j) := dis.mono Finset.inter_subset_left Finset.inter_subset_left
      have cap := Finset.card_le_card (show (H ∩ B j) ∪ (O ∩ B j) ⊆ B j from
        Finset.union_subset Finset.inter_subset_right Finset.inter_subset_right)
      rw [Finset.card_union_of_disjoint d,h.1] at cap
      exact Nat.mul_le_mul_left _ (show (O ∩ B j).card ≤ 11-(H ∩ B j).card by omega)
    next no =>
      by_cases ji : j=i
      · subst j
        have empty : O ∩ B i = ∅ := by ext x; simp [O]
        simp [empty]
      · have empty : H ∩ B j = ∅ := by
          apply Finset.eq_empty_iff_forall_notMem.mpr
          intro x hx
          obtain ⟨xh,xj⟩ := Finset.mem_inter.mp hx
          exact no (companion_only_clear B h _ (marked_sub ..) (marked_six B i)
            (companion_eq B i ▸ xh) xj ji)
        simp [empty]
  have cap := Finset.sum_le_sum (s := Finset.univ) (fun j _ => row j)
  simpa [H,J,← Finset.sum_filter] using need.trans cap

end Cover61.LocalRows
