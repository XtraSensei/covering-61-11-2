import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext84 : ∀ t, GoodStep 84 t := by decide +kernel

theorem ext85 : ∀ t, GoodStep 85 t := by decide +kernel

theorem ext86 : ∀ t, GoodStep 86 t := by decide +kernel

theorem ext87 : ∀ t, GoodStep 87 t := by decide +kernel

theorem ext88 : ∀ t, GoodStep 88 t := by decide +kernel

theorem ext89 : ∀ t, GoodStep 89 t := by decide +kernel

theorem ext90 : ∀ t, GoodStep 90 t := by decide +kernel

theorem ext91 : ∀ t, GoodStep 91 t := by decide +kernel

theorem ext92 : ∀ t, GoodStep 92 t := by decide +kernel

theorem ext93 : ∀ t, GoodStep 93 t := by decide +kernel

theorem ext94 : ∀ t, GoodStep 94 t := by decide +kernel

theorem ext95 : ∀ t, GoodStep 95 t := by decide +kernel

end Cover61.Nine
