import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext120 : ∀ t, GoodStep 120 t := by decide +kernel

theorem ext121 : ∀ t, GoodStep 121 t := by decide +kernel

theorem ext122 : ∀ t, GoodStep 122 t := by decide +kernel

theorem ext123 : ∀ t, GoodStep 123 t := by decide +kernel

theorem ext124 : ∀ t, GoodStep 124 t := by decide +kernel

theorem ext125 : ∀ t, GoodStep 125 t := by decide +kernel

theorem ext126 : ∀ t, GoodStep 126 t := by decide +kernel

theorem ext127 : ∀ t, GoodStep 127 t := by decide +kernel

theorem ext128 : ∀ t, GoodStep 128 t := by decide +kernel

theorem ext129 : ∀ t, GoodStep 129 t := by decide +kernel

theorem ext130 : ∀ t, GoodStep 130 t := by decide +kernel

theorem ext131 : ∀ t, GoodStep 131 t := by decide +kernel

end Cover61.Nine
