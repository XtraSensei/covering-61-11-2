import Mathlib.Tactic.FinCases

import Cover61.TenCover

import Cover61.Layer11_0

import Cover61.NoQuad12Part0

import Cover61.NoQuad12Part1

import Cover61.NoQuad12Part2

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem eleven_exhausts : Exhausts rows11_0 0 := induction_step rows10_0 rows11_0 0 Cover61.ten_exhausts steps11_0 balanced11_0

theorem noQuadExhausts : Exhausts rows12_0 0 := by
  apply induction_step rows11_0 rows12_0 0 eleven_exhausts
  · intro j; fin_cases j
    · exact noQuadCheck0
    · exact noQuadCheck1
    · exact noQuadCheck2
    · exact noQuadCheck3
    · exact noQuadCheck4
    · exact noQuadCheck5
    · exact noQuadCheck6
    · exact noQuadCheck7
    · exact noQuadCheck8
    · exact noQuadCheck9
    · exact noQuadCheck10
    · exact noQuadCheck11
    · exact noQuadCheck12
    · exact noQuadCheck13
    · exact noQuadCheck14
    · exact noQuadCheck15
    · exact noQuadCheck16
    · exact noQuadCheck17
    · exact noQuadCheck18
    · exact noQuadCheck19
    · exact noQuadCheck20
    · exact noQuadCheck21
    · exact noQuadCheck22
    · exact noQuadCheck23
    · exact noQuadCheck24
    · exact noQuadCheck25
    · exact noQuadCheck26
    · exact noQuadCheck27
    · exact noQuadCheck28
    · exact noQuadCheck29
    · exact noQuadCheck30
    · exact noQuadCheck31
    · exact noQuadCheck32
    · exact noQuadCheck33
    · exact noQuadCheck34
    · exact noQuadCheck35
  · intro j; fin_cases j <;> decide +kernel

private def missing0 (i : Fin 38) : Int := if i=6 then -1 else 0

private theorem noQuadDead0 : ∀ B, IsCover B → ¬ Weighted.Realizes B (rows12_0 0) :=
  Weighted.exclude _ missing0 0 (by decide +kernel) (by decide +kernel) (by decide +kernel)

private def missing1 (i : Fin 38) : Int := if i=6 then -1 else 0

private theorem noQuadDead1 : ∀ B, IsCover B → ¬ Weighted.Realizes B (rows12_0 1) :=
  Weighted.exclude _ missing1 0 (by decide +kernel) (by decide +kernel) (by decide +kernel)

private def missing2 (i : Fin 38) : Int := if i=6 then -1 else 0

private theorem noQuadDead2 : ∀ B, IsCover B → ¬ Weighted.Realizes B (rows12_0 2) :=
  Weighted.exclude _ missing2 0 (by decide +kernel) (by decide +kernel) (by decide +kernel)

private def missing3 (i : Fin 38) : Int := if i=6 then -1 else 0

private theorem noQuadDead3 : ∀ B, IsCover B → ¬ Weighted.Realizes B (rows12_0 3) :=
  Weighted.exclude _ missing3 0 (by decide +kernel) (by decide +kernel) (by decide +kernel)

private def missing4 (i : Fin 38) : Int := if i=6 then -1 else 0

private theorem noQuadDead4 : ∀ B, IsCover B → ¬ Weighted.Realizes B (rows12_0 4) :=
  Weighted.exclude _ missing4 0 (by decide +kernel) (by decide +kernel) (by decide +kernel)

theorem twelve_has_quad (B : Family 38) (h : IsCover B) (count : (lows B).card=12) :
    ∃ i, 4≤(LocalRows.marked B i).card := by
  by_contra! small
  obtain ⟨j,hj⟩ := catalogue_of_width_three B h count (fun j => by have := small j; omega) _ noQuadExhausts
  fin_cases j
  · exact noQuadDead0 B h hj
  · exact noQuadDead1 B h hj
  · exact noQuadDead2 B h hj
  · exact noQuadDead3 B h hj
  · exact noQuadDead4 B h hj

end Cover61.Layers

