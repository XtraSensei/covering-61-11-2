import Cover61.Partitions

namespace Cover61.Catalog

open Partitions

set_option maxRecDepth 50000

set_option maxHeartbeats 3000000

def s11_052_03Head : Finset (Fin 11) := {1,3,7}

def s11_052_03Rest : List (Finset (Fin 11)) := [
  {0,1}, {0,2}, {1,2}, {3,4}, {0,3,5}, {4,5}, {3,6}, {5,6}, {7}, {0,4,7}, {2,6,7}, {8}, {2,3,8}, {1,5,8}, {4,6,8}, {9}, {1,4,9}, {2,5,9}, {0,6,9}, {7,8,9}, {10}, {2,4,10}, {1,6,10}, {5,7,10}, {0,8,10}, {3,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_052_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_052_03Head s11_052_03Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_053_01Head : Finset (Fin 11) := {2,5,8}

def s11_053_01Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {0,2,4}, {3,4}, {0,3,5}, {4,5}, {0,6}, {5,6}, {7}, {1,5,7}, {3,6,7}, {8}, {1,6,8}, {4,7,8}, {9}, {1,4,9}, {2,6,9}, {0,7,9}, {3,8,9}, {10}, {1,3,10}, {4,6,10}, {2,7,10}, {0,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_053_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_053_01Head s11_053_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_053_02Head : Finset (Fin 11) := {2,5,8}

def s11_053_02Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {0,2,4}, {3,4}, {0,3,5}, {4,5}, {0,6}, {5,6}, {7}, {1,5,7}, {4,6,7}, {8}, {1,6,8}, {3,7,8}, {9}, {1,3,9}, {2,6,9}, {0,7,9}, {4,8,9}, {10}, {1,4,10}, {3,6,10}, {2,7,10}, {0,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_053_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_053_02Head s11_053_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_053_03Head : Finset (Fin 11) := {0,3,5}

def s11_053_03Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {0,6}, {1,4,6}, {5,6}, {7}, {0,2,7}, {1,5,7}, {8}, {2,5,8}, {3,6,8}, {4,7,8}, {9}, {0,4,9}, {2,6,9}, {3,7,9}, {1,8,9}, {10}, {1,3,10}, {2,4,10}, {6,7,10}, {0,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_053_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_053_03Head s11_053_03Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_053_04Head : Finset (Fin 11) := {0,2,7}

def s11_053_04Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {0,3,5}, {4,5}, {0,6}, {5,6}, {7}, {1,5,7}, {4,6,7}, {8}, {1,4,8}, {2,5,8}, {3,6,8}, {9}, {1,3,9}, {0,4,9}, {2,6,9}, {7,8,9}, {10}, {2,4,10}, {1,6,10}, {3,7,10}, {0,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_053_04_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_053_04Head s11_053_04Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_053_05Head : Finset (Fin 11) := {0,3,5}

def s11_053_05Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {0,6}, {2,4,6}, {5,6}, {7}, {0,4,7}, {1,5,7}, {8}, {2,5,8}, {1,6,8}, {3,7,8}, {9}, {0,2,9}, {1,3,9}, {6,7,9}, {4,8,9}, {10}, {1,4,10}, {3,6,10}, {2,7,10}, {0,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_053_05_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_053_05Head s11_053_05Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_053_06Head : Finset (Fin 11) := {7,8,9}

def s11_053_06Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {0,3,5}, {4,5}, {0,6}, {5,6}, {7}, {0,4,7}, {1,5,7}, {2,6,7}, {8}, {1,4,8}, {2,5,8}, {3,6,8}, {9}, {0,2,9}, {1,3,9}, {4,6,9}, {10}, {2,4,10}, {1,6,10}, {3,7,10}, {0,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_053_06_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_053_06Head s11_053_06Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_053_07Head : Finset (Fin 11) := {1,5,7}

def s11_053_07Rest : List (Finset (Fin 11)) := [
  {0,1}, {1,2}, {2,3}, {3,4}, {0,3,5}, {4,5}, {0,6}, {5,6}, {7}, {2,4,7}, {3,6,7}, {8}, {0,4,8}, {2,5,8}, {1,6,8}, {9}, {0,2,9}, {1,3,9}, {4,6,9}, {7,8,9}, {10}, {1,4,10}, {2,6,10}, {0,7,10}, {3,8,10}, {5,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_053_07_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_053_07Head s11_053_07Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_054_01Head : Finset (Fin 11) := {0,1}

def s11_054_01Rest : List (Finset (Fin 11)) := [
  {0,2}, {1,2}, {3,4}, {3,5}, {4,5}, {0,3,6}, {2,4,6}, {1,3,7}, {0,5,7}, {6,7}, {0,4,8}, {2,5,8}, {1,6,8}, {7,8}, {2,3,9}, {1,5,9}, {6,9}, {4,7,9}, {8,9}, {10}, {1,4,10}, {5,6,10}, {2,7,10}, {3,8,10}, {0,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_054_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_054_01Head s11_054_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s11_055_01Head : Finset (Fin 11) := {0,3,5}

def s11_055_01Rest : List (Finset (Fin 11)) := [
  {0,1}, {0,2}, {1,2}, {3,4}, {4,5}, {1,3,6}, {5,6}, {2,3,7}, {0,4,7}, {6,7}, {2,4,8}, {1,5,8}, {0,6,8}, {7,8}, {3,9}, {1,4,9}, {2,6,9}, {5,7,9}, {8,9}, {10}, {2,5,10}, {4,6,10}, {1,7,10}, {3,8,10}, {0,9,10}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s11_055_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s11_055_01Head s11_055_01Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
