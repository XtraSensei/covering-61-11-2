import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.Ring.Int
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fintype.Fin

namespace Cover61.LinearBox

/-- Two nonnegative populations indexed by the same set of types. -/
structure Expr (n : Nat) where
  const : Int
  a : Fin n → Int
  b : Fin n → Int

variable {n : Nat}

def constant (c : Int) : Expr n := ⟨c,fun _ => 0,fun _ => 0⟩
def first (f : Fin n→Nat) : Expr n := ⟨0,fun i => f i,fun _ => 0⟩
def second (f : Fin n→Nat) : Expr n := ⟨0,fun _ => 0,fun i => f i⟩
def add (x y : Expr n) : Expr n := ⟨x.const+y.const,fun i => x.a i+y.a i,fun i => x.b i+y.b i⟩
def scale (c : Int) (x : Expr n) : Expr n := ⟨c*x.const,fun i => c*x.a i,fun i => c*x.b i⟩
def sub (x y : Expr n) : Expr n := add x (scale (-1) y)
def val (u v : Fin n→Nat) (x : Expr n) : Int := x.const + ∑ i,(x.a i * u i + x.b i * v i)

@[simp] theorem val_const (u v : Fin n→Nat) (k : Int) : val u v (constant k)=k := by simp [val,constant]
@[simp] theorem val_first (u v f : Fin n→Nat) : val u v (first f)=↑(∑ i,u i*f i) := by
  simp [val,first,mul_comm]
@[simp] theorem val_second (u v f : Fin n→Nat) : val u v (second f)=↑(∑ i,v i*f i) := by
  simp [val,second,mul_comm]
@[simp] theorem val_add (u v : Fin n→Nat) (x y : Expr n) :
    val u v (add x y)=val u v x+val u v y := by
  simp only [val,add,add_mul,Finset.sum_add_distrib]
  omega
@[simp] theorem val_scale (u v : Fin n→Nat) (c : Int) (x : Expr n) :
    val u v (scale c x)=c*val u v x := by
  simp only [val,scale,mul_add,Finset.mul_sum,mul_assoc]
@[simp] theorem val_sub (u v : Fin n→Nat) (x y : Expr n) :
    val u v (sub x y)=val u v x-val u v y := by simp [sub]; omega

def unit (i : Fin n) (m : Nat) : Fin n → Nat := fun j => if j=i then m else 0
@[simp] theorem sum_unit (f : Fin n→Nat) (i : Fin n) (m : Nat) :
    ∑ j,f j*unit i m j=f i*m := by simp [unit,mul_ite]

def maxOn (U V : Fin n→Nat) (x : Expr n) : Int :=
  x.const+∑ i,(max 0 (x.a i)*U i+max 0 (x.b i)*V i)

theorem le_max (u v U V : Fin n→Nat) (hu : ∀ i,u i≤U i) (hv : ∀ i,v i≤V i) (x : Expr n) :
    val u v x≤maxOn U V x := by
  apply add_le_add_right
  apply Finset.sum_le_sum
  intro i _
  have each (c : Int) (k m : Nat) (km : k≤m) : c*k≤max 0 c*m := by
    apply (mul_le_mul_of_nonneg_right (le_max_right 0 c) (by omega : (0:Int)≤k)).trans
    exact mul_le_mul_of_nonneg_left (by exact_mod_cast km) (le_max_left _ _)
  exact add_le_add (each _ _ _ (hu i)) (each _ _ _ (hv i))

structure Entry (n : Nat) where
  equality : Bool
  expr : Expr n

def total : List (Int × Entry n) → Expr n
  | [] => constant 0
  | (k,row)::tail => add (scale k row.expr) (total tail)

theorem sound (u v U V : Fin n→Nat) (hu : ∀ i,u i≤U i) (hv : ∀ i,v i≤V i)
    (terms : List (Int × Entry n))
    (rows : ∀ t ∈ terms, if t.2.equality then val u v t.2.expr=0 else 0≤val u v t.2.expr)
    (sign : terms.all (fun t => t.2.equality || decide (0≤t.1))=true)
    (gap : maxOn U V (total terms)<0) : False := by
  have nonneg : 0≤val u v (total terms) := by
    clear gap
    induction terms with
    | nil => simp [total]
    | cons t ts ih =>
      obtain ⟨k,r⟩ := t
      rw [List.all_cons,Bool.and_eq_true] at sign
      obtain ⟨ok,rest⟩ := sign
      have present := rows (k,r) (by simp)
      have first : 0≤k*val u v r.expr := by
        by_cases eq : r.equality=true
        · simp [eq] at present; simp [present]
        · simp [eq] at present ok
          exact mul_nonneg ok present
      simpa only [total,val_add,val_scale] using add_nonneg first
        (ih (fun q hq => rows q (List.mem_cons_of_mem _ hq)) rest)
  exact (not_lt_of_ge (nonneg.trans (le_max u v U V hu hv _))) gap

end Cover61.LinearBox
