import Cover61.FiveBoundary

namespace Cover61.LocalRows

def cells (B : Family 38) (i : Photo) := through B i (marked B i)
def line (B : Family 38) (i : Photo) (x : Point) := appearances B (cells B i) x

theorem cells_count (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    (cells B i).card=25 := by rw [cells,(counts B h i _ (marked_sub B i) (marked_six B i)).1,five]

theorem cells_groups_disjoint (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    Disjoint (cells B i) (groups B i) := by
  have only := (five_group_cover B h i five).2.2
  apply Finset.disjoint_left.mpr
  intro j jc jg
  have cl := only (Finset.mem_erase.mpr ⟨through_other jc,jg⟩)
  exact (Finset.mem_sdiff.mp cl).2 jc

theorem outside_line_count (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (x : Point) (out : x ∉ B i) : (line B i x).card=5 :=
  ((outside_counts B h i _ (marked_sub B i) (marked_six B i) x out).1).trans five

theorem low_line_count (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (x : Point) (low : x ∈ lows B) : (line B i x).card=5 := by
  by_cases xi : x ∈ B i
  · have xm : x ∈ marked B i := Finset.mem_inter.mpr ⟨low,xi⟩
    have eq : line B i x = (appearances B Finset.univ x).erase i := by
      ext j
      constructor
      · intro hj
        obtain ⟨cj,xj⟩ := Finset.mem_filter.mp hj
        exact Finset.mem_erase.mpr ⟨through_other cj,by simpa [appearances] using xj⟩
      · intro hj
        obtain ⟨ji,mem⟩ := Finset.mem_erase.mp hj
        have xj := (Finset.mem_filter.mp mem).2
        exact Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_erase.mpr ⟨ji,Finset.mem_univ _⟩,
          ⟨x,Finset.mem_inter.mpr ⟨xm,xj⟩⟩⟩,xj⟩
    have sz : (appearances B Finset.univ x).card=6 := (Finset.mem_filter.mp low).2
    rw [eq,Finset.card_erase_of_mem (by simpa [appearances] using xi),sz]
  · exact outside_line_count B h i five x xi

noncomputable def groupOf (B : Family 38) (i : Photo) (x : Point) : Photo :=
  if ex : ∃ j, appearances B (groups B i) x={j} then Classical.choose ex else i

theorem groupOf_spec (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (x : Point) (low : x ∈ lows B) : appearances B (groups B i) x={groupOf B i x} := by
  classical
  have ex := Finset.card_eq_one.mp ((five_group_cover B h i five).2.1 x low)
  simpa [groupOf,ex] using Classical.choose_spec ex

theorem groupOf_mem (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (x : Point) (low : x ∈ lows B) : groupOf B i x ∈ groups B i ∧ x ∈ B (groupOf B i x) := by
  have mem := groupOf_spec B h i five x low
  exact Finset.mem_filter.mp (mem ▸ Finset.mem_singleton_self _)

theorem low_rows_split (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (x : Point) (low : x ∈ lows B) : appearances B Finset.univ x=insert (groupOf B i x) (line B i x) := by
  have member := groupOf_mem B h i five x low
  have outside : groupOf B i x ∉ line B i x := fun hx => Finset.disjoint_left.mp
    (cells_groups_disjoint B h i five) (Finset.mem_filter.mp hx).1 member.1
  symm
  apply Finset.eq_of_subset_of_card_le
  · intro j hj
    rcases Finset.mem_insert.mp hj with rfl|m
    · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,member.2⟩
    · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,(Finset.mem_filter.mp m).2⟩
  · rw [Finset.card_insert_of_notMem outside,low_line_count B h i five x low]
    exact (Finset.mem_filter.mp low).2.le

theorem same_group_disjoint (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (x y : Point) (xl : x ∈ lows B) (yl : y ∈ lows B) (ne : x≠y) (grp : groupOf B i x=groupOf B i y) :
    Disjoint (line B i x) (line B i y) := by
  have px := groupOf_mem B h i five x xl
  have py := groupOf_mem B h i five y yl
  apply Finset.disjoint_left.mpr
  intro j jx jy
  have diff : j≠groupOf B i x := fun e => Finset.disjoint_left.mp (cells_groups_disjoint B h i five)
    (Finset.mem_filter.mp jx).1 (e ▸ px.1)
  exact ne (intersection_single B h x y (Finset.mem_filter.mp xl).2 j _ diff (Finset.mem_filter.mp jx).2 px.2
    (Finset.mem_filter.mp jy).2 (grp ▸ py.2))

/-- When y does not use x's group row, their sole meeting lies on x's five-cell line. -/
theorem line_meeting (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (x y : Point) (xl : x ∈ lows B) (ne : x≠y) (away : y ∉ B (groupOf B i x)) :
    (line B i x ∩ line B i y).card=1 := by
  have matchSet : line B i x ∩ line B i y=Finset.univ.filter (fun j => x ∈ B j ∧ y ∈ B j) := by
    ext j
    constructor
    · intro v
      obtain ⟨u,w⟩ := Finset.mem_inter.mp v
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,(Finset.mem_filter.mp u).2,(Finset.mem_filter.mp w).2⟩
    · intro v
      obtain ⟨xj,yj⟩ := (Finset.mem_filter.mp v).2
      have yes : j ∈ appearances B Finset.univ x := by simpa [appearances] using xj
      rw [low_rows_split B h i five x xl] at yes
      have inLine := (Finset.mem_insert.mp yes).resolve_left (fun e => away (e ▸ yj))
      exact Finset.mem_inter.mpr ⟨inLine,Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp inLine).1,yj⟩⟩
  rw [matchSet]
  exact six_meets_once B h x y (Finset.mem_filter.mp xl).2 ne

theorem other_group_cross (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (x y : Point) (xl : x ∈ lows B) (yl : y ∈ lows B) (diff : groupOf B i x≠groupOf B i y) :
    (line B i x ∩ line B i y).card=1 := by
  apply line_meeting B h i five x y xl (fun e => diff (congrArg _ e))
  intro both
  have mem : groupOf B i x ∈ appearances B (groups B i) y := Finset.mem_filter.mpr
    ⟨(groupOf_mem B h i five x xl).1,both⟩
  rw [groupOf_spec B h i five y yl,Finset.mem_singleton] at mem
  exact diff mem

end Cover61.LocalRows
