import Cover61.IntegerBounds
import Cover61.RepeatBudget

namespace Cover61.Photos

def roundUp (z v : Nat) := (z+v-1)/v

theorem round_le {v : Nat} (pos : 0<v) (z y : Nat) : roundUp z v≤y ↔ z≤y*v := by
  rw [roundUp,Nat.div_le_iff_le_mul pos]
  omega

theorem rounded_visits {α : Type} [DecidableEq α] (J : Finset α) (v s w : Nat) (pos : 0<v)
    (z : α→Nat) (cover : w≤∑ j ∈ J,z j) :
    roundUp (w+J.card*s) v≤∑ j ∈ J,roundUp (z j+s) v := by
  apply (round_le pos _ _).mpr
  have many := Finset.sum_le_sum (s := J) (fun j _ => (round_le pos (z j+s) _).mp (Nat.le_refl _))
  rw [Finset.sum_add_distrib,←Finset.sum_mul] at many
  simp only [Finset.sum_const,Nat.nsmul_eq_mul] at many
  omega

theorem two_visits (a b t w : Nat) (need : w≤a+b) (apart : 2*t<w) :
    (if a≤t then 1 else 0)+(if b≤t then 1 else 0) ≤
    (if w-t≤a then 1 else 0)+(if w-t≤b then 1 else 0) := by
  split_ifs <;> omega

theorem hit_product {α : Type} [DecidableEq α] (S : Finset α) (x : α→Nat) (hit : 1≤∑ i ∈ S,x i) (k : α) :
    x k≤∑ i ∈ S,x k*x i := by rw [←Finset.mul_sum];simpa using Nat.mul_le_mul_left (x k) hit

theorem balanced_pairs {α : Type} [DecidableEq α] (J : Finset α) (w : α→Int) (q s : Int)
    (mass : ∑ j ∈ J,w j=(J.card:Int)*q+s) :
    ((J.card:Int)-s)*(q*(q-1))+s*((q+1)*q)≤∑ j ∈ J,w j*(w j-1) := by
  have row (j : α) (_ : j ∈ J) : 2*q*w j-q*(q+1)≤w j*(w j-1) := by
    have eq : w j*(w j-1)-(2*q*w j-q*(q+1))=(w j-q)*(w j-q-1) := by grind only
    have := Cuts.integer_consecutive (w j) q;omega
  have lim := Finset.sum_le_sum row
  rw [Finset.sum_sub_distrib,←Finset.mul_sum,mass,Finset.sum_const] at lim
  exact le_trans (le_of_eq (by simp only [nsmul_eq_mul];grind only)) lim

theorem anchored_repeat_budget (B : Family 38) (h : IsCover B) (x : Point) (others anchors : Finset Point)
    (outside : x ∉ others ∪ anchors) (apart : Disjoint others anchors) :
    (∑ y ∈ others,(partners B x y-1))+(∑ y ∈ anchors,(partners B x y-1))≤10*(degree B x-6) := by
  rw [←Finset.sum_union apart,←repeat_sum B h]
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro y hy
    exact Finset.mem_erase.mpr ⟨fun eq => outside (eq ▸ hy),Finset.mem_univ _⟩
  · exact fun _ _ _ => Nat.zero_le _

theorem orbit_price {α β : Type} [DecidableEq α] [DecidableEq β] (G : Finset α) (J : Finset β)
    (a : β→Int) (rhs : Int) (x : α→β→Int) (valid : ∀ g ∈ G,rhs≤∑ j ∈ J,a j*x g j) :
    (G.card:Int)*rhs≤∑ j ∈ J,a j*(∑ g ∈ G,x g j) := by
  have bound := Finset.sum_le_sum valid
  rw [Finset.sum_const,nsmul_eq_mul,Finset.sum_comm] at bound
  simpa only [Finset.mul_sum] using bound

end Cover61.Photos
