import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end84 : EndOK 84 := by decide +kernel

theorem end85 : EndOK 85 := by decide +kernel

theorem end86 : EndOK 86 := by decide +kernel

theorem end87 : EndOK 87 := by decide +kernel

theorem end88 : EndOK 88 := by decide +kernel

theorem end89 : EndOK 89 := by decide +kernel

theorem end90 : EndOK 90 := by decide +kernel

theorem end91 : EndOK 91 := by decide +kernel

theorem end92 : EndOK 92 := by decide +kernel

theorem end93 : EndOK 93 := by decide +kernel

theorem end94 : EndOK 94 := by decide +kernel

theorem end95 : EndOK 95 := by decide +kernel

theorem end96 : EndOK 96 := by decide +kernel

theorem end97 : EndOK 97 := by decide +kernel

theorem reg30 : Regular (candidates 30) := by decide +kernel

theorem reg31 : Regular (candidates 31) := by decide +kernel

theorem reg32 : Regular (candidates 32) := by decide +kernel

theorem reg33 : Regular (candidates 33) := by decide +kernel

theorem reg34 : Regular (candidates 34) := by decide +kernel

end Cover61.Nine
