import Cover61.NoQuadData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem noQuadCheck12 : ∃ cert, Checked (rows11_0 12) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck13 : ∃ cert, Checked (rows11_0 13) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck14 : ∃ cert, Checked (rows11_0 14) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck15 : ∃ cert, Checked (rows11_0 15) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck16 : ∃ cert, Checked (rows11_0 16) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck17 : ∃ cert, Checked (rows11_0 17) rows12_0 0 cert :=
  ⟨[⟨{{0,1},{2,3},{4,5},{6,7},{8,9},{10}},3,⟨6537887754959,242415723847⟩⟩,
  ⟨{{0,1},{2,3},{4,9},{5,6},{7,8},{10}},0,⟨6535716597564,5629204210212⟩⟩,
  ⟨{{0,3},{1,2},{4,5},{6,7},{8,9},{10}},3,⟨8159521455217,8159415203665⟩⟩,
  ⟨{{0,3},{1,2},{4,9},{5,6},{7,8},{10}},3,⟨3338218822070,6524383730139⟩⟩], by decide +kernel⟩

theorem noQuadCheck18 : ∃ cert, Checked (rows11_0 18) rows12_0 0 cert :=
  ⟨[⟨{{0,1},{2,3},{4,5},{6,7},{8,9},{10}},4,⟨5615747017320,1572868989252⟩⟩,
  ⟨{{0,1},{2,3},{4,9},{5,6},{7,8},{10}},3,⟨4908235353032,5588433820288⟩⟩,
  ⟨{{0,3},{1,2},{4,5},{6,7},{8,9},{10}},1,⟨8805431995921,8804151541009⟩⟩,
  ⟨{{0,3},{1,2},{4,9},{5,6},{7,8},{10}},4,⟨4892215862501,1706128580409⟩⟩], by decide +kernel⟩

theorem noQuadCheck19 : ∃ cert, Checked (rows11_0 19) rows12_0 0 cert :=
  ⟨[⟨{{0,1},{2,3},{4,5},{6,7},{8,9},{10}},2,⟨5583344991796,4097720345719⟩⟩,
  ⟨{{0,1},{2,3},{4,9},{5,6},{7,8},{10}},1,⟨2403006486760,916990481429⟩⟩,
  ⟨{{0,3},{1,2},{4,5},{6,7},{8,9},{10}},0,⟨8800282349606,8820920012080⟩⟩,
  ⟨{{0,3},{1,2},{4,9},{5,6},{7,8},{10}},0,⟨8134001446868,8116527779514⟩⟩], by decide +kernel⟩

theorem noQuadCheck20 : ∃ cert, Checked (rows11_0 20) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck21 : ∃ cert, Checked (rows11_0 21) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck22 : ∃ cert, Checked (rows11_0 22) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck23 : ∃ cert, Checked (rows11_0 23) rows12_0 0 cert :=
  ⟨[⟨{{0,1},{2,3},{4,5},{6,7},{8,9},{10}},3,⟨7211053342636,1609268467587⟩⟩,
  ⟨{{0,9},{1,2},{3,4},{5,6},{7,8},{10}},1,⟨5622554392048,1722070982368⟩⟩], by decide +kernel⟩

end Cover61.Layers

