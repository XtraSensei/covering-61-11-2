import Cover61.AGScene

namespace Cover61.Affine

def atom (s r : Role) : Nat := if r=s then 1 else 0
def seatF (d : Dir) (l : Loc) (r : Role) : Nat := if line d l ∈ lines r then 1 else 0

private theorem popCoeffs : ∀ r : Role,
    (∑ d, ∑ l, atom (S d l) r) + (∑ d, ∑ l, seatF d l r) = 2 + ∑ d, atom (T d) r := by decide +kernel
private theorem seatCoeffs : ∀ (d : Dir) (l : Loc) (r : Role),
    atom (S d l) r + atom (T d) r + (∑ k, atom (D d k) r) = seatF d l r + atom (D d l) r := by decide +kernel
private theorem cannotSD : ∀ d l i, allowed (S d l) i = true → allowed (D d l) i = false := by decide +kernel
private theorem cannotTS : ∀ d e l i, d ≠ e → allowed (T d) i = true → allowed (S e l) i = false := by decide +kernel

namespace Scene

private def mass (g : Scene) (f : Role → Nat) := ∑ r, g.n r * f r
private theorem addMass (g : Scene) (f h : Role → Nat) :
    g.mass (fun r => f r+h r) = g.mass f + g.mass h := by simp [mass,Nat.mul_add,Finset.sum_add_distrib]
private theorem sumMass (g : Scene) {ι : Type} [Fintype ι] (f : ι → Role → Nat) :
    g.mass (fun r => ∑ i, f i r) = ∑ i, g.mass (f i) := by
  unfold mass
  simp only [Finset.mul_sum]
  exact Finset.sum_comm
private theorem atomMass (g : Scene) (s : Role) : g.mass (atom s) = g.n s := by
  simp [mass,atom,mul_ite]
private theorem twoMass (g : Scene) : g.mass (fun _ => 2) = 104 := by
  unfold mass
  rw [g.group_sum]
  simp [g.population]
private theorem seatMass (g : Scene) (d : Dir) (l : Loc) : g.mass (seatF d l) = 8 := g.lineSeats d l

theorem hasRole (g : Scene) (r : Role) (pos : 0 < g.n r) : ∃ z : g.O, (g.profile z).r = r := by
  obtain ⟨z,hz⟩ := Finset.card_pos.mp pos
  exact ⟨z,(Finset.mem_filter.mp hz).2⟩

theorem incompatible (g : Scene) {r s : Role} (nz : 0 < g.n r)
    (no : ∀ i, allowed r i = true → allowed s i = false) : g.n s = 0 := by
  by_contra! ns
  obtain ⟨a,ha⟩ := g.hasRole r nz
  obtain ⟨b,hb⟩ := g.hasRole s (by omega)
  obtain ⟨i,hi⟩ := g.encounter a b
  obtain ⟨ia,ib⟩ := Finset.mem_inter.mp hi
  have aa := (g.profile a).support ia
  have bb := (g.profile b).support ib
  rw [ha] at aa
  rw [hb,no i aa] at bb
  contradiction

theorem populations (g : Scene) :
    ∃ d, g.n (T d) = 4 ∧ (∀ l, g.n (S d l) = 4 ∧ g.n (D d l) = 0) ∧
    ∀ e, e ≠ d → g.n (T e) = 0 ∧ ∀ l, g.n (S e l) = 0 ∧ g.n (D e l) = 4 := by
  apply census (fun d => g.n (T d)) (fun d l => g.n (D d l)) (fun d l => g.n (S d l))
  · have e := congrArg g.mass (funext popCoeffs)
    simp only [addMass,sumMass,atomMass,seatMass,twoMass] at e
    have constSeats : (∑ _d : Dir, ∑ _l : Loc, (8 : Nat)) = 96 := by decide
    rw [constSeats] at e
    have arith (s t : Nat) (eq : s+96=104+t) : s=t+8 := by omega
    exact arith _ _ e
  · intro d l
    have e := congrArg g.mass (funext (seatCoeffs d l))
    simpa only [addMass,sumMass,atomMass,seatMass] using e
  · intro d l nz
    exact g.incompatible nz (cannotSD d l)
  · intro d e l nz ns
    by_contra ne
    have zero := g.incompatible nz (fun i => cannotTS d e l i ne)
    omega

end Scene
end Cover61.Affine
