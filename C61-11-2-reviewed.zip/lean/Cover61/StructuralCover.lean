import Cover61.FourCosts
import Cover61.Thirteen
import Cover61.NoQuad12

namespace Cover61
open LocalRows Skeleton Growth

theorem at_most_twelve_of_width_four (B : Family 38) (h : IsCover B)
    (width : ∀ i,(marked B i).card≤4) : (lows B).card≤12 := by
  have upper := at_most_thirteen_of_local B h width (fun many i four => four_cost_three B h i four width many)
  by_contra! bad
  exact thirteen_impossible B h (by omega) (fun i four => four_cost_three B h i four width (by omega))

theorem ten_catalogue (B : Family 38) (h : IsCover B) (count : (lows B).card=10) :
    ∃ j : Fin 65, Weighted.Realizes B (Layers.rows10_0 j) :=
  ten_catalogue_of_width_three B h count (small_width_three B h (by omega))

theorem eleven_catalogue (B : Family 38) (h : IsCover B) (count : (lows B).card=11) :
    ∃ j : Fin 36, Weighted.Realizes B (Layers.rows11_0 j) :=
  catalogue_of_width_three B h count (small_width_three B h (by omega)) _ Layers.eleven_exhausts

theorem twelve_disjoint (B : Family 38) (h : IsCover B) (a : (lows B).card=12) (i j : Fin 38)
    (fi : (marked B i).card=4) (fj : (marked B j).card=4) (ne : i≠j) : Disjoint (marked B i) (marked B j) := by
  have width := no_five_of_le_fourteen B h (by omega)
  have := four_cost_three B h i fi width (by omega)
  have := four_cost_three B h j fj width (by omega)
  have := total_excess B h
  apply disjoint_costly B h i j ne
  omega

theorem twelve_shape (B : Family 38) (h : IsCover B) (a : (lows B).card=12)
    (p : Fin 12 ↪ Point) (six : ∀ x,degree B (p x)=6)
    (eq : ∀ i, (Partitions.lowRow B p i).map p=marked B i) :
    Balanced (Partitions.lowRow B p) ∧ ∃ q, (q=1 ∨ q=2 ∨ q=3) ∧ Shape (big (Partitions.lowRow B p)) q := by
  let r := Partitions.lowRow B p
  have size (i : Fin 38) : (r i).card=(marked B i).card := by rw [←eq,Finset.card_map]
  have width := no_five_of_le_fourteen B h (by omega)
  have four := fullRows B 4
  have qq : quads (big r) = (fullRows B 4).image r := by
    ext s
    constructor
    · intro hs
      obtain ⟨hb,sz⟩ := Finset.mem_filter.mp hs
      obtain ⟨⟨i,rfl⟩,_⟩ := (big_mem r s).mp hb
      exact Finset.mem_image.mpr ⟨i,Finset.mem_filter.mpr ⟨Finset.mem_univ _,(size i).symm.trans sz⟩,rfl⟩
    · rintro hs
      obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hs
      have sz : (r i).card=4 := (size i).trans (Finset.mem_filter.mp hi).2
      exact Finset.mem_filter.mpr ⟨(big_mem r _).mpr ⟨⟨i,rfl⟩,by omega⟩,sz⟩
  have dis (i : Fin 38) (hi : i ∈ fullRows B 4) (j : Fin 38) (hj : j ∈ fullRows B 4) (ne : i≠j) :=
    twelve_disjoint B h a i j (Finset.mem_filter.mp hi).2 (Finset.mem_filter.mp hj).2 ne
  have max := disjoint_low_seats B 4 dis
  obtain ⟨i,wide⟩ := Layers.twelve_has_quad B h a
  have qi : i ∈ fullRows B 4 := by
    have := width i
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,by omega⟩
  have pos := Finset.card_pos.mpr (show (quads (big r)).Nonempty from qq ▸ ⟨r i,Finset.mem_image_of_mem r qi⟩)
  have le : (quads (big r)).card ≤ (fullRows B 4).card := qq ▸ Finset.card_image_le
  have bal : Balanced r := by
    constructor
    · intro x; simpa [tally,containing,r,Partitions.lowRow,degree] using six x
    · intro x y ne
      simpa [tally,containing,r,Partitions.lowRow,partners,Finset.insert_subset_iff] using six_meets_once B h _ _ (six x) (p.injective.ne ne)
  refine ⟨bal,(quads (big r)).card,by omega,fun s hs => ?_,rfl,?_⟩
  · obtain ⟨⟨j,rfl⟩,_⟩ := (big_mem r _).mp hs
    exact (size j).trans_le (width j)
  · intro s hs t ht ne
    rw [qq] at hs ht
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hs
    obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp ht
    have d := dis i hi j hj (fun e => ne (congrArg r e))
    rw [←eq i,←eq j] at d
    exact Finset.disjoint_left.mpr (fun x hx hy => Finset.disjoint_left.mp d (Finset.mem_map_of_mem p hx) (Finset.mem_map_of_mem p hy))

end Cover61
