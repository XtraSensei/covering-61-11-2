import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_2_72 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,6}, {3,7,9}, {4}, {5}, {8,10}},14,⟨391807966737,6008379686111⟩⟩,
  ⟨{{0,5,8}, {1,3}, {2,7}, {4}, {6}, {9,10}},18,⟨4506505587353,978420540130⟩⟩
]

theorem checked12_2_72 : ∃ cert, Checked (rows11_1 72) rows12_2 2 cert :=
  ⟨routes12_2_72, by decide +kernel⟩

private def routes12_2_73 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,6,8}, {4}, {7,10}, {9}},14,⟨1141504815308,1027007601543⟩⟩,
  ⟨{{0,1,7}, {2,3}, {4}, {5}, {6,10}, {8,9}},20,⟨412487994974,6162850626647⟩⟩
]

theorem checked12_2_73 : ∃ cert, Checked (rows11_1 73) rows12_2 2 cert :=
  ⟨routes12_2_73, by decide +kernel⟩

private def routes12_2_74 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,6}, {3,7,9}, {4,10}, {5}, {8}},14,⟨3932896683144,4532287590204⟩⟩,
  ⟨{{0,3}, {1,5}, {2,4,6}, {7}, {8}, {9,10}},18,⟨419959548569,978417554147⟩⟩
]

theorem checked12_2_74 : ∃ cert, Checked (rows11_1 74) rows12_2 2 cert :=
  ⟨routes12_2_74, by decide +kernel⟩

private def routes12_2_75 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,6}, {3,4,5}, {7}, {8,10}, {9}},16,⟨396321489641,911376260399⟩⟩
]

theorem checked12_2_75 : ∃ cert, Checked (rows11_1 75) rows12_2 2 cert :=
  ⟨routes12_2_75, by decide +kernel⟩

private def routes12_2_76 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,5,9}, {4,10}, {7}, {8}},9,⟨1741231986032,2311819693601⟩⟩,
  ⟨{{0,3}, {1,4,9}, {2,7}, {5,10}, {6}, {8}},7,⟨1741267377982,3726922299232⟩⟩
]

theorem checked12_2_76 : ∃ cert, Checked (rows11_1 76) rows12_2 2 cert :=
  ⟨routes12_2_76, by decide +kernel⟩

private def routes12_2_77 : List (Branch 11 23) := [
  ⟨{{0,6,9}, {1,5}, {2,3}, {4}, {7}, {8,10}},21,⟨2485941039890,1713678341298⟩⟩
]

theorem checked12_2_77 : ∃ cert, Checked (rows11_1 77) rows12_2 2 cert :=
  ⟨routes12_2_77, by decide +kernel⟩

private def routes12_2_78 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,5,9}, {4}, {7,10}, {8}},18,⟨3932969686954,4494807498291⟩⟩,
  ⟨{{0,1,7}, {2,3}, {4}, {5}, {6,10}, {8,9}},18,⟨1040161172006,4815231848779⟩⟩
]

theorem checked12_2_78 : ∃ cert, Checked (rows11_1 78) rows12_2 2 cert :=
  ⟨routes12_2_78, by decide +kernel⟩

private def routes12_2_79 : List (Branch 11 23) := [
  ⟨{{0,5,8}, {1,6}, {2,3}, {4,10}, {7}, {9}},16,⟨3913764004612,4603159858407⟩⟩
]

theorem checked12_2_79 : ∃ cert, Checked (rows11_1 79) rows12_2 2 cert :=
  ⟨routes12_2_79, by decide +kernel⟩

private def routes12_2_80 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,3}, {2,5,9}, {6}, {7,10}, {8}},17,⟨1127299438221,1117697677910⟩⟩,
  ⟨{{0,1,7}, {2,3}, {4}, {5,10}, {6}, {8,9}},17,⟨1040158434854,4134140842315⟩⟩,
  ⟨{{0,6,9}, {1,3}, {2,7}, {4}, {5,10}, {8}},10,⟨3933029905156,5351366827059⟩⟩,
  ⟨{{0,6,9}, {1,5}, {2,3}, {4}, {7,10}, {8}},7,⟨3932958738940,3814182263859⟩⟩
]

theorem checked12_2_80 : ∃ cert, Checked (rows11_1 80) rows12_2 2 cert :=
  ⟨routes12_2_80, by decide +kernel⟩

private def routes12_2_81 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,6}, {3,4,8}, {5}, {7,10}, {9}},17,⟨4532754470541,1117700663882⟩⟩,
  ⟨{{0,1,7}, {2,3}, {4}, {5}, {6,10}, {8,9}},19,⟨412487994974,6162850626647⟩⟩
]

theorem checked12_2_81 : ∃ cert, Checked (rows11_1 81) rows12_2 2 cert :=
  ⟨routes12_2_81, by decide +kernel⟩

private def routes12_2_82 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,6}, {3,4,8}, {5,10}, {7}, {9}},10,⟨2570847892228,5351366579955⟩⟩
]

theorem checked12_2_82 : ∃ cert, Checked (rows11_1 82) rows12_2 2 cert :=
  ⟨routes12_2_82, by decide +kernel⟩

private def routes12_2_83 : List (Branch 11 23) := [
  
]

theorem checked12_2_83 : ∃ cert, Checked (rows11_1 83) rows12_2 2 cert :=
  ⟨routes12_2_83, by decide +kernel⟩

end Cover61.Layers
