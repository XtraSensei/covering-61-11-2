import Cover61.GrowthReplay

namespace Cover61.Growth
open Skeleton

def drop {n : Nat} (s : Row (n+1)) : Row n := Finset.univ.filter (fun x => x.castSucc ∈ s)
def before {n} (r : Rows (n+1)) : Rows n := fun i => drop (r i)
def taken {n} (r : Rows (n+1)) := Finset.univ.filter (fun i => Fin.last n ∈ r i)

@[simp] theorem mem_drop {n} (s : Row (n+1)) (x : Fin n) : x ∈ drop s ↔ x.castSucc ∈ s := by simp [drop]
@[simp] theorem mem_lift {n} (s : Row n) (x : Fin n) : x.castSucc ∈ lift s ↔ x ∈ s := by
  exact Finset.mem_map' Fin.castSuccEmb

theorem lift_drop {n} (s : Row (n+1)) : lift (drop s) = s.erase (Fin.last n) := by
  ext x
  induction x using Fin.lastCases with
  | last => simp [last_not_lift]
  | cast i => simp [Fin.castSucc_ne_last]
@[simp] theorem drop_lift {n} (s : Row n) : drop (lift s) = s := by ext; simp
theorem lift_inj {n} : Function.Injective (lift (n:=n)) := fun a b h => by
  simpa using congrArg drop h

theorem reconstruct {n} (r : Rows (n+1)) : extension (before r) (taken r) = r := by
  funext i
  by_cases hi : Fin.last n ∈ r i
  · simp [extension,before,taken,hi,plus,lift_drop]
  · simp [extension,before,taken,hi,lift_drop,Finset.erase_eq_of_notMem hi]

theorem before_bal {n} (r : Rows (n+1)) (h : Balanced r) : Balanced (before r) := by
  constructor
  · intro x; simpa [tally,containing,before] using h.1 x.castSucc
  · intro x y ne
    simpa [tally,containing,before,Finset.insert_subset_iff] using h.2 x.castSucc y.castSucc (Fin.castSucc_injective _ |>.ne ne)

theorem taken_count {n} (r : Rows (n+1)) (h : Balanced r) : (taken r).card=6 := by
  simpa [taken,tally,containing] using h.1 (Fin.last n)
theorem taken_fits {n} (r : Rows (n+1)) (h : Balanced r) : Weighted.Fits (before r) (taken r) Finset.univ := by
  intro x
  simpa [before,taken,Finset.filter_filter,tally,containing,Finset.insert_subset_iff,and_comm] using
    h.2 x.castSucc (Fin.last n) (Fin.castSucc_ne_last x)

def prolong {n} (p : Equiv.Perm (Fin n)) : Equiv.Perm (Fin (n+1)) where
  toFun := Fin.lastCases (Fin.last n) (fun x => (p x).castSucc)
  invFun := Fin.lastCases (Fin.last n) (fun x => (p.symm x).castSucc)
  left_inv x := by induction x using Fin.lastCases <;> simp
  right_inv x := by induction x using Fin.lastCases <;> simp

theorem before_move {n} (r : Rows (n+1)) (p : Equiv.Perm (Fin n)) (e : Equiv.Perm (Fin 38)) :
    before (move (prolong p) e r) = move p e (before r) := by
  funext i; ext x
  simp only [before,mem_drop,move_mem]
  simp [prolong]

theorem rename_size {n} (p : Equiv.Perm (Fin n)) (H : Sys n) : (rename p H).card=H.card := by
  apply Finset.card_image_of_injective
  intro a b eq
  have h := congrArg (fun c : Row n => c.image p.symm) eq
  simpa [Finset.image_image,Function.comp_def] using h

theorem quads_rename {n} (p : Equiv.Perm (Fin n)) (H : Sys n) :
    quads (rename p H) = rename p (quads H) := by
  ext s
  constructor
  · intro hs
    obtain ⟨hm,hc⟩ := Finset.mem_filter.mp hs
    obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hm
    rw [Finset.card_image_of_injective _ p.injective] at hc
    exact Finset.mem_image.mpr ⟨t,Finset.mem_filter.mpr ⟨ht,hc⟩,rfl⟩
  · intro hs
    obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hs
    obtain ⟨hm,hc⟩ := Finset.mem_filter.mp ht
    exact Finset.mem_filter.mpr ⟨Finset.mem_image_of_mem _ hm,(Finset.card_image_of_injective _ p.injective).trans hc⟩

theorem shape_move {n} (r : Rows n) (p : Equiv.Perm (Fin n)) (e : Equiv.Perm (Fin 38))
    (q : Nat) (h : Shape (big r) q) : Shape (big (move p e r)) q := by
  rw [move_big]
  refine ⟨?_,by rw [quads_rename,rename_size,h.2.1],?_⟩
  · intro s hs
    obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hs
    exact (Finset.card_image_of_injective _ p.injective).le.trans (h.1 _ ht)
  · rw [quads_rename]
    intro s hs t ht ne
    obtain ⟨a,ha,rfl⟩ := Finset.mem_image.mp hs
    obtain ⟨b,hb,rfl⟩ := Finset.mem_image.mp ht
    have dis := h.2.2 a ha b hb (fun eq => ne (congrArg (Finset.image p) eq))
    apply Finset.disjoint_left.mpr
    intro x xa xb
    obtain ⟨y,ya,rfl⟩ := Finset.mem_image.mp xa
    obtain ⟨z,zb,eq⟩ := Finset.mem_image.mp xb
    exact Finset.disjoint_left.mp dis ya (p.injective eq ▸ zb)

theorem quad_before {n} (r : Rows (n+1)) (le : ∀ i, (r i).card ≤ 4) :
    (quads (big (before r))).image lift = (quads (big r)).filter (fun s => Fin.last n ∉ s) := by
  ext s
  constructor
  · intro h
    obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp h
    obtain ⟨hb,hc⟩ := Finset.mem_filter.mp ht
    obtain ⟨⟨i,rfl⟩,_⟩ := (big_mem _ _).mp hb
    have sz : ((r i).erase (Fin.last n)).card = 4 := by rw [← lift_drop,card_lift]; exact hc
    have no : Fin.last n ∉ r i := by
      intro hi
      rw [Finset.card_erase_of_mem hi] at sz
      have := le i; omega
    have eq : lift (before r i) = r i := by simp [before,lift_drop,Finset.erase_eq_of_notMem no]
    rw [eq,Finset.erase_eq_of_notMem no] at *
    exact Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨(big_mem _ _).mpr ⟨⟨i,rfl⟩,by omega⟩,sz⟩,no⟩
  · intro h
    obtain ⟨hq,no⟩ := Finset.mem_filter.mp h
    obtain ⟨hb,hc⟩ := Finset.mem_filter.mp hq
    obtain ⟨⟨i,rfl⟩,_⟩ := (big_mem _ _).mp hb
    have eq : lift (before r i) = r i := by simp [before,lift_drop,Finset.erase_eq_of_notMem no]
    have sz : (before r i).card = 4 := by rw [← card_lift,eq,hc]
    exact Finset.mem_image.mpr ⟨before r i,Finset.mem_filter.mpr ⟨(big_mem _ _).mpr ⟨⟨i,rfl⟩,by omega⟩,sz⟩,eq⟩

theorem before_shape {n} (r : Rows (n+1)) (q : Nat) (h : Shape (big r) q)
    (chosen : 0 < q → ∃ s ∈ quads (big r), Fin.last n ∈ s) : Shape (big (before r)) (q-1) := by
  have le (i) : (r i).card ≤ 4 := (width r q h i).trans (by unfold bound; split <;> omega)
  have eq := quad_before r le
  have liftmem {s : Row n} (hs : s ∈ quads (big (before r))) : lift s ∈ quads (big r) := by
    have hx := Finset.mem_image_of_mem lift hs
    rw [eq] at hx
    exact (Finset.mem_filter.mp hx).1
  refine ⟨?_,?_,?_⟩
  · intro s hs
    obtain ⟨⟨i,rfl⟩,_⟩ := (big_mem _ _).mp hs
    change (drop (r i)).card ≤ 4
    rw [← card_lift,lift_drop]
    exact (Finset.card_le_card (Finset.erase_subset ..)).trans (le i)
  · rw [← Finset.card_image_of_injective _ lift_inj,eq]
    by_cases z : q=0
    · have em := Finset.card_eq_zero.mp (h.2.1.trans z)
      simp [em,z]
    · obtain ⟨s,hs,sl⟩ := chosen (by omega)
      have filt : (quads (big r)).filter (fun t => Fin.last n ∉ t) = (quads (big r)).erase s := by
        ext t; simp only [Finset.mem_filter,Finset.mem_erase]
        constructor
        · rintro ⟨ht,hn⟩; exact ⟨fun eq => hn (eq ▸ sl),ht⟩
        · rintro ⟨ne,ht⟩
          exact ⟨ht,fun mem => Finset.disjoint_left.mp (h.2.2 t ht s hs ne) mem sl⟩
      rw [filt,Finset.card_erase_of_mem hs,h.2.1]
  · intro s hs t ht ne
    have dis := h.2.2 _ (liftmem hs) _ (liftmem ht) (fun eq => ne (lift_inj eq))
    exact Finset.disjoint_left.mpr (fun x xs xt => Finset.disjoint_left.mp dis
      ((mem_lift s x).mpr xs) ((mem_lift t x).mpr xt))

end Cover61.Growth
