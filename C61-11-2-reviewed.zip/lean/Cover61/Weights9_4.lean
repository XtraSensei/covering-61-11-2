import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w9_30Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,5}, {1,4,7}, {2,4,8}, {2,6,7}, {3,6,8}, {0,7}, {0,8}, {1,6}, {1,8}, {2,3}, {2,5}, {3,7}, {4,5}, {4,6}, {5,7}, {5,8}, {7,8}, {0}, {1}, {2}, {3}, {4}, {6}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_30Cost : Cost := fun i =>
  ([0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_30_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_30Rows :=
  Weighted.exclude _ w9_30Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_31Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,5}, {1,4,7}, {2,6,7}, {4,6,8}, {5,7,8}, {0,7}, {0,8}, {1,6}, {1,8}, {2,3}, {2,4}, {2,5}, {2,8}, {3,6}, {3,7}, {3,8}, {4,5}, {0}, {1}, {4}, {5}, {6}, {7}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_31Cost : Cost := fun i =>
  ([0, 0, 0, -1, 0, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_31_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_31Rows :=
  Weighted.exclude _ w9_31Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_36Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {0,7,8}, {1,3,5}, {1,4,6}, {2,3,7}, {2,5,8}, {3,6,8}, {1,7}, {1,8}, {2,4}, {2,6}, {4,5}, {4,7}, {4,8}, {5,7}, {6,7}, {0}, {0}, {1}, {2}, {3}, {3}, {5}, {6}, {8}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_36Cost : Cost := fun i =>
  ([0, 1, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_36_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_36Rows :=
  Weighted.exclude _ w9_36Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
