import Cover61.Weighted
import Mathlib.Data.Finset.Dedup

namespace Cover61

/-- Translate a labelled row table to the distinguished-row presentation
used by the partition obstructions. The 37 other indices are checked explicitly. -/
theorem pointed_of_realizes {n : Nat} {B : Family 38} {r : Weighted.Rows n}
    (real : Weighted.Realizes B r) (i : Fin 38) (idx : List (Fin 38))
    (distinct : idx.Nodup) (all : ∀ k,k ∈ idx ↔ k≠i)
    {head : Finset (Fin n)} {tail : List (Finset (Fin n))}
    (first : r i=head) (others : idx.map r=tail) : Partitions.Realizes B head tail := by
  obtain ⟨p,e,six,rows⟩ := real
  refine ⟨p,e i,idx.map e,six,?_,(rows i).trans first,?_⟩
  · apply (List.perm_ext_iff_of_nodup (distinct.map e.injective) (Finset.nodup_toList _)).2
    intro j
    rw [List.mem_map,Finset.mem_toList,Finset.mem_erase]
    constructor
    · rintro ⟨k,hk,rfl⟩
      exact ⟨fun eq => (all k).1 hk (e.injective eq),Finset.mem_univ _⟩
    · rintro ⟨hne,_⟩
      refine ⟨e.symm j,(all _).2 (fun eq => hne ?_),e.apply_symm_apply j⟩
      exact (e.apply_symm_apply j).symm.trans (congrArg e eq)
  · simpa only [List.map_map,Function.comp_def,rows] using others

theorem rows_of_realizes {n : Nat} {B : Family 38} {r s : Weighted.Rows n}
    (real : Weighted.Realizes B r) (same : ∀ i,r i=s i) : Weighted.Realizes B s :=
  (funext same : r=s) ▸ real

end Cover61
