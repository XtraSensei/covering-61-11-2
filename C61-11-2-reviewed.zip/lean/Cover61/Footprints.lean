import Cover61.NormalizeGrid

namespace Cover61.Grid.Chart
open LatinFive
variable {α : Type} [DecidableEq α] {U : Finset α} (D : Chart U)

structure Path (D : Chart U) where
  cells : Finset α
  inside : cells ⊆ U
  rows : Along D.R cells
  cols : Along D.C cells
  symbols : Along D.S cells

namespace Path
variable {D} (P : Path D)

noncomputable def atRow (i : Five) : α := Classical.choose (Finset.card_eq_one.mp (P.rows i))
theorem uniqueRow (i : Five) : P.cells ∩ D.R.row i={P.atRow i} := Classical.choose_spec (Finset.card_eq_one.mp (P.rows i))
theorem at_mem (i : Five) : P.atRow i ∈ P.cells ∧ P.atRow i ∈ D.R.row i :=
  Finset.mem_inter.mp (P.uniqueRow i ▸ Finset.mem_singleton_self _)
theorem at_of_mem (x : α) (px : x ∈ P.cells) : P.atRow (D.R.coord x)=x := by
  have hp := Finset.mem_inter.mpr ⟨px,D.R.coord_mem x (P.inside px)⟩
  exact (Finset.mem_singleton.mp (P.uniqueRow _ ▸ hp)).symm

noncomputable def column (i : Five) := D.C.coord (P.atRow i)
theorem coord_point (i : Five) : P.atRow i=D.cell i (P.column i) :=
  D.cell_of_mem (P.at_mem i).2 (D.C.coord_mem _ (P.inside (P.at_mem i).1))

theorem at_inj : Function.Injective P.atRow := by
  intro i j e
  exact (D.R.coord_eq (P.at_mem i).2).symm.trans ((congrArg D.R.coord e).trans (D.R.coord_eq (P.at_mem j).2))

theorem coords_inj (A : Axis U) (along : Along A P.cells) : Function.Injective (fun i => A.coord (P.atRow i)) := by
  intro i j eq
  change A.coord (P.atRow i)=A.coord (P.atRow j) at eq
  have l := A.coord_mem _ (P.inside (P.at_mem i).1)
  have r := A.coord_mem _ (P.inside (P.at_mem j).1)
  apply P.at_inj
  exact Finset.card_le_one.mp (along _).le _ (Finset.mem_inter.mpr ⟨(P.at_mem i).1,l⟩)
    _ (Finset.mem_inter.mpr ⟨(P.at_mem j).1,eq ▸ r⟩)

theorem col_inj : Function.Injective P.column := P.coords_inj D.C P.cols
theorem sym_inj : Function.Injective (fun i => D.symbol i (P.column i)) := by
  simpa only [symbol,←P.coord_point] using P.coords_inj D.S P.symbols

noncomputable def mask := cellMask (pack P.column)
theorem code_ok : pack P.column ∈ permutations := permutation_code _ P.col_inj

theorem mask_at (x : α) (hx : x ∈ U) :
    P.mask.testBit (5*(D.R.coord x).val+(D.C.coord x).val)=true ↔ x ∈ P.cells := by
  rw [mask,bit_code P.code_ok,beq_iff_eq,unpack]
  constructor
  · intro e
    have eq : P.column (D.R.coord x)=D.C.coord x := Fin.ext e
    have actual := D.cell_of_mem (D.R.coord_mem x hx) (D.C.coord_mem x hx)
    have hits := P.coord_point (D.R.coord x)
    rw [eq,←actual] at hits
    exact hits ▸ (P.at_mem _).1
  · intro px
    exact congrArg Fin.val (congrArg D.C.coord (P.at_of_mem x px))

theorem same_mask (Q : Path D) (same : P.mask=Q.mask) : P.cells=Q.cells := by
  ext x
  by_cases xu : x ∈ U
  · rw [←P.mask_at x xu,←Q.mask_at x xu,same]
  · exact ⟨fun h => (xu (P.inside h)).elim,fun h => (xu (Q.inside h)).elim⟩

theorem meet_count (Q : Path D) : commonRows (pack P.column) (pack Q.column)=(P.cells ∩ Q.cells).card := by
  rw [common_count P.col_inj Q.col_inj]
  let K := Finset.univ.filter (fun i => P.column i=Q.column i)
  have eq : K.image P.atRow=P.cells ∩ Q.cells := by
    ext x
    constructor
    · intro hx
      obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hx
      have same := (Finset.mem_filter.mp hi).2
      have ix := P.coord_point i
      rw [same,←Q.coord_point] at ix
      exact Finset.mem_inter.mpr ⟨(P.at_mem i).1,ix ▸ (Q.at_mem i).1⟩
    · intro hx
      obtain ⟨px,qx⟩ := Finset.mem_inter.mp hx
      have pi := P.at_of_mem x px
      have qi := Q.at_of_mem x qx
      exact Finset.mem_image.mpr ⟨D.R.coord x,Finset.mem_filter.mpr ⟨Finset.mem_univ _,congrArg D.C.coord (pi.trans qi.symm)⟩,pi⟩
  rw [←eq,Finset.card_image_of_injective _ P.at_inj]

theorem masks_once (Q : Path D) (one : (P.cells ∩ Q.cells).card=1) : once P.mask Q.mask=true := by
  change once (cellMask (pack _)) (cellMask (pack _))=true
  rw [(pair_test P.code_ok Q.code_ok).2,P.meet_count,one];rfl

theorem masks_disjoint (Q : Path D) : disjoint P.mask Q.mask=true ↔ Disjoint P.cells Q.cells := by
  change disjoint (cellMask (pack _)) (cellMask (pack _))=true ↔ _
  rw [(pair_test P.code_ok Q.code_ok).1,P.meet_count,beq_iff_eq,Finset.card_eq_zero,Finset.disjoint_iff_inter_eq_empty]

private theorem unique_codes : ∀ u : Label→Label, (∀ i j,u i=u j → i=j) →
    ((List.finRange 5).map (fun i => (u i).val)).eraseDups.length=5 := by decide +kernel

theorem transversal : P.mask ∈ transversals (rowPrefix D.word 5) := by
  apply List.mem_map.mpr
  refine ⟨pack P.column,List.mem_filter.mpr ⟨P.code_ok,?_⟩,rfl⟩
  have words (i : Five) : (rowPrefix D.word 5)[i.val]?.getD 0=D.word i.val := by
    simp [rowPrefix,List.getElem?_eq_getElem,i.isLt]
  have eq : indices.map (fun i => digit ((rowPrefix D.word 5)[i]?.getD 0) (digit (pack P.column) i))=
      (List.finRange 5).map (fun i => (D.symbol i (P.column i)).val) := by
    apply List.ext_getElem
    · simp [indices]
    · intro i left right
      have small : i<5 := by simpa [indices] using left
      let j : Five := ⟨i,small⟩
      simp only [indices,List.getElem_map,List.getElem_range,List.getElem_finRange]
      change digit ((rowPrefix D.word 5)[j.val]?.getD 0) (digit (pack P.column) j.val)=(D.symbol j (P.column j)).val
      rw [words,D.word_at,unpack,unpack]
  rw [eq,unique_codes _ P.sym_inj];rfl

end Path
end Cover61.Grid.Chart
