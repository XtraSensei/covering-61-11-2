import Cover61.Affine

namespace Cover61.Affine

/-- Three attendance comparisons against the same omitted line cancel the three
bits of its double-line participant. -/
private theorem cancelLine (a b c d e f u v w : Bool)
    (ha : (b == v) ≠ (c == w)) (hb : (a == u) ≠ (d == w))
    (hc : (e == u) ≠ (f == v)) :
    ((a ^^ e) ^^ (b ^^ f) ^^ (c ^^ d)) = true := by
  revert ha hb hc
  decide +revert

/-- Consider one single-line participant in each of the first two horizontal
rows, and all four in the third row. If each pair of participants meets and
each omitted-line participant meets these singles exactly once, all four
third-row participants must use exactly the same six singleton blocks. -/
theorem same_six_bits (ab ac ba bc : Row) (ca cb : Fin 4 → Row)
    (line : ∀ i j : Fin 3, ∃ u v w : Bool,
      (ab j == v) ≠ (ac (i+j) == w) ∧ (ba i == u) ≠ (bc (i+j) == w) ∧
      ∀ s, (ca s i == u) ≠ (cb s j == v))
    (meet : ∀ s, ∃ i, ba i = ca s i) :
    ∀ s, ca s = ca 0 ∧ cb s = cb 0 := by
  have aa (s : Fin 4) (i : Fin 3) : ba i = ca s i := by
    have hc := row_constant (fun k => ba k ^^ ca s k) (fun k => ab k ^^ cb s k)
      (fun k => ac k ^^ bc k) (by
        intro i j
        obtain ⟨u,v,w,ha,hb,hh⟩ := line i j
        exact cancelLine _ _ _ _ _ _ _ _ _ ha hb (hh s))
    obtain ⟨k,hk⟩ := meet s
    have he := (hc i).trans (hc k).symm
    change (ba i ^^ ca s i) = (ba k ^^ ca s k) at he
    rw [hk] at he
    cases h : ca s k <;> cases hp : ba i <;> cases hq : ca s i <;> simp_all
  intro s
  refine ⟨funext (fun i => (aa s i).symm.trans (aa 0 i)),?_⟩
  funext j
  obtain ⟨u,v,w,_,_,hh⟩ := line 0 j
  have hs := hh s
  have hz := hh 0
  rw [← aa s 0] at hs
  rw [← aa 0 0] at hz
  have unique (x y v t : Bool) (h : t ≠ (x == v)) (k : t ≠ (y == v)) : x = y := by decide +revert
  exact unique _ _ _ _ hs hz

end Cover61.Affine
