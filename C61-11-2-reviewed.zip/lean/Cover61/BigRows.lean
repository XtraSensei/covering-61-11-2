import Cover61.ForcedCore

namespace Cover61.Skeleton

def Balanced {n : Nat} (r : Rows n) :=
  (∀ x, tally r {x}=6) ∧ ∀ x y : Fin n, x ≠ y → tally r {x,y}=1
instance {n : Nat} (r : Rows n) : Decidable (Balanced r) := by unfold Balanced; infer_instance
def big {n : Nat} (r : Rows n) : Sys n := (Finset.univ.image r).filter (fun s => 3 ≤ s.card)
def quads {n : Nat} (H : Sys n) := H.filter (fun s => s.card=4)
def Shape {n : Nat} (H : Sys n) (q : Nat) := (∀ s ∈ H, s.card ≤ 4) ∧
  (quads H).card=q ∧ ∀ s ∈ quads H, ∀ t ∈ quads H, s ≠ t → Disjoint s t
section
-- Traverse the recorded rows, including for both bounded quantifiers on quads.
attribute [local instance 2000] Finset.decidableDforallFinset
instance {n : Nat} (H : Sys n) (q : Nat) : Decidable (Shape H q) := by unfold Shape; infer_instance
end

def move {n : Nat} (p : Equiv.Perm (Fin n)) (e : Equiv.Perm (Fin 38)) (r : Rows n) : Rows n :=
  fun i => (r (e i)).image p
def Similar {n : Nat} (a b : Rows n) := ∃ p e, move p e a = b

theorem similar_refl {n} (a : Rows n) : Similar a a := by
  refine ⟨Equiv.refl _,Equiv.refl _,?_⟩; funext i; simp [move]

theorem similar_trans {n} {a b c : Rows n} (ab : Similar a b) (bc : Similar b c) : Similar a c := by
  obtain ⟨p,e,rfl⟩ := ab
  obtain ⟨q,f,rfl⟩ := bc
  refine ⟨p.trans q,f.trans e,?_⟩
  funext i; simp [move,Finset.image_image,Function.comp_def]

theorem move_mem {n} (r : Rows n) (p : Equiv.Perm (Fin n)) (e : Equiv.Perm (Fin 38)) (i x) :
    x ∈ move p e r i ↔ p.symm x ∈ r (e i) := push_mem p r (e i) x

theorem move_balanced {n} (r : Rows n) (h : Balanced r) (p : Equiv.Perm (Fin n)) (e : Equiv.Perm (Fin 38)) :
    Balanced (move p e r) := by
  have transfer (pred : Fin 38 → Prop) [DecidablePred pred] :
      (Finset.univ.filter (fun i => pred (e i))).card = (Finset.univ.filter pred).card := by
    simpa using Equiv.sum_comp e (fun j => if pred j then (1:Nat) else 0)
  constructor
  · intro x
    have eq := transfer (fun j => p.symm x ∈ r j)
    simpa [tally,containing,move_mem] using eq.trans (show (Finset.univ.filter (fun j => p.symm x ∈ r j)).card=6 by
      simpa [tally,containing] using h.1 (p.symm x))
  · intro x y ne
    have eq := transfer (fun j => p.symm x ∈ r j ∧ p.symm y ∈ r j)
    simpa [tally,containing,Finset.insert_subset_iff,move_mem] using
      eq.trans (show (Finset.univ.filter (fun j => p.symm x ∈ r j ∧ p.symm y ∈ r j)).card = 1 by
        simpa [tally,containing,Finset.insert_subset_iff] using h.2 _ _ (p.symm.injective.ne ne))

theorem big_mem {n} (r : Rows n) (s : Row n) :
    s ∈ big r ↔ (∃ i, r i=s) ∧ 3 ≤ s.card := by simp [big]

theorem move_big {n} (r : Rows n) (p : Equiv.Perm (Fin n)) (e : Equiv.Perm (Fin 38)) :
    big (move p e r) = rename p (big r) := by
  ext s
  rw [big_mem]
  constructor
  · rintro ⟨⟨i,rfl⟩,lower⟩
    refine Finset.mem_image.mpr ⟨r (e i),(big_mem _ _).mpr ⟨⟨e i,rfl⟩,?_⟩,rfl⟩
    simpa [move,Finset.card_image_of_injective _ p.injective] using lower
  · intro hs
    obtain ⟨w,hw,rfl⟩ := Finset.mem_image.mp hs
    obtain ⟨⟨i,rfl⟩,lower⟩ := (big_mem _ _).mp hw
    exact ⟨⟨e.symm i,by simp [move]⟩,by rwa [Finset.card_image_of_injective _ p.injective]⟩

theorem uniqueIndex {n} (r : Rows n) (hr : Balanced r) (s : Row n) (two : 1<s.card) :
    (containing r s).card ≤ 1 := by
  obtain ⟨x,y,hx,hy,ne⟩ := Finset.one_lt_card_iff.mp two
  have sub : containing r s ⊆ containing r {x,y} := by
    intro i hi
    have inside := (Finset.mem_filter.mp hi).2
    simp [containing,Finset.insert_subset_iff,inside hx,inside hy]
  exact (Finset.card_le_card sub).trans_eq (hr.2 _ _ ne)

theorem tallies_big {n} {r t : Rows n} (hr : Balanced r) (ht : Balanced t) (eq : big r = big t) :
    ∀ s, tally r s = tally t s := by
  intro s
  by_cases zero : s.card=0
  · have he := Finset.card_eq_zero.mp zero; subst s; simp [tally,containing]
  by_cases one : s.card=1
  · obtain ⟨x,rfl⟩ := Finset.card_eq_one.mp one; rw [hr.1,ht.1]
  by_cases two : s.card=2
  · obtain ⟨x,y,ne,rfl⟩ := Finset.card_eq_two.mp two; rw [hr.2 _ _ ne,ht.2 _ _ ne]
  have tag (v : Rows n) (hv : Balanced v) : tally v s = if ∃ w ∈ big v, s ⊆ w then 1 else 0 := by
    have le : tally v s ≤ 1 := uniqueIndex v hv s (by omega)
    split
    next yes =>
      obtain ⟨w,hw,sub⟩ := yes
      obtain ⟨⟨i,rfl⟩,_⟩ := (big_mem _ _).mp hw
      have pos : 0 < tally v s := Finset.card_pos.mpr ⟨i,Finset.mem_filter.mpr ⟨Finset.mem_univ _,sub⟩⟩
      omega
    next no =>
      apply Finset.card_eq_zero.mpr
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro i hi
      have sub := (Finset.mem_filter.mp hi).2
      have sz := Finset.card_le_card sub
      exact no ⟨v i,(big_mem _ _).mpr ⟨⟨i,rfl⟩,by omega⟩,sub⟩
  rw [tag r hr,tag t ht,eq]

theorem similar_of_big {n} {r t : Rows n} (hr : Balanced r) (ht : Balanced t) (iso : Iso (big r) (big t)) :
    Similar r t := by
  obtain ⟨p,hp⟩ := iso
  let a := move p (Equiv.refl _) r
  have eq : big a = big t := (move_big _ _ _).trans hp
  obtain ⟨e,he⟩ := arrange a t (fiber_sizes _ _ (tallies_big (move_balanced _ hr _ _) ht eq))
  exact ⟨p,e,funext he⟩

theorem realizes_similar {n} (B : Family 38) (p : Fin n ↪ Point) (six : ∀ j, degree B (p j)=6)
    {t : Rows n} (sim : Similar (Partitions.lowRow B p) t) : Weighted.Realizes B t := by
  obtain ⟨q,e,rfl⟩ := sim
  refine ⟨q.symm.toEmbedding.trans p,e,fun j => six _,?_⟩
  intro i; ext x; rw [move_mem]; simp [Partitions.lowRow]

end Cover61.Skeleton
