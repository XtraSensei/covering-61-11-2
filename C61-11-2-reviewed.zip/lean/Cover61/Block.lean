import Cover61.Incidence
import Mathlib.Tactic.NormNum

namespace Cover61

private def common {b : Nat} (B : Family b) (x y : Point) :=
  Finset.univ.filter (fun i => x ∈ B i ∧ y ∈ B i)

theorem intersection_single {b : Nat} (B : Family b) (h : IsCover B)
    (x y : Point) (hx : degree B x = 6) (i j : Fin b) (hne : i ≠ j)
    (xi : x ∈ B i) (xj : x ∈ B j) (yi : y ∈ B i) (yj : y ∈ B j) : x = y := by
  by_contra ne
  have small : (common B x y).card = 1 := six_meets_once B h x y hx ne
  have sub : ({i,j} : Finset (Fin b)) ⊆ common B x y := by
    intro k hk
    simp only [Finset.mem_insert,Finset.mem_singleton] at hk
    rcases hk with rfl | rfl <;> simp [common, *]
  have card := Finset.card_le_card sub
  simp [hne,small] at card

private theorem sum_inter {β : Type} [DecidableEq β] (s t : Finset β) :
    (∑ x ∈ s, if x ∈ t then 1 else 0 : Nat) = (s ∩ t).card := by
  simp

/-- Count the low-point seats in every row other than the distinguished one. -/
private theorem low_seats (B : Family 38) (i : Fin 38) (q : Finset Point)
    (inside : q ⊆ B i) (six : ∀ x ∈ q, degree B x = 6) :
    ∑ j ∈ Finset.univ.erase i, (q ∩ B j).card = q.card * 5 := by
  calc
    _ = ∑ j ∈ Finset.univ.erase i, ∑ x ∈ q, if x ∈ B j then 1 else 0 := by
      simp only [sum_inter]
    _ = ∑ x ∈ q, ∑ j ∈ Finset.univ.erase i, if x ∈ B j then 1 else 0 := Finset.sum_comm
    _ = ∑ _x ∈ q, 5 := by
      apply Finset.sum_congr rfl
      intro x hx
      have he := Finset.sum_erase_add Finset.univ (fun j => (if x ∈ B j then 1 else 0 : Nat))
        (Finset.mem_univ i)
      have hd := six x hx
      simp only [if_pos (inside hx),Finset.sum_boole] at he
      change (Finset.univ.filter (fun j => x ∈ B j)).card = 6 at hd
      rw [hd] at he
      simp only [Finset.sum_boole]
      omega
    _ = _ := by simp

theorem cross_sum {b : Nat} (B : Family b) (u v : Finset Point) :
    ∑ x ∈ u, ∑ y ∈ v, partners B x y =
    ∑ j, (u ∩ B j).card * (v ∩ B j).card := by
  calc
    _ = ∑ x ∈ u, ∑ y ∈ v, ∑ j, if x ∈ B j ∧ y ∈ B j then 1 else 0 := by simp [partners]
    _ = ∑ x ∈ u, ∑ j, ∑ y ∈ v, if x ∈ B j ∧ y ∈ B j then 1 else 0 := by
      apply Finset.sum_congr rfl; intro x _; exact Finset.sum_comm
    _ = ∑ j, ∑ x ∈ u, ∑ y ∈ v, if x ∈ B j ∧ y ∈ B j then 1 else 0 := Finset.sum_comm
    _ = _ := by
      apply Finset.sum_congr rfl
      intro j _
      rw [← sum_inter u (B j),Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro x _
      by_cases hx : x ∈ B j <;> simp [hx]

private theorem room (s t : Nat) (h : s+t ≤ 11) : s*t ≤ 30 := by
  have hs : s ≤ 11 := by omega
  have cases : s = 0 ∨ s = 1 ∨ s = 2 ∨ s = 3 ∨ s = 4 ∨ s = 5 ∨ s = 6 ∨ s = 7 ∨ s = 8 ∨ s = 9 ∨ s = 10 ∨ s = 11 := by omega
  rcases cases with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> omega

/-- No block of a 38-cover contains six points of replication six. -/
theorem at_most_five (B : Family 38) (h : IsCover B) (i : Fin 38) :
    ((B i).filter (fun x => degree B x = 6)).card ≤ 5 := by
  classical
  let q := (B i).filter (fun x => degree B x = 6)
  let u := B i \ q
  let v := Finset.univ \ B i
  have qi : q ⊆ B i := Finset.filter_subset _ _
  have sq : ∀ x ∈ q, degree B x = 6 := fun _ hx => (Finset.mem_filter.mp hx).2
  have uv : Disjoint u v := Finset.disjoint_left.mpr (fun _ hx hy =>
    (Finset.mem_sdiff.mp hy).2 (Finset.mem_sdiff.mp hx).1)
  have need : u.card*v.card ≤ ∑ j, (u ∩ B j).card * (v ∩ B j).card := by
    rw [← cross_sum]
    calc
      _ = ∑ x ∈ u, ∑ _y ∈ v, 1 := by simp
      _ ≤ _ := by
        apply Finset.sum_le_sum; intro x hx
        apply Finset.sum_le_sum; intro y hy
        apply partners_pos B h
        intro e; exact Finset.disjoint_left.mp uv hx (e ▸ hy)
  let f (j : Fin 38) := (u ∩ B j).card * (v ∩ B j).card
  have zero : f i = 0 := by
    have ve : v ∩ B i = ∅ := by ext x; simp [v]
    simp [f,ve]
  have outside := Finset.sum_erase_add Finset.univ f (Finset.mem_univ i)
  rw [zero,Nat.add_zero] at outside
  change u.card*v.card ≤ ∑ j, f j at need
  rw [← outside] at need
  have row (j : Fin 38) (hj : j ∈ Finset.univ.erase i) :
      f j + 30*(q ∩ B j).card ≤ 30 := by
    by_cases hn : (q ∩ B j).Nonempty
    · obtain ⟨x,hx⟩ := hn
      obtain ⟨xq,xj⟩ := Finset.mem_inter.mp hx
      have only (y : Point) (yi : y ∈ B i) (yj : y ∈ B j) : x = y :=
        intersection_single B h x y (sq x xq) i j (Finset.mem_erase.mp hj).1.symm
          (qi xq) xj yi yj
      have single : q ∩ B j ⊆ {x} := by
        intro y hy
        obtain ⟨yq,yj⟩ := Finset.mem_inter.mp hy
        exact Finset.mem_singleton.mpr (only y (qi yq) yj).symm
      have none : u ∩ B j = ∅ := by
        apply Finset.eq_empty_iff_forall_notMem.mpr
        intro y hy
        obtain ⟨yu,yj⟩ := Finset.mem_inter.mp hy
        obtain ⟨yi,yn⟩ := Finset.mem_sdiff.mp yu
        exact yn ((only y yi yj) ▸ xq)
      have sz := Finset.card_le_card single
      simp at sz
      simp [f,none]; omega
    · have empty := Finset.not_nonempty_iff_eq_empty.mp hn
      simp only [empty,Finset.card_empty,Nat.mul_zero,Nat.add_zero]
      apply room
      have dis : Disjoint (u ∩ B j) (v ∩ B j) :=
        uv.mono (Finset.inter_subset_left) (Finset.inter_subset_left)
      have sub : (u ∩ B j) ∪ (v ∩ B j) ⊆ B j :=
        Finset.union_subset Finset.inter_subset_right Finset.inter_subset_right
      have sz := Finset.card_le_card sub
      simpa [Finset.card_union_of_disjoint dis,h.1] using sz
  have cap := Finset.sum_le_sum row
  rw [Finset.sum_add_distrib,← Finset.mul_sum,low_seats B i q qi sq] at cap
  have us : u.card = 11-q.card := by simp [u,Finset.card_sdiff_of_subset qi,h.1]
  have vs : v.card = 50 := by simp [v,Finset.card_sdiff_of_subset,h.1]
  rw [us,vs] at need
  simp at cap
  change q.card ≤ 5
  omega

end Cover61
