import Cover61.CompleteCatalogue
import Cover61.Keep9_0
import Cover61.Keep10_0
import Cover61.Keep11_0
import Cover61.Keep12_1
import Cover61.Keep12_2
import Cover61.Keep12_3

namespace Cover61
open Remainder

/-- Every possible covering must occur in one of the 45 remaining low-point
tables after the 169 elementary row obstructions and the affine obstruction. -/
theorem cover_remaining (B : Family 38) (h : IsCover B) :
    ((lows B).card=9 ∧ ∃ j ∈ live9_0,Weighted.Realizes B (Nine.candidates j)) ∨
    ((lows B).card=10 ∧ ∃ j ∈ live10_0,Weighted.Realizes B (Layers.rows10_0 j)) ∨
    ((lows B).card=11 ∧ ∃ j ∈ live11_0,Weighted.Realizes B (Layers.rows11_0 j)) ∨
    ((lows B).card=12 ∧ ((∃ j ∈ live12_1,Weighted.Realizes B (Layers.rows12_1 j)) ∨
      (∃ j ∈ live12_2,Weighted.Realizes B (Layers.rows12_2 j)) ∨
      (∃ j ∈ live12_3,Weighted.Realizes B (Layers.rows12_3 j)))) := by
  rcases cover_catalogue B h with ⟨a,j,hj⟩|⟨a,j,hj⟩|⟨a,j,hj⟩|⟨a,rest⟩
  · exact Or.inl ⟨a,j,keep9_0 B h a j hj,hj⟩
  · exact Or.inr (Or.inl ⟨a,j,keep10_0 B h j hj,hj⟩)
  · exact Or.inr (Or.inr (Or.inl ⟨a,j,keep11_0 B h j hj,hj⟩))
  · refine Or.inr (Or.inr (Or.inr ⟨a,?_⟩))
    rcases rest with ⟨j,hj⟩|⟨j,hj⟩|⟨j,hj⟩
    · exact Or.inl ⟨j,keep12_1 B h j hj,hj⟩
    · exact Or.inr (Or.inl ⟨j,keep12_2 B h j hj,hj⟩)
    · exact Or.inr (Or.inr ⟨j,keep12_3 B h j hj,hj⟩)

theorem remaining_count :
    Remainder.live9_0.card+Remainder.live10_0.card+Remainder.live11_0.card+
    Remainder.live12_1.card+Remainder.live12_2.card+Remainder.live12_3.card=45 := by decide

end Cover61
