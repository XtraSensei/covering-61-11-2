import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext72 : ∀ t, GoodStep 72 t := by decide +kernel

theorem ext73 : ∀ t, GoodStep 73 t := by decide +kernel

theorem ext74 : ∀ t, GoodStep 74 t := by decide +kernel

theorem ext75 : ∀ t, GoodStep 75 t := by decide +kernel

theorem ext76 : ∀ t, GoodStep 76 t := by decide +kernel

theorem ext77 : ∀ t, GoodStep 77 t := by decide +kernel

theorem ext78 : ∀ t, GoodStep 78 t := by decide +kernel

theorem ext79 : ∀ t, GoodStep 79 t := by decide +kernel

theorem ext80 : ∀ t, GoodStep 80 t := by decide +kernel

theorem ext81 : ∀ t, GoodStep 81 t := by decide +kernel

theorem ext82 : ∀ t, GoodStep 82 t := by decide +kernel

theorem ext83 : ∀ t, GoodStep 83 t := by decide +kernel

end Cover61.Nine
