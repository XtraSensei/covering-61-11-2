import Cover61.DegreeLabels
import Cover61.FourCase0
import Cover61.FourCase1
import Cover61.FourCase2
import Cover61.FourCase3
import Cover61.FourCase4
import Cover61.FourRows

namespace Cover61.LocalRows

private abbrev Profile (f : Fin 7 → Nat) (a b c d : Nat) :=
  multiplicity f 0=a ∧ multiplicity f 1=b ∧ multiplicity f 2=c ∧ multiplicity f 3=d

private theorem same_profile {f g : Fin 7 → Nat} {a b c d : Nat}
    (low : (∑ i,f i) ≤ 3) (small : (∑ i,g i) ≤ 3)
    (hf : Profile f a b c d) (hg : Profile g a b c d) : ∀ k, multiplicity f k=multiplicity g k := by
  obtain ⟨f0,f1,f2,f3⟩ := hf
  obtain ⟨g0,g1,g2,g3⟩ := hg
  intro k
  by_cases h : 3<k
  · rw [(small_degrees _ low).2.2 k h,(small_degrees _ small).2.2 k h]
  · have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 := by omega
    rcases cases with rfl|rfl|rfl|rfl <;> omega

/-- A four-low-point block with at least five outside low points spends at least two units. -/
theorem four_cost_two (B : Family 38) (h : IsCover B) (i : Photo) (four : (marked B i).card=4)
    (width : ∀ j,(marked B j).card≤4) : 2 ≤ excess B (companions B i) := by
  by_contra! low
  have pos := four_needs_excess B h i four width
  let lab := companionLabels B h i four
  let f (x : Fin 7) := degree B (lab x).val-7
  have s : (∑ x,f x)=1 := by have eq := sum_label_degree B i lab; change (∑ x,f x)=_ at eq; omega
  obtain ⟨num,mass,_⟩ := small_degrees f (by omega)
  have prof : Profile f 6 1 0 0 := by unfold Profile; omega
  have same := same_profile (g := FourCase0.extra) (by omega : (∑ x,f x)≤3) (by decide +kernel) prof (by decide +kernel)
  have minL : 9 ≤ (lows B).card := nine_six_people B h
  obtain ⟨v⟩ := view_of_degrees B h i four width 5 (by omega) _ lab same
  exact FourCase0.excluded v

theorem four_cost_three (B : Family 38) (h : IsCover B) (i : Photo) (four : (marked B i).card=4)
    (width : ∀ j,(marked B j).card≤4) (many : 11≤(lows B).card) : 3 ≤ excess B (companions B i) := by
  by_contra! low
  have two := four_cost_two B h i four width
  let lab := companionLabels B h i four
  let f (x : Fin 7) := degree B (lab x).val-7
  have s : (∑ x,f x)=2 := by have eq := sum_label_degree B i lab; change (∑ x,f x)=_ at eq; omega
  obtain ⟨num,mass,_⟩ := small_degrees f (by omega)
  by_cases one : multiplicity f 2=1
  · have prof : Profile f 6 0 1 0 := by unfold Profile; omega
    have same := same_profile (g := FourCase1.extra) (by omega : (∑ x,f x)≤3) (by decide +kernel) prof (by decide +kernel)
    obtain ⟨v⟩ := view_of_degrees B h i four width 7 many _ lab same
    exact FourCase1.excluded v
  · have prof : Profile f 5 2 0 0 := by unfold Profile; omega
    have same := same_profile (g := FourCase2.extra) (by omega : (∑ x,f x)≤3) (by decide +kernel) prof (by decide +kernel)
    obtain ⟨v⟩ := view_of_degrees B h i four width 7 many _ lab same
    exact FourCase2.excluded v

theorem four_cost_spread (B : Family 38) (h : IsCover B) (i : Photo) (four : (marked B i).card=4)
    (width : ∀ j,(marked B j).card≤4) (many : 12≤(lows B).card)
    (cost : excess B (companions B i)=3) (lab : Fin 7 ≃ ↥(companions B i)) :
    multiplicity (fun x => degree B (lab x).val-7) 1=3 := by
  let f (x : Fin 7) := degree B (lab x).val-7
  have s : (∑ x,f x)=3 := (sum_label_degree B i lab).trans cost
  obtain ⟨num,mass,_⟩ := small_degrees f (by omega)
  by_contra! bad
  change multiplicity f 1 ≠ 3 at bad
  by_cases one : multiplicity f 3=1
  · have prof : Profile f 6 0 0 1 := by unfold Profile; omega
    have same := same_profile (g := FourCase3.extra) (by omega : (∑ x,f x)≤3) (by decide +kernel) prof (by decide +kernel)
    obtain ⟨v⟩ := view_of_degrees B h i four width 8 many _ lab same
    exact FourCase3.excluded v
  · have prof : Profile f 5 1 1 0 := by unfold Profile; omega
    have same := same_profile (g := FourCase4.extra) (by omega : (∑ x,f x)≤3) (by decide +kernel) prof (by decide +kernel)
    obtain ⟨v⟩ := view_of_degrees B h i four width 8 many _ lab same
    exact FourCase4.excluded v

theorem small_width_three (B : Family 38) (h : IsCover B) (small : (lows B).card≤11) :
    ∀ i,(marked B i).card≤3 := by
  have width := no_five_of_le_fourteen B h (by omega)
  intro i
  by_contra! wide
  have four : (marked B i).card=4 := by have := width i; omega
  have le := local_excess_le B h i
  have lb := four_cost_two B h i four width
  have more := four_cost_three B h i four width (by omega)
  omega

end Cover61.LocalRows
