import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end28 : EndOK 28 := by decide +kernel

theorem end29 : EndOK 29 := by decide +kernel

theorem end30 : EndOK 30 := by decide +kernel

theorem end31 : EndOK 31 := by decide +kernel

theorem end32 : EndOK 32 := by decide +kernel

theorem end33 : EndOK 33 := by decide +kernel

theorem end34 : EndOK 34 := by decide +kernel

theorem end35 : EndOK 35 := by decide +kernel

theorem end36 : EndOK 36 := by decide +kernel

theorem end37 : EndOK 37 := by decide +kernel

theorem end38 : EndOK 38 := by decide +kernel

theorem end39 : EndOK 39 := by decide +kernel

theorem end40 : EndOK 40 := by decide +kernel

theorem end41 : EndOK 41 := by decide +kernel

theorem reg10 : Regular (candidates 10) := by decide +kernel

theorem reg11 : Regular (candidates 11) := by decide +kernel

theorem reg12 : Regular (candidates 12) := by decide +kernel

theorem reg13 : Regular (candidates 13) := by decide +kernel

theorem reg14 : Regular (candidates 14) := by decide +kernel

end Cover61.Nine
