import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced10_1_120 : Balanced (rows10_1 120) := by decide +kernel

theorem balanced10_1_121 : Balanced (rows10_1 121) := by decide +kernel

theorem balanced10_1_122 : Balanced (rows10_1 122) := by decide +kernel

theorem balanced10_1_123 : Balanced (rows10_1 123) := by decide +kernel

theorem balanced10_1_124 : Balanced (rows10_1 124) := by decide +kernel

theorem balanced10_1_125 : Balanced (rows10_1 125) := by decide +kernel

theorem balanced10_1_126 : Balanced (rows10_1 126) := by decide +kernel

theorem balanced10_1_127 : Balanced (rows10_1 127) := by decide +kernel

theorem balanced10_1_128 : Balanced (rows10_1 128) := by decide +kernel

theorem balanced10_1_129 : Balanced (rows10_1 129) := by decide +kernel

theorem balanced10_1_130 : Balanced (rows10_1 130) := by decide +kernel

theorem balanced10_1_131 : Balanced (rows10_1 131) := by decide +kernel

end Cover61.Layers
