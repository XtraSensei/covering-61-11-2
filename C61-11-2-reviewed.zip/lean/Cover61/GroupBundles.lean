import Cover61.NormalizeGrid
import Cover61.ThreeResidual

namespace Cover61.LocalRows
open Grid

variable (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)

include h five in
theorem groupOf_eq {j : Photo} (jg : j ∈ groups B i) {x : Point} (hx : x ∈ marked B j) : groupOf B i x=j := by
  obtain ⟨low,xj⟩ := Finset.mem_inter.mp hx
  have mem : j ∈ appearances B (groups B i) x := Finset.mem_filter.mpr ⟨jg,xj⟩
  rw [groupOf_spec B h i five x low,Finset.mem_singleton] at mem
  exact mem.symm

theorem line_sub (x : Point) : line B i x ⊆ cells B i := Finset.filter_subset ..

include h five

def groupBundle (j : Photo) (jg : j ∈ groups B i) : Grid.Bundle (cells B i) where
  lines := (marked B j).image (line B i)
  sub L hL := by obtain ⟨x,_,rfl⟩ := Finset.mem_image.mp hL;exact line_sub B i x
  size L hL := by
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hL
    exact low_line_count B h i five x (Finset.mem_inter.mp hx).1
  separate L hL M hM ne := by
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hL
    obtain ⟨y,hy,rfl⟩ := Finset.mem_image.mp hM
    exact same_group_disjoint B h i five x y (Finset.mem_inter.mp hx).1 (Finset.mem_inter.mp hy).1
      (fun e => ne (congrArg _ e)) ((groupOf_eq B h i five jg hx).trans (groupOf_eq B h i five jg hy).symm)

theorem bundle_count (j : Photo) (jg : j ∈ groups B i) :
    (groupBundle B h i five j jg).lines.card=(marked B j).card := by
  apply Finset.card_image_of_injOn
  intro x hx y hy eq
  by_contra ne
  have apart := same_group_disjoint B h i five x y (Finset.mem_inter.mp hx).1 (Finset.mem_inter.mp hy).1 ne
    ((groupOf_eq B h i five jg hx).trans (groupOf_eq B h i five jg hy).symm)
  have sz := low_line_count B h i five y (Finset.mem_inter.mp hy).1
  rw [eq,disjoint_self] at apart
  simp [apart] at sz

theorem group_cross (j k : Photo) (jg : j ∈ groups B i) (kg : k ∈ groups B i) (ne : j≠k) :
    Cross (groupBundle B h i five j jg).lines (groupBundle B h i five k kg).lines := by
  intro L hl M hm
  obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hl
  obtain ⟨y,hy,rfl⟩ := Finset.mem_image.mp hm
  apply other_group_cross B h i five x y (Finset.mem_inter.mp hx).1 (Finset.mem_inter.mp hy).1
  rwa [groupOf_eq B h i five jg hx,groupOf_eq B h i five kg hy]

theorem choose_axes (three : (groups B i).card=3) (a : (lows B).card=15) :
    ∀ j ∈ groups B i,(marked B j).card=5 := by
  intro j jg
  have cap := Finset.sum_le_sum (s := (groups B i).erase j) (fun t _ => marked_width_five B h t)
  have sum := Finset.sum_erase_add (groups B i) (fun t => (marked B t).card) jg
  rw [group_sizes_sum B h i five,a] at sum
  simp [Finset.card_erase_of_mem jg,three] at cap
  have := marked_width_five B h j
  omega

theorem choose_four_axes (four : (groups B i).card=4) (a : 17≤(lows B).card) :
    ∃ k ∈ groups B i, 2≤(marked B k).card ∧ ∀ j ∈ (groups B i).erase k,4≤(marked B j).card := by
  let G := groups B i
  let s (j : Photo) := (marked B j).card
  have all : ∑ j ∈ G,s j=(lows B).card := group_sizes_sum B h i five
  obtain ⟨k,hk,small⟩ := Finset.exists_min_image G s (Finset.card_pos.mp (by change 0<(groups B i).card;omega))
  have cap (T : Finset Photo) : ∑ j ∈ T,s j≤T.card*5 := by simpa using Finset.sum_le_sum (s := T) (fun j _ => marked_width_five B h j)
  have hsum := Finset.sum_erase_add G s hk
  have size : (G.erase k).card=3 := by rw [Finset.card_erase_of_mem hk,four]
  have pc := cap (G.erase k)
  rw [all] at hsum;rw [size] at pc
  refine ⟨k,hk,by change 2≤s k;omega,?_⟩
  intro j hj
  have sj := small j (Finset.mem_erase.mp hj).2
  have rem := Finset.sum_erase_add (G.erase k) s hj
  have excess := cap ((G.erase k).erase j)
  rw [Finset.card_erase_of_mem hj,size] at excess
  change 4≤s j
  omega

end Cover61.LocalRows
