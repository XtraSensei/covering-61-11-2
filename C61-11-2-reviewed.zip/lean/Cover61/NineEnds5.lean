import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end70 : EndOK 70 := by decide +kernel

theorem end71 : EndOK 71 := by decide +kernel

theorem end72 : EndOK 72 := by decide +kernel

theorem end73 : EndOK 73 := by decide +kernel

theorem end74 : EndOK 74 := by decide +kernel

theorem end75 : EndOK 75 := by decide +kernel

theorem end76 : EndOK 76 := by decide +kernel

theorem end77 : EndOK 77 := by decide +kernel

theorem end78 : EndOK 78 := by decide +kernel

theorem end79 : EndOK 79 := by decide +kernel

theorem end80 : EndOK 80 := by decide +kernel

theorem end81 : EndOK 81 := by decide +kernel

theorem end82 : EndOK 82 := by decide +kernel

theorem end83 : EndOK 83 := by decide +kernel

theorem reg25 : Regular (candidates 25) := by decide +kernel

theorem reg26 : Regular (candidates 26) := by decide +kernel

theorem reg27 : Regular (candidates 27) := by decide +kernel

theorem reg28 : Regular (candidates 28) := by decide +kernel

theorem reg29 : Regular (candidates 29) := by decide +kernel

end Cover61.Nine
