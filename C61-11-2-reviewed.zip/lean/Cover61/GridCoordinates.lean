import Cover61.ParallelFive

namespace Cover61.Grid

abbrev Five := Fin 5
variable {α : Type} [DecidableEq α] {U : Finset α}

structure Axis (U : Finset α) where
  row : Five → Finset α
  sub : ∀ i, row i ⊆ U
  size : ∀ i,(row i).card=5
  cover : ∀ x ∈ U, ∃! i, x ∈ row i

noncomputable def Bundle.axis (P : Bundle U) (twentyFive : U.card=25) (five : P.lines.card=5) : Axis U := by
  classical
  let e : Five ≃ ↥P.lines := (Fintype.equivFinOfCardEq (by simpa using five)).symm
  have all : P.occupied=U := Finset.eq_of_subset_of_card_le P.occupied_sub (by rw [P.occupied_size,five,twentyFive])
  refine ⟨fun i => (e i).val,fun i => P.sub _ (e i).property,fun i => P.size _ (e i).property,?_⟩
  intro x hx
  have occ : x ∈ P.occupied := by rw [all];exact hx
  obtain ⟨l,hl,mem⟩ := Finset.mem_biUnion.mp occ
  let k := e.symm ⟨l,hl⟩
  have ek : (e k).val=l := congrArg Subtype.val (e.apply_symm_apply _)
  have xk : x ∈ (e k).val := by rw [ek];exact mem
  refine ⟨k,xk,?_⟩
  intro j hj
  by_contra ne
  have distinct : (e j).val≠(e k).val := fun eq => ne (e.injective (Subtype.ext eq))
  exact Finset.disjoint_left.mp (P.separate _ (e j).property _ (e k).property distinct) hj xk

theorem Bundle.axis_member (P : Bundle U) (twentyFive : U.card=25) (five : P.lines.card=5) (j : Five) :
    (P.axis twentyFive five).row j ∈ P.lines := by
  unfold Bundle.axis
  exact Subtype.property _

noncomputable def Axis.coord (X : Axis U) (x : α) : Five :=
  if h : x ∈ U then Classical.choose (X.cover x h) else 0

theorem Axis.coord_mem (X : Axis U) (x : α) (h : x ∈ U) : x ∈ X.row (X.coord x) := by
  simpa [Axis.coord,h] using (Classical.choose_spec (X.cover x h)).1

theorem Axis.coord_eq (X : Axis U) {x : α} {i : Five} (mem : x ∈ X.row i) : X.coord x=i := by
  let hx := X.sub i mem
  unfold Axis.coord
  rw [dif_pos hx]
  exact ((Classical.choose_spec (X.cover x hx)).2 i mem).symm

structure Chart (U : Finset α) where
  R : Axis U
  C : Axis U
  S : Axis U
  rc : ∀ i j,(R.row i ∩ C.row j).card=1
  rs : ∀ i j,(R.row i ∩ S.row j).card=1
  cs : ∀ i j,(C.row i ∩ S.row j).card=1

namespace Chart
variable (D : Chart U)

noncomputable def cell (i j : Five) : α := Classical.choose (Finset.card_eq_one.mp (D.rc i j))

theorem cell_spec (i j : Five) : D.R.row i ∩ D.C.row j={D.cell i j} := Classical.choose_spec (Finset.card_eq_one.mp (D.rc i j))

theorem cell_mem (i j : Five) : D.cell i j ∈ D.R.row i ∧ D.cell i j ∈ D.C.row j :=
  Finset.mem_inter.mp (D.cell_spec i j ▸ Finset.mem_singleton_self _)

theorem cell_of_mem {x : α} {i j : Five} (r : x ∈ D.R.row i) (c : x ∈ D.C.row j) : x=D.cell i j :=
  Finset.mem_singleton.mp (D.cell_spec i j ▸ (show x ∈ D.R.row i ∩ D.C.row j from Finset.mem_inter.mpr ⟨r,c⟩))

noncomputable def symbol (i j : Five) := D.S.coord (D.cell i j)

private theorem symbol_mem (i j : Five) : D.cell i j ∈ D.S.row (D.symbol i j) :=
  D.S.coord_mem _ (D.R.sub _ (D.cell_mem i j).1)

theorem row_inj (i : Five) : Function.Injective (D.symbol i) := by
  intro j k eq
  have both : D.cell i j=D.cell i k := Finset.card_le_one.mp (D.rs i (D.symbol i j)).le
    _ (Finset.mem_inter.mpr ⟨(D.cell_mem i j).1,D.symbol_mem i j⟩)
    _ (Finset.mem_inter.mpr ⟨(D.cell_mem i k).1,eq ▸ D.symbol_mem i k⟩)
  exact (D.C.coord_eq (D.cell_mem i j).2).symm.trans (both ▸ D.C.coord_eq (D.cell_mem i k).2)

theorem col_inj (j : Five) : Function.Injective (fun i => D.symbol i j) := by
  intro i k eq
  change D.symbol i j=D.symbol k j at eq
  have both : D.cell i j=D.cell k j := Finset.card_le_one.mp (D.cs j (D.symbol i j)).le
    _ (Finset.mem_inter.mpr ⟨(D.cell_mem i j).2,D.symbol_mem i j⟩)
    _ (Finset.mem_inter.mpr ⟨(D.cell_mem k j).2,eq ▸ D.symbol_mem k j⟩)
  exact (D.R.coord_eq (D.cell_mem i j).1).symm.trans (both ▸ D.R.coord_eq (D.cell_mem k j).1)

end Chart
end Cover61.Grid
