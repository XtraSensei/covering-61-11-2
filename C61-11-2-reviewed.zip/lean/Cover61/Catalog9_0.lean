import Cover61.Partitions

namespace Cover61.Catalog

open Partitions

set_option maxRecDepth 50000

set_option maxHeartbeats 3000000

def s9_00Head : Finset (Fin 9) := {0,7}

def s9_00Rest : List (Finset (Fin 9)) := [
  {0,1,2}, {0,3,4}, {1,3,5}, {2,6,7}, {4,6,8}, {5,7,8}, {0,5}, {0,6}, {0,8}, {1,4}, {1,6}, {1,7}, {1,8}, {2,3}, {2,4}, {2,5}, {2,8}, {3,6}, {3,7}, {3,8}, {4,5}, {4,7}, {5,6}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s9_00_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s9_00Head s9_00Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

def s9_02Head : Finset (Fin 9) := {1,3,5}

def s9_02Rest : List (Finset (Fin 9)) := [
  {0,1,2}, {0,3,4}, {0,5,6}, {0,7,8}, {1,4,7}, {2,6,8}, {1,6}, {1,8}, {2,3}, {2,4}, {2,5}, {2,7}, {3,6}, {3,7}, {3,8}, {4,5}, {4,6}, {4,8}, {5,7}, {5,8}, {6,7}, {0}, {0}, {1}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅]

theorem s9_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B s9_02Head s9_02Rest :=
  exclude _ _ (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
