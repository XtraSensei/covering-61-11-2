import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced11_1_108 : Balanced (rows11_1 108) := by decide +kernel

theorem balanced11_1_109 : Balanced (rows11_1 109) := by decide +kernel

theorem balanced11_1_110 : Balanced (rows11_1 110) := by decide +kernel

theorem balanced11_1_111 : Balanced (rows11_1 111) := by decide +kernel

theorem balanced11_1_112 : Balanced (rows11_1 112) := by decide +kernel

theorem balanced11_1_113 : Balanced (rows11_1 113) := by decide +kernel

theorem balanced11_1_114 : Balanced (rows11_1 114) := by decide +kernel

theorem balanced11_1_115 : Balanced (rows11_1 115) := by decide +kernel

theorem balanced11_1_116 : Balanced (rows11_1 116) := by decide +kernel

theorem balanced11_1_117 : Balanced (rows11_1 117) := by decide +kernel

end Cover61.Layers
