import Cover61.FourHistogram
import Cover61.LinearBox

namespace Cover61.LocalRows.FourView

open LinearBox
variable {R n g k : Nat} {e : Fin 7→Nat}

/-- Tabulated group incidences and tariffs come with combinatorial proofs. -/
structure Table (R n g k : Nat) (e : Fin 7→Nat) where
  colors : Colors n
  group : Fin g → SevenSet
  units : Fin g → Fin n → Nat
  counts : ∀ j C, units j (colors.cls C)=(group j ∩ C).card
  price : Fin k → Fin n → Nat
  target : Fin k → Nat
  prices : ∀ (v : FourView R e) j, v.ValidPrice (fun C => price j (colors.cls C)) (target j)

inductive Rule (n g k : Nat) where
  | visits (j : Fin g)
  | budget (j : Fin g)
  | chosen
  | size (s : Nat)
  | endpoint (a : Fin n) (right useOpposite : Bool)
  | mass (s : Nat)
  | price (j : Fin k)

variable (T : Table R n g k e)

def rule (h : Nat→Nat) : Rule n g k → Entry n
  | .visits j => ⟨true,sub (constant (∑ x ∈ T.group j, (6+e x) : Nat)) (first (T.units j))⟩
  | .budget j => ⟨false,sub (constant (∑ x ∈ T.group j, (10*(1+e x)) : Nat))
      (first (fun a => T.units j a*(T.colors.size a-1)))⟩
  | .chosen => ⟨true,sub (constant R) (second fun _ => 1)⟩
  | .size s => ⟨true,sub (constant (h s)) (first fun a => if T.colors.size a=s then 1 else 0)⟩
  | .endpoint a right opposite =>
    let b := T.colors.other a
    let j := if right then b else a
    let mult := if opposite then h (T.colors.size (if right then a else b)) else 4
    ⟨false,sub (first (unit j mult)) (second (unit a 1))⟩
  | .mass s => ⟨false,sub (constant (cap h s)) (second fun a => if T.colors.size a=s then 1 else 0)⟩
  | .price j => ⟨false,sub (first fun a => (11-T.colors.size a)*T.price j a)
      (add (constant ((50-R)*T.target j : Nat)) (second fun a => T.price j a+T.price j (T.colors.other a)))⟩

theorem rule_valid (v : FourView R e) (r : Rule n g k) :
    let a := rule T v.hist r
    if a.equality then val (v.rowCount T.colors) (v.lowCount T.colors) a.expr=0
      else 0≤val (v.rowCount T.colors) (v.lowCount T.colors) a.expr := by
  cases r with
  | visits j =>
    have old := visits_group v T.colors (T.group j) (T.units j) (T.counts j)
    simp only [rule,val_sub,val_const,val_first,if_true]
    rw [old]; simp
  | budget j =>
    have old := budget_group v T.colors (T.group j) (T.units j) (T.counts j)
    simp only [rule,val_sub,val_const,val_first,Bool.false_eq_true,if_false,sub_nonneg]
    exact_mod_cast old
  | chosen =>
    have old := low_total v T.colors
    simp [rule,old]
  | size s =>
    have old := hist_eq v T.colors s
    simp only [rule,val_sub,val_const,val_first,if_true]
    rw [old]; simp
  | mass s =>
    have old := size_slots v T.colors s
    simp only [rule,val_sub,val_const,val_second,Bool.false_eq_true,if_false,sub_nonneg]
    exact_mod_cast old
  | endpoint a right opp =>
    have bounds := low_slots v T.colors a
    obtain ⟨prod,left,rightSide⟩ := (show _ ∧ _ ∧ _ by simpa only [le_min_iff] using bounds)
    have ha := row_le_hist v T.colors a
    have hb := row_le_hist v T.colors (T.colors.other a)
    cases right <;> cases opp <;> simp [rule,sub_nonneg]
    · rw [mul_comm]; exact_mod_cast left
    · exact_mod_cast prod.trans (Nat.mul_le_mul_left _ hb)
    · rw [mul_comm]; exact_mod_cast rightSide
    · rw [mul_comm]
      exact_mod_cast prod.trans (Nat.mul_le_mul_right (v.rowCount T.colors (T.colors.other a)) ha)
  | price j =>
    have old := grouped_price v T.colors (T.price j) (T.target j) (T.prices v j)
    simp only [rule,val_sub,val_const,val_add,val_first,val_second,Bool.false_eq_true,if_false,sub_nonneg]
    exact_mod_cast old

def upperLow (colors : Colors n) (h : Nat→Nat) (a : Fin n) :=
  if colors.size a≤3 then cap h (colors.size a) else 0

theorem low_le_upper (v : FourView R e) (colors : Colors n) (a : Fin n) :
    v.lowCount colors a ≤ upperLow colors v.hist a := by
  unfold upperLow
  split
  next le =>
    have old := size_slots v colors (colors.size a)
    have single := Finset.single_le_sum (s := Finset.univ)
      (f := fun b => v.lowCount colors b*(if colors.size b=colors.size a then 1 else 0))
      (fun b _ => Nat.zero_le _) (Finset.mem_univ a)
    simpa using single.trans old
  next large =>
    apply le_of_eq; apply Finset.card_eq_zero.mpr
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro y hy
    obtain ⟨ys,cls⟩ := Finset.mem_filter.mp hy
    have atMost := (v.endpoints y ys).2.2.1
    change colors.cls (v.C (v.left y))=a at cls
    rw [← colors.card,cls] at atMost
    exact large atMost

def terms (h : Nat→Nat) (doc : List (Int × Rule n g k)) :=
  doc.map (fun t => (t.1,rule T h t.2))

def valid (h : Nat→Nat) (doc : List (Int × Rule n g k)) : Bool :=
  let ts := terms T h doc
  ts.all (fun t => t.2.equality || decide (0≤t.1)) &&
    decide (maxOn (fun a => h (T.colors.size a)) (upperLow T.colors h) (total ts)<0)

theorem rejected (v : FourView R e) (doc : List (Int × Rule n g k)) (ok : valid T v.hist doc=true) : False := by
  obtain ⟨sign,gap⟩ := Bool.and_eq_true_iff.mp ok
  apply sound (v.rowCount T.colors) (v.lowCount T.colors) _ _ (row_le_hist v T.colors) (low_le_upper v T.colors)
    (terms T v.hist doc) _ sign (of_decide_eq_true gap)
  intro t ht
  obtain ⟨p,_,rfl⟩ := List.mem_map.mp ht
  exact rule_valid T v p.2

end Cover61.LocalRows.FourView
