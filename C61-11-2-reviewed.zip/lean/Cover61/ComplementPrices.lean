import Cover61.LocalWeighted

namespace Cover61.LocalRows

theorem complementary_order (B : Family 38) (h : IsCover B) (i : Photo)
    (four : (marked B i).card=4) (y : Point) (yl : y ∈ lows B) (out : y ∉ B i) :
    ∃ j k, j ≠ k ∧ appearances B (clear B i (marked B i)) y={j,k} ∧ amount B i j ≤ 3 ∧
      (companions B i ∩ B k) = companions B i \ (companions B i ∩ B j) := by
  obtain ⟨j,k,ne,both,op⟩ := four_forces_complements B h i (marked B i) (marked_sub B i)
    (marked_six B i) four y out (Finset.mem_filter.mp yl).2
  let H := companions B i
  have shape : H ∩ B k = H \ (H ∩ B j) := by
    ext z; by_cases hz : z ∈ H
    · simpa [hz] using op z (companion_eq B i ▸ hz)
    · simp [hz]
  by_cases le : amount B i j ≤ 3
  · exact ⟨j,k,ne,both,le,shape⟩
  · have size := companion_card B h i
    have add : amount B i k + amount B i j = H.card := by
      unfold amount
      change (H ∩ B k).card + (H ∩ B j).card = _
      rw [shape,Finset.card_sdiff_of_subset Finset.inter_subset_left,
        Nat.sub_add_cancel (Finset.card_le_card Finset.inter_subset_left)]
    change H.card + _ = 11 at size
    refine ⟨k,j,ne.symm,by simpa [Finset.pair_comm] using both,by omega,?_⟩
    change H ∩ B j = H \ (H ∩ B k)
    rw [shape]; ext z; simp

/-- Each chosen low point occupies a distinct pair of blocks. No block can
contribute more than four such low points on either side. -/
theorem pair_capacity (B : Family 38) (h : IsCover B) (width : ∀ j, (marked B j).card ≤ 4)
    (O : Finset Point) (L R : Finset Photo) (u v : Point → Photo)
    (low : O ⊆ lows B) (choice : ∀ x ∈ O, u x ∈ L ∧ v x ∈ R ∧ u x ≠ v x ∧ x ∈ B (u x) ∧ x ∈ B (v x)) :
    O.card ≤ min (L.card*R.card) (min (4*L.card) (4*R.card)) := by
  let p (x : Point) := (u x,v x)
  have inside : O.image p ⊆ L ×ˢ R := by
    rintro _ hp
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hp
    exact Finset.mem_product.mpr ⟨(choice x hx).1,(choice x hx).2.1⟩
  have inj : Set.InjOn p (O : Set Point) := by
    intro x hx y hy eq
    obtain ⟨_,_,ne,xu,xv⟩ := choice x hx
    obtain ⟨_,_,_,yu,yv⟩ := choice y hy
    have eu : u x=u y := congrArg Prod.fst eq
    have ev : v x=v y := congrArg Prod.snd eq
    exact intersection_single B h x y (Finset.mem_filter.mp (low hx)).2 _ _ ne xu xv (eu ▸ yu) (ev ▸ yv)
  have product := Finset.card_le_card inside
  rw [Finset.card_image_of_injOn inj,Finset.card_product] at product
  have side (J : Finset Photo) (f : Point → Photo) (mem : ∀ x ∈ O, f x ∈ J ∧ x ∈ B (f x)) :
      O.card ≤ 4*J.card := by
    have sub : O ⊆ J.biUnion (marked B) := fun x hx => Finset.mem_biUnion.mpr
      ⟨f x,(mem x hx).1,Finset.mem_inter.mpr ⟨low hx,(mem x hx).2⟩⟩
    have le := (Finset.card_le_card sub).trans Finset.card_biUnion_le
    exact le.trans (by simpa [Nat.mul_comm] using Finset.sum_le_sum (s := J) (fun j _ => width j))
  exact le_min product (le_min (side L u (fun x hx => ⟨(choice x hx).1,(choice x hx).2.2.2.1⟩))
    (side R v (fun x hx => ⟨(choice x hx).2.1,(choice x hx).2.2.2.2⟩)))

theorem remaining_weighted_capacity (B : Family 38) (h : IsCover B) (i : Photo)
    (S : Finset Point) (outside : ∀ y ∈ S, y ∉ B i) (u v : Point → Photo)
    (pair : ∀ y ∈ S, u y ≠ v y ∧ appearances B (clear B i (marked B i)) y={u y,v y})
    (w : Point → Nat) (p : Photo → Nat) (divisor target : Nat)
    (rounds : ∀ j ∈ clear B i (marked B i), (∑ z ∈ companions B i ∩ B j, w z) ≤ divisor*p j)
    (need : divisor*(target-1) < ∑ z ∈ companions B i, w z) :
    (50-S.card)*target + (∑ y ∈ S, (p (u y)+p (v y))) ≤
      ∑ j ∈ clear B i (marked B i), (11-amount B i j)*p j := by
  let O := (Finset.univ : Finset Point) \ B i
  let J := clear B i (marked B i)
  let H := companions B i
  let cost (y : Point) := ∑ j ∈ appearances B J y, p j
  have sub : S ⊆ O := fun y hy => Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,outside y hy⟩
  have os : O.card=50 := by simp [O,Finset.card_sdiff_of_subset,h.1]
  have pay := weighted_companion_cut B h i (O \ S)
    (fun _ hy => (Finset.mem_sdiff.mp (Finset.mem_sdiff.mp hy).1).2) w p divisor target rounds need
  rw [← weighted_visits,Finset.card_sdiff_of_subset sub,os] at pay
  have exactCost (y : Point) (hy : y ∈ S) : cost y=p (u y)+p (v y) := by
    dsimp [cost,J]
    rw [(pair y hy).2]
    simp [(pair y hy).1]
  have all : (50-S.card)*target + (∑ y ∈ S, (p (u y)+p (v y))) ≤ ∑ y ∈ O, cost y := by
    rw [← Finset.sum_congr rfl exactCost,← Finset.sum_sdiff sub]
    exact Nat.add_le_add_right pay _
  change _ ≤ ∑ y ∈ O, ∑ j ∈ appearances B J y, p j at all
  rw [weighted_visits] at all
  apply all.trans
  apply Finset.sum_le_sum
  intro j _
  have dis : Disjoint (H ∩ B j) (O ∩ B j) := by
    apply Finset.disjoint_left.mpr
    intro z hz zo
    exact (Finset.mem_sdiff.mp (Finset.mem_inter.mp zo).1).2 (Finset.mem_sdiff.mp (Finset.mem_inter.mp hz).1).1
  have bound := Finset.card_le_card (show (H ∩ B j) ∪ (O ∩ B j) ⊆ B j from
    Finset.union_subset Finset.inter_subset_right Finset.inter_subset_right)
  rw [Finset.card_union_of_disjoint dis,h.1] at bound
  change amount B i j + (O ∩ B j).card ≤ 11 at bound
  exact Nat.mul_le_mul_right _ (by omega)

end Cover61.LocalRows
