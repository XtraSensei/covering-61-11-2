import Cover61.FourColors

namespace Cover61.LocalRows

namespace Histogram

/-- Counts in descending order of block size. -/
def data (h : Nat → Nat) : Nat → List Nat
  | 0 => [h 0]
  | k+1 => h (k+1) :: data h k

def total (h f : Nat → Nat) : Nat → Nat
  | 0 => h 0 * f 0
  | k+1 => h (k+1) * f (k+1) + total h f k

theorem max_mass (h : Nat→Nat) (k : Nat) : total h id k ≤ k*total h (fun _ => 1) k := by
  induction k with
  | zero => simp [total]
  | succ k ih =>
    simp only [total,id_eq,Nat.mul_one]
    rw [Nat.mul_add (k+1) (h (k+1)) (total h (fun _ => 1) k),
      Nat.mul_comm (h (k+1)) (k+1),Nat.succ_mul k (total h (fun _ => 1) k)]
    omega

def enumerate : Nat → Nat → Nat → Nat → List (List Nat)
  | 0,n,m,c => if m=0 ∧ c=0 then [[n]] else []
  | k+1,n,m,c => if (k+1)*n<m then [] else
    (List.range (n+1)).flatMap (fun t =>
      if t*(k+1)≤m then (enumerate k (n-t) (m-t*(k+1)) (c-t*room (k+1))).map (t :: ·) else [])

theorem complete (h : Nat → Nat) (k c : Nat) (needed : c ≤ total h room k) :
    data h k ∈ enumerate k (total h (fun _ => 1) k) (total h id k) c := by
  induction k generalizing c with
  | zero =>
    have z : c=0 := by simpa [total,room] using needed
    simp [data,enumerate,total,z]
  | succ k ih =>
    rw [enumerate,if_neg (Nat.not_lt.mpr (max_mass h (k+1)))]
    apply List.mem_flatMap.mpr
    refine ⟨h (k+1),List.mem_range.mpr ?_,?_⟩
    · simp only [total,Nat.mul_one]; omega
    · have mass : h (k+1)*(k+1) ≤ total h id (k+1) := by simp [total]
      rw [if_pos mass]
      apply List.mem_map.mpr
      refine ⟨data h k,?_,rfl⟩
      simp only [total,id_eq,Nat.mul_one,Nat.add_sub_cancel_left]
      apply ih
      change c ≤ h (k+1)*room (k+1)+total h room k at needed
      omega

theorem total_seven (h f : Nat → Nat) : total h f 7 = ∑ j : Fin 8, h j.val*f j.val := by
  have all : (Finset.univ : Finset (Fin 8))={0,1,2,3,4,5,6,7} := by decide
  rw [all]
  simp [total,add_assoc,add_comm,add_left_comm]

end Histogram

namespace FourView

variable {R : Nat} {e : Fin 7→Nat} (v : FourView R e)

theorem hist_cost (f : Nat→Nat) : Histogram.total v.hist f 7 =∑ j ∈ v.J, f (v.C j).card := by
  let t (j : Photo) : Fin 8 := ⟨(v.C j).card,by
    have := Finset.card_le_univ (v.C j); simpa using Nat.lt_succ_of_le this⟩
  have eq (x : Fin 8) : countBy v.J t x=v.hist x.val := by
    unfold countBy hist
    congr 1
  rw [Histogram.total_seven]
  simpa only [eq] using weighted_count v.J t (fun j => f j.val)

theorem hist_mass : Histogram.total v.hist id 7=42+∑ x,e x := by
  rw [v.hist_cost]
  have row (j : Photo) : (v.C j).card=∑ x : Fin 7, if x ∈ v.C j then 1 else 0 := by simp
  change (∑ j ∈ v.J, (v.C j).card) = _
  rw [Finset.sum_congr rfl (fun j _ => row j),Finset.sum_comm]
  simp [v.people,Finset.sum_add_distrib]

theorem possible_histogram : Histogram.data v.hist 7 ∈ Histogram.enumerate 7 17 (42+∑ x,e x) 350 := by
  have n : Histogram.total v.hist (fun _ => 1) 7=17 := by rw [v.hist_cost]; simp [v.rows]
  have cap : 350 ≤ Histogram.total v.hist room 7 := by rw [v.hist_cost]; exact v.capacity
  simpa only [n,v.hist_mass] using Histogram.complete v.hist 7 350 cap

end FourView
end Cover61.LocalRows
