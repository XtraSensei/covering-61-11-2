import Cover61.LatinFive

namespace Cover61.LatinFive

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

theorem transversal_census :
    (squares.filter (fun s => (transversals s).length==3)).length=50 ∧
    (squares.filter (fun s => (transversals s).length==15)).length=6 := by decide +kernel

end Cover61.LatinFive
