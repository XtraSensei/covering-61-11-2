import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w10_001_01Rows : Rows 10 := fun i =>
  ([{0,1,2}, {0,3}, {1,3}, {2,3}, {4}, {0,4}, {5}, {0,5}, {3,4,5}, {6}, {1,6}, {2,4,6}, {7}, {1,7}, {2,5,7}, {0,6,7}, {8}, {2,8}, {1,4,8}, {5,6,8}, {3,7,8}, {9}, {2,9}, {1,5,9}, {3,6,9}, {4,7,9}, {0,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_001_01Cost : Cost := fun i =>
  ([0, 0, 0, 0, 1, 0, 1, 0, -3, 1, 0, -1, 1, 0, -1, -1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_001_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_001_01Rows :=
  Weighted.exclude _ w10_001_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_001_02Rows : Rows 10 := fun i =>
  ([{0,1,2}, {0,3}, {1,3}, {2,3}, {4}, {0,4}, {5}, {0,5}, {3,4,5}, {6}, {1,6}, {2,5,6}, {7}, {1,7}, {2,4,7}, {3,6,7}, {8}, {2,8}, {1,4,8}, {0,6,8}, {5,7,8}, {9}, {2,9}, {1,5,9}, {4,6,9}, {0,7,9}, {3,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_001_02Cost : Cost := fun i =>
  ([-2, 0, 0, 0, 2, 1, 0, 1, 0, 2, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, -2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_001_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_001_02Rows :=
  Weighted.exclude _ w10_001_02Cost (2) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_001_03Rows : Rows 10 := fun i =>
  ([{0,3}, {1,3}, {2,3}, {4}, {0,4}, {1,2,4}, {5}, {0,5}, {3,4,5}, {6}, {1,6}, {0,2,6}, {7}, {1,7}, {2,5,7}, {3,6,7}, {8}, {0,1,8}, {2,8}, {5,6,8}, {4,7,8}, {9}, {2,9}, {1,5,9}, {4,6,9}, {0,7,9}, {3,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_001_03Cost : Cost := fun i =>
  ([0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_001_03_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_001_03Rows :=
  Weighted.exclude _ w10_001_03Cost (2) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_001_04Rows : Rows 10 := fun i =>
  ([{0,3}, {1,3}, {2,3}, {4}, {0,4}, {1,2,4}, {5}, {0,5}, {3,4,5}, {6}, {1,6}, {0,2,6}, {7}, {1,7}, {2,5,7}, {4,6,7}, {8}, {0,1,8}, {2,8}, {5,6,8}, {3,7,8}, {9}, {2,9}, {1,5,9}, {3,6,9}, {0,7,9}, {4,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_001_04Cost : Cost := fun i =>
  ([0, 0, 0, 1, 0, -1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_001_04_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_001_04Rows :=
  Weighted.exclude _ w10_001_04Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
