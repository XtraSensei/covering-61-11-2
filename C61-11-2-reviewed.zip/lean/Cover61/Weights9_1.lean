import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w9_09Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,5}, {1,7,8}, {2,4,7}, {4,6,8}, {0,7}, {0,8}, {1,4}, {1,6}, {2,3}, {2,5}, {2,6}, {2,8}, {3,6}, {3,7}, {3,8}, {4,5}, {5,7}, {5,8}, {6,7}, {0}, {1}, {4}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_09Cost : Cost := fun i =>
  ([0, 0, 0, -3, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1, -1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_09_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_09Rows :=
  Weighted.exclude _ w9_09Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_10Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,7}, {1,5,8}, {2,4,7}, {3,6,8}, {0,7}, {0,8}, {1,4}, {1,6}, {2,3}, {2,5}, {2,6}, {2,8}, {3,5}, {4,5}, {4,6}, {4,8}, {5,7}, {6,7}, {7,8}, {0}, {1}, {3}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_10Cost : Cost := fun i =>
  ([0, 0, 0, -1, 0, -1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_10_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_10Rows :=
  Weighted.exclude _ w9_10Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_11Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,7}, {1,5,8}, {2,4,7}, {4,6,8}, {0,7}, {0,8}, {1,4}, {1,6}, {2,3}, {2,5}, {2,6}, {2,8}, {3,5}, {3,6}, {3,8}, {4,5}, {5,7}, {6,7}, {7,8}, {0}, {1}, {4}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_11Cost : Cost := fun i =>
  ([0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_11_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_11Rows :=
  Weighted.exclude _ w9_11Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w9_12Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {1,3,7}, {1,5,8}, {2,4,8}, {4,6,7}, {0,7}, {0,8}, {1,4}, {1,6}, {2,3}, {2,5}, {2,6}, {2,7}, {3,5}, {3,6}, {3,8}, {4,5}, {5,7}, {6,8}, {7,8}, {0}, {1}, {4}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def w9_12Cost : Cost := fun i =>
  ([0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w9_12_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w9_12Rows :=
  Weighted.exclude _ w9_12Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
