import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end112 : EndOK 112 := by decide +kernel

theorem end113 : EndOK 113 := by decide +kernel

theorem end114 : EndOK 114 := by decide +kernel

theorem end115 : EndOK 115 := by decide +kernel

theorem end116 : EndOK 116 := by decide +kernel

theorem end117 : EndOK 117 := by decide +kernel

theorem end118 : EndOK 118 := by decide +kernel

theorem end119 : EndOK 119 := by decide +kernel

theorem end120 : EndOK 120 := by decide +kernel

theorem end121 : EndOK 121 := by decide +kernel

theorem end122 : EndOK 122 := by decide +kernel

theorem end123 : EndOK 123 := by decide +kernel

theorem end124 : EndOK 124 := by decide +kernel

theorem end125 : EndOK 125 := by decide +kernel

theorem reg40 : Regular (candidates 40) := by decide +kernel

theorem reg41 : Regular (candidates 41) := by decide +kernel

theorem reg42 : Regular (candidates 42) := by decide +kernel

theorem reg43 : Regular (candidates 43) := by decide +kernel

theorem reg44 : Regular (candidates 44) := by decide +kernel

end Cover61.Nine
