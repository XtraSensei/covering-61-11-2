import Cover61.FourTariffs
import Mathlib.Tactic.FinCases

namespace Cover61.LocalRows.FourCase0
open FourView
set_option maxRecDepth 100000
set_option maxHeartbeats 6000000

def extra (i : Fin 7) : Nat := (#[1,0,0,0,0,0,0] : Array Nat)[i.val]!
private def classify (C : SevenSet) : Fin 14 := (#[0,1,2,3,2,3,4,5,2,3,4,5,4,5,6,7,2,3,4,5,4,5,6,7,4,5,6,7,6,7,8,9,2,3,4,5,4,5,6,7,4,5,6,7,6,7,8,9,4,5,6,7,6,7,8,9,6,7,8,9,8,9,10,11,2,3,4,5,4,5,6,7,4,5,6,7,6,7,8,9,4,5,6,7,6,7,8,9,6,7,8,9,8,9,10,11,4,5,6,7,6,7,8,9,6,7,8,9,8,9,10,11,6,7,8,9,8,9,10,11,8,9,10,11,10,11,12,13] : Array (Fin 14))[(mask C)%128]!
private def widths (i : Fin 14) : Nat := (#[0,1,1,2,2,3,3,4,4,5,5,6,6,7] : Array (Nat))[i.val]!
private def opposite (i : Fin 14) : Fin 14 := (#[13,12,11,10,9,8,7,6,5,4,3,2,1,0] : Array (Fin 14))[i.val]!
private def colors : Colors 14 where
  cls := classify
  size := widths
  other := opposite
  card := by decide +kernel
  complement := by decide +kernel
  otherSize := by decide +kernel

private def groups (i : Fin 2) : SevenSet := (#[{1,2,3,4,5,6},{0}] : Array (SevenSet))[i.val]!
private def units (j : Fin 2) (i : Fin 14) : Nat :=
  ((#[#[0,0,1,1,2,2,3,3,4,4,5,5,6,6],#[0,1,0,1,0,1,0,1,0,1,0,1,0,1]] : Array (Array Nat))[j.val]!)[i.val]!
private theorem units_ok : ∀ j C, units j (classify C)=(groups j ∩ C).card := by decide +kernel

private def words0 : List Nat := [2134,2080,1918,1432,2116,2008,1684,712,2044,1882,1396,1990,1666,694,1774,1288,1612,640,964,478,2110,2002,1678,706,1966,1642,670,1534,562,238,2032,1870,1384,1978,1654,682,1762,1276,1600,628,952,466,1960,1636,664,1528,556,232,1726,1240,1564,592,916,430,1510,538,214,808,322,160]
private def pay0 (i : Fin 14) : Nat := (#[0,60,70,130,140,200,210,270,280,340,350,410,420,480] : Array (Nat))[i.val]!
private theorem costs0 : ∀ C : SevenSet, tariffs 1 words0 C=pay0 (classify C) := by decide +kernel
private theorem need0 : tariffs 1 words0 Finset.univ=480 := by decide +kernel
private theorem valid0 (v : FourView 5 extra) : v.ValidPrice (fun C => pay0 (classify C)) 480 := by
  have a := many_tariffs v 1 words0 (by decide)
  rw [need0,funext costs0] at a
  exact a

private def words1 : List Nat := [2183,2177,2159,2105,1943,1457]
private def pay1 (i : Fin 14) : Nat := (#[0,6,6,6,6,12,12,12,12,18,18,18,18,24] : Array (Nat))[i.val]!
private theorem costs1 : ∀ C : SevenSet, tariffs 4 words1 C=pay1 (classify C) := by decide +kernel
private theorem need1 : tariffs 4 words1 Finset.univ=24 := by decide +kernel
private theorem valid1 (v : FourView 5 extra) : v.ValidPrice (fun C => pay1 (classify C)) 24 := by
  have a := many_tariffs v 4 words1 (by decide)
  rw [need1,funext costs1] at a
  exact a

private def pay (i : Fin 2) : Fin 14 → Nat := (#[pay0,pay1] : Array (Fin 14 → Nat))[i.val]!
private def need (i : Fin 2) : Nat := (#[480,24] : Array (Nat))[i.val]!
private def T : Table 5 14 2 2 extra where
  colors := colors
  group := groups
  units := units
  counts := units_ok
  price := pay
  target := need
  prices := by
    intro v j
    fin_cases j
    · exact valid0 v
    · exact valid1 v

private def document0 : List (Int × Rule 14 2 2) := [(-1,.chosen)]
private def batch0 : List (List Nat) := [[0,0,0,0,13,1,2,1],[0,0,0,0,12,3,1,1],[0,0,0,0,11,5,0,1],[0,0,0,0,13,0,4,0],[0,0,0,0,12,2,3,0],[0,0,0,0,11,4,2,0],[0,0,0,0,10,6,1,0],[0,0,0,0,9,8,0,0]]
private theorem checked0 : batch0.all (fun h => valid T (decodeHist h) document0)=true := by decide +kernel

private def document1 : List (Int × Rule 14 2 2) := [(20,.visits 1),(-20,.size 2),(-60,.size 3),(-110,.size 4),(10,.budget 0),(1,.endpoint 5 true true)]
private def batch1 : List (List Nat) := [[0,0,0,1,10,4,1,1],[0,0,0,2,7,7,0,1],[0,0,0,1,9,6,0,1],[0,0,0,1,11,1,4,0],[0,0,0,2,8,4,3,0],[0,0,0,1,10,3,3,0],[0,0,0,3,5,7,2,0],[0,0,0,2,7,6,2,0],[0,0,0,1,9,5,2,0],[0,0,0,4,2,10,1,0],[0,0,0,3,4,9,1,0]]
private theorem checked1 : batch1.all (fun h => valid T (decodeHist h) document1)=true := by decide +kernel

private def document2 : List (Int × Rule 14 2 2) := [(8,.visits 1),(-8,.size 2),(-24,.size 3),(-72,.size 5),(1,.endpoint 3 false false),(2,.endpoint 3 true false),(4,.budget 0)]
private def batch2 : List (List Nat) := [[0,0,1,0,8,6,2,0],[0,0,1,0,7,8,1,0]]
private theorem checked2 : batch2.all (fun h => valid T (decodeHist h) document2)=true := by decide +kernel

private def document3 : List (Int × Rule 14 2 2) := [(6,.visits 1),(-3,.chosen),(-12,.size 2),(-30,.size 3),(-60,.size 4),(-102,.size 5),(3,.endpoint 5 true false),(6,.budget 0),(2,.endpoint 3 true true),(6,.endpoint 6 false true),(3,.mass 2)]
private def batch3 : List (List Nat) := [[0,0,1,1,5,9,1,0],[0,0,1,2,2,12,0,0],[0,0,0,4,1,12,0,0],[0,0,1,1,4,11,0,0],[0,0,1,0,6,10,0,0]]
private theorem checked3 : batch3.all (fun h => valid T (decodeHist h) document3)=true := by decide +kernel

private def document4 : List (Int × Rule 14 2 2) := [(540,.visits 1),(-800,.chosen),(700,.size 1),(-1460,.size 3),(-4320,.size 4),(1,.price 0),(320,.endpoint 5 true false),(630,.budget 0),(320,.endpoint 6 false true)]
private def batch4 : List (List Nat) := [[0,0,0,2,6,8,1,0],[0,0,0,3,3,11,0,0]]
private theorem checked4 : batch4.all (fun h => valid T (decodeHist h) document4)=true := by decide +kernel

private def document5 : List (Int × Rule 14 2 2) := [(-1,.chosen),(1,.mass 3)]
private def batch5 : List (List Nat) := [[0,0,0,1,8,7,1,0],[0,0,0,1,7,9,0,0]]
private theorem checked5 : batch5.all (fun h => valid T (decodeHist h) document5)=true := by decide +kernel

private def document6 : List (Int × Rule 14 2 2) := [(27,.visits 0),(27,.visits 1),(-24,.chosen),(15,.size 3),(-24,.size 4),(1,.price 1)]
private def batch6 : List (List Nat) := [[0,0,0,2,5,10,0,0]]
private theorem checked6 : batch6.all (fun h => valid T (decodeHist h) document6)=true := by decide +kernel

private def documents (i : Fin 7) : List (Int × Rule 14 2 2) := (#[document0,document1,document2,document3,document4,document5,document6] : Array (List (Int × Rule 14 2 2)))[i.val]!
private def batches (i : Fin 7) : List (List Nat) := (#[batch0,batch1,batch2,batch3,batch4,batch5,batch6] : Array (List (List Nat)))[i.val]!
private theorem checked (j : Fin 7) : (batches j).all (fun h => valid T (decodeHist h) (documents j))=true := by
  fin_cases j
  · exact checked0
  · exact checked1
  · exact checked2
  · exact checked3
  · exact checked4
  · exact checked5
  · exact checked6

private def containsHistogram (h : List Nat) := (List.finRange 7).any (fun j => (batches j).contains h)
private theorem present : (Histogram.enumerate 7 17 43 350).all containsHistogram=true := by decide +kernel
theorem excluded (v : FourView 5 extra) : False := by
  have seats : 42+(∑ x,extra x)=43 := by decide +kernel
  have hs := v.possible_histogram
  rw [seats] at hs
  obtain ⟨j,_,ok⟩ := List.any_eq_true.mp (List.all_eq_true.mp present _ hs)
  have inside : Histogram.data v.hist 7 ∈ batches j := by simpa using ok
  have price := List.all_eq_true.mp (checked j) _ inside
  rw [read_hist] at price
  exact rejected T v (documents j) price

end Cover61.LocalRows.FourCase0
