import Mathlib.Tactic.FinCases
import Cover61.Layer12_1Part0
import Cover61.Layer12_1Part1
import Cover61.Layer12_1Part2
namespace Cover61.Layers
open Skeleton Growth
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
theorem steps12_1 (j : Fin 36) : ∃ cert, Checked (rows11_0 j) rows12_1 1 cert := by
  fin_cases j
  · exact checked12_1_0
  · exact checked12_1_1
  · exact checked12_1_2
  · exact checked12_1_3
  · exact checked12_1_4
  · exact checked12_1_5
  · exact checked12_1_6
  · exact checked12_1_7
  · exact checked12_1_8
  · exact checked12_1_9
  · exact checked12_1_10
  · exact checked12_1_11
  · exact checked12_1_12
  · exact checked12_1_13
  · exact checked12_1_14
  · exact checked12_1_15
  · exact checked12_1_16
  · exact checked12_1_17
  · exact checked12_1_18
  · exact checked12_1_19
  · exact checked12_1_20
  · exact checked12_1_21
  · exact checked12_1_22
  · exact checked12_1_23
  · exact checked12_1_24
  · exact checked12_1_25
  · exact checked12_1_26
  · exact checked12_1_27
  · exact checked12_1_28
  · exact checked12_1_29
  · exact checked12_1_30
  · exact checked12_1_31
  · exact checked12_1_32
  · exact checked12_1_33
  · exact checked12_1_34
  · exact checked12_1_35
theorem balanced12_1 (j : Fin 22) : Balanced (rows12_1 j) := by
  fin_cases j
  · exact balanced12_1_0
  · exact balanced12_1_1
  · exact balanced12_1_2
  · exact balanced12_1_3
  · exact balanced12_1_4
  · exact balanced12_1_5
  · exact balanced12_1_6
  · exact balanced12_1_7
  · exact balanced12_1_8
  · exact balanced12_1_9
  · exact balanced12_1_10
  · exact balanced12_1_11
  · exact balanced12_1_12
  · exact balanced12_1_13
  · exact balanced12_1_14
  · exact balanced12_1_15
  · exact balanced12_1_16
  · exact balanced12_1_17
  · exact balanced12_1_18
  · exact balanced12_1_19
  · exact balanced12_1_20
  · exact balanced12_1_21
end Cover61.Layers
