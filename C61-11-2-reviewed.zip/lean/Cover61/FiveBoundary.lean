import Cover61.FourColors

namespace Cover61.LocalRows

theorem marked_width_five (B : Family 38) (h : IsCover B) (j : Photo) : (marked B j).card≤5 := by
  have eq : marked B j = (B j).filter (fun x => degree B x=6) := by ext x; simp [marked,lows,and_comm]
  rw [eq]; exact at_most_five B h j

theorem group_count_cases (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5) :
    ((groups B i).card=3 ∧ (lows B).card=15 ∧ excess B (companions B i)=6) ∨
    ((groups B i).card=4 ∧ 17≤(lows B).card) ∨
    ((groups B i).card=5 ∧ 19≤(lows B).card) := by
  have size := five_group_size B h i five
  obtain ⟨b,c⟩ := five_group_excess B h i five
  have e := local_excess_le B h i
  have top := at_most_twenty B h
  omega

private theorem meet_groups (B : Family 38) (h : IsCover B) (i j : Photo) (five : (marked B i).card=5)
    (q : (marked B j).Nonempty) (shared : (companions B i ∩ B j).Nonempty) : j ∈ groups B i := by
  obtain ⟨z,hz⟩ := shared
  obtain ⟨y,hy⟩ := q
  obtain ⟨yl,yj⟩ := Finset.mem_inter.mp hy
  obtain ⟨zh,zj⟩ := Finset.mem_inter.mp hz
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ _,?_,⟨y,Finset.mem_inter.mpr ⟨yl,yj⟩⟩⟩
  by_cases ji : j=i
  · subst j; exact Finset.sdiff_subset
  have ch := companion_eq B i ▸ zh
  have jc := companion_only_clear B h _ (marked_sub B i) (marked_six B i) ch zj ji
  have out : y ∉ B i := by
    intro yi
    exact (Finset.mem_sdiff.mp jc).2 (Finset.mem_filter.mpr ⟨(Finset.mem_sdiff.mp jc).1,
      ⟨y,Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨yl,yi⟩,yj⟩⟩⟩)
  obtain ⟨k,only,all⟩ := five_forces_group B h i _ (marked_sub B i) (marked_six B i) five y out (Finset.mem_filter.mp yl).2
  have qj : j ∈ appearances B (clear B i (marked B i)) y := Finset.mem_filter.mpr ⟨jc,yj⟩
  rw [only,Finset.mem_singleton] at qj
  rwa [qj,companion_eq]

/-- At twenty low points the four five-low-point rows use all twenty low points. -/
theorem twenty_groups (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (twenty : (lows B).card=20) : (groups B i).card=4 := by
  let F := fullRows B 5
  let G := groups B i
  have need := full_rows_needed B h 4 (marked_width_five B h)
  change (lows B).card*((lows B).card+5) ≤ 4*((lows B).card*6)+5*F.card at need
  rw [twenty] at need
  have six (j : Photo) (q : (marked B j).card=5) : 6≤excess B (companions B j) := by
    have sz := companion_card B h j
    have p := Finset.sum_le_sum (s := companions B j) (f := fun _ => 1) (g := fun x => degree B x-7)
      (fun x hx => by have := five_members_high B h j q (by omega) x hx; omega)
    simp at p
    unfold excess; omega
  have sub : F ⊆ G := by
    intro j hj
    have q := (Finset.mem_filter.mp hj).2
    apply meet_groups B h i j five (Finset.card_pos.mp (by omega))
    by_contra notShared
    have dis : Disjoint (companions B i) (companions B j) := Finset.disjoint_left.mpr (fun x hi hj =>
      notShared ⟨x,Finset.mem_inter.mpr ⟨hi,(Finset.mem_sdiff.mp hj).1⟩⟩)
    have cap := Finset.sum_le_univ_sum_of_nonneg (s := companions B i ∪ companions B j)
      (f := fun x => degree B x-7) (fun _ => Nat.zero_le _)
    rw [Finset.sum_union dis] at cap
    change excess B (companions B i)+excess B (companions B j) ≤ _ at cap
    have := total_excess B h
    have := six i five
    have := six j q
    omega
  have parts := (five_group_cover B h i five).2.1
  have total := block_sum B G (lows B)
  rw [Finset.sum_congr rfl parts] at total
  simp [twenty] at total
  have full (j : Photo) (hj : j ∈ F) : (marked B j).card=5 := (Finset.mem_filter.mp hj).2
  have paid := Finset.sum_congr rfl full
  change (∑ j ∈ G,(marked B j).card)=20 at total
  have diff := Finset.sum_sdiff sub (f := fun j => (marked B j).card)
  rw [paid,total] at diff
  simp at diff
  have positive := Finset.sum_le_sum (s := G \ F) (f := fun _ => 1) (g := fun j => (marked B j).card)
    (fun j hj => Finset.card_pos.mpr (Finset.mem_filter.mp (Finset.mem_sdiff.mp hj).1).2.2)
  simp at positive
  have dcard := Finset.card_sdiff_of_subset sub
  have lower := Finset.card_le_card sub
  change G.card=4
  omega

private def bins (s : Photo→Nat) (J : Finset Photo) (k : Nat) := (J.filter (fun j => s j=k)).card

private theorem tally_six (s : Photo→Nat) (le : ∀ j,s j≤6) (J : Finset Photo) (w : Nat→Nat) :
    ∑ j ∈ J,w (s j) = bins s J 0*w 0+bins s J 1*w 1+bins s J 2*w 2+bins s J 3*w 3+
      bins s J 4*w 4+bins s J 5*w 5+bins s J 6*w 6 := by
  let f (j : Photo) : Fin 7 := ⟨s j,Nat.lt_succ_of_le (le j)⟩
  have eq (k : Fin 7) : FourView.countBy J f k=bins s J k.val := by unfold FourView.countBy bins; congr 1
  have count := FourView.weighted_count J f (fun k => w k.val)
  have un : (Finset.univ : Finset (Fin 7))={0,1,2,3,4,5,6} := by decide
  rw [un] at count
  simpa [eq,f,add_assoc,add_comm,add_left_comm] using count.symm

/-- The twelve clear blocks in the five-group boundary force sizes 2, 3 and 6.
Pricing a size-two visit at three half-units contradicts their total capacity. -/
theorem nineteen_no_five_groups (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (a : (lows B).card=19) (g : (groups B i).card=5) : False := by
  let H := companions B i
  let J := clear B i (marked B i)
  let s := amount B i
  have hc := companion_card B h i
  have six : H.card=6 := by change (companions B i).card=6; omega
  have le (j : Photo) : s j ≤ 6 := (Finset.card_le_card Finset.inter_subset_left).trans_eq six
  have cc := (counts B h i _ (marked_sub B i) (marked_six B i)).2
  have jc : J.card=12 := by change J.card+5*(marked B i).card=37 at cc; omega
  have ci := (five_group_cover B h i five).1
  have groupSub : (groups B i).erase i ⊆ J.filter (fun j => s j=6) := by
    intro j hj
    have all := (Finset.mem_filter.mp (Finset.mem_erase.mp hj).2).2.1
    exact Finset.mem_filter.mpr ⟨(five_group_cover B h i five).2.2 hj,by
      change (companions B i ∩ B j).card=6
      rw [Finset.inter_eq_left.mpr all]; exact six⟩
  have four := Finset.card_le_card groupSub
  rw [Finset.card_erase_of_mem ci,g] at four
  change 4≤bins s J 6 at four
  have d := local_excess_le B h i
  have dom := (five_group_excess B h i five).1
  have v := total_companion_visits B h i
  change (∑ j ∈ J,s j)=6*H.card + excess B (companions B i) at v
  rw [six] at v
  have total := tally_six s le J (fun _ => 1)
  have visits := tally_six s le J id
  have cap := (local_capacity B h i).trans_eq (tally_six s le J room)
  change H.card*50 ≤ _ at cap
  rw [six] at cap
  simp only [id_eq] at visits
  rw [v] at visits
  simp [room] at cap
  simp [jc] at total
  have profile : bins s J 0=0 ∧ bins s J 1=0 ∧ bins s J 2=2 ∧ bins s J 3=6 ∧ bins s J 4=0 ∧ bins s J 5=0 ∧ bins s J 6=4 := by omega
  obtain ⟨n0,n1,n2,n3,n4,n5,n6⟩ := profile
  let O := (Finset.univ : Finset Point) \ B i
  let price (k : Nat) := if k=2 then 3 else 2*k
  have person (y : Point) (hy : y ∈ O) : 12≤∑ j ∈ appearances B J y,price (s j) := by
    let T := appearances B J y
    have meet (z : Point) (hz : z ∈ H) : z ∈ T.biUnion (B ·) := by
      have ne : y≠z := fun e => (Finset.mem_sdiff.mp hy).2 (e ▸ (Finset.mem_sdiff.mp hz).1)
      obtain ⟨j,yj,zj⟩ := h.2 y z ne
      have cj := companion_only_clear B h _ (marked_sub B i) (marked_six B i) (companion_eq B i ▸ hz) zj
        (fun eq => (Finset.mem_sdiff.mp hy).2 (eq ▸ yj))
      exact Finset.mem_biUnion.mpr ⟨j,Finset.mem_filter.mpr ⟨cj,yj⟩,zj⟩
    have sub : H ⊆ T.biUnion (fun j => H ∩ B j) := by
      intro z hz
      obtain ⟨j,hj,hzj⟩ := Finset.mem_biUnion.mp (meet z hz)
      exact Finset.mem_biUnion.mpr ⟨j,hj,Finset.mem_inter.mpr ⟨hz,hzj⟩⟩
    have need := (Finset.card_le_card sub).trans Finset.card_biUnion_le
    change H.card ≤ ∑ j ∈ T,s j at need
    rw [six] at need
    have max (k : Nat) : bins s T k ≤ bins s J k := Finset.card_le_card (Finset.filter_subset_filter _ (Finset.filter_subset ..))
    have lhs := tally_six s le T id
    have rhs := tally_six s le T price
    simp [id_eq] at lhs
    have := max 1; have := max 2; have := max 4; have := max 5
    change 12 ≤ ∑ j ∈ T,price (s j)
    rw [rhs]
    simp [price]
    omega
  have pay := Finset.sum_le_sum person
  rw [weighted_visits] at pay
  have side (j : Photo) : (O ∩ B j).card≤11-s j := by
    have dis : Disjoint (H ∩ B j) (O ∩ B j) := Finset.disjoint_left.mpr (fun z hz ho =>
      (Finset.mem_sdiff.mp (Finset.mem_inter.mp ho).1).2 (Finset.mem_sdiff.mp (Finset.mem_inter.mp hz).1).1)
    have bound := Finset.card_le_card (show (H ∩ B j) ∪ (O ∩ B j) ⊆ B j from
      Finset.union_subset Finset.inter_subset_right Finset.inter_subset_right)
    rw [Finset.card_union_of_disjoint dis,h.1] at bound
    change s j + _ ≤ 11 at bound
    omega
  have capacity := Finset.sum_le_sum (s := J) (fun j _ => Nat.mul_le_mul_right (price (s j)) (side j))
  have all := (pay.trans capacity).trans_eq (tally_six s le J (fun k => (11-k)*price k))
  have os : O.card=50 := by simp [O,Finset.card_sdiff_of_subset,h.1]
  simp [os,price,n0,n1,n2,n3,n4,n5,n6] at all

end Cover61.LocalRows
