import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext60 : ∀ t, GoodStep 60 t := by decide +kernel

theorem ext61 : ∀ t, GoodStep 61 t := by decide +kernel

theorem ext62 : ∀ t, GoodStep 62 t := by decide +kernel

theorem ext63 : ∀ t, GoodStep 63 t := by decide +kernel

theorem ext64 : ∀ t, GoodStep 64 t := by decide +kernel

theorem ext65 : ∀ t, GoodStep 65 t := by decide +kernel

theorem ext66 : ∀ t, GoodStep 66 t := by decide +kernel

theorem ext67 : ∀ t, GoodStep 67 t := by decide +kernel

theorem ext68 : ∀ t, GoodStep 68 t := by decide +kernel

theorem ext69 : ∀ t, GoodStep 69 t := by decide +kernel

theorem ext70 : ∀ t, GoodStep 70 t := by decide +kernel

theorem ext71 : ∀ t, GoodStep 71 t := by decide +kernel

end Cover61.Nine
