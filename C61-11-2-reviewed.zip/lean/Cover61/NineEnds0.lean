import Cover61.NineEndData

namespace Cover61.Nine

open Skeleton

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem end0 : EndOK 0 := by decide +kernel

theorem end1 : EndOK 1 := by decide +kernel

theorem end2 : EndOK 2 := by decide +kernel

theorem end3 : EndOK 3 := by decide +kernel

theorem end4 : EndOK 4 := by decide +kernel

theorem end5 : EndOK 5 := by decide +kernel

theorem end6 : EndOK 6 := by decide +kernel

theorem end7 : EndOK 7 := by decide +kernel

theorem end8 : EndOK 8 := by decide +kernel

theorem end9 : EndOK 9 := by decide +kernel

theorem end10 : EndOK 10 := by decide +kernel

theorem end11 : EndOK 11 := by decide +kernel

theorem end12 : EndOK 12 := by decide +kernel

theorem end13 : EndOK 13 := by decide +kernel

theorem reg0 : Regular (candidates 0) := by decide +kernel

theorem reg1 : Regular (candidates 1) := by decide +kernel

theorem reg2 : Regular (candidates 2) := by decide +kernel

theorem reg3 : Regular (candidates 3) := by decide +kernel

theorem reg4 : Regular (candidates 4) := by decide +kernel

end Cover61.Nine
