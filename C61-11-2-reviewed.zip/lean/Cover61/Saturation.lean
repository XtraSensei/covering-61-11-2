import Cover61.Moments

namespace Cover61

/-- If the internal block incidences of a set of seven-fold points exhaust its
meeting budget, every external pair touching the set occurs once. -/
theorem outside_meets_once_of_saturation (B : Family 38) (h : IsCover B) (S : Finset Point)
    (d : ∀ x ∈ S, degree B x = 7)
    (sat : S.card * (S.card + 16) ≤ ∑ i, (S ∩ B i).card * (S ∩ B i).card)
    (x : Point) (hx : x ∈ S) (y : Point) (hy : y ∉ S) : partners B x y = 1 := by
  let O := (Finset.univ : Finset Point) \ S
  have oc : O.card = 61 - S.card := by
    rw [Finset.card_sdiff_of_subset (Finset.subset_univ _)]; simp
  have small : S.card ≤ 61 := by simpa using Finset.card_le_card (Finset.subset_univ S)
  have total (u : Point) (hu : u ∈ S) : ∑ v, partners B u v = 77 := by
    have diag : partners B u u = 7 := by simpa [partners,degree] using d u hu
    have e := Finset.sum_erase_add Finset.univ (partners B u) (Finset.mem_univ u)
    rw [partnerSum B h,d u hu,diag] at e
    omega
  have both : (∑ u ∈ S, ∑ v ∈ O, partners B u v) +
      (∑ u ∈ S, ∑ v ∈ S, partners B u v) = S.card*77 := by
    rw [← Finset.sum_add_distrib]
    have row (u : Point) (hu : u ∈ S) :
        (∑ v ∈ O, partners B u v) + (∑ v ∈ S, partners B u v) = 77 := by
      rw [Finset.sum_sdiff (Finset.subset_univ S),total u hu]
    rw [Finset.sum_congr rfl row]; simp
  rw [← cross_sum] at sat
  have pos (u : Point) (hu : u ∈ S) (v : Point) (hv : v ∈ O) : 1 ≤ partners B u v := by
    apply partners_pos B h
    intro eq
    exact (Finset.mem_sdiff.mp hv).2 (eq ▸ hu)
  have base (u : Point) (hu : u ∈ S) : O.card ≤ ∑ v ∈ O, partners B u v := by
    simpa using Finset.sum_le_sum (s:=O) (f:=fun _ => 1) (g:=partners B u) (pos u hu)
  by_contra ne
  have yO : y ∈ O := Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,hy⟩
  have gt : 1 < partners B x y := by have := pos x hx y yO; omega
  have strict : O.card < ∑ v ∈ O, partners B x v := by
    simpa using Finset.sum_lt_sum (s:=O) (f:=fun _ => 1) (g:=partners B x)
      (pos x hx) ⟨y,yO,gt⟩
  have more := Finset.sum_lt_sum (s := S) (f := fun _ => O.card)
    (g := fun u => ∑ v ∈ O, partners B u v) base ⟨x,hx,strict⟩
  have algebra : S.card * O.card + S.card * (S.card+16) = S.card*77 := by
    rw [← Nat.mul_add,oc]
    congr 1
    omega
  simp only [Finset.sum_const,Nat.nsmul_eq_mul] at more
  omega

theorem split_eight (a b : Nat) (h : a+b = 8) : 24 ≤ a*(a-1)+b*(b-1) := by
  have lim : a < 9 := by omega
  let v : Fin 9 := ⟨a,lim⟩
  have m : ∀ t : Fin 9, 24 ≤ t.val*(t.val-1)+(8-t.val)*(8-t.val-1) := by decide
  have eq : b = 8-a := by omega
  simpa [eq,v] using m v

end Cover61
