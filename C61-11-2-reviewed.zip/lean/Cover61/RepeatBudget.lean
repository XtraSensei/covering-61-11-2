import Cover61.FiveRows

namespace Cover61

theorem repeat_sum (B : Family 38) (h : IsCover B) (x : Point) :
    ∑ y ∈ Finset.univ.erase x, (partners B x y-1) = 10*(degree B x-6) := by
  let V := (Finset.univ : Finset Point).erase x
  have eq (y : Point) (hy : y ∈ V) : partners B x y = partners B x y-1 + 1 := by
    have := partners_pos B h x y (Finset.mem_erase.mp hy).1.symm
    omega
  have total := partnerSum B h x
  rw [Finset.sum_congr rfl eq,Finset.sum_add_distrib] at total
  have sz : V.card=60 := by simp [V]
  change (∑ y ∈ V, (partners B x y-1)) + (∑ _y ∈ V, 1) = _ at total
  simp [sz] at total
  have := degree_ge_six B h x
  change (∑ y ∈ V, (partners B x y-1)) = _
  omega

/-- Repeated common rows spend part of each group member's repeat budget. -/
theorem shared_rows_budget (B : Family 38) (h : IsCover B) (H : Finset Point) (J : Finset (Fin 38))
    (all : ∀ j ∈ J, H ⊆ B j) (x : Point) (hx : x ∈ H) :
    (H.card-1)*(J.card-1) ≤ 10*(degree B x-6) := by
  have each (y : Point) (_ : y ∈ H.erase x) (hy : y ∈ H) : J.card ≤ partners B x y := by
    apply Finset.card_le_card
    intro j hj
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,all j hj hx,all j hj hy⟩
  have low := Finset.sum_le_sum (s := H.erase x) (fun y hy =>
    Nat.sub_le_sub_right (each y hy (Finset.mem_erase.mp hy).2) 1)
  have sub : H.erase x ⊆ (Finset.univ : Finset Point).erase x :=
    Finset.erase_subset_erase _ (Finset.subset_univ _)
  have upper := Finset.sum_le_sum_of_subset_of_nonneg (f := fun y => partners B x y-1) sub
    (fun _ _ _ => Nat.zero_le _)
  rw [repeat_sum B h x] at upper
  simpa [Finset.card_erase_of_mem hx] using low.trans upper

namespace LocalRows
def fullRows (B : Family 38) (t : Nat) := Finset.univ.filter (fun j => (marked B j).card=t)

theorem visits_full_rows (B : Family 38) (h : IsCover B) (x : Point) (high : x ∉ lows B) (t : Nat) :
    (appearances B (fullRows B t) x).card * t ≤ (lows B).card := by
  let J := appearances B (fullRows B t) x
  have one (y : Point) (hy : y ∈ lows B) : partners B y x=1 := six_meets_once B h y x
    (Finset.mem_filter.mp hy).2 (fun e => high (e ▸ hy))
  have eq := cross_sum B (lows B) {x}
  simp only [Finset.sum_singleton] at eq
  rw [Finset.sum_congr rfl one] at eq
  simp only [Finset.sum_const,Nat.nsmul_eq_mul,Nat.mul_one] at eq
  have row (j : Photo) (hj : j ∈ J) :
      ((lows B) ∩ B j).card * (({x} : Finset Point) ∩ B j).card = t := by
    obtain ⟨jf,xj⟩ := Finset.mem_filter.mp hj
    have size := (Finset.mem_filter.mp jf).2
    change (lows B ∩ B j).card=t at size
    simp [xj,size]
  have upper := Finset.sum_le_univ_sum_of_nonneg (s := J)
    (f := fun j => (lows B ∩ B j).card * (({x} : Finset Point) ∩ B j).card) (fun _ => Nat.zero_le _)
  rw [Finset.sum_congr rfl row,← eq] at upper
  simpa [J] using upper

theorem sum_local_excess (B : Family 38) (h : IsCover B) (t q : Nat)
    (tpos : 0<t) (small : (lows B).card < (q+1)*t) :
    ∑ j ∈ fullRows B t, excess B (companions B j) ≤ q * ∑ x, (degree B x-7) := by
  let J := fullRows B t
  let w (x : Point) := degree B x-7
  have eq (j : Photo) : excess B (companions B j) = ∑ x : Point, if x ∈ B j then w x else 0 := by
    unfold excess
    rw [← Finset.sum_filter]
    have sub : companions B j ⊆ Finset.univ.filter (fun x => x ∈ B j) :=
      fun x hx => Finset.mem_filter.mpr ⟨Finset.mem_univ _,(Finset.mem_sdiff.mp hx).1⟩
    apply Finset.sum_subset sub
    intro x hx no
    have low : x ∈ lows B := by
      by_contra nl
      exact no (Finset.mem_sdiff.mpr ⟨(Finset.mem_filter.mp hx).2,nl⟩)
    simp [w,(Finset.mem_filter.mp low).2]
  rw [Finset.sum_congr rfl (fun j _ => eq j),Finset.sum_comm,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro x _
  rw [← Finset.sum_filter,Finset.sum_const,Nat.nsmul_eq_mul]
  change (appearances B J x).card*w x ≤ q*w x
  by_cases low : x ∈ lows B
  · simp [w,(Finset.mem_filter.mp low).2]
  · apply Nat.mul_le_mul_right
    by_contra! no
    have := visits_full_rows B h x low t
    have bad := Nat.mul_le_mul_right t (show q+1 ≤ (appearances B J x).card by omega)
    exact (Nat.not_le_of_gt small) (bad.trans this)

theorem five_members_high (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
    (many : 15 < (lows B).card) : ∀ x ∈ companions B i, 8 ≤ degree B x := by
  have members := companion_card B h i
  have hc : (companions B i).card=6 := by omega
  have size := five_group_size B h i five
  intro x hx
  have bound := shared_rows_budget B h (companions B i) (groups B i)
    (fun j hj => (Finset.mem_filter.mp hj).2.1) x hx
  rw [hc] at bound
  omega

theorem at_most_twenty (B : Family 38) (h : IsCover B) : (lows B).card ≤ 20 := by
  let a := (lows B).card
  have top := at_most_twenty_five B h
  by_contra! big
  have full : ∀ i, lowCount B i ≤ 4+1 := by
    intro i
    have eq : marked B i = (B i).filter (fun x => degree B x=6) := by ext x; simp [marked,lows,and_comm]
    change (marked B i).card ≤ 5
    rw [eq]; exact at_most_five B h i
  have moment := full_rows_needed B h 4 full
  change a*(a+5) ≤ 4*(a*6) + 5*(fullRows B 5).card at moment
  have per (j : Photo) (hj : j ∈ fullRows B 5) : 6 ≤ excess B (companions B j) := by
    have five := (Finset.mem_filter.mp hj).2
    have lc := companion_card B h j
    have card : (companions B j).card=6 := by omega
    have lower := Finset.sum_le_sum (s := companions B j) (f := fun _ => 1)
      (g := fun x => degree B x-7) (fun x hx => by
        have := five_members_high B h j five (by omega) x hx
        omega)
    simpa [card,excess] using lower
  have lo := Finset.sum_le_sum per
  simp only [Finset.sum_const,Nat.nsmul_eq_mul] at lo
  have ex := total_excess B h
  change (∑ x, (degree B x-7)) + 9=a at ex
  change a ≤ 25 at top
  change 20 < a at big
  have contradiction_for (q : Nat) (small : a < (q+1)*5) :
      (fullRows B 5).card*6 ≤ q*(∑ x, (degree B x-7)) := lo.trans (sum_local_excess B h 5 q (by decide) small)
  have cases : a=21 ∨ a=22 ∨ a=23 ∨ a=24 ∨ a=25 := by omega
  rcases cases with z|z|z|z|z
  all_goals first
    | have le := contradiction_for 4 (by omega); rw [z] at moment; omega
    | have le := contradiction_for 5 (by omega); rw [z] at moment; omega

end LocalRows
end Cover61
