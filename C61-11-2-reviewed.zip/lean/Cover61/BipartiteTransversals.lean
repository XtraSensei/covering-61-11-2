import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.SDiff

namespace Cover61

/-- Ordinary people on one class of disjoint transversals. Their last two
blocks are endpoints in a bipartite graph. Different transversal colours must meet. -/
theorem bipartite_color_bound {P A B C : Type} [DecidableEq P] [DecidableEq A] [DecidableEq B] [DecidableEq C]
    (S : Finset P) (a : P→A) (b : P→B) (c : P→C) (d m : Nat)
    (la : ∀ u,(S.filter (fun x => a x=u)).card≤d) (lb : ∀ v,(S.filter (fun x => b x=v)).card≤d)
    (lc : ∀ i,(S.filter (fun x => c x=i)).card≤m)
    (cover : ∀ x ∈ S, ∀ y ∈ S, c x≠c y → a x=a y ∨ b x=b y) : S.card≤m+max d m := by
  classical
  by_cases parallel : ∀ x ∈ S, ∀ y ∈ S, a x=a y ∨ b x=b y
  · by_cases different : ∃ x ∈ S, ∃ y ∈ S, a x≠a y
    · obtain ⟨x,hx,y,hy,ne⟩ := different
      have eq := (parallel x hx y hy).resolve_left ne
      have all : S ⊆ S.filter (fun z => b z=b x) := by
        intro z hz
        refine Finset.mem_filter.mpr ⟨hz,?_⟩
        by_contra nb
        have p := (parallel z hz x hx).resolve_right nb
        have q := (parallel z hz y hy).resolve_right (fun e => nb (e.trans eq.symm))
        exact ne (p.symm.trans q)
      have := (Finset.card_le_card all).trans (lb _)
      omega
    · by_cases em : S.Nonempty
      · obtain ⟨x,hx⟩ := em
        have all : S ⊆ S.filter (fun z => a z=a x) := fun z hz => Finset.mem_filter.mpr
          ⟨hz,by by_contra ne; exact different ⟨z,hz,x,hx,ne⟩⟩
        have := (Finset.card_le_card all).trans (la _)
        omega
      · simp [Finset.not_nonempty_iff_eq_empty.mp em]
  · push_neg at parallel
    obtain ⟨x,hx,y,hy,na,nb⟩ := parallel
    have cc : c x=c y := by by_contra ne; exact nb ((cover x hx y hy ne).resolve_left na)
    let K := S.filter (fun z => c z=c x)
    let T := S \ K
    have size := Finset.card_sdiff_add_card_eq_card (show K ⊆ S from Finset.filter_subset ..)
    have small : K.card≤m := lc _
    have corners (z : P) (hz : z ∈ T) : (a z=a x ∧ b z=b y) ∨ (a z=a y ∧ b z=b x) := by
      obtain ⟨mem,no⟩ := Finset.mem_sdiff.mp hz
      have nz : c z≠c x := fun e => no (Finset.mem_filter.mpr ⟨mem,e⟩)
      rcases cover z mem x hx nz with u|v <;> rcases cover z mem y hy (fun e => nz (e.trans cc.symm)) with w|k
      · exact (na (u.symm.trans w)).elim
      · exact Or.inl ⟨u,k⟩
      · exact Or.inr ⟨w,v⟩
      · exact (nb (v.symm.trans k)).elim
    have same {p q : P} (hp : p ∈ T) (hq : q ∈ T) (p1 : a p=a x ∧ b p=b y) (q2 : a q=a y ∧ b q=b x) : c p=c q := by
      by_contra ne
      rcases cover p (Finset.mem_sdiff.mp hp).1 q (Finset.mem_sdiff.mp hq).1 ne with u|v
      · exact na (p1.1.symm.trans (u.trans q2.1))
      · exact nb (q2.2.symm.trans (v.symm.trans p1.2))
    have limit : T.card≤max d m := by
      by_cases first : ∃ p ∈ T, a p=a x ∧ b p=b y
      · obtain ⟨p,hp,px⟩ := first
        by_cases second : ∃ q ∈ T, a q=a y ∧ b q=b x
        · obtain ⟨q,hq,qy⟩ := second
          have all : T ⊆ S.filter (fun z => c z=c p) := by
            intro z hz
            refine Finset.mem_filter.mpr ⟨(Finset.mem_sdiff.mp hz).1,?_⟩
            rcases corners z hz with zx|zy
            · exact (same hz hq zx qy).trans (same hp hq px qy).symm
            · exact (same hp hz px zy).symm
          exact ((Finset.card_le_card all).trans (lc _)).trans (Nat.le_max_right ..)
        · have all : T ⊆ S.filter (fun z => a z=a x) := fun z hz => Finset.mem_filter.mpr
            ⟨(Finset.mem_sdiff.mp hz).1,((corners z hz).resolve_right (fun h => second ⟨z,hz,h⟩)).1⟩
          exact ((Finset.card_le_card all).trans (la _)).trans (Nat.le_max_left ..)
      · have all : T ⊆ S.filter (fun z => a z=a y) := fun z hz => Finset.mem_filter.mpr
          ⟨(Finset.mem_sdiff.mp hz).1,((corners z hz).resolve_left (fun h => first ⟨z,hz,h⟩)).1⟩
        exact ((Finset.card_le_card all).trans (la _)).trans (Nat.le_max_left ..)
    change T.card+K.card=S.card at size
    omega

end Cover61
