import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w10_044_02Rows : Rows 10 := fun i =>
  ([{0,4}, {1,4}, {2,3,4}, {0,5}, {2,5}, {1,3,5}, {1,6}, {0,2,6}, {3,6}, {4,6}, {0,1,7}, {2,7}, {3,7}, {5,7}, {0,8}, {1,2,8}, {3,8}, {4,5,8}, {6,7,8}, {1,9}, {2,9}, {0,3,9}, {5,6,9}, {4,7,9}, {8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_044_02Cost : Cost := fun i =>
  ([0, 0, 0, 0, 0, 0, 0, -1, 1, 0, -1, 0, 1, 0, -1, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_044_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_044_02Rows :=
  Weighted.exclude _ w10_044_02Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w10_047_02Rows : Rows 10 := fun i =>
  ([{0,1,2}, {0,3}, {1,4}, {0,5}, {3,5}, {2,4,5}, {0,6}, {1,6}, {2,3,6}, {4,6}, {1,7}, {2,7}, {3,4,7}, {5,6,7}, {2,8}, {3,8}, {0,4,8}, {1,5,8}, {7,8}, {2,9}, {1,3,9}, {4,9}, {5,9}, {0,7,9}, {6,8,9}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 10)))[i.val]'(i.isLt)

private def w10_047_02Cost : Cost := fun i =>
  ([0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w10_047_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w10_047_02Rows :=
  Weighted.exclude _ w10_047_02Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
