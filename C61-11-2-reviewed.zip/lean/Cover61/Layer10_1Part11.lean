import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced10_1_132 : Balanced (rows10_1 132) := by decide +kernel

theorem balanced10_1_133 : Balanced (rows10_1 133) := by decide +kernel

theorem balanced10_1_134 : Balanced (rows10_1 134) := by decide +kernel

theorem balanced10_1_135 : Balanced (rows10_1 135) := by decide +kernel

theorem balanced10_1_136 : Balanced (rows10_1 136) := by decide +kernel

theorem balanced10_1_137 : Balanced (rows10_1 137) := by decide +kernel

theorem balanced10_1_138 : Balanced (rows10_1 138) := by decide +kernel

theorem balanced10_1_139 : Balanced (rows10_1 139) := by decide +kernel

theorem balanced10_1_140 : Balanced (rows10_1 140) := by decide +kernel

theorem balanced10_1_141 : Balanced (rows10_1 141) := by decide +kernel

theorem balanced10_1_142 : Balanced (rows10_1 142) := by decide +kernel

theorem balanced10_1_143 : Balanced (rows10_1 143) := by decide +kernel

end Cover61.Layers
