import Cover61.AffineBits
import Mathlib.Algebra.Order.BigOperators.Group.Finset

namespace Cover61.Affine

/-- Arithmetic of the four parallel classes. A double-line participant is
counted by the omitted line, a single-line participant by the chosen line. -/
theorem census (x : Fin 4 → Nat) (y z : Fin 4 → Fin 3 → Nat)
    (pop : (∑ d, ∑ l, z d l) = (∑ d, x d) + 8)
    (seat : ∀ d l, z d l + x d + (∑ k, y d k) = 8 + y d l)
    (conflict : ∀ d l, 0 < z d l → y d l = 0)
    (parallel : ∀ d e l, 0 < x d → 0 < z e l → d = e) :
    ∃ d, x d = 4 ∧ (∀ l, z d l = 4 ∧ y d l = 0) ∧
      ∀ e, e ≠ d → x e = 0 ∧ ∀ l, z e l = 0 ∧ y e l = 4 := by
  have existsS : ∃ d l, 0 < z d l := by
    by_contra! hn
    have allZero (d l) : z d l = 0 := by have := hn d l; omega
    simp [allZero] at pop
  obtain ⟨d,l,sl⟩ := existsS
  have flat (j : Fin 3) : z d j = z d l ∧ y d j = 0 := by
    have a := seat d l
    have b := seat d j
    rw [conflict d l sl] at a
    have pos : 0 < z d j := by omega
    have zero := conflict d j pos
    omega
  have atD : (∑ e, x e) = x d := by
    apply Finset.sum_eq_single d
    · intro e _ ne
      by_contra nz
      exact ne (parallel e d l (by omega) sl)
    · simp
  rw [atD] at pop
  have lineZ : (∑ j, z d j) = 3 * z d l := by
    rw [Finset.sum_congr rfl (g := fun _ => z d l) (fun j _ => (flat j).1)]
    simp
  have noD : (∑ j, y d j) = 0 := Finset.sum_eq_zero fun j _ => (flat j).2
  have hrow := seat d l
  rw [noD,(flat l).2] at hrow
  have one := Finset.single_le_sum (s := Finset.univ) (f := fun e => ∑ j, z e j)
    (fun e _ => Nat.zero_le _) (Finset.mem_univ d)
  rw [lineZ,pop] at one
  have posT : 0 < x d := by omega
  have outside (e : Fin 4) (ed : e ≠ d) (j : Fin 3) : z e j = 0 := by
    by_contra nz
    exact ed (parallel d e j posT (by omega)).symm
  have allS : (∑ e, ∑ j, z e j) = ∑ j, z d j := by
    apply Finset.sum_eq_single d
    · intro e _ ed
      exact Finset.sum_eq_zero fun j _ => outside e ed j
    · simp
  rw [lineZ,pop] at allS
  have val : x d = 4 := by omega
  refine ⟨d,val,fun j => ⟨by have := (flat j).1; omega,(flat j).2⟩,?_⟩
  intro e ed
  have noT : x e = 0 := by
    by_contra nz
    exact ed (parallel e d l (by omega) sl)
  refine ⟨noT,?_⟩
  intro j
  have values (k : Fin 3) : y e k = y e j := by
    have a := seat e k
    have b := seat e j
    rw [outside e ed k] at a
    rw [outside e ed j] at b
    omega
  have lineY : (∑ k, y e k) = 3*y e j := by
    rw [Finset.sum_congr rfl (g := fun _ => y e j) (fun k _ => values k)]
    simp
  have hs := seat e j
  rw [outside e ed j,noT,lineY] at hs
  exact ⟨outside e ed j,by omega⟩

end Cover61.Affine
