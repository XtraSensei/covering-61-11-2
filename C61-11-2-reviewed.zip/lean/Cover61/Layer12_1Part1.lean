import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_1_12 : List (Branch 11 22) := [
  ⟨{{0,6}, {1,2}, {3,4}, {5,9,10}, {7}, {8}},20,⟨944192226736,6400788415769⟩⟩,
  ⟨{{0,6}, {1,2}, {3,8,10}, {4,5}, {7}, {9}},15,⟨228232674208,3136053851183⟩⟩,
  ⟨{{0,7,10}, {1,2}, {3,4}, {5,6}, {8}, {9}},15,⟨231006554185,4565307347579⟩⟩
]

theorem checked12_1_12 : ∃ cert, Checked (rows11_0 12) rows12_1 1 cert :=
  ⟨routes12_1_12, by decide +kernel⟩

private def routes12_1_13 : List (Branch 11 22) := [
  ⟨{{0,2}, {1,4,10}, {3,5}, {6,7}, {8,9}},20,⟨1709807074712,3911455835617⟩⟩,
  ⟨{{0,2}, {1,4,10}, {3,5}, {6,9}, {7,8}},20,⟨1694795764486,1503884079808⟩⟩
]

theorem checked12_1_13 : ∃ cert, Checked (rows11_0 13) rows12_1 1 cert :=
  ⟨routes12_1_13, by decide +kernel⟩

private def routes12_1_14 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,5,10}, {3,4}, {6,7}, {8,9}},8,⟨1705047803987,94732497101⟩⟩,
  ⟨{{0,2}, {1,7,10}, {3,4}, {5,6}, {8,9}},15,⟨1697205321801,6316623169285⟩⟩,
  ⟨{{0,9,10}, {1,2}, {3,4}, {5,6}, {7,8}},8,⟨2362479581484,2730576531276⟩⟩
]

theorem checked12_1_14 : ∃ cert, Checked (rows11_0 14) rows12_1 1 cert :=
  ⟨routes12_1_14, by decide +kernel⟩

private def routes12_1_15 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,6,10}, {3,9}, {4,5}, {7,8}},4,⟨2380742865908,4153777894442⟩⟩,
  ⟨{{0,2}, {1,4,10}, {3,9}, {5,6}, {7,8}},21,⟨1705898421656,3911428692193⟩⟩,
  ⟨{{0,8,10}, {1,2}, {3,9}, {4,5}, {6,7}},21,⟨1724206851312,5769218316048⟩⟩
]

theorem checked12_1_15 : ∃ cert, Checked (rows11_0 15) rows12_1 1 cert :=
  ⟨routes12_1_15, by decide +kernel⟩

private def routes12_1_16 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3,10}, {4,5}, {6,7}, {8,9}},9,⟨2411539114281,6935406623750⟩⟩,
  ⟨{{0,2}, {1,6,10}, {3,9}, {4,5}, {7,8}},9,⟨2380778430921,5511627244585⟩⟩,
  ⟨{{0,8,10}, {1,2}, {3,9}, {4,5}, {6,7}},6,⟨2405304282480,5769295414080⟩⟩
]

theorem checked12_1_16 : ∃ cert, Checked (rows11_0 16) rows12_1 1 cert :=
  ⟨routes12_1_16, by decide +kernel⟩

private def routes12_1_17 : List (Branch 11 22) := [
  
]

theorem checked12_1_17 : ∃ cert, Checked (rows11_0 17) rows12_1 1 cert :=
  ⟨routes12_1_17, by decide +kernel⟩

private def routes12_1_18 : List (Branch 11 22) := [
  
]

theorem checked12_1_18 : ∃ cert, Checked (rows11_0 18) rows12_1 1 cert :=
  ⟨routes12_1_18, by decide +kernel⟩

private def routes12_1_19 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,7,10}, {5,6}, {8,9}},18,⟨1717844816248,6345282457096⟩⟩,
  ⟨{{0,3}, {1,2}, {4,7,10}, {5,6}, {8,9}},16,⟨1717417823968,4983171610120⟩⟩
]

theorem checked12_1_19 : ∃ cert, Checked (rows11_0 19) rows12_1 1 cert :=
  ⟨routes12_1_19, by decide +kernel⟩

private def routes12_1_20 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,5,10}, {6,7}, {8,9}},18,⟨2412478262084,7074333883936⟩⟩,
  ⟨{{0,1}, {2,7,10}, {3,4}, {5,6}, {8,9}},18,⟨2393348408176,4960177295414⟩⟩,
  ⟨{{0,4}, {1,2}, {3,6,10}, {5,9}, {7,8}},18,⟨2387192602949,4160816460075⟩⟩,
  ⟨{{0,4}, {1,8,10}, {2,3}, {5,9}, {6,7}},18,⟨2405301526089,5759372761153⟩⟩,
  ⟨{{0,9,10}, {1,2}, {3,4}, {5,6}, {7,8}},18,⟨2362987994928,6274959362892⟩⟩
]

theorem checked12_1_20 : ∃ cert, Checked (rows11_0 20) rows12_1 1 cert :=
  ⟨routes12_1_20, by decide +kernel⟩

private def routes12_1_21 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,7,10}, {5,6}, {8,9}},5,⟨2392873559626,2273221200151⟩⟩,
  ⟨{{0,1}, {2,8,10}, {3,4}, {5,9}, {6,7}},0,⟨2405297859954,5764909542722⟩⟩,
  ⟨{{0,4}, {1,2}, {3,5,10}, {6,7}, {8,9}},5,⟨1731387427253,7080353356527⟩⟩,
  ⟨{{0,4}, {1,6,10}, {2,3}, {5,9}, {7,8}},5,⟨2376048632408,5521086613801⟩⟩,
  ⟨{{0,9,10}, {1,2}, {3,4}, {5,6}, {7,8}},5,⟨2357000620117,1034375297769⟩⟩
]

theorem checked12_1_21 : ∃ cert, Checked (rows11_0 21) rows12_1 1 cert :=
  ⟨routes12_1_21, by decide +kernel⟩

private def routes12_1_22 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,6,10}, {5,9}, {7,8}},1,⟨2380742726912,4164019819564⟩⟩,
  ⟨{{0,1}, {2,7,10}, {3,4}, {5,6}, {8,9}},1,⟨2383455388710,6331626164534⟩⟩,
  ⟨{{0,4}, {1,2}, {3,9,10}, {5,6}, {7,8}},1,⟨2362943178090,6265730992719⟩⟩,
  ⟨{{0,4}, {1,5,10}, {2,3}, {6,7}, {8,9}},1,⟨2406389962328,5025747430429⟩⟩,
  ⟨{{0,8,10}, {1,2}, {3,4}, {5,9}, {6,7}},1,⟨2405297900544,5779499060544⟩⟩
]

theorem checked12_1_22 : ∃ cert, Checked (rows11_0 22) rows12_1 1 cert :=
  ⟨routes12_1_22, by decide +kernel⟩

private def routes12_1_23 : List (Branch 11 22) := [
  ⟨{{0,1}, {2,3}, {4,7,10}, {5,6}, {8,9}},12,⟨1711356799746,3935515277287⟩⟩
]

theorem checked12_1_23 : ∃ cert, Checked (rows11_0 23) rows12_1 1 cert :=
  ⟨routes12_1_23, by decide +kernel⟩

theorem balanced12_1_12 : Balanced (rows12_1 12) := by decide +kernel

theorem balanced12_1_13 : Balanced (rows12_1 13) := by decide +kernel

theorem balanced12_1_14 : Balanced (rows12_1 14) := by decide +kernel

theorem balanced12_1_15 : Balanced (rows12_1 15) := by decide +kernel

theorem balanced12_1_16 : Balanced (rows12_1 16) := by decide +kernel

theorem balanced12_1_17 : Balanced (rows12_1 17) := by decide +kernel

theorem balanced12_1_18 : Balanced (rows12_1 18) := by decide +kernel

theorem balanced12_1_19 : Balanced (rows12_1 19) := by decide +kernel

theorem balanced12_1_20 : Balanced (rows12_1 20) := by decide +kernel

theorem balanced12_1_21 : Balanced (rows12_1 21) := by decide +kernel

end Cover61.Layers
