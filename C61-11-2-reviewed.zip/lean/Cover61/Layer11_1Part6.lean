import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem balanced11_1_72 : Balanced (rows11_1 72) := by decide +kernel

theorem balanced11_1_73 : Balanced (rows11_1 73) := by decide +kernel

theorem balanced11_1_74 : Balanced (rows11_1 74) := by decide +kernel

theorem balanced11_1_75 : Balanced (rows11_1 75) := by decide +kernel

theorem balanced11_1_76 : Balanced (rows11_1 76) := by decide +kernel

theorem balanced11_1_77 : Balanced (rows11_1 77) := by decide +kernel

theorem balanced11_1_78 : Balanced (rows11_1 78) := by decide +kernel

theorem balanced11_1_79 : Balanced (rows11_1 79) := by decide +kernel

theorem balanced11_1_80 : Balanced (rows11_1 80) := by decide +kernel

theorem balanced11_1_81 : Balanced (rows11_1 81) := by decide +kernel

theorem balanced11_1_82 : Balanced (rows11_1 82) := by decide +kernel

theorem balanced11_1_83 : Balanced (rows11_1 83) := by decide +kernel

end Cover61.Layers
