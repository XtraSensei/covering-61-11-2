import Cover61.CatalogueBridge
import Cover61.Catalog
import Cover61.Weights
import Cover61.NineCover
import Cover61.LayerData
namespace Cover61.Remainder
set_option maxRecDepth 60000
set_option maxHeartbeats 4000000
def live12_1 : Finset (Fin 22) := {1}
theorem keep12_1 (B : Family 38) (h : IsCover B) (j : Fin 22)
    (real : Weighted.Realizes B (Layers.rows12_1 j)) : j ∈ live12_1 := by
  fin_cases j
  · exact False.elim (Catalog.s12_059_01_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · decide +kernel
  · exact False.elim (Catalog.s12_059_03_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_04_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_05_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_06_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_07_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_08_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_09_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_10_excluded B h (pointed_of_realizes real 5
      [0,1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_11_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_12_excluded B h (pointed_of_realizes real 4
      [0,1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_13_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_14_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_15_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_16_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_17_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_18_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_19_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_20_excluded B h (pointed_of_realizes real 2
      [0,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_21_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
  · exact False.elim (Catalog.s12_059_22_excluded B h (pointed_of_realizes real 0
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37] (by decide +kernel) (by decide +kernel) (by decide +kernel) (by decide +kernel)))
end Cover61.Remainder
