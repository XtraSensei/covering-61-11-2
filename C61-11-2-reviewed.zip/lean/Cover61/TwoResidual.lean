import Cover61.ThreeResidual

namespace Cover61.LocalRows

variable (B : Family 38) (h : IsCover B) (i : Photo) (five : (marked B i).card=5)
variable (three : (groups B i).card=3)
include h five

theorem companion_residual_meet (x : Point) (hx : x ∈ ordinary B i) (z : Point) (hz : z ∈ companions B i) :
    ∃ j ∈ appearances B (residual B i) x,z ∈ B j := by
  have coord := (five_group_cover B h i five).1
  have ne : x≠z := fun e => ordinary_away B i hx coord (e ▸ (Finset.mem_sdiff.mp hz).1)
  obtain ⟨j,xj,zj⟩ := h.2 x z ne
  have ng : j ∉ groups B i := fun jg => ordinary_away B i hx jg xj
  have nc : j ∉ cells B i := fun jc => Finset.disjoint_left.mp (no_companion_cell B h i j jc) hz zj
  exact ⟨j,Finset.mem_filter.mpr ⟨Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,fun m => (Finset.mem_union.mp m).elim ng nc⟩,xj⟩,zj⟩

include three
theorem residual_pair (z : Point) (zh : z ∈ companions B i) (x : Point) (hx : x ∈ ordinary B i) :
    ∃ a b : Photo, appearances B (residual B i) x={a,b} ∧ z ∈ B a ∧ z ∉ B b := by
  have c := group_count_cases B h i five
  obtain ⟨_,n,ex⟩|⟨g,_⟩|⟨g,_⟩ := c <;> try omega
  have eq := total_excess B h
  have same : (∑ y,(degree B y-7))=excess B (companions B i) := by omega
  have dx := ordinary_seven B h i five same x hx
  have visits := ordinary_residual_visits B h i five x hx
  obtain ⟨a,b,ne,rows⟩ := Finset.card_eq_two.mp (by omega : (appearances B (residual B i) x).card=2)
  have ag : a ∈ residual B i := (Finset.mem_filter.mp (show a ∈ appearances B (residual B i) x by rw [rows];simp)).1
  have bg : b ∈ residual B i := (Finset.mem_filter.mp (show b ∈ appearances B (residual B i) x by rw [rows];simp)).1
  let H := companions B i
  have union : (H ∩ B a) ∪ (H ∩ B b)=H := by
    apply Finset.Subset.antisymm (Finset.union_subset Finset.inter_subset_left Finset.inter_subset_left)
    intro t th
    obtain ⟨j,jx,tj⟩ := companion_residual_meet B h i five x hx t th
    rw [rows,Finset.mem_insert,Finset.mem_singleton] at jx
    rcases jx with rfl|rfl
    · exact Finset.mem_union_left _ (Finset.mem_inter.mpr ⟨th,tj⟩)
    · exact Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨th,tj⟩)
  have counts := (group_three_sizes B h i five three).2.2.2
  have balance := Finset.card_union_add_card_inter (H ∩ B a) (H ∩ B b)
  rw [union] at balance
  change H.card+_ = amount B i a+amount B i b at balance
  rw [counts a ag,counts b bg] at balance
  have hc := companion_card B h i
  have six : H.card=6 := by change (companions B i).card=6;omega
  have empty : (H ∩ B a) ∩ (H ∩ B b)=∅ := Finset.card_eq_zero.mp (by omega)
  have only (za : z ∈ B a) (zb : z ∈ B b) : False := by
    have both := Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨zh,za⟩,Finset.mem_inter.mpr ⟨zh,zb⟩⟩
    exact Finset.notMem_empty z (empty ▸ both)
  have whereZ : z ∈ (H ∩ B a) ∪ (H ∩ B b) := by rw [union];exact zh
  rcases Finset.mem_union.mp whereZ with za|zb
  · exact ⟨a,b,rows,(Finset.mem_inter.mp za).2,only (Finset.mem_inter.mp za).2⟩
  · exact ⟨b,a,rows.trans (Finset.pair_comm a b),(Finset.mem_inter.mp zb).2,fun za => only za (Finset.mem_inter.mp zb).2⟩

theorem residual_row_capacity (j : Photo) (jr : j ∈ residual B i) : (ordinary B i ∩ B j).card≤8 := by
  let H := companions B i
  let S := ordinary B i ∩ B j
  have apart : Disjoint S (H ∩ B j) := Finset.disjoint_left.mpr (fun x hx hz =>
    ordinary_away B i (Finset.mem_inter.mp hx).1 (five_group_cover B h i five).1 (Finset.mem_sdiff.mp (Finset.mem_inter.mp hz).1).1)
  have lim := Finset.card_le_card (show S ∪ (H ∩ B j) ⊆ B j from Finset.union_subset Finset.inter_subset_right Finset.inter_subset_right)
  rw [Finset.card_union_of_disjoint apart,h.1] at lim
  change S.card+amount B i j ≤ 11 at lim
  rw [(group_three_sizes B h i five three).2.2.2 j jr] at lim
  change S.card≤8;omega

end Cover61.LocalRows
