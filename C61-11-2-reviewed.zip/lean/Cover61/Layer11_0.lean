import Mathlib.Tactic.FinCases
import Cover61.Layer11_0Part0
import Cover61.Layer11_0Part1
import Cover61.Layer11_0Part2
import Cover61.Layer11_0Part3
import Cover61.Layer11_0Part4
import Cover61.Layer11_0Part5
namespace Cover61.Layers
open Skeleton Growth
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
theorem steps11_0 (j : Fin 65) : ∃ cert, Checked (rows10_0 j) rows11_0 0 cert := by
  fin_cases j
  · exact checked11_0_0
  · exact checked11_0_1
  · exact checked11_0_2
  · exact checked11_0_3
  · exact checked11_0_4
  · exact checked11_0_5
  · exact checked11_0_6
  · exact checked11_0_7
  · exact checked11_0_8
  · exact checked11_0_9
  · exact checked11_0_10
  · exact checked11_0_11
  · exact checked11_0_12
  · exact checked11_0_13
  · exact checked11_0_14
  · exact checked11_0_15
  · exact checked11_0_16
  · exact checked11_0_17
  · exact checked11_0_18
  · exact checked11_0_19
  · exact checked11_0_20
  · exact checked11_0_21
  · exact checked11_0_22
  · exact checked11_0_23
  · exact checked11_0_24
  · exact checked11_0_25
  · exact checked11_0_26
  · exact checked11_0_27
  · exact checked11_0_28
  · exact checked11_0_29
  · exact checked11_0_30
  · exact checked11_0_31
  · exact checked11_0_32
  · exact checked11_0_33
  · exact checked11_0_34
  · exact checked11_0_35
  · exact checked11_0_36
  · exact checked11_0_37
  · exact checked11_0_38
  · exact checked11_0_39
  · exact checked11_0_40
  · exact checked11_0_41
  · exact checked11_0_42
  · exact checked11_0_43
  · exact checked11_0_44
  · exact checked11_0_45
  · exact checked11_0_46
  · exact checked11_0_47
  · exact checked11_0_48
  · exact checked11_0_49
  · exact checked11_0_50
  · exact checked11_0_51
  · exact checked11_0_52
  · exact checked11_0_53
  · exact checked11_0_54
  · exact checked11_0_55
  · exact checked11_0_56
  · exact checked11_0_57
  · exact checked11_0_58
  · exact checked11_0_59
  · exact checked11_0_60
  · exact checked11_0_61
  · exact checked11_0_62
  · exact checked11_0_63
  · exact checked11_0_64
theorem balanced11_0 (j : Fin 36) : Balanced (rows11_0 j) := by
  fin_cases j
  · exact balanced11_0_0
  · exact balanced11_0_1
  · exact balanced11_0_2
  · exact balanced11_0_3
  · exact balanced11_0_4
  · exact balanced11_0_5
  · exact balanced11_0_6
  · exact balanced11_0_7
  · exact balanced11_0_8
  · exact balanced11_0_9
  · exact balanced11_0_10
  · exact balanced11_0_11
  · exact balanced11_0_12
  · exact balanced11_0_13
  · exact balanced11_0_14
  · exact balanced11_0_15
  · exact balanced11_0_16
  · exact balanced11_0_17
  · exact balanced11_0_18
  · exact balanced11_0_19
  · exact balanced11_0_20
  · exact balanced11_0_21
  · exact balanced11_0_22
  · exact balanced11_0_23
  · exact balanced11_0_24
  · exact balanced11_0_25
  · exact balanced11_0_26
  · exact balanced11_0_27
  · exact balanced11_0_28
  · exact balanced11_0_29
  · exact balanced11_0_30
  · exact balanced11_0_31
  · exact balanced11_0_32
  · exact balanced11_0_33
  · exact balanced11_0_34
  · exact balanced11_0_35
end Cover61.Layers
