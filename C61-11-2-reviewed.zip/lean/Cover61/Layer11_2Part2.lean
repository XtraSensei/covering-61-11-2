import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes11_2_24 : List (Branch 10 54) := [
  ⟨{{0,8}, {1,4,7}, {2,5}, {3,6}, {9}},19,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_24 : ∃ cert, Checked (rows10_1 24) rows11_2 2 cert :=
  ⟨routes11_2_24, by decide +kernel⟩

private def routes11_2_25 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,6,8}, {3,7}, {4,5}, {9}},17,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_25 : ∃ cert, Checked (rows10_1 25) rows11_2 2 cert :=
  ⟨routes11_2_25, by decide +kernel⟩

private def routes11_2_26 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,6,8}, {3,7}, {4,5}, {9}},8,⟨166882672475,136253788575⟩⟩
]

theorem checked11_2_26 : ∃ cert, Checked (rows10_1 26) rows11_2 2 cert :=
  ⟨routes11_2_26, by decide +kernel⟩

private def routes11_2_27 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,6,8}, {3,7}, {4,5}, {9}},18,⟨258879076995,258879076995⟩⟩,
  ⟨{{0,5,6}, {1,8}, {2,4}, {3,7}, {9}},19,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_27 : ∃ cert, Checked (rows10_1 27) rows11_2 2 cert :=
  ⟨routes11_2_27, by decide +kernel⟩

private def routes11_2_28 : List (Branch 10 54) := [
  ⟨{{0,9}, {1}, {2,4,7}, {3,6}, {5,8}},14,⟨154714070185,239746968785⟩⟩,
  ⟨{{0,9}, {1}, {2,6,8}, {3,7}, {4,5}},14,⟨155111001005,239998527805⟩⟩
]

theorem checked11_2_28 : ∃ cert, Checked (rows10_1 28) rows11_2 2 cert :=
  ⟨routes11_2_28, by decide +kernel⟩

private def routes11_2_29 : List (Branch 10 54) := [
  
]

theorem checked11_2_29 : ∃ cert, Checked (rows10_1 29) rows11_2 2 cert :=
  ⟨routes11_2_29, by decide +kernel⟩

private def routes11_2_30 : List (Branch 10 54) := [
  
]

theorem checked11_2_30 : ∃ cert, Checked (rows10_1 30) rows11_2 2 cert :=
  ⟨routes11_2_30, by decide +kernel⟩

private def routes11_2_31 : List (Branch 10 54) := [
  
]

theorem checked11_2_31 : ∃ cert, Checked (rows10_1 31) rows11_2 2 cert :=
  ⟨routes11_2_31, by decide +kernel⟩

private def routes11_2_32 : List (Branch 10 54) := [
  
]

theorem checked11_2_32 : ∃ cert, Checked (rows10_1 32) rows11_2 2 cert :=
  ⟨routes11_2_32, by decide +kernel⟩

private def routes11_2_33 : List (Branch 10 54) := [
  
]

theorem checked11_2_33 : ∃ cert, Checked (rows10_1 33) rows11_2 2 cert :=
  ⟨routes11_2_33, by decide +kernel⟩

private def routes11_2_34 : List (Branch 10 54) := [
  
]

theorem checked11_2_34 : ∃ cert, Checked (rows10_1 34) rows11_2 2 cert :=
  ⟨routes11_2_34, by decide +kernel⟩

private def routes11_2_35 : List (Branch 10 54) := [
  ⟨{{0,7}, {1,4}, {2,6,8}, {3,5}, {9}},20,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,7}, {1,5,8}, {2,3}, {4,6}, {9}},20,⟨282456929975,282456929975⟩⟩
]

theorem checked11_2_35 : ∃ cert, Checked (rows10_1 35) rows11_2 2 cert :=
  ⟨routes11_2_35, by decide +kernel⟩

theorem balanced11_2_24 : Balanced (rows11_2 24) := by decide +kernel

theorem balanced11_2_25 : Balanced (rows11_2 25) := by decide +kernel

theorem balanced11_2_26 : Balanced (rows11_2 26) := by decide +kernel

theorem balanced11_2_27 : Balanced (rows11_2 27) := by decide +kernel

theorem balanced11_2_28 : Balanced (rows11_2 28) := by decide +kernel

theorem balanced11_2_29 : Balanced (rows11_2 29) := by decide +kernel

theorem balanced11_2_30 : Balanced (rows11_2 30) := by decide +kernel

theorem balanced11_2_31 : Balanced (rows11_2 31) := by decide +kernel

theorem balanced11_2_32 : Balanced (rows11_2 32) := by decide +kernel

theorem balanced11_2_33 : Balanced (rows11_2 33) := by decide +kernel

theorem balanced11_2_34 : Balanced (rows11_2 34) := by decide +kernel

theorem balanced11_2_35 : Balanced (rows11_2 35) := by decide +kernel

end Cover61.Layers
