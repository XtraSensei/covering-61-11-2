import Cover61.Growth

namespace Cover61.Growth
open Skeleton

def bound (q : Nat) := if q=0 then 3 else 4
def limited {n} (r : Rows n) (q : Nat) : Rows n := fun i =>
  if (r i).card < bound q then r i else ∅

theorem width {n} (r : Rows n) (q : Nat) (ok : Shape (big r) q) (i : Fin 38) : (r i).card ≤ bound q := by
  by_cases small : (r i).card < 3
  · unfold bound; split <;> omega
  have hi := (big_mem r _).mpr ⟨⟨i,rfl⟩,by omega⟩
  have le := ok.1 _ hi
  unfold bound; split
  next eq =>
    have few := ok.2.1.trans eq
    by_contra! no
    have inQ : r i ∈ quads (big r) := Finset.mem_filter.mpr ⟨hi,by omega⟩
    have pos := Finset.card_pos.mpr (show (quads (big r)).Nonempty from ⟨_,inQ⟩)
    omega
  next => exact le

structure Branch (n m : Nat) where
  parts : Sys n
  output : Fin m
  key : Code

def Checked {n m} (r : Rows n) (dest : Fin m → Rows (n+1)) (q : Nat)
    (cert : List (Branch n m)) : Prop :=
  (∀ P ∈ branches (limited r q) 6 Finset.univ, Shape (highAfter r P) q → P ∈ cert.map Branch.parts) ∧
  ∀ b ∈ cert, ValidCode (n+1) b.key ∧
    rename (digits (n+1) b.key.forward) (highAfter r b.parts) = big (dest b.output)
section
-- The ambient type of P has 2^(2^n) elements. Only generated partitions matter.
attribute [local instance 2000] Finset.decidableDforallFinset
instance {n m} (r : Rows n) (dest : Fin m → Rows (n+1)) (q : Nat) (cert : List (Branch n m)) :
    Decidable (Checked r dest q cert) := by unfold Checked; infer_instance
end

theorem checked_sound {n m} (r : Rows n) (dest : Fin m → Rows (n+1)) (q : Nat)
    (cert : List (Branch n m)) (checked : Checked r dest q cert)
    (T : Finset (Fin 38)) (count : T.card=6) (fits : Weighted.Fits r T Finset.univ)
    (bal : Balanced r) (child : Balanced (extension r T)) (out : ∀ k, Balanced (dest k))
    (shape : Shape (big (extension r T)) q) : ∃ k, Similar (extension r T) (dest k) := by
  let v := limited r q
  have agrees (i : Fin 38) (hi : i ∈ T) : v i = r i := by
    have max := width (extension r T) q shape i
    simp [extension,hi] at max
    exact if_pos (show (r i).card < bound q by omega)
  have same : picks v T = picks r T := by
    unfold picks
    rw [Finset.image_congr agrees]
  have valid : Weighted.Fits v T Finset.univ := by
    intro x
    have eq := Finset.filter_congr (s := T) (p := fun i => x ∈ v i) (q := fun i => x ∈ r i)
      (fun i hi => by rw [agrees i hi])
    rw [eq]; exact fits x
  have generated := branches_complete v 6 T Finset.univ valid count.le
  rw [same] at generated
  rw [high_extension r bal] at shape
  obtain ⟨b,hb,eq⟩ := List.mem_map.mp (checked.1 _ generated shape)
  obtain ⟨key,check⟩ := checked.2 b hb
  refine ⟨b.output,similar_of_big child (out _) ⟨permutation _ key,?_⟩⟩
  rw [high_extension r bal,← eq]; exact check

end Cover61.Growth
