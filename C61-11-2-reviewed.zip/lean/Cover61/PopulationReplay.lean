import Cover61.IntervalPrice
import Mathlib.Data.List.FinRange

namespace Cover61.Population
open Prices

structure Bounds (n : Nat) where
  lo : Fin n→Int
  hi : Fin n→Int

def Bounds.contains {n} (b : Bounds n) (x : Fin n→Int) := (∀ j,b.lo j≤x j) ∧ ∀ j,x j≤b.hi j

def maximum {n} (b : Bounds n) (r : Row n) := ∑ j,Replay.highTerm (r.coeff j) (b.lo j) (b.hi j)

theorem maximum_bound {n} (b : Bounds n) (r : Row n) (x : Fin n→Int) (mem : b.contains x) :
    eval r.coeff x≤maximum b r := by
  apply Finset.sum_le_sum
  intro j _
  unfold Replay.highTerm
  split
  next h => exact Int.mul_le_mul_of_nonneg_left (mem.2 j) h
  next h => exact mul_le_mul_of_nonpos_left (mem.1 j) (le_of_not_ge h)

def narrow {n} (b : Bounds n) (r : Row n) : Bounds n where
  lo j := if 0<r.coeff j then max (b.lo j) (b.hi j-(maximum b r-r.rhs)/r.coeff j) else b.lo j
  hi j := if r.coeff j<0 then min (b.hi j) (b.lo j+(maximum b r-r.rhs)/(-r.coeff j)) else b.hi j

theorem narrow_sound {n} (b : Bounds n) (r : Row n) (x : Fin n→Int) (mem : b.contains x)
    (valid : r.rhs≤eval r.coeff x) : (narrow b r).contains x := by
  constructor
  · intro j
    by_cases pos : 0<r.coeff j
    · simp only [narrow,if_pos pos,maximum]
      apply max_le (mem.1 j)
      exact (Replay.tighten_positive r.coeff b.lo b.hi x mem.1 mem.2 j pos r.rhs 0).1 valid
    · simpa [narrow,pos] using mem.1 j
  · intro j
    by_cases neg : r.coeff j<0
    · simp only [narrow,if_pos neg,maximum]
      apply le_min (mem.2 j)
      exact (Replay.tighten_negative r.coeff b.lo b.hi x mem.1 mem.2 j neg r.rhs 0).1 valid
    · simpa [narrow,neg] using mem.2 j

def upperRow {n} (a : Fin n→Int) (R : Int) : Row n := ⟨fun j => -a j,-R⟩
theorem upperRow_valid {n} (a x : Fin n→Int) (R : Int) (valid : eval a x≤R) :
    (upperRow a R).rhs≤eval (upperRow a R).coeff x := by
  simpa [upperRow,eval,neg_mul,Finset.sum_neg_distrib] using neg_le_neg valid

def fix {n} (b : Bounds n) (j : Fin n) (v : Int) : Bounds n :=
  ⟨Function.update b.lo j v,Function.update b.hi j v⟩

theorem fix_sound {n} (b : Bounds n) (x : Fin n→Int) (mem : b.contains x) (j : Fin n) :
    (fix b j (x j)).contains x := by
  constructor <;> intro k <;> by_cases eq : k=j
  · subst k;simp [fix]
  · simpa [fix,Function.update_of_ne eq] using mem.1 k
  · subst k;simp [fix]
  · simpa [fix,Function.update_of_ne eq] using mem.2 k

inductive Tree (n m p : Nat) where
  | empty
  | fixed (output : Fin p)
  | price (row : Fin m) (next : Tree n m p)
  | split (j : Fin n) (k : Nat) (kids : Fin k→Tree n m p)

def check {n m p} (row : Bounds n→Fin m→Row n) (output : Fin p→Fin n→Int) :
    Tree n m p → Bounds n → Bool
  | .empty,b => decide (∃ j,b.hi j<b.lo j)
  | .fixed i,b => decide (∀ j,b.lo j=output i j ∧ b.hi j=output i j)
  | .price i t,b => decide (maximum b (row b i)<(row b i).rhs) || check row output t (narrow b (row b i))
  | .split j k kids,b => decide (b.lo j+(k:Int)=b.hi j+1) &&
      (List.finRange k).all (fun i => check row output (kids i) (fix b j (b.lo j+(i.val:Int))))

/-- An exhaustive integer box tree either excludes a candidate or returns
one of the recorded complete populations. Empty output lists certify impossibility. -/
theorem sound {n m p} (row : Bounds n→Fin m→Row n) (output : Fin p→Fin n→Int) (x : Fin n→Int)
    (valid : ∀ b,b.contains x → ∀ i,(row b i).rhs≤eval (row b i).coeff x) (t : Tree n m p)
    (b : Bounds n) (mem : b.contains x) (accepted : check row output t b=true) : ∃ i,x=output i := by
  induction t generalizing b with
  | empty =>
    obtain ⟨j,bad⟩ := of_decide_eq_true accepted
    exact False.elim ((not_lt_of_ge ((mem.1 j).trans (mem.2 j))) bad)
  | fixed i =>
    have both := of_decide_eq_true accepted
    exact ⟨i,funext (fun j => by have := both j;have := mem.1 j;have := mem.2 j;omega)⟩
  | price i t ih =>
    obtain bad|next := Bool.or_eq_true_iff.mp accepted
    · exact False.elim ((not_lt_of_ge ((valid b mem i).trans (maximum_bound b _ x mem))) (of_decide_eq_true bad))
    · exact ih _ (narrow_sound b _ x mem (valid b mem i)) next
  | split j k kids ih =>
    obtain ⟨length,all⟩ := Bool.and_eq_true_iff.mp accepted
    have exactLength := of_decide_eq_true length
    have lo := mem.1 j;have hi := mem.2 j
    let i : Fin k := ⟨(x j-b.lo j).toNat,by omega⟩
    have same : b.lo j+(i.val:Int)=x j := by dsimp [i];omega
    have next := List.all_eq_true.mp all i (List.mem_finRange i)
    rw [same] at next
    exact ih i _ (fix_sound b x mem j) next

end Cover61.Population
