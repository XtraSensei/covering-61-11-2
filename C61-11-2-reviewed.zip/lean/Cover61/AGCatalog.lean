import Cover61.AGExclude

namespace Cover61.Catalog
open Affine Weighted

/-- Transport a projected incidence pattern under renamings of labels and blocks. -/
theorem relabel {n : Nat} {r t : Rows n} (p : Equiv.Perm (Fin n)) (e : Equiv.Perm Photo)
    (matchRows : ∀ i x, x ∈ t i ↔ p x ∈ r (e i)) {B : Family 38} :
    Realizes B r → Realizes B t := by
  rintro ⟨labels,photos,six,rows⟩
  refine ⟨p.toEmbedding.trans labels,e.trans photos,fun x => six (p x),?_⟩
  intro i
  ext x
  rw [matchRows,← rows]
  simp [Partitions.lowRow]

def s9_49Rows : Rows 9 := fun i =>
  ([{0,1,2}, {0,3,4}, {0,5,6}, {0,7,8}, {1,3,5}, {1,4,7}, {2,3,8}, {2,4,6}, {1,6,8}, {2,5,7}, {3,6,7}, {4,5,8}, {0}, {0}, {1}, {1}, {2}, {2}, {3}, {3}, {4}, {4}, {5}, {5}, {6}, {6}, {7}, {7}, {8}, {8}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 9)))[i.val]'(i.isLt)

private def renameLabels : Equiv.Perm (Fin 9) :=
  ⟨fun i => ([0,1,2,3,6,7,4,8,5] : List (Fin 9))[i.val]'(i.isLt),
    fun i => ([0,1,2,3,6,8,4,5,7] : List (Fin 9))[i.val]'(i.isLt), by decide +kernel, by decide +kernel⟩

private def renamePhotos : Equiv.Perm (Fin 38) :=
  ⟨fun i => ([0,10,11,1,8,9,2,5,6,3,4,7,13,12,15,14,17,16,19,18,25,24,27,26,21,20,29,28,23,22,37,36,35,34,33,32,31,30] : List (Fin 38))[i.val]'(i.isLt),
    fun i => ([0,3,6,9,10,7,8,11,4,5,1,2,13,12,15,14,17,16,19,18,25,24,29,28,21,20,23,22,27,26,37,36,35,34,33,32,31,30] : List (Fin 38))[i.val]'(i.isLt), by decide +kernel, by decide +kernel⟩
 
private theorem matching : ∀ i x, x ∈ planeRows i ↔ renameLabels x ∈ s9_49Rows (renamePhotos i) := by decide +kernel

theorem s9_49_excluded (B : Family 38) (h : IsCover B) (nine : (lows B).card=9) :
    ¬ Realizes B s9_49Rows :=
  fun witness => Affine.excluded B h nine (relabel renameLabels renamePhotos matching witness)

end Cover61.Catalog
