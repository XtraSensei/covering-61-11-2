import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes12_2_36 : List (Branch 11 23) := [
  
]

theorem checked12_2_36 : ∃ cert, Checked (rows11_1 36) rows12_2 2 cert :=
  ⟨routes12_2_36, by decide +kernel⟩

private def routes12_2_37 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,3}, {4,7,9}, {5}, {6}, {8,10}},16,⟨3126638923738,5975622330953⟩⟩,
  ⟨{{0,6,8}, {1,3}, {2,7}, {4}, {5}, {9,10}},16,⟨3212378509637,5779623100361⟩⟩
]

theorem checked12_2_37 : ∃ cert, Checked (rows11_1 37) rows12_2 2 cert :=
  ⟨routes12_2_37, by decide +kernel⟩

private def routes12_2_38 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,3}, {4,5,8}, {6,10}, {7}, {9}},14,⟨3145350567205,4691403114343⟩⟩,
  ⟨{{0,3}, {1,5}, {2,6,9}, {4,10}, {7}, {8}},20,⟨4560937750226,6219181235641⟩⟩,
  ⟨{{0,4}, {1,3}, {2,6,9}, {5,10}, {7}, {8}},21,⟨4499020347998,6157693853014⟩⟩
]

theorem checked12_2_38 : ∃ cert, Checked (rows11_1 38) rows12_2 2 cert :=
  ⟨routes12_2_38, by decide +kernel⟩

private def routes12_2_39 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,6}, {2,8}, {4,7,9}, {5,10}},4,⟨2479369055009,1679317629033⟩⟩,
  ⟨{{0,4}, {1,6}, {2,3,5}, {7}, {8}, {9,10}},16,⟨2531287503173,5779623081353⟩⟩
]

theorem checked12_2_39 : ∃ cert, Checked (rows11_1 39) rows12_2 2 cert :=
  ⟨routes12_2_39, by decide +kernel⟩

private def routes12_2_40 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,4,6}, {7}, {8,10}, {9}},8,⟨2511489021965,5276941633062⟩⟩,
  ⟨{{0,2}, {1,6}, {3,7,8}, {4,10}, {5}, {9}},13,⟨4470365386069,1003861869274⟩⟩
]

theorem checked12_2_40 : ∃ cert, Checked (rows11_1 40) rows12_2 2 cert :=
  ⟨routes12_2_40, by decide +kernel⟩

private def routes12_2_41 : List (Branch 11 23) := [
  ⟨{{0,2}, {1,5}, {3,4,6}, {7,10}, {8}, {9}},9,⟨396776354249,1275534926831⟩⟩,
  ⟨{{0,2}, {1,6}, {3,7,8}, {4,10}, {5}, {9}},13,⟨3728538989835,3047148793942⟩⟩
]

theorem checked12_2_41 : ∃ cert, Checked (rows11_1 41) rows12_2 2 cert :=
  ⟨routes12_2_41, by decide +kernel⟩

private def routes12_2_42 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,5}, {2,6,9}, {4,10}, {7}, {8}},3,⟨388890531920,2311792540739⟩⟩
]

theorem checked12_2_42 : ∃ cert, Checked (rows11_1 42) rows12_2 2 cert :=
  ⟨routes12_2_42, by decide +kernel⟩

private def routes12_2_43 : List (Branch 11 23) := [
  
]

theorem checked12_2_43 : ∃ cert, Checked (rows11_1 43) rows12_2 2 cert :=
  ⟨routes12_2_43, by decide +kernel⟩

private def routes12_2_44 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,6}, {2,3,5}, {7}, {8,10}, {9}},15,⟨1764456910810,5975622310361⟩⟩
]

theorem checked12_2_44 : ∃ cert, Checked (rows11_1 44) rows12_2 2 cert :=
  ⟨routes12_2_44, by decide +kernel⟩

private def routes12_2_45 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,8,9}, {2,7}, {4,10}, {5}, {6}},7,⟨383379142916,1816524252455⟩⟩,
  ⟨{{0,5,9}, {1,3}, {2,8}, {4,10}, {6}, {7}},21,⟨3125971892274,3473573773615⟩⟩
]

theorem checked12_2_45 : ∃ cert, Checked (rows11_1 45) rows12_2 2 cert :=
  ⟨routes12_2_45, by decide +kernel⟩

private def routes12_2_46 : List (Branch 11 23) := [
  ⟨{{0,4}, {1,3}, {2,6,9}, {5}, {7,10}, {8}},22,⟨1070089481219,90881093798⟩⟩,
  ⟨{{0,1,7}, {2,8}, {3,9}, {4}, {5}, {6,10}},18,⟨2526175195214,4134143596627⟩⟩,
  ⟨{{0,5,9}, {1,3}, {2,7}, {4}, {6,10}, {8}},9,⟨3189164062865,5332839272552⟩⟩
]

theorem checked12_2_46 : ∃ cert, Checked (rows11_1 46) rows12_2 2 cert :=
  ⟨routes12_2_46, by decide +kernel⟩

private def routes12_2_47 : List (Branch 11 23) := [
  ⟨{{0,3}, {1,5}, {2,6,9}, {4}, {7,10}, {8}},19,⟨3799305617866,5227511379387⟩⟩,
  ⟨{{0,1,7}, {2,8}, {3,9}, {4}, {5,10}, {6}},17,⟨2526177932366,4815234603091⟩⟩,
  ⟨{{0,5,9}, {1,3}, {2,8}, {4}, {6}, {7,10}},12,⟨2485219687610,4557245585585⟩⟩
]

theorem checked12_2_47 : ∃ cert, Checked (rows11_1 47) rows12_2 2 cert :=
  ⟨routes12_2_47, by decide +kernel⟩

end Cover61.Layers
