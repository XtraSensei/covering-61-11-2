import Cover61.Weighted

namespace Cover61.Catalog

open Weighted

set_option maxRecDepth 100000

set_option maxHeartbeats 10000000

def w12_060_01Rows : Rows 12 := fun i =>
  ([{2}, {3}, {0,1,2,3}, {0,4}, {1,4}, {0,5}, {1,5}, {6}, {7}, {4,5,6,7}, {3,5,8}, {0,6,8}, {2,7,8}, {2,4,9}, {1,6,9}, {3,7,9}, {8,9}, {3,4,10}, {2,6,10}, {0,7,10}, {1,8,10}, {5,9,10}, {2,5,11}, {3,6,11}, {1,7,11}, {4,8,11}, {0,9,11}, {10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 12)))[i.val]'(i.isLt)

private def w12_060_01Cost : Cost := fun i =>
  ([0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w12_060_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w12_060_01Rows :=
  Weighted.exclude _ w12_060_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w12_073_01Rows : Rows 12 := fun i =>
  ([{0}, {1}, {2}, {3}, {0,1,2,3}, {4}, {5}, {6}, {7}, {4,5,6,7}, {8}, {0,4,8}, {2,5,8}, {1,6,8}, {3,7,8}, {9}, {1,4,9}, {0,5,9}, {3,6,9}, {2,7,9}, {10}, {2,4,10}, {3,5,10}, {0,6,10}, {1,7,10}, {11}, {3,4,11}, {1,5,11}, {2,6,11}, {0,7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 12)))[i.val]'(i.isLt)

private def w12_073_01Cost : Cost := fun i =>
  ([1, 1, 1, 1, 4, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w12_073_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w12_073_01Rows :=
  Weighted.exclude _ w12_073_01Cost (4) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w12_123_01Rows : Rows 12 := fun i =>
  ([{1}, {2}, {3}, {0,1,2,3}, {0,4}, {5}, {6}, {7}, {4,5,6,7}, {0,8}, {4,8}, {2,5,8}, {1,6,8}, {3,7,8}, {9}, {1,4,9}, {0,5,9}, {3,6,9}, {2,7,9}, {10}, {2,4,10}, {3,5,10}, {0,6,10}, {1,7,10}, {11}, {3,4,11}, {1,5,11}, {2,6,11}, {0,7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 12)))[i.val]'(i.isLt)

private def w12_123_01Cost : Cost := fun i =>
  ([1, 1, 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w12_123_01_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w12_123_01Rows :=
  Weighted.exclude _ w12_123_01Cost (1) (by decide +kernel) (by decide +kernel) (by decide +kernel)

def w12_123_02Rows : Rows 12 := fun i =>
  ([{1}, {2}, {3}, {0,1,2,3}, {0,4}, {5}, {6}, {7}, {4,5,6,7}, {0,8}, {4,8}, {1,5,8}, {2,6,8}, {3,7,8}, {9}, {1,4,9}, {0,5,9}, {3,6,9}, {2,7,9}, {10}, {2,4,10}, {3,5,10}, {0,6,10}, {1,7,10}, {11}, {3,4,11}, {2,5,11}, {1,6,11}, {0,7,11}, {8,9,10,11}, ∅, ∅, ∅, ∅, ∅, ∅, ∅, ∅] : List (Finset (Fin 12)))[i.val]'(i.isLt)

private def w12_123_02Cost : Cost := fun i =>
  ([0, 0, 1, 0, 0, 1, 1, 0, 0, -2, 0, 0, 0, 0, 0, 1, 0, -1, -3, 0, 1, -1, 0, -3, 1, 3, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] : List Int)[i.val]'(i.isLt)

theorem w12_123_02_excluded : ∀ B : Family 38, IsCover B → ¬ Realizes B w12_123_02Rows :=
  Weighted.exclude _ w12_123_02Cost (0) (by decide +kernel) (by decide +kernel) (by decide +kernel)

end Cover61.Catalog
