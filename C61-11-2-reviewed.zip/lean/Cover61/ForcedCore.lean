import Cover61.RowHistogram

namespace Cover61.Skeleton

def core {n : Nat} (H : Sys n) : Sys n := H ∪
  ((Finset.univ : Row n).powersetCard 2).filter (fun s => ¬ ∃ t ∈ H, s ⊆ t)
def feasible {n : Nat} (H : Sys n) : Prop := ∀ x : Fin n, ((core H).filter (fun s => x ∈ s)).card ≤ 6
instance {n : Nat} (H : Sys n) : Decidable (feasible H) := by unfold feasible; infer_instance

theorem core_present {n : Nat} (r : Rows n) (reg : Regular r) :
    core (diagram r) ⊆ Finset.univ.image r := by
  intro s hs
  rcases Finset.mem_union.mp hs with inH | pair
  · exact (Finset.mem_filter.mp inH).1
  obtain ⟨hc,hole⟩ := Finset.mem_filter.mp pair
  obtain ⟨x,y,ne,rfl⟩ := Finset.card_eq_two.mp (Finset.mem_powersetCard.mp hc).2
  have hit := reg.2.2 x y ne
  obtain ⟨i,hi⟩ := Finset.card_pos.mp (show 0 < (containing r {x,y}).card by change 0 < tally r {x,y}; omega)
  have sub := (Finset.mem_filter.mp hi).2
  have upper := reg.1 i
  have few : (r i).card ≠ 3 := fun eq => hole ⟨r i,(mem_diagram _ _).mpr ⟨⟨i,rfl⟩,eq⟩,sub⟩
  have size : ({x,y} : Row n).card = 2 := by simp [ne]
  have eq := Finset.eq_of_subset_of_card_le sub (by omega)
  exact Finset.mem_image.mpr ⟨i,Finset.mem_univ _,eq.symm⟩

theorem feasible_of_regular {n : Nat} (r : Rows n) (reg : Regular r) : feasible (diagram r) := by
  intro x
  have sub : (core (diagram r)).filter (fun s => x ∈ s) ⊆ (containing r {x}).image r := by
    intro s hs
    obtain ⟨hc,hx⟩ := Finset.mem_filter.mp hs
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp (core_present r reg hc)
    exact Finset.mem_image.mpr ⟨i,by simp [containing,hx],rfl⟩
  exact ((Finset.card_le_card sub).trans Finset.card_image_le).trans_eq (reg.2.1 x)

def push {n : Nat} (p : Equiv.Perm (Fin n)) (r : Rows n) : Rows n :=
  fun i => (r i).image p

theorem push_mem {n : Nat} (p : Equiv.Perm (Fin n)) (r : Rows n) (i x) :
    x ∈ push p r i ↔ p.symm x ∈ r i := by
  constructor
  · intro hx
    obtain ⟨z,hz,rfl⟩ := Finset.mem_image.mp hx
    simpa using hz
  · intro hx
    exact Finset.mem_image.mpr ⟨_,hx,p.apply_symm_apply _⟩

theorem push_diagram {n : Nat} (p : Equiv.Perm (Fin n)) (r : Rows n) :
    diagram (push p r) = rename p (diagram r) := by
  ext s
  rw [mem_diagram]
  constructor
  · rintro ⟨⟨i,rfl⟩,sz⟩
    refine Finset.mem_image.mpr ⟨r i,(mem_diagram _ _).mpr ⟨⟨i,rfl⟩,?_⟩,rfl⟩
    simpa [push,Finset.card_image_of_injective _ p.injective] using sz
  · intro hs
    obtain ⟨w,hw,rfl⟩ := Finset.mem_image.mp hs
    obtain ⟨⟨i,rfl⟩,sz⟩ := (mem_diagram _ _).mp hw
    exact ⟨⟨i,rfl⟩,(Finset.card_image_of_injective _ p.injective).trans sz⟩

theorem push_regular {n : Nat} (p : Equiv.Perm (Fin n)) (r : Rows n) (reg : Regular r) :
    Regular (push p r) := by
  refine ⟨fun i => (Finset.card_image_of_injective _ p.injective).le.trans (reg.1 i),?_,?_⟩
  · intro x
    simpa [tally,containing,push_mem] using reg.2.1 (p.symm x)
  · intro x y ne
    simpa [tally,containing,Finset.insert_subset_iff,push_mem] using reg.2.2 (p.symm x) (p.symm y) (p.symm.injective.ne ne)

theorem realizes_of_iso {n : Nat} (B : Family 38) (h : IsCover B) (labels : Fin n ↪ Point)
    (six : ∀ x, degree B (labels x)=6) (width : ∀ i, (Partitions.lowRow B labels i).card ≤ 3)
    (t : Rows n) (regT : Regular t) (iso : Iso (diagram (Partitions.lowRow B labels)) (diagram t)) :
    Weighted.Realizes B t := by
  let r := Partitions.lowRow B labels
  obtain ⟨q,eq⟩ := iso
  have reg := regular_projection B h labels six width
  have same : diagram (push q r) = diagram t := (push_diagram q r).trans eq
  obtain ⟨e,he⟩ := arrange (push q r) t (fiber_sizes _ _ (tallies _ _ (push_regular q _ reg) regT same))
  refine ⟨q.symm.toEmbedding.trans labels,e,fun j => six (q.symm j),?_⟩
  intro i
  rw [← he i]
  ext x
  rw [push_mem]
  simp [Partitions.lowRow,r]

end Cover61.Skeleton
