import Cover61.NoQuadData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

theorem noQuadCheck0 : ∃ cert, Checked (rows11_0 0) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck1 : ∃ cert, Checked (rows11_0 1) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck2 : ∃ cert, Checked (rows11_0 2) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck3 : ∃ cert, Checked (rows11_0 3) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck4 : ∃ cert, Checked (rows11_0 4) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck5 : ∃ cert, Checked (rows11_0 5) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck6 : ∃ cert, Checked (rows11_0 6) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck7 : ∃ cert, Checked (rows11_0 7) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck8 : ∃ cert, Checked (rows11_0 8) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck9 : ∃ cert, Checked (rows11_0 9) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck10 : ∃ cert, Checked (rows11_0 10) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

theorem noQuadCheck11 : ∃ cert, Checked (rows11_0 11) rows12_0 0 cert :=
  ⟨[], by decide +kernel⟩

end Cover61.Layers

