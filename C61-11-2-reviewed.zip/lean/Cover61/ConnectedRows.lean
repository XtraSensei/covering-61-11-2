import Cover61.IntegerBounds

namespace Cover61.Cuts

inductive Linked {b : Nat} (visits : Point→Finset (Fin b)) : Finset (Fin b) → Nat → Prop
  | first (x : Point) (non : (visits x).Nonempty) : Linked visits (visits x) ((visits x).card-1)
  | attach {U k} (h : Linked visits U k) (x : Point) (touch : (U ∩ visits x).Nonempty) :
      Linked visits (U ∪ visits x) (k+((visits x).card-1))

theorem linked_capacity {b : Nat} (B : Family b) (size : ∀ j,(B j).card=11) (visits : Point→Finset (Fin b))
    (attends : ∀ x,∀ j ∈ visits x,x ∈ B j) {U k} (linked : Linked visits U k) : (U.biUnion B).card≤11+10*k := by
  induction linked with
  | first x non =>
    obtain ⟨j,hj⟩ := non
    have touch : (({j} : Finset (Fin b)) ∩ visits x).Nonempty := ⟨j,Finset.mem_inter.mpr ⟨Finset.mem_singleton_self _,hj⟩⟩
    have bound := attached_blocks B size {j} (visits x) x (attends x) touch
    rw [Finset.union_eq_right.mpr (Finset.singleton_subset_iff.mpr hj)] at bound
    simpa [size] using bound
  | attach head x touch ih =>
    have bound := attached_blocks B size _ _ x (attends x) touch
    omega

/-- People required to meet a connected family of population types in the
unfilled blocks fit in the union of those blocks. -/
theorem connected_neighbors {b : Nat} (B : Family b) (size : ∀ j,(B j).card=11) (visits : Point→Finset (Fin b))
    (attends : ∀ x,∀ j ∈ visits x,x ∈ B j) {U k} (linked : Linked visits U k) (N : Finset Point)
    (required : ∀ y ∈ N,∃ j ∈ U,y ∈ B j) : N.card≤11+10*k := by
  apply (Finset.card_le_card _).trans (linked_capacity B size visits attends linked)
  intro y hy
  obtain ⟨j,mem,yj⟩ := required y hy
  exact Finset.mem_biUnion.mpr ⟨j,mem,yj⟩

end Cover61.Cuts
