import Cover61.FourGroups
import Cover61.ThreeGroups
import Cover61.StructuralCover

namespace Cover61
open LocalRows

theorem no_five_low_points (B : Family 38) (h : IsCover B) (i : Fin 38) : (marked B i).card≤4 := by
  have bound := marked_width_five B h i
  by_contra! many
  have five : (marked B i).card=5 := by omega
  rcases group_count_cases B h i five with ⟨g,a,d⟩|⟨g,a⟩|⟨g,a⟩
  · exact three_groups_impossible B h i five g a d
  · exact four_groups_impossible B h i five g a
  · have top := at_most_twenty B h
    by_cases n : (lows B).card=19
    · exact nineteen_no_five_groups B h i five n g
    · have four := twenty_groups B h i five (by omega)
      omega

theorem low_count_range (B : Family 38) (h : IsCover B) : 9≤(lows B).card ∧ (lows B).card≤12 :=
  ⟨by have := total_excess B h;omega,at_most_twelve_of_width_four B h (no_five_low_points B h)⟩

end Cover61
