import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes11_2_72 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,5,8}, {3,6}, {4,7}, {9}},40,⟨258680372005,258680372005⟩⟩
]

theorem checked11_2_72 : ∃ cert, Checked (rows10_1 72) rows11_2 2 cert :=
  ⟨routes11_2_72, by decide +kernel⟩

private def routes11_2_73 : List (Branch 10 54) := [
  ⟨{{0}, {1,7}, {2,6,8}, {3}, {4,5}, {9}},26,⟨162413244975,45384582875⟩⟩,
  ⟨{{0,7,8}, {1}, {2,9}, {3}, {4,5}, {6}},0,⟨75678617375,233739000975⟩⟩,
  ⟨{{0,7,8}, {1}, {2,9}, {3,6}, {4,5}},20,⟨24303316915,233699770215⟩⟩,
  ⟨{{0,9}, {1,7}, {2,6,8}, {3}, {4,5}},42,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_73 : ∃ cert, Checked (rows10_1 73) rows11_2 2 cert :=
  ⟨routes11_2_73, by decide +kernel⟩

private def routes11_2_74 : List (Branch 10 54) := [
  ⟨{{0}, {1,3,5}, {2}, {4,8}, {6,7}, {9}},26,⟨68095337335,45382811435⟩⟩,
  ⟨{{0,3,4}, {1}, {2}, {5,8}, {6,7}, {9}},25,⟨140557467555,14728734355⟩⟩,
  ⟨{{0,3,4}, {1,8}, {2}, {5,7}, {6}, {9}},7,⟨48771587545,22668272245⟩⟩,
  ⟨{{0,3,4}, {1,8}, {2,5}, {6,7}, {9}},42,⟨163851073715,5475526915⟩⟩,
  ⟨{{0,9}, {1,3,5}, {2}, {4,8}, {6,7}},42,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_74 : ∃ cert, Checked (rows10_1 74) rows11_2 2 cert :=
  ⟨routes11_2_74, by decide +kernel⟩

private def routes11_2_75 : List (Branch 10 54) := [
  
]

theorem checked11_2_75 : ∃ cert, Checked (rows10_1 75) rows11_2 2 cert :=
  ⟨routes11_2_75, by decide +kernel⟩

private def routes11_2_76 : List (Branch 10 54) := [
  ⟨{{0}, {1,7}, {2,6,8}, {3}, {4,5}, {9}},42,⟨93112642985,5473756685⟩⟩
]

theorem checked11_2_76 : ∃ cert, Checked (rows10_1 76) rows11_2 2 cert :=
  ⟨routes11_2_76, by decide +kernel⟩

private def routes11_2_77 : List (Branch 10 54) := [
  ⟨{{0}, {1,8}, {2,3,7}, {4,5}, {6}, {9}},14,⟨187740071995,43081377895⟩⟩,
  ⟨{{0,7,8}, {1}, {2,6}, {3}, {4,5}, {9}},14,⟨188186502355,174043545655⟩⟩,
  ⟨{{0,7,8}, {1}, {2,6}, {3,9}, {4,5}},31,⟨125537733595,22437131195⟩⟩,
  ⟨{{0,9}, {1,8}, {2,3,7}, {4,5}, {6}},31,⟨125760962075,100250217475⟩⟩
]

theorem checked11_2_77 : ∃ cert, Checked (rows10_1 77) rows11_2 2 cert :=
  ⟨routes11_2_77, by decide +kernel⟩

private def routes11_2_78 : List (Branch 10 54) := [
  
]

theorem checked11_2_78 : ∃ cert, Checked (rows10_1 78) rows11_2 2 cert :=
  ⟨routes11_2_78, by decide +kernel⟩

private def routes11_2_79 : List (Branch 10 54) := [
  
]

theorem checked11_2_79 : ∃ cert, Checked (rows10_1 79) rows11_2 2 cert :=
  ⟨routes11_2_79, by decide +kernel⟩

private def routes11_2_80 : List (Branch 10 54) := [
  ⟨{{0,7,8}, {1}, {2,4}, {3,6}, {5}, {9}},13,⟨218999125735,98959536435⟩⟩,
  ⟨{{0,7,8}, {1}, {2,5}, {3,6}, {4,9}},19,⟨48741880615,22237544915⟩⟩,
  ⟨{{0,7,8}, {1}, {2,6}, {3}, {4,9}, {5}},0,⟨49955551655,233739000755⟩⟩
]

theorem checked11_2_80 : ∃ cert, Checked (rows10_1 80) rows11_2 2 cert :=
  ⟨routes11_2_80, by decide +kernel⟩

private def routes11_2_81 : List (Branch 10 54) := [
  ⟨{{0,7,8}, {1}, {2,4}, {3,6}, {5}, {9}},12,⟨188170530355,122168669855⟩⟩,
  ⟨{{0,7,8}, {1}, {2,5}, {3,6}, {4}, {9}},18,⟨48741880615,22237544915⟩⟩,
  ⟨{{0,7,8}, {1}, {2,6}, {3,9}, {4}, {5}},0,⟨24035990405,233756277105⟩⟩,
  ⟨{{0,9}, {1}, {2,3,7}, {4}, {5}, {6,8}},18,⟨75573575445,240971336845⟩⟩
]

theorem checked11_2_81 : ∃ cert, Checked (rows10_1 81) rows11_2 2 cert :=
  ⟨routes11_2_81, by decide +kernel⟩

private def routes11_2_82 : List (Branch 10 54) := [
  ⟨{{0,1,2}, {3,8}, {4}, {5}, {6,7}, {9}},17,⟨84536440785,45725877885⟩⟩,
  ⟨{{0,1,2}, {3,9}, {4}, {5,7}, {6,8}},28,⟨51377617135,235296206135⟩⟩,
  ⟨{{0,1,2}, {3,9}, {4,7}, {5}, {6,8}},19,⟨24482354895,234181164095⟩⟩,
  ⟨{{0,9}, {1}, {2,3,7}, {4}, {5}, {6,8}},16,⟨75573575445,240971336845⟩⟩
]

theorem checked11_2_82 : ∃ cert, Checked (rows10_1 82) rows11_2 2 cert :=
  ⟨routes11_2_82, by decide +kernel⟩

private def routes11_2_83 : List (Branch 10 54) := [
  
]

theorem checked11_2_83 : ∃ cert, Checked (rows10_1 83) rows11_2 2 cert :=
  ⟨routes11_2_83, by decide +kernel⟩

end Cover61.Layers
