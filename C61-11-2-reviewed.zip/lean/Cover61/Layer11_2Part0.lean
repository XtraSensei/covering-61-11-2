import Cover61.LayerData

namespace Cover61.Layers

open Skeleton Growth

set_option maxRecDepth 100000

set_option maxHeartbeats 4000000

private def routes11_2_0 : List (Branch 10 54) := [
  ⟨{{0,5}, {1,7}, {2,3}, {4,6,8}, {9}},0,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,6}, {1,4}, {2,3}, {5,7,8}, {9}},0,⟨282440691875,282440691875⟩⟩
]

theorem checked11_2_0 : ∃ cert, Checked (rows10_1 0) rows11_2 2 cert :=
  ⟨routes11_2_0, by decide +kernel⟩

private def routes11_2_1 : List (Branch 10 54) := [
  ⟨{{0,5}, {1,7}, {2,3}, {4,6,8}, {9}},1,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,6}, {1,8}, {2,4}, {3,5,7}, {9}},2,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,7}, {1,3}, {2,5}, {4,6,8}, {9}},2,⟨281798231385,281798231385⟩⟩,
  ⟨{{0,8}, {1,4}, {2,6}, {3,5,7}, {9}},1,⟨281798231385,281798231385⟩⟩
]

theorem checked11_2_1 : ∃ cert, Checked (rows10_1 1) rows11_2 2 cert :=
  ⟨routes11_2_1, by decide +kernel⟩

private def routes11_2_2 : List (Branch 10 54) := [
  ⟨{{0,3,4}, {1,6}, {2,7}, {5,8}, {9}},3,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,3,4}, {1,8}, {2,5}, {6,7}, {9}},3,⟨281994713715,281994713715⟩⟩
]

theorem checked11_2_2 : ∃ cert, Checked (rows10_1 2) rows11_2 2 cert :=
  ⟨routes11_2_2, by decide +kernel⟩

private def routes11_2_3 : List (Branch 10 54) := [
  
]

theorem checked11_2_3 : ∃ cert, Checked (rows10_1 3) rows11_2 2 cert :=
  ⟨routes11_2_3, by decide +kernel⟩

private def routes11_2_4 : List (Branch 10 54) := [
  
]

theorem checked11_2_4 : ∃ cert, Checked (rows10_1 4) rows11_2 2 cert :=
  ⟨routes11_2_4, by decide +kernel⟩

private def routes11_2_5 : List (Branch 10 54) := [
  
]

theorem checked11_2_5 : ∃ cert, Checked (rows10_1 5) rows11_2 2 cert :=
  ⟨routes11_2_5, by decide +kernel⟩

private def routes11_2_6 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,6,8}, {3,7}, {4,5}, {9}},3,⟨258879076995,258879076995⟩⟩
]

theorem checked11_2_6 : ∃ cert, Checked (rows10_1 6) rows11_2 2 cert :=
  ⟨routes11_2_6, by decide +kernel⟩

private def routes11_2_7 : List (Branch 10 54) := [
  
]

theorem checked11_2_7 : ∃ cert, Checked (rows10_1 7) rows11_2 2 cert :=
  ⟨routes11_2_7, by decide +kernel⟩

private def routes11_2_8 : List (Branch 10 54) := [
  ⟨{{0,5,6}, {1,8}, {2,4}, {3,7}, {9}},4,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,5,6}, {1,9}, {2,7}, {3}, {4,8}},4,⟨266897170865,266897170865⟩⟩,
  ⟨{{0,8}, {1,4,7}, {2,5}, {3,6}, {9}},4,⟨282440691875,282440691875⟩⟩,
  ⟨{{0,9}, {1,4,7}, {2,6}, {3}, {5,8}},4,⟨266879308835,266879308835⟩⟩
]

theorem checked11_2_8 : ∃ cert, Checked (rows10_1 8) rows11_2 2 cert :=
  ⟨routes11_2_8, by decide +kernel⟩

private def routes11_2_9 : List (Branch 10 54) := [
  
]

theorem checked11_2_9 : ∃ cert, Checked (rows10_1 9) rows11_2 2 cert :=
  ⟨routes11_2_9, by decide +kernel⟩

private def routes11_2_10 : List (Branch 10 54) := [
  ⟨{{0}, {1}, {2,3,8}, {4,6}, {5,7}, {9}},4,⟨258879076995,258879076995⟩⟩,
  ⟨{{0}, {1,4,7}, {2,6}, {3}, {5,8}, {9}},4,⟨258684173605,258684173605⟩⟩,
  ⟨{{0,7}, {1,6}, {2,3,8}, {4,5}, {9}},5,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,4,7}, {2,5}, {3,6}, {9}},5,⟨282263650515,282263650515⟩⟩
]

theorem checked11_2_10 : ∃ cert, Checked (rows10_1 10) rows11_2 2 cert :=
  ⟨routes11_2_10, by decide +kernel⟩

private def routes11_2_11 : List (Branch 10 54) := [
  ⟨{{0,1,2}, {3,7}, {4,6}, {5,8}, {9}},6,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,1,2}, {3,8}, {4,6}, {5,7}, {9}},7,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,3,4}, {1,6}, {2,7}, {5,8}, {9}},8,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,3,4}, {1,8}, {2,6}, {5,7}, {9}},9,⟨282458553905,282458553905⟩⟩,
  ⟨{{0,8}, {1,3,5}, {2,7}, {4,6}, {9}},10,⟨282458553905,282458553905⟩⟩
]

theorem checked11_2_11 : ∃ cert, Checked (rows10_1 11) rows11_2 2 cert :=
  ⟨routes11_2_11, by decide +kernel⟩

theorem balanced11_2_0 : Balanced (rows11_2 0) := by decide +kernel

theorem balanced11_2_1 : Balanced (rows11_2 1) := by decide +kernel

theorem balanced11_2_2 : Balanced (rows11_2 2) := by decide +kernel

theorem balanced11_2_3 : Balanced (rows11_2 3) := by decide +kernel

theorem balanced11_2_4 : Balanced (rows11_2 4) := by decide +kernel

theorem balanced11_2_5 : Balanced (rows11_2 5) := by decide +kernel

theorem balanced11_2_6 : Balanced (rows11_2 6) := by decide +kernel

theorem balanced11_2_7 : Balanced (rows11_2 7) := by decide +kernel

theorem balanced11_2_8 : Balanced (rows11_2 8) := by decide +kernel

theorem balanced11_2_9 : Balanced (rows11_2 9) := by decide +kernel

theorem balanced11_2_10 : Balanced (rows11_2 10) := by decide +kernel

theorem balanced11_2_11 : Balanced (rows11_2 11) := by decide +kernel

end Cover61.Layers
