import Cover61.NineData

namespace Cover61.Nine

set_option maxHeartbeats 4000000

set_option maxRecDepth 50000

theorem ext108 : ∀ t, GoodStep 108 t := by decide +kernel

theorem ext109 : ∀ t, GoodStep 109 t := by decide +kernel

theorem ext110 : ∀ t, GoodStep 110 t := by decide +kernel

theorem ext111 : ∀ t, GoodStep 111 t := by decide +kernel

theorem ext112 : ∀ t, GoodStep 112 t := by decide +kernel

theorem ext113 : ∀ t, GoodStep 113 t := by decide +kernel

theorem ext114 : ∀ t, GoodStep 114 t := by decide +kernel

theorem ext115 : ∀ t, GoodStep 115 t := by decide +kernel

theorem ext116 : ∀ t, GoodStep 116 t := by decide +kernel

theorem ext117 : ∀ t, GoodStep 117 t := by decide +kernel

theorem ext118 : ∀ t, GoodStep 118 t := by decide +kernel

theorem ext119 : ∀ t, GoodStep 119 t := by decide +kernel

end Cover61.Nine
