import Cover61.Cuts

namespace Cover61.Cuts

theorem integer_consecutive (z k : Int) : 0≤(z-k)*(z-k-1) := by
  by_cases le : z≤k
  · apply Int.mul_nonneg_of_nonpos_of_nonpos <;> omega
  · apply Int.mul_nonneg <;> omega

def cutValue (x : Int) := x*(11-x)

theorem balanced_sum {α : Type} [DecidableEq α] (J : Finset α) (w : α→Int) (q s : Int)
    (mass : ∑ j ∈ J,w j=(J.card:Int)*q+s) :
    ∑ j ∈ J,cutValue (w j)≤((J.card:Int)-s)*cutValue q+s*cutValue (q+1) := by
  have row (j : α) (_ : j ∈ J) : cutValue (w j)≤(10-2*q)*w j+q*(q+1) := by
    have eq : cutValue (w j)+(w j-q)*(w j-q-1)=(10-2*q)*w j+q*(q+1) := by
      unfold cutValue;grind only
    have pos := integer_consecutive (w j) q
    omega
  have sum := Finset.sum_le_sum row
  rw [Finset.sum_add_distrib,←Finset.mul_sum,mass,Finset.sum_const] at sum
  exact sum.trans_eq (by simp only [nsmul_eq_mul,cutValue];grind only)

theorem balanced_capacity {b : Nat} (B : Family b) (h : ∀ j,(B j).card=11)
    (J : Finset (Fin b)) (X : Finset Point) (M : Finset (Point × Point))
    (cross : ∀ t ∈ M,t.1 ∈ X ∧ t.2 ∉ X) (cover : ∀ t ∈ M,∃ j ∈ J,t.1 ∈ B j ∧ t.2 ∈ B j)
    (q s : Int) (mass : ∑ j ∈ J,((B j ∩ X).card:Int)=(J.card:Int)*q+s) :
    (M.card:Int)≤((J.card:Int)-s)*cutValue q+s*cutValue (q+1) := by
  have cap := capacity B h J X M cross cover
  have row (j : Fin b) : ((((B j ∩ X).card*(11-(B j ∩ X).card):Nat):Int))=cutValue (B j ∩ X).card := by
    have sub := Finset.card_le_card (Finset.inter_subset_left (s₁ := B j) (s₂ := X))
    rw [h] at sub
    simp [cutValue,Nat.cast_sub sub]
  have bound : (M.card:Int)≤∑ j ∈ J,cutValue (B j ∩ X).card := by
    have eq := Int.ofNat_le.mpr cap
    simpa only [Nat.cast_sum,row] using eq
  exact bound.trans (balanced_sum J _ q s mass)

/-- If the new blocks all contain x and one already belongs to P, each
additional block contributes at most ten previously unseen people. -/
theorem attached_blocks {b : Nat} (B : Family b) (h : ∀ j,(B j).card=11)
    (P Q : Finset (Fin b)) (x : Point) (all : ∀ j ∈ Q,x ∈ B j) (touch : (P ∩ Q).Nonempty) :
    ((P ∪ Q).biUnion B).card≤(P.biUnion B).card+10*(Q.card-1) := by
  obtain ⟨j,hj⟩ := touch
  obtain ⟨jp,jq⟩ := Finset.mem_inter.mp hj
  have seen : x ∈ P.biUnion B := Finset.mem_biUnion.mpr ⟨j,jp,all j jq⟩
  let T := Q \ P
  have sub : (P ∪ Q).biUnion B ⊆ P.biUnion B ∪ T.biUnion (fun t => (B t).erase x) := by
    intro y hy
    obtain ⟨k,kk,ky⟩ := Finset.mem_biUnion.mp hy
    by_cases kp : k ∈ P
    · exact Finset.mem_union_left _ (Finset.mem_biUnion.mpr ⟨k,kp,ky⟩)
    · have kq := (Finset.mem_union.mp kk).resolve_left kp
      by_cases eq : y=x
      · exact Finset.mem_union_left _ (eq ▸ seen)
      · exact Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨k,Finset.mem_sdiff.mpr ⟨kq,kp⟩,Finset.mem_erase.mpr ⟨eq,ky⟩⟩)
  have size (t : Fin b) (ht : t ∈ T) : ((B t).erase x).card=10 := by
    rw [Finset.card_erase_of_mem (all t (Finset.mem_sdiff.mp ht).1),h]
  have rem := Finset.card_biUnion_le (s := T) (t := fun t => (B t).erase x)
  rw [Finset.sum_congr rfl size] at rem;simp at rem
  have inc : T ⊆ Q.erase j := fun t ht => Finset.mem_erase.mpr
    ⟨fun eq => (Finset.mem_sdiff.mp ht).2 (eq ▸ jp),(Finset.mem_sdiff.mp ht).1⟩
  have small := Finset.card_le_card inc;rw [Finset.card_erase_of_mem jq] at small
  have bound := (Finset.card_le_card sub).trans (Finset.card_union_le _ _)
  omega

end Cover61.Cuts
