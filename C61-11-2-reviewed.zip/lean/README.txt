C(61,11,2) 的 Lean 工程

Lean 4.36.0，Mathlib v4.36.0。lake-manifest.json 固定依赖的 Git 修订号。初次配置需取得 Mathlib 缓存。独立机器的工程根目录下可运行

    lake exe cache get
    lake build
    lake env lean Audit.lean

本研究工作区的 Windows 构建使用受限入口。首条命令按依赖顺序逐个构建本项目模块，最后执行完整构建和审计。只需复核一个源文件时可用第二条。

    python -B work/serial_lean.py
    python -B work/lean_task.py check Audit.lean

上界与低点骨架

Cover61.exists39 是 39 块覆盖的存在性定理。Cover61.cover_catalogue 由 38 块覆盖的定义推出，它的低点骨架属于九点 50 个、十点 65 个、十一点 36 个或十二点 64 个代表。十二点按四低点块数分为 22、23、19 个。Cover61.Affine.excluded 与 Catalog.s9_49_excluded 从仿射骨架的实际出席推出矛盾。

四低点块的整数界

FourView 与 FourColors 从实际块族导出出现次数、重复预算、互补对容量和整数价格。FourRules 证明每一行的来源，LinearBox 验证整数线性组合。FourCase0 至 FourCase4 用同一个核验器处理 567 个直方图。FourCosts 把这些结论送回实际覆盖。Thirteen 与 StructuralCover 给出在全局块宽至多四时的十二低点上界，Layers.twelve_has_quad 通过先加后删一个标签的分类证明十二低点必有四低点块。

五低点块与拉丁方

FiveGrid、PhysicalGrid 把假设覆盖中的二十五个块作成格子，证实可以使用约化五阶拉丁方调查。ThreeGroups、FourGroups、FiveBoundary 排除了整组块数量为三、四、五的全部情形。PartI 中 no_five_low_points 与 low_count_range 的前提只有 IsCover B。Profiles 推出五种可能的次数表及八次点在所有四低点块中的位置。

价格、目录与边界

105 个缺少所需分割的骨架和 64 个违反座位价格的骨架有逐项内核证明。九点第 49 号由仿射平面论证排除。Cover61.cover_remaining 将这 170 个排除接回覆盖条件，Cover61.remaining_count 给出剩余 45 个表的总数。catalog-status.txt 列出目录对应关系。Prices.sound 与 Replay.sound 给出一般整数分离证明；Population.sound 涵盖带区间收紧、逐值分支及完整人数分配的证明树。Supports.Nine37.exhaustive 证明给定的 121 个集合覆盖九点第 37 号互斥图的所有可行支持。

Audit.lean 列出接受公理检查的声明。完整的 251 项外部计算证明另附于评审包。任意 38 块覆盖均不可能的顶层定理尚未导出。
